#import <Foundation/Foundation.h>
#import <Metal/Metal.h>

#include "metalrobo/MetalNumanXHumanIO.hpp"
#include "metalrobo/ArticulatedDynamics.hpp"
#include "metalrobo/NumiHumanInitialState.hpp"
#include "numi/matter/matter.hpp"
#include "metalrobo/NeuronCultureArtifacts.hpp"
#include "metalrobo/engine_types.h"
#include "metalrobo/mrnx_bridge_v1.h"
#include "metalrobo/numanx_human_matter_adapter_gpu.h"
#include "metalrobo/numanx_human_io_gpu.h"
#include "numi/matter/shared.h"

#include <array>
#include <algorithm>
#include <atomic>
#include <bit>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <iostream>
#include <filesystem>
#include <iterator>
#include <limits>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include <unistd.h>

#ifndef MRNX_FULLBODY_RIGID
#error MRNX_FULLBODY_RIGID is required
#endif
#ifndef MRNX_FULLBODY_MUSCLE
#error MRNX_FULLBODY_MUSCLE is required
#endif
#ifndef MRNX_FULLBODY_SUPPORT_CONTACT
#error MRNX_FULLBODY_SUPPORT_CONTACT is required
#endif
#ifndef MRNX_METALROBO_METALLIB
#error MRNX_METALROBO_METALLIB is required
#endif
#ifndef MRNX_MATTER_METALLIB
#error MRNX_MATTER_METALLIB is required
#endif
#ifndef MRNX_MATTER_MATERIAL
#error MRNX_MATTER_MATERIAL is required
#endif

namespace {

constexpr std::uint64_t kFnvOffset = 14695981039346656037ull;
constexpr std::uint64_t kFnvPrime = 1099511628211ull;
std::uint64_t equalityFingerprint(const std::vector<std::uint8_t>& bytes) {
    std::uint64_t hash=kFnvOffset;
    for (const auto byte : bytes) { hash ^= byte; hash *= kFnvPrime; }
    return hash;
}

std::uint64_t constrainedFingerprint(std::uint64_t base, const std::vector<std::uint8_t>& bytes) {
    base ^= equalityFingerprint({'N','H','E','Q','2'});
    base *= kFnvPrime;
    base ^= equalityFingerprint(bytes);
    base *= kFnvPrime;
    return base == 0u ? kFnvOffset : base;
}

constexpr std::uint64_t kStartMicros = 1'000u;
constexpr std::uint64_t kDurationMicros = 2'000u;

void require(const bool condition, const char* message) {
    if (!condition) throw std::runtime_error(message);
}

void mixU32(std::uint64_t& hash, const std::uint32_t value) noexcept {
    for (std::uint32_t byte = 0u; byte < 4u; ++byte) {
        hash ^= (value >> (byte * 8u)) & 0xffu;
        hash *= kFnvPrime;
    }
}

void mixU64(std::uint64_t& hash, const std::uint64_t value) noexcept {
    for (std::uint32_t byte = 0u; byte < 8u; ++byte) {
        hash ^= (value >> (byte * 8u)) & 0xffu;
        hash *= kFnvPrime;
    }
}

void mixFloat(std::uint64_t& hash, const float value) noexcept {
    mixU32(hash, std::bit_cast<std::uint32_t>(value));
}

std::vector<std::uint8_t> readPayloadBytes(const char* path) {
    std::ifstream input(path, std::ios::binary);
    require(input.is_open(), "provenance payload did not open");
    std::vector<std::uint8_t> bytes{
        std::istreambuf_iterator<char>(input),
        std::istreambuf_iterator<char>()};
    require(!bytes.empty() && !input.bad(),
            "provenance payload did not read exactly");
    return bytes;
}

void qualifyHumanSupportKKT(id<MTLDevice> device, unsigned shape = 0) {
    NSError* libraryError = nil;
    id<MTLLibrary> library = [device
        newLibraryWithURL:[NSURL fileURLWithPath:
            [NSString stringWithUTF8String:MRNX_MATTER_METALLIB]]
                       error:&libraryError];
    require(library != nil, "Matter support qualification library failed");
    const auto pipeline = [&](NSString* name) {
        id<MTLFunction> function = [library newFunctionWithName:
            [@"numi_matter_metal::" stringByAppendingString:name]];
        NSError* error = nil;
        id<MTLComputePipelineState> result = function == nil ? nil :
            [device newComputePipelineStateWithFunction:function error:&error];
        require(result != nil, "Matter support qualification pipeline failed");
        return result;
    };
    id<MTLComputePipelineState> checkpointPipeline =
        pipeline(@"nm_human_support_checkpoint");
    id<MTLComputePipelineState> evaluatePipeline =
        pipeline(@"nm_human_support_evaluate");
    id<MTLComputePipelineState> residualPipeline =
        pipeline(@"nm_human_support_accumulate_rigid_residual");
    id<MTLComputePipelineState> operatorPipeline =
        pipeline(@"nm_fgmres_apply_human_support");
    auto dualPipeline = pipeline(@"nm_fgmres_apply_support_dual");
    id<MTLComputePipelineState> commitPipeline =
        pipeline(@"nm_human_support_commit");
    id<MTLComputePipelineState> rollbackPipeline =
        pipeline(@"nm_human_support_rollback");

    NMMatterDispatchGPU dispatch{};
    dispatch.environmentCount = 1u;
    dispatch.objectCount = 1u;
    dispatch.rigidGeneralizedCapacity = 1u;
    const NMFGMRESLayoutGPU layout{1,1,2,0};
    NMHumanSupportDispatchGPU support{};
    support.contactCount = 1u;
    support.articulatedNv = 1u;
    support.bodyCount = 1u;
    support.bodyStride = 1u;
    support.groundPointAndTimestep.w = 0.01f;
    support.groundNormal.y = 1.0f;
    NMHumanSupportContactGPU contact{};
    contact.identity = {0u, 7u, 0u, 0u};
    contact.localPoint.y = -0.01f;
    contact.frictionSlopAndStabilization = {0.5f, 0.02f, 0.2f, 0.0f};
    MRBodyStateGPU body{};
    body.orientation.w = 1.0f;
    body.linearVelocityAndInverseMass.y = -1.0f;
    if (shape) {
        contact.identity.w = 1u;
        contact.localPoint = {0.0f,0.0f,0.0f,0.01f};
        body.orientation = {0.0f,0.0f,std::sqrt(0.5f),std::sqrt(0.5f)};
        body.angularVelocity.z = 2.0f;
        if (shape==2) {
            contact.identity.w=2u;contact.localPoint.w=0;
            contact.supportRadii={0.02f,0.01f,0.03f,0};
            contact.supportOrientation={0,0,std::sqrt(0.5f),std::sqrt(0.5f)};
        }
    }
    // The delta alone is deliberately different from the total velocity.
    // Support must include the free predictor carried by candidateBodies.
    const float generalized = -0.25f;
    // The scalar test coordinate has the explicitly supplied point tangent.
    // Shape geometry and source-compiled curved Jacobians are also covered by
    // the full-body primitive oracle; this test isolates NCP linearization.
    const std::array<float, 3u> jacobian{shape ? -0.02f : 0.0f, 1.0f, 0.0f};
    const float freeVelocity = -0.75f;
    const nm_float4 zero4{};
    const NMMatterStatusGPU success{};
    NMMatterStatusGPU failure{};
    failure.code = NM_STATUS_CONTACT_FAILURE;
    NMFGMRESStateGPU fgmres{};
    nm_float4 direction{};
    direction.x = 2.0f;
    const std::array<nm_float4,2> directionRows{direction,{0.4f,0.3f,0.2f,0}};
    const std::array<nm_float4,2> zeroRows{};
    const NMHumanSupportKKTGPU zeroKKT{};

    const auto buffer = [&](const void* bytes, const NSUInteger length) {
        id<MTLBuffer> result = [device newBufferWithBytes:bytes length:length
            options:MTLResourceStorageModeShared];
        require(result != nil, "Matter support qualification buffer failed");
        return result;
    };
    id<MTLBuffer> contacts = buffer(&contact, sizeof(contact));
    id<MTLBuffer> bodies = buffer(&body, sizeof(body));
    id<MTLBuffer> generalizedBuffer = buffer(&generalized, sizeof(generalized));
    id<MTLBuffer> jacobians = buffer(jacobian.data(), sizeof(jacobian));
    const nm_float4 initialHistory{shape==2 ? 0.5f : 0.0f, 0.0f, 0.0f, 0.5f};
    id<MTLBuffer> acceptedHistory = buffer(&initialHistory, sizeof(initialHistory));
    id<MTLBuffer> candidateHistory = buffer(&zero4, sizeof(zero4));
    id<MTLBuffer> checkpointHistory = buffer(&zero4, sizeof(zero4));
    const NMHumanSupportConsequenceGPU zeroConsequence{};
    id<MTLBuffer> acceptedConsequence =
        buffer(&zeroConsequence, sizeof(zeroConsequence));
    id<MTLBuffer> candidateConsequence =
        buffer(&zeroConsequence, sizeof(zeroConsequence));
    id<MTLBuffer> checkpointConsequence =
        buffer(&zeroConsequence, sizeof(zeroConsequence));
    const NMContactSampleGPU zeroSample{};
    id<MTLBuffer> samples = buffer(&zeroSample, sizeof(zeroSample));
    id<MTLBuffer> successStatus = buffer(&success, sizeof(success));
    id<MTLBuffer> failureStatus = buffer(&failure, sizeof(failure));
    id<MTLBuffer> residual = buffer(zeroRows.data(), sizeof(zeroRows));
    id<MTLBuffer> kkt = buffer(&zeroKKT,sizeof(zeroKKT));
    id<MTLBuffer> freeBuffer = buffer(&freeVelocity,sizeof(freeVelocity));
    id<MTLBuffer> directionBuffer = buffer(directionRows.data(), sizeof(directionRows));
    id<MTLBuffer> work = buffer(zeroRows.data(), sizeof(zeroRows));
    id<MTLBuffer> fgmresState = buffer(&fgmres, sizeof(fgmres));
    id<MTLBuffer> committedHistory = buffer(&zero4, sizeof(zero4));
    id<MTLBuffer> committedConsequence =
        buffer(&zeroConsequence, sizeof(zeroConsequence));

    id<MTLCommandQueue> queue = [device newCommandQueue];
    id<MTLCommandBuffer> command = [queue commandBuffer];
    require(queue != nil && command != nil,
            "Matter support qualification command failed");
    const auto encodeOne = [&](id<MTLComputePipelineState> state,
                               const auto& bind) {
        id<MTLComputeCommandEncoder> encoder =
            [command computeCommandEncoder];
        require(encoder != nil, "Matter support qualification encoder failed");
        [encoder setComputePipelineState:state];
        bind(encoder);
        [encoder setBytes:&layout length:sizeof(layout) atIndex:30u];
        [encoder dispatchThreads:MTLSizeMake(1u, 1u, 1u)
            threadsPerThreadgroup:MTLSizeMake(1u, 1u, 1u)];
        [encoder endEncoding];
    };
    const std::uint32_t count = 1u;
    encodeOne(checkpointPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&count length:sizeof(count) atIndex:1u];
        [encoder setBuffer:acceptedHistory offset:0u atIndex:2u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:3u];
        [encoder setBuffer:checkpointHistory offset:0u atIndex:4u];
        [encoder setBuffer:acceptedConsequence offset:0u atIndex:5u];
        [encoder setBuffer:candidateConsequence offset:0u atIndex:6u];
        [encoder setBuffer:checkpointConsequence offset:0u atIndex:7u];
    });
    encodeOne(evaluatePipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:contacts offset:0u atIndex:2u];
        [encoder setBuffer:bodies offset:0u atIndex:3u];
        [encoder setBuffer:generalizedBuffer offset:0u atIndex:4u];
        [encoder setBuffer:jacobians offset:0u atIndex:5u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:7u];
        [encoder setBuffer:samples offset:0u atIndex:8u];
        [encoder setBuffer:candidateConsequence offset:0u atIndex:9u];
        [encoder setBuffer:successStatus offset:0u atIndex:10u];
        [encoder setBuffer:bodies offset:0u atIndex:11u];
        [encoder setBuffer:kkt offset:0u atIndex:12u];
        [encoder setBuffer:residual offset:0u atIndex:13u];
        [encoder setBuffer:freeBuffer offset:0u atIndex:14u];
    });
    encodeOne(residualPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:samples offset:0u atIndex:2u];
        [encoder setBuffer:jacobians offset:0u atIndex:3u];
        [encoder setBuffer:residual offset:0u atIndex:4u];
    });
    encodeOne(operatorPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:directionBuffer offset:0u atIndex:2u];
        [encoder setBuffer:work offset:0u atIndex:3u];
        [encoder setBuffer:samples offset:0u atIndex:4u];
        [encoder setBuffer:jacobians offset:0u atIndex:5u];
        [encoder setBuffer:fgmresState offset:0u atIndex:6u];
    });
    encodeOne(dualPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:directionBuffer offset:0u atIndex:2u];
        [encoder setBuffer:work offset:0u atIndex:3u];
        [encoder setBuffer:kkt offset:0u atIndex:4u];
        [encoder setBuffer:jacobians offset:0u atIndex:5u];
        [encoder setBuffer:fgmresState offset:0u atIndex:6u];
    });
    const nm_float4 alpha{0.25f,0,0,0};
    auto alphaBuffer = buffer(&alpha,sizeof(alpha));
    encodeOne(pipeline(@"nm_human_support_apply_solution"), [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:directionBuffer offset:0u atIndex:2u];
        [encoder setBuffer:alphaBuffer offset:0u atIndex:3u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:4u];
    });
    encodeOne(evaluatePipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&support length:sizeof(support) atIndex:1u];
        [encoder setBuffer:contacts offset:0u atIndex:2u];
        [encoder setBuffer:bodies offset:0u atIndex:3u];
        [encoder setBuffer:generalizedBuffer offset:0u atIndex:4u];
        [encoder setBuffer:jacobians offset:0u atIndex:5u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:7u];
        [encoder setBuffer:samples offset:0u atIndex:8u];
        [encoder setBuffer:candidateConsequence offset:0u atIndex:9u];
        [encoder setBuffer:successStatus offset:0u atIndex:10u];
        [encoder setBuffer:bodies offset:0u atIndex:11u];
        [encoder setBuffer:kkt offset:0u atIndex:12u];
        [encoder setBuffer:residual offset:0u atIndex:13u];
        [encoder setBuffer:freeBuffer offset:0u atIndex:14u];
    });
    encodeOne(commitPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&count length:sizeof(count) atIndex:1u];
        [encoder setBuffer:successStatus offset:0u atIndex:2u];
        [encoder setBuffer:acceptedHistory offset:0u atIndex:3u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:4u];
        [encoder setBuffer:acceptedConsequence offset:0u atIndex:5u];
        [encoder setBuffer:candidateConsequence offset:0u atIndex:6u];
    });
    id<MTLBlitCommandEncoder> snapshot = [command blitCommandEncoder];
    require(snapshot != nil, "Matter support qualification snapshot failed");
    [snapshot copyFromBuffer:acceptedHistory sourceOffset:0u
        toBuffer:committedHistory destinationOffset:0u size:sizeof(nm_float4)];
    [snapshot copyFromBuffer:acceptedConsequence sourceOffset:0u
        toBuffer:committedConsequence destinationOffset:0u
        size:sizeof(NMHumanSupportConsequenceGPU)];
    [snapshot endEncoding];
    encodeOne(rollbackPipeline, [&](id<MTLComputeCommandEncoder> encoder) {
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
        [encoder setBytes:&count length:sizeof(count) atIndex:1u];
        [encoder setBuffer:failureStatus offset:0u atIndex:2u];
        [encoder setBuffer:acceptedHistory offset:0u atIndex:3u];
        [encoder setBuffer:candidateHistory offset:0u atIndex:4u];
        [encoder setBuffer:checkpointHistory offset:0u atIndex:5u];
        [encoder setBuffer:acceptedConsequence offset:0u atIndex:6u];
        [encoder setBuffer:candidateConsequence offset:0u atIndex:7u];
        [encoder setBuffer:checkpointConsequence offset:0u atIndex:8u];
    });
    // Central differences of the assembled dual residual perturb both
    // velocity/position and independent impulse. Initial gap remains frozen.
    // No finite-difference helper uses the stored projection derivative.
    constexpr float epsilon = 1.0e-3f;
    const auto perturbSupport = [&](const float sign) {
        MRBodyStateGPU perturbed = body;
        perturbed.position.y += sign * epsilon * direction.x *
            support.groundPointAndTimestep.w;
        perturbed.linearVelocityAndInverseMass.y += sign * epsilon * direction.x;
        id<MTLBuffer> perturbedBodies = buffer(&perturbed, sizeof(perturbed));
        perturbed.position.x += sign * epsilon * direction.x *
            jacobian[0] * support.groundPointAndTimestep.w;
        // Refresh after completing the candidate geometry perturbation.
        perturbedBodies = buffer(&perturbed, sizeof(perturbed));
        const float perturbedGeneralized = generalized + sign * epsilon * direction.x;
        auto perturbedGeneralizedBuffer = buffer(&perturbedGeneralized,sizeof(perturbedGeneralized));
        const nm_float4 perturbedHistory{initialHistory.x+sign*epsilon*directionRows[1].x,0,
            sign*epsilon*directionRows[1].z,
            initialHistory.w+sign*epsilon*directionRows[1].y};
        id<MTLBuffer> historyOut = buffer(&perturbedHistory, sizeof(perturbedHistory));
        auto kktOut = buffer(&zeroKKT,sizeof(zeroKKT));
        auto residualOut = buffer(zeroRows.data(),sizeof(zeroRows));
        id<MTLBuffer> sampleOut = buffer(&zeroSample, sizeof(zeroSample));
        id<MTLBuffer> consequenceOut = buffer(&zeroConsequence, sizeof(zeroConsequence));
        encodeOne(evaluatePipeline, [&](id<MTLComputeCommandEncoder> encoder) {
            [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:0u];
            [encoder setBytes:&support length:sizeof(support) atIndex:1u];
            [encoder setBuffer:contacts offset:0u atIndex:2u];
            [encoder setBuffer:perturbedBodies offset:0u atIndex:3u];
            [encoder setBuffer:perturbedGeneralizedBuffer offset:0u atIndex:4u];
            [encoder setBuffer:jacobians offset:0u atIndex:5u];
            [encoder setBuffer:historyOut offset:0u atIndex:7u];
            [encoder setBuffer:sampleOut offset:0u atIndex:8u];
            [encoder setBuffer:consequenceOut offset:0u atIndex:9u];
            [encoder setBuffer:successStatus offset:0u atIndex:10u];
            [encoder setBuffer:bodies offset:0u atIndex:11u];
            [encoder setBuffer:kktOut offset:0u atIndex:12u];
            [encoder setBuffer:residualOut offset:0u atIndex:13u];
            [encoder setBuffer:freeBuffer offset:0u atIndex:14u];
        });
        return kktOut;
    };
    id<MTLBuffer> plusSample = perturbSupport(1.0f);
    id<MTLBuffer> minusSample = perturbSupport(-1.0f);
    [command commit];
    [command waitUntilCompleted];
    require(command.status == MTLCommandBufferStatusCompleted,
            "Matter support qualification GPU command failed");

    const auto& committed =
        *static_cast<const NMHumanSupportConsequenceGPU*>(
            committedConsequence.contents);
    const auto& history =
        *static_cast<const nm_float4*>(committedHistory.contents);
    const auto& residualValue =
        *static_cast<const nm_float4*>(residual.contents);
    const auto& operatorValue =
        *static_cast<const nm_float4*>(work.contents);
    const auto& rolledHistory =
        *static_cast<const nm_float4*>(acceptedHistory.contents);
    const auto& rolledConsequence =
        *static_cast<const NMHumanSupportConsequenceGPU*>(
            acceptedConsequence.contents);
    require(committed.identity.x == 0u && committed.identity.y == 7u &&
                committed.identity.w ==
                    NM_HUMAN_SUPPORT_CONSEQUENCE_VERSION &&
                (committed.identity.z & NM_CONTACT_VALID) != 0u &&
                std::abs(committed.impulseAndNormal.w - 0.575f) < 1.0e-5f &&
                history.w == committed.impulseAndNormal.w &&
                std::abs(residualValue.x-(0.5f+jacobian[0]*initialHistory.x))<1.0e-6f &&
                std::abs(operatorValue.x + jacobian[0]*directionRows[1].x +
                    directionRows[1].y)<1.0e-6f,
            "Matter support J^T lambda or independent dual action is wrong");
    if (shape) require(std::abs(committed.pointAndSeparation.y+0.01f)<1.0e-7f &&
        std::abs(committed.tangentVelocityAndImpulse.x-0.02f)<1.0e-6f &&
        std::abs(committed.impulseAndNormal.x-(initialHistory.x+0.1f))<1.0e-6f,
        "Matter sphere surface/friction moment arm is wrong");
    const auto plus = static_cast<const NMHumanSupportKKTGPU*>(plusSample.contents)->residual;
    const auto minus = static_cast<const NMHumanSupportKKTGPU*>(minusSample.contents)->residual;
    const auto dual = static_cast<const nm_float4*>(work.contents)[1];
    const float error = std::max({
        std::abs(dual.x+(plus.x-minus.x)/(2*epsilon)),
        std::abs(dual.y+(plus.y-minus.y)/(2*epsilon)),
        std::abs(dual.z+(plus.z-minus.z)/(2*epsilon))});
    require(error<3.0e-4f, "support NCP action disagrees with finite difference");
    std::cout << "SUPPORT shape=" << shape << " total_velocity=-1 delta_velocity=-0.25"
              << " dual_fd_error=" << error << '\n';
    require(rolledHistory.x == initialHistory.x && rolledHistory.y == 0.0f &&
                rolledHistory.z == 0.0f && rolledHistory.w == initialHistory.w &&
                rolledConsequence.identity.x == 0u &&
                rolledConsequence.identity.y == 0u &&
                rolledConsequence.identity.z == 0u &&
                rolledConsequence.identity.w == 0u,
            "Matter support checkpoint rollback did not restore exact bytes");
}

void mixBytes(
    std::uint64_t& hash,
    const void* raw,
    const std::size_t byteCount
) noexcept {
    const auto* bytes = static_cast<const std::uint8_t*>(raw);
    for (std::size_t index = 0u; index < byteCount; ++index) {
        hash ^= bytes[index];
        hash *= kFnvPrime;
    }
}

std::uint64_t fullBodySourceFingerprint(
    const std::vector<std::uint8_t>& rigid,
    const std::vector<std::uint8_t>& muscle,
    const std::vector<std::uint8_t>& support
) noexcept {
    constexpr char domain[] = "mrnx.fullbody.source.v1";
    std::uint64_t hash = kFnvOffset;
    mixBytes(hash, domain, sizeof(domain) - 1u);
    for (const auto* payload : {&rigid, &muscle, &support}) {
        mixU64(hash, static_cast<std::uint64_t>(payload->size()));
        mixBytes(hash, payload->data(), payload->size());
    }
    return hash == 0u ? kFnvOffset : hash;
}

std::uint64_t motorOutputFingerprint(
    const MRNumanXBrainMotorOutputHeaderGPU& header,
    const float* excitation
) noexcept {
    std::uint64_t hash = kFnvOffset;
    mixU32(hash, MR_NUMANX_BRAIN_MOTOR_OUTPUT_VERSION);
    mixU32(hash, header.formatVersion);
    mixU32(hash, header.flags);
    mixU64(hash, header.timestampMicroseconds);
    mixU64(hash, header.brainGeneration);
    mixU64(hash, header.profileFingerprint);
    mixU64(hash, header.protectiveCommandFingerprint);
    mixU32(hash, header.muscleCount);
    mixU32(hash, header.environmentIdentifier);
    mixFloat(hash, header.motorInhibition);
    mixFloat(hash, header.autonomicArousal);
    mixU32(hash, header.actuatorCommandKind);
    mixU32(hash, header.reserved);
    mixFloat(hash, header.outputMinimum);
    mixFloat(hash, header.outputMaximum);
    for (std::uint32_t index = 0u; index < header.muscleCount; ++index) {
        mixFloat(hash, excitation[index]);
    }
    return hash;
}

std::uint64_t readyGateFingerprint(
    const MRNumanXBrainMotorReadyGateGPU& gate
) noexcept {
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(&gate);
    std::uint64_t hash = kFnvOffset;
    for (std::size_t index = 0u; index < 152u; ++index) {
        hash ^= bytes[index];
        hash *= kFnvPrime;
    }
    return hash == 0u ? kFnvOffset : hash;
}

std::uint64_t timingFingerprint(
    const mrnx_candidate_timing_v1& timing
) noexcept {
    const auto* bytes = reinterpret_cast<const std::uint8_t*>(&timing);
    std::uint64_t hash = kFnvOffset;
    for (std::size_t index = 0u;
         index < offsetof(mrnx_candidate_timing_v1, timing_fingerprint);
         ++index) {
        hash ^= bytes[index];
        hash *= kFnvPrime;
    }
    return hash == 0u ? kFnvOffset : hash;
}

mrnx_metal_range_v1 range(
    id<MTLBuffer> buffer,
    const std::uint32_t elementType,
    const std::uint32_t elementBytes
) noexcept {
    mrnx_metal_range_v1 result{};
    result.abi_version = MRNX_BRIDGE_ABI_V1;
    result.struct_size = sizeof(result);
    result.metal_buffer = (__bridge void*)buffer;
    result.gpu_address = buffer.gpuAddress;
    result.byte_count = buffer.length;
    result.element_type = elementType;
    result.element_byte_count = elementBytes;
    return result;
}

struct Completion {
    std::atomic<std::uint32_t> count{0u};
    std::atomic<std::uint32_t> status{0u};
    mrnx_prepared_v1* prepared = nullptr;
    mrnx_candidate_v1* candidate = nullptr;
    mrnx_root_v1 root{};
};

void settled(
    void* raw,
    mrnx_prepared_v1* prepared,
    mrnx_candidate_v1* candidate,
    const mrnx_completion_v1* completion,
    const mrnx_root_v1* root
) {
    auto* capture = static_cast<Completion*>(raw);
    if (capture == nullptr || completion == nullptr) return;
    if (prepared != nullptr) mrnx_bridge_v1_prepared_retain(prepared);
    if (candidate != nullptr) mrnx_bridge_v1_candidate_retain(candidate);
    capture->prepared = prepared;
    capture->candidate = candidate;
    if (root != nullptr) capture->root = *root;
    capture->status.store(completion->status, std::memory_order_release);
    capture->count.fetch_add(1u, std::memory_order_acq_rel);
}

void waitForCompletion(Completion& completion, const unsigned timeoutSeconds=10u) {
    const auto deadline = std::chrono::steady_clock::now() +
        std::chrono::seconds(timeoutSeconds);
    while (completion.count.load(std::memory_order_acquire) == 0u &&
           std::chrono::steady_clock::now() < deadline) {
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    require(
        completion.count.load(std::memory_order_acquire) == 1u,
        "full-body root did not settle exactly once");
}

numi::matter::WorldSource authoredFixtureWorld(const std::vector<float>& preparedQ = {}) {
    // Decode only the existing rigid ABI needed by this qualification fixture.
    // Production asset parsing remains in the native runtime owner.
    std::ifstream input(MRNX_FULLBODY_RIGID, std::ios::binary);
    std::array<std::uint32_t, 20u> header{};
    input.read(reinterpret_cast<char*>(header.data()), sizeof(header));
    require(input.good() && header[5u] == 157u && header[7u] == 129u &&
                header[8u] == 128u, "unexpected full-body fixture header");
    auto read = [&]<typename T>(T& value) {
        input.read(reinterpret_cast<char*>(&value), sizeof(T));
        require(input.good(), "truncated rigid fixture");
    };
    metalrobo::EngineModel model;
    read(model.world);
    model.articulations.resize(1u);
    read(model.articulations[0u]);
    model.bodies.resize(header[5u]);
    model.joints.resize(header[6u]);
    model.dofs.resize(header[8u]);
    model.defaultQ.resize(header[7u]);
    model.defaultV.resize(header[8u]);
    for (auto& value : model.bodies) read(value);
    for (auto& value : model.joints) read(value);
    for (auto& value : model.dofs) read(value);
    for (auto& value : model.defaultQ) read(value);
    for (auto& value : model.defaultV) read(value);
    require(preparedQ.empty() || preparedQ.size() == model.defaultQ.size(), "prepared fixture pose dimensions");
    const auto& q = preparedQ.empty() ? model.defaultQ : preparedQ;
    std::vector<metalrobo::ArticulatedBodyKinematics> bodies(model.bodies.size());
    require(metalrobo::computeArticulatedBodyKinematics(model, 0u,
                std::vector<double>(q.begin(), q.end()),
                std::vector<double>(model.defaultV.begin(), model.defaultV.end()),
                bodies).succeeded(), "authored fixture kinematics failed");
    const auto material = numi::matter::parseMatterFile(MRNX_MATTER_MATERIAL);
    require(material.succeeded(), "authored fixture material failed");
    numi::matter::WorldSource world;
    world.frameTimestep = static_cast<double>(kDurationMicros) / 1'000'000.0;
    world.gravity = {model.world.gravityAndTimestep.x,
                     model.world.gravityAndTimestep.y,
                     model.world.gravityAndTimestep.z};
    world.articulatedDofCapacity = 160u;
    world.articulatedQCapacity = 161u;
    world.mixedSolver.newtonIterations = 16u;
    world.mixedSolver.relativeResidual = 5.0e-3;
    world.materials.push_back(material.material);
    // Three disjoint tiny samples exercise a package wider than the old
    // four-node constant and the ten support queries. No anatomical claim.
    for (std::uint32_t objectIndex = 0u; objectIndex < 3u; ++objectIndex) {
        numi::matter::ObjectSource object;
        object.name = "authored_fixture_" + std::to_string(objectIndex);
        object.representation = numi::matter::Representation::fem;
        object.mixedFEM = false;
        object.characteristicLength = 0.01;
        const std::array<std::array<double, 3u>, 4u> offsets{{
            {0.0, 0.0, 0.0}, {0.01, 0.0, 0.0},
            {0.0, 0.01, 0.0}, {0.0, 0.0, 0.01}}};
        const auto& body = bodies[0u];
        const auto& q = body.orientation;
        for (std::uint32_t node = 0u; node < 4u; ++node) {
            auto local = offsets[node];
            local[0] += 0.03 * objectIndex;
            const std::array<double, 3u> t{
                2.0 * (q[1] * local[2] - q[2] * local[1]),
                2.0 * (q[2] * local[0] - q[0] * local[2]),
                2.0 * (q[0] * local[1] - q[1] * local[0])};
            object.femNodes.push_back({
                body.centerOfMassPosition[0] + local[0] + q[3] * t[0] + q[1] * t[2] - q[2] * t[1],
                body.centerOfMassPosition[1] + local[1] + q[3] * t[1] + q[2] * t[0] - q[0] * t[2],
                body.centerOfMassPosition[2] + local[2] + q[3] * t[2] + q[0] * t[1] - q[1] * t[0]});
            numi::matter::FEMHumanAttachmentSource attachment;
            attachment.node = node;
            attachment.bodyIndex = 0u;
            attachment.stableIdentifier = 1000u + 4u * objectIndex + node;
            attachment.localPoint = local;
            object.femHumanAttachments.push_back(attachment);
        }
        object.tetrahedra.push_back({{0u, 1u, 2u, 3u}});
        world.objects.push_back(object);
    }
    return world;
}



void qualifyTouchAggregation(id<MTLDevice> device) {
    NSError* error=nil;
    id<MTLLibrary> library=[device newLibraryWithURL:[NSURL fileURLWithPath:@MRNX_METALROBO_METALLIB] error:&error];
    require(library!=nil,"touch aggregation library unavailable");
    id<MTLFunction> function=[library newFunctionWithName:@"numanx_human_aggregate_support"];
    require(function!=nil,"touch aggregation kernel missing");
    id<MTLComputePipelineState> pipeline=[device newComputePipelineStateWithFunction:function error:&error];
    require(pipeline!=nil,"touch aggregation pipeline failed");
    id<MTLCommandQueue> queue=[device newCommandQueue];
    std::vector<MRNumanXHumanSupportConsequenceGPU> rows(18u);
    std::vector<mr_uint4> mapping;
    unsigned first=0u;
    for(unsigned receptor=0;receptor<10;++receptor) {
        const unsigned count=receptor<8?2u:1u;
        mapping.push_back({first,count,100u+receptor,200u+receptor});
        for(unsigned j=0;j<count;++j) {
            const unsigned index=first+j;auto& r=rows[index];
            r.identity={index,200u+receptor,1u,MR_NUMANX_HUMAN_SUPPORT_CONSEQUENCE_VERSION};
            r.pointAndSeparation={float(index),0,0,-float(index)/100.0f};
            r.impulseAndNormal={0,0,float(index+1),float(index+1)};
            r.tangentVelocityAndImpulse={float(index),0,0,float(index+1)/4.0f};
        }
        first+=count;
    }
    id<MTLBuffer> input=[device newBufferWithBytes:rows.data() length:rows.size()*sizeof(rows[0]) options:MTLResourceStorageModeShared];
    id<MTLBuffer> map=[device newBufferWithBytes:mapping.data() length:mapping.size()*sizeof(mapping[0]) options:MTLResourceStorageModeShared];
    id<MTLBuffer> output=[device newBufferWithLength:10u*sizeof(rows[0]) options:MTLResourceStorageModeShared];
    require(input!=nil&&map!=nil&&output!=nil&&queue!=nil,"touch aggregation allocation failed");
    const auto run=[&]() {
        id<MTLCommandBuffer> command=[queue commandBuffer];
        id<MTLComputeCommandEncoder> encoder=[command computeCommandEncoder];
        [encoder setComputePipelineState:pipeline];
        [encoder setBuffer:input offset:0 atIndex:0];[encoder setBuffer:map offset:0 atIndex:1];
        [encoder setBuffer:output offset:0 atIndex:2];
        const mr_uint4 dispatch{18u,10u,0u,0u};
        [encoder setBytes:&dispatch length:sizeof(dispatch) atIndex:3];
        [encoder dispatchThreads:MTLSizeMake(10,1,1) threadsPerThreadgroup:MTLSizeMake(10,1,1)];
        [encoder endEncoding];[command commit];[command waitUntilCompleted];
        require(command.status==MTLCommandBufferStatusCompleted,"touch aggregation GPU failure");
        std::vector<MRNumanXHumanSupportConsequenceGPU> values(10u);
        std::memcpy(values.data(),output.contents,output.length);return values;
    };
    const auto result=run();
    double total=0,weighted=0,expectedTotal=0,expectedWeighted=0;
    for(const auto& row:rows) {expectedTotal+=row.impulseAndNormal.w;expectedWeighted+=row.pointAndSeparation.x*row.impulseAndNormal.w;}
    for(unsigned i=0;i<10;++i) {
        const auto& m=mapping[i];const auto& r=result[i];
        require(r.identity.x==i&&r.identity.y==m.w&&r.identity.w==1u,"touch geometry identity lost");
        float impulse=0,friction=0,minimum=INFINITY;
        for(unsigned j=m.x;j<m.x+m.y;++j) {impulse+=rows[j].impulseAndNormal.w;friction+=rows[j].tangentVelocityAndImpulse.w;minimum=std::min(minimum,rows[j].pointAndSeparation.w);}
        require(r.impulseAndNormal.w==impulse&&r.tangentVelocityAndImpulse.w==friction&&r.pointAndSeparation.w==minimum,"touch row load/gap aggregation changed");
        total+=r.impulseAndNormal.w;weighted+=double(r.pointAndSeparation.x)*r.impulseAndNormal.w;
    }
    require(total==expectedTotal&&std::abs(weighted-expectedWeighted)<1e-4,"touch total impulse or centre of pressure lost");
    const auto replay=run();require(std::memcmp(result.data(),replay.data(),10u*sizeof(rows[0]))==0,"touch aggregation replay drift");
    auto* raw=static_cast<MRNumanXHumanSupportConsequenceGPU*>(input.contents);
    for(unsigned mutation=0;mutation<4;++mutation) {
        std::memcpy(input.contents,rows.data(),input.length);
        if(mutation==0)raw[1].identity.y^=1u;
        if(mutation==1)raw[1].impulseAndNormal.w=-1;
        if(mutation==2)raw[1].pointAndSeparation.x=NAN;
        if(mutation==3)raw[1].identity.x=18u;
        const auto invalid=run();
        require(invalid[0].identity.w==0u&&invalid[1].identity.w==1u,"bad row did not invalidate only its receptor");
    }
    std::printf("numanx_touch_aggregation=pass rows=18 receptors=10 impulse=%.9g centre_of_pressure=conserved replay=bitwise malformed_rows=4\n",total);
}

// Qualification fixture only: import a saved native compiler state and cook
// the existing three tiny pelvis samples in that pose. No tissue registration,
// calibration or dynamics is performed by this construction helper.
int writePreparedStanceFixture(const char* certificate, const char* output,
    const char* contacts, const char* equalities, const char* limits,
    const std::uint64_t timestepMicroseconds = 100u, const bool importInitialState = false,
    const std::uint32_t newtonIterations = 16u) {
    @autoreleasepool {
        require(timestepMicroseconds > 0u && timestepMicroseconds <= 1'000'000u,
            "prepared fixture timestep outside (0, 1000000] microseconds");
        metalrobo::NumiHumanInitialState initial;
        if (importInitialState) {
            const auto rigid = readPayloadBytes(MRNX_FULLBODY_RIGID);
            require(rigid.size() >= 80u, "truncated source rigid fixture");
            std::array<std::uint8_t, 32u> sourceSHA{};
            std::copy_n(rigid.begin()+48u, 32u, sourceSHA.begin());
            const auto bytes = readPayloadBytes(certificate);
            std::string error;
            const bool decoded = metalrobo::decodeNumiHumanInitialState(
                {reinterpret_cast<const std::byte*>(bytes.data()), bytes.size()},
                MRNX_FULL_BODY_NQ, MRNX_FULL_BODY_NV, MRNX_FULL_BODY_MUSCLE_COUNT,
                sourceSHA, initial, error);
            require(decoded, error.c_str());
        } else {
        std::ifstream log(certificate);
        require(log.good(), "could not open native stance certificate");
        std::string line, qText, muscleText;
        unsigned qCount=0, muscleCount=0;
        while(std::getline(log,line)) {
            const std::string qPrefix="compiled_equilibrium_q=";
            const std::string musclePrefix="compiled_equilibrium_muscles=";
            if(line.starts_with(qPrefix)) {qText=line.substr(qPrefix.size());++qCount;}
            if(line.starts_with(musclePrefix)) {muscleText=line.substr(musclePrefix.size());++muscleCount;}
        }
        require(qCount==1 && muscleCount==1,"certificate state missing or duplicated");
        const auto parse=[](const std::string& text) -> id {
            NSData* data=[NSData dataWithBytes:text.data() length:text.size()];
            NSError* error=nil;
            id result=[NSJSONSerialization JSONObjectWithData:data options:0 error:&error];
            require(result!=nil && error==nil,"invalid native state JSON");return result;
        };
        id qJSON=parse(qText), muscleJSON=parse(muscleText);
        require([qJSON isKindOfClass:[NSArray class]] && [qJSON count]==MRNX_FULL_BODY_NQ &&
            [muscleJSON isKindOfClass:[NSDictionary class]] &&
            [muscleJSON[@"schema"] isEqual:@"numi.human.offline-muscle-state.v1"],"native state schema mismatch");
        NSArray* activation=muscleJSON[@"activation_fp32"];
        NSArray* fiber=muscleJSON[@"reference_fiber_length_m"];
        require([activation isKindOfClass:[NSArray class]] && [fiber isKindOfClass:[NSArray class]] &&
            activation.count==MRNX_FULL_BODY_MUSCLE_COUNT && fiber.count==MRNX_FULL_BODY_MUSCLE_COUNT,
            "native muscle state dimensions mismatch");
        const auto scalar=[](id x) {
            require([x isKindOfClass:[NSNumber class]] && CFGetTypeID((__bridge CFTypeRef)x)!=CFBooleanGetTypeID(),
                "state component is not numeric");
            const float value=[x floatValue];require(std::isfinite(value),"nonfinite prepared state");return value;
        };
        for(id x in qJSON) initial.q.push_back(scalar(x));
        initial.v.assign(MRNX_FULL_BODY_NV,0.0f);
        for(unsigned i=0;i<MRNX_FULL_BODY_MUSCLE_COUNT;++i) {
            const float a=scalar(activation[i]);
            MRMujocoMuscleStateGPU state{};state.excitationAndActivation={a,a,scalar(fiber[i]),0.0f};
            initial.muscles.push_back(state);
        }
        }
        require(newtonIterations > 0u && newtonIterations <= 128u, "invalid prepared Newton iteration budget");
        auto world=authoredFixtureWorld(initial.q);world.frameTimestep=timestepMicroseconds*1.0e-6;
        world.mixedSolver.newtonIterations = newtonIterations;
        numi::matter::CompileOptions options;options.maximumRateExponent=0u;
        const auto compiled=numi::matter::compileWorld(world,options);
        require(compiled.succeeded(),"prepared fixture world failed to compile");
        const auto rigid=readPayloadBytes(MRNX_FULLBODY_RIGID);
        require(rigid.size()>=80u,"truncated source rigid fixture");
        std::copy_n(rigid.begin()+48u,32u,initial.sourceArchiveSHA256.begin());
        const auto base=fullBodySourceFingerprint(rigid,readPayloadBytes(MRNX_FULLBODY_MUSCLE),readPayloadBytes(contacts));
        auto source=constrainedFingerprint(base,readPayloadBytes(equalities));
        source=((source^equalityFingerprint({'N','H','L','I','M','1'}))*kFnvPrime ^
            equalityFingerprint(readPayloadBytes(limits)))*kFnvPrime;
        const auto expectedSource = source==0u?kFnvOffset:source;
        require(!importInitialState || initial.humanSourceFingerprint == expectedSource,
            "imported prepared state composed source mismatch");
        initial.humanSourceFingerprint=expectedSource;
        initial.worldFingerprint=compiled.world.fingerprint;initial.timestepMicroseconds=timestepMicroseconds;
        std::string error;std::vector<std::byte> bytes;
        const bool encoded=metalrobo::encodeNumiHumanInitialState(initial,bytes,error);
        require(encoded,error.c_str());
        const std::filesystem::path directory(output);std::filesystem::create_directories(directory);
        const bool saved=numi::matter::writePackage(compiled,directory/("prepared-"+std::to_string(timestepMicroseconds)+"us.nmatterpack"),&error);
        require(saved,error.c_str());
        std::ofstream stateFile(directory/"prepared.nhinit",std::ios::binary);
        stateFile.write(reinterpret_cast<const char*>(bytes.data()),bytes.size());
        require(stateFile.good(),"could not write prepared state");
        const std::vector<std::uint8_t> raw(reinterpret_cast<const std::uint8_t*>(bytes.data()),
            reinterpret_cast<const std::uint8_t*>(bytes.data())+bytes.size());
        std::ofstream receipt(directory/"prepared.json");
        receipt << "{\"schema\":\"numi.human.prepared-stance-fixture.v1\",\"human_source_fp\":\"" << std::hex << base
            << "\",\"composed_human_source_fp\":\"" << initial.humanSourceFingerprint
            << "\",\"world_fp\":\"" << initial.worldFingerprint
            << "\",\"initial_state_fp\":\"" << equalityFingerprint(raw)
            << "\",\"scope\":\"three tiny pelvis samples; no anatomical tissue or sustained behavior qualification\"}\n";
        require(receipt.good(),"could not write prepared fixture identity");
        std::cout << "prepared_stance_fixture=compiled nq=129 nv=128 muscles=416 objects=3 attachments=12\n";
        return 0;
    }
}

mrnx_runtime_v1* makeAuthoredRuntime(
    const mrnx_runtime_config_v2& base,
    mrnx_runtime_info_v1& info,
    const bool sourceEqualities
) {
    auto source = authoredFixtureWorld();
    const auto package = std::filesystem::temp_directory_path() /
        ("numanx-authored-" + std::to_string(getpid()) + ".nmatterpack");
    const auto packagePath = package.string();
    mrnx_runtime_config_v3 config{};
    config.abi_version = MRNX_RUNTIME_CONFIG_ABI_V3;
    config.struct_size = sizeof(config);
    config.runtime = base;
    config.runtime.matter_material_path = nullptr;
    config.matter_world_package_path = packagePath.c_str();
    config.expected_model_source_fingerprint = fullBodySourceFingerprint(
        readPayloadBytes(MRNX_FULLBODY_RIGID),
        readPayloadBytes(MRNX_FULLBODY_MUSCLE),
        readPayloadBytes(MRNX_FULLBODY_SUPPORT_CONTACT));
    const auto cook = [&](const numi::matter::WorldSource& world) {
        numi::matter::CompileOptions options;
        options.maximumRateExponent = 0u;
        const auto compiled = numi::matter::compileWorld(world, options);
        std::string error;
        require(compiled.succeeded() &&
                    numi::matter::writePackage(compiled, package, &error),
                "authored fixture package failed");
        config.expected_matter_world_fingerprint = compiled.world.fingerprint;
    };
    const auto reject = [&](const mrnx_runtime_config_v3& candidate,
                            const mrnx_runtime_status_v1 status) {
        mrnx_runtime_info_v1 failed{};
        auto* runtime = mrnx_bridge_v1_runtime_create_v3(&candidate, &failed);
        require(runtime == nullptr && failed.status == status,
                "invalid authored world was admitted or misclassified");
    };
    cook(source);
    auto changed = config;
    changed.expected_model_source_fingerprint ^= 1u;
    reject(changed, MRNX_RUNTIME_ASSET_FAILURE_V1);
    changed = config;
    changed.expected_matter_world_fingerprint ^= 1u;
    reject(changed, MRNX_RUNTIME_ASSET_FAILURE_V1);
    changed = config;
    changed.runtime.matter_material_path = MRNX_MATTER_MATERIAL;
    reject(changed, MRNX_RUNTIME_INVALID_CONFIGURATION_V1);
    changed = config;
    changed.matter_world_package_path = "/nonexistent-numanx-world.nmatterpack";
    reject(changed, MRNX_RUNTIME_ASSET_FAILURE_V1);
    changed = config;
    changed.runtime.timestep_microseconds += 1u;
    reject(changed, MRNX_RUNTIME_ASSET_FAILURE_V1);
    auto bad = source;
    bad.gravity[2] += 1.0;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad = source;
    bad.objects[0u].femHumanAttachments[0u].localPoint[0] += 0.01;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad = source;
    bad.objects[0u].femHumanAttachments[0u].bodyIndex = 157u;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad = source;
    bad.objects[0u].femInitialVelocity[0] = 0.1;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad = source;
    bad.deterministic = false;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad = source;
    bad.materials[0u].mixed.maximumActiveTension = 100.0;
    cook(bad);
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    cook(source);
    {
        std::fstream corrupted(package, std::ios::binary | std::ios::in | std::ios::out);
        char byte = 0;
        corrupted.read(&byte, 1);
        byte ^= 1;
        corrupted.seekp(0);
        corrupted.write(&byte, 1);
    }
    reject(config, MRNX_RUNTIME_ASSET_FAILURE_V1);
    cook(source);
    mrnx_runtime_v1* runtime = nullptr;
    std::filesystem::path equalityTemporary;
    if (sourceEqualities) {
        const char* equalityPath = std::getenv("MRNX_JOINT_EQUALITIES");
        require(equalityPath != nullptr, "MRNX_JOINT_EQUALITIES must identify NHEQ2");
        const auto equalityBytes = readPayloadBytes(equalityPath);
        equalityTemporary = package.string()+".nheq";
        const auto equalityPathString = equalityTemporary.string();
        const auto writeEquality = [&](const std::vector<std::uint8_t>& bytes) {
            std::ofstream output(equalityTemporary, std::ios::binary);
            output.write(reinterpret_cast<const char*>(bytes.data()), bytes.size());
            require(output.good(), "could not retain equality fixture");
        };
        writeEquality(equalityBytes);
        mrnx_runtime_config_v4 constrained{};
        constrained.abi_version=MRNX_RUNTIME_CONFIG_ABI_V4;
        constrained.struct_size=sizeof(constrained);
        constrained.runtime=config;
        constrained.joint_equality_payload_path=equalityPathString.c_str();
        constrained.expected_joint_equality_fingerprint=equalityFingerprint(equalityBytes);
        const auto rejectEquality = [&](const mrnx_runtime_config_v4& candidate,
                                        const mrnx_runtime_status_v1 expected) {
            mrnx_runtime_info_v1 rejected{};
            auto* unexpected=mrnx_bridge_v1_runtime_create_v4(&candidate,&rejected);
            require(unexpected==nullptr && rejected.status==expected,
                    "invalid NHEQ2 source was admitted or misclassified");
        };
        auto invalid=constrained;
        invalid.abi_version=3u;
        rejectEquality(invalid,MRNX_RUNTIME_INVALID_CONFIGURATION_V1);
        invalid=constrained;invalid.runtime.struct_size-=8u;
        rejectEquality(invalid,MRNX_RUNTIME_INVALID_CONFIGURATION_V1);
        invalid=constrained;invalid.expected_joint_equality_fingerprint^=1u;
        rejectEquality(invalid,MRNX_RUNTIME_ASSET_FAILURE_V1);
        for (const std::size_t offset : {std::size_t(4u),std::size_t(16u),std::size_t(32u),std::size_t(48u)}) {
            auto bytes=equalityBytes;bytes[offset]^=1u;writeEquality(bytes);
            invalid=constrained;invalid.expected_joint_equality_fingerprint=equalityFingerprint(bytes);
            rejectEquality(invalid,MRNX_RUNTIME_ASSET_FAILURE_V1);
        }
        auto truncated=equalityBytes;truncated.pop_back();writeEquality(truncated);
        invalid=constrained;invalid.expected_joint_equality_fingerprint=equalityFingerprint(truncated);
        rejectEquality(invalid,MRNX_RUNTIME_ASSET_FAILURE_V1);
        writeEquality(equalityBytes);
        runtime=mrnx_bridge_v1_runtime_create_v4(&constrained,&info);
        require(runtime != nullptr, "valid source-compliant authored world was rejected");
        require(info.model_source_fingerprint == constrainedFingerprint(
                    config.expected_model_source_fingerprint,equalityBytes),
                "NHEQ2 source is absent from Human program identity");
        std::filesystem::remove(equalityTemporary);
        std::printf("numanx_source_equalities_admission=pass rows=51 negative_cases=8 source_fp=%016llx\n",
                    static_cast<unsigned long long>(info.model_source_fingerprint));
    } else {
        runtime=mrnx_bridge_v1_runtime_create_v3(&config,&info);
    }
    require(runtime != nullptr, "valid authored world was rejected");
    mrnx_runtime_world_info_v1 worldInfo{};
    worldInfo.abi_version = MRNX_BRIDGE_ABI_V1;
    worldInfo.struct_size = sizeof(worldInfo);
    require(mrnx_bridge_v1_runtime_copy_world_info(runtime, &worldInfo) &&
        worldInfo.authored_package == 1u && worldInfo.object_count == 3u &&
        worldInfo.fem_node_count == 12u && worldInfo.fem_attachment_count == 12u &&
        worldInfo.world_fingerprint == config.expected_matter_world_fingerprint &&
        worldInfo.physics_fingerprint != 0u,
        "authored world metadata does not identify the loaded package");
    // Rewriting/removing the file after construction must not change retained
    // runtime state or its proof authority.
    std::filesystem::remove(package);
    if (const char* retained = std::getenv("MRNX_AUTHORED_FIXTURE_DIR")) {
        const std::filesystem::path directory(retained);
        std::filesystem::create_directories(directory);
        source.frameTimestep = 0.0001;
        numi::matter::CompileOptions options;
        options.maximumRateExponent = 0u;
        const auto compiled = numi::matter::compileWorld(source, options);
        std::string error;
        require(compiled.succeeded() && numi::matter::writePackage(compiled,
                    directory / "authored-100us.nmatterpack", &error),
                "retaining authored Swift fixture failed");
        std::ofstream receipt(directory / "authored-100us.json");
        receipt << "{\"human_source_fp\":\"" << std::hex
                << config.expected_model_source_fingerprint
                << "\",\"matter_world_fp\":\"" << compiled.world.fingerprint
                << "\",\"timestep_microseconds\":100}\n";
        require(receipt.good(), "retaining authored fixture identity failed");
    }
    std::printf("numanx_authored_world_admission=pass negative_cases=12 objects=3 attachments=12\n");
    return runtime;
}

std::uint64_t costalFingerprint(std::uint64_t source, const std::uint64_t world) {
    for(const auto byte:std::array<unsigned char,8>{'N','H','T','M','A','S','S','1'}) {
        source^=byte;source*=kFnvPrime;
    }
    mixU64(source,equalityFingerprint(readPayloadBytes(std::getenv("MRNX_COSTAL_BINDING"))));
    mixU64(source,world);return source;
}

mrnx_runtime_v1* makeCostalRuntime(const mrnx_runtime_config_v2& base,
                                  mrnx_runtime_info_v1& info) {
    const char* package=std::getenv("MRNX_COSTAL_WORLD");
    const char* binding=std::getenv("MRNX_COSTAL_BINDING");
    const char* cartilage=std::getenv("MRNX_COSTAL_PAYLOAD");
    const char* equality=std::getenv("MRNX_JOINT_EQUALITIES");
    require(package&&binding&&cartilage&&equality,"costal runtime needs MRNX_COSTAL_WORLD/BINDING/PAYLOAD and MRNX_JOINT_EQUALITIES");
    numi::matter::CompiledWorld world;std::string error;
    require(numi::matter::readPackage(package,world,nullptr,&error),"could not read registered costal package");
    mrnx_runtime_config_v5 config{};
    config.abi_version=MRNX_RUNTIME_CONFIG_ABI_V5;config.struct_size=sizeof(config);
    config.costal_cartilage_payload_path=cartilage;config.costal_binding_payload_path=binding;
    config.expected_costal_binding_fingerprint=equalityFingerprint(readPayloadBytes(binding));
    auto& v4=config.runtime;v4.abi_version=MRNX_RUNTIME_CONFIG_ABI_V4;v4.struct_size=sizeof(v4);
    v4.joint_equality_payload_path=equality;v4.expected_joint_equality_fingerprint=equalityFingerprint(readPayloadBytes(equality));
    auto& v3=v4.runtime;v3.abi_version=MRNX_RUNTIME_CONFIG_ABI_V3;v3.struct_size=sizeof(v3);
    v3.runtime=base;v3.runtime.matter_material_path=nullptr;v3.matter_world_package_path=package;
    v3.expected_matter_world_fingerprint=world.fingerprint;
    v3.expected_model_source_fingerprint=fullBodySourceFingerprint(readPayloadBytes(MRNX_FULLBODY_RIGID),
        readPayloadBytes(MRNX_FULLBODY_MUSCLE),readPayloadBytes(MRNX_FULLBODY_SUPPORT_CONTACT));
    const auto reject=[&](const mrnx_runtime_config_v5& bad,const mrnx_runtime_status_v1 status) {
        mrnx_runtime_info_v1 failed{};
        auto* result=mrnx_bridge_v1_runtime_create_v5(&bad,&failed);
        require(result==nullptr&&failed.status==status,"invalid costal mass ownership was admitted");
    };
    auto bad=config;bad.struct_size-=8;reject(bad,MRNX_RUNTIME_INVALID_CONFIGURATION_V1);
    bad=config;bad.expected_costal_binding_fingerprint^=1;reject(bad,MRNX_RUNTIME_ASSET_FAILURE_V1);
    bad=config;bad.costal_cartilage_payload_path=MRNX_FULLBODY_RIGID;reject(bad,MRNX_RUNTIME_ASSET_FAILURE_V1);
    // A legacy v4 cannot silently add the tissue mass; it sees incompatible
    // local frames and must reject before persistent runtime allocation.
    mrnx_runtime_info_v1 legacy{};
    require(mrnx_bridge_v1_runtime_create_v4(&v4,&legacy)==nullptr&&legacy.status==MRNX_RUNTIME_ASSET_FAILURE_V1,
            "legacy runtime admitted a mass-partitioned tissue package");
    auto* result=mrnx_bridge_v1_runtime_create_v5(&config,&info);
    require(result!=nullptr,"registered costal mass runtime was rejected");
    require(info.model_source_fingerprint==costalFingerprint(constrainedFingerprint(
        v3.expected_model_source_fingerprint,readPayloadBytes(equality)),world.fingerprint),
        "tissue mass ownership is absent from runtime identity");
    std::printf("numanx_costal_mass_admission=pass nodes=%zu tets=%zu attachments=%zu negative_cases=4 source_fp=%016llx\n",
        world.fem.nodes.size(),world.fem.tetrahedra.size(),world.fem.humanAttachments.size(),
        static_cast<unsigned long long>(info.model_source_fingerprint));
    return result;
}

int run(const bool authored, const bool sourceEqualities, const bool costalTissue) {
    const std::uint64_t durationMicros=costalTissue?10u:kDurationMicros;
    @autoreleasepool {
        id<MTLDevice> device = MTLCreateSystemDefaultDevice();
        require(device != nil, "Metal device unavailable");
        qualifyHumanSupportKKT(device);
        qualifyHumanSupportKKT(device, 1u);
        qualifyHumanSupportKKT(device, 2u);
        const auto culturePack = metalrobo::makePotterReferenceCulture(
            1000u, 50000u, 2056u);
        metalrobo::CompiledNeuronCulture compiledCulture;
        require(metalrobo::compileNeuronCulture(
                    culturePack, compiledCulture).succeeded(),
                "full-body culture pack did not compile");
        const auto culturePath = std::filesystem::temp_directory_path() /
            ("numanx-fullbody-culture-" + std::to_string(getpid()) +
             ".nculture");
        require(metalrobo::writeCompiledNeuronCulture(
                    compiledCulture, culturePath).succeeded(),
                "full-body culture artifact publication failed");
        const auto culturePathString = culturePath.string();
        mrnx_runtime_config_v2 config{};
        config.abi_version = MRNX_RUNTIME_CONFIG_ABI_V2;
        config.struct_size = sizeof(config);
        config.metal_device = (__bridge void*)device;
        config.rigid_payload_path = MRNX_FULLBODY_RIGID;
        config.muscle_payload_path = MRNX_FULLBODY_MUSCLE;
        config.support_contact_payload_path = MRNX_FULLBODY_SUPPORT_CONTACT;
        config.visual_pack_path = MRNX_FULLBODY_VISUAL_PACK;
        config.vision_profile_path = MRNX_FULLBODY_VISION_PROFILE;
        config.metalrobo_metallib_path = MRNX_METALROBO_METALLIB;
        config.matter_metallib_path = MRNX_MATTER_METALLIB;
        config.matter_material_path = MRNX_MATTER_MATERIAL;
        config.timestep_microseconds = durationMicros;
        config.maximum_retained_bytes = (costalTissue?2ull:1ull) * 1024ull * 1024ull * 1024ull;
        config.transaction_slot_count = 2u;
        config.culture_pack_path = culturePathString.c_str();
        config.culture_window_ticks = 100u;
        config.culture_current_per_newton = 4.0f;
        auto mismatchedSupport = config;
        mismatchedSupport.support_contact_payload_path = MRNX_FULLBODY_MUSCLE;
        mrnx_runtime_info_v1 mismatchedInfo{};
        mismatchedInfo.abi_version = MRNX_BRIDGE_ABI_V1;
        mismatchedInfo.struct_size = sizeof(mismatchedInfo);
        mrnx_runtime_v1* mismatchedRuntime =
            mrnx_bridge_v1_runtime_create_v2(
                &mismatchedSupport, &mismatchedInfo);
        require(
            mismatchedRuntime == nullptr &&
                mismatchedInfo.status == MRNX_RUNTIME_ASSET_FAILURE_V1,
            "mismatched source support-contact authority was admitted");
        mrnx_runtime_info_v1 info{};
        mrnx_runtime_v1* runtime = costalTissue ? makeCostalRuntime(config,info) : authored
            ? makeAuthoredRuntime(config, info, sourceEqualities)
            : mrnx_bridge_v1_runtime_create_v2(&config, &info);
        if (runtime == nullptr || info.status != MRNX_RUNTIME_READY_V1) {
            std::fprintf(
                stderr, "full-body runtime status=%u\n", info.status);
        }
        require(runtime != nullptr && info.status == MRNX_RUNTIME_READY_V1,
                "full-body runtime creation failed");
        mrnx_runtime_world_info_v1 worldInfo{};
        worldInfo.abi_version = MRNX_BRIDGE_ABI_V1;
        worldInfo.struct_size = sizeof(worldInfo);
        require(mrnx_bridge_v1_runtime_copy_world_info(runtime, &worldInfo) &&
                    worldInfo.authored_package == (authored ? 1u : 0u),
                "runtime world kind was not reported exactly");
        require(info.q_coordinate_count == 129u && info.dof_count == 128u &&
                    info.muscle_count == 416u && info.body_count == 157u &&
                    info.accepted_state_proof_program_fingerprint != 0u &&
                    info.model_source_fingerprint != 0u,
                "full-body runtime provenance is wrong");
        const auto rigidPayload = readPayloadBytes(MRNX_FULLBODY_RIGID);
        const auto musclePayload = readPayloadBytes(MRNX_FULLBODY_MUSCLE);
        const auto supportPayload =
            readPayloadBytes(MRNX_FULLBODY_SUPPORT_CONTACT);
        auto expectedSource=sourceEqualities ?
            constrainedFingerprint(fullBodySourceFingerprint(rigidPayload,musclePayload,supportPayload),
                readPayloadBytes(std::getenv("MRNX_JOINT_EQUALITIES"))) :
            fullBodySourceFingerprint(rigidPayload,musclePayload,supportPayload);
        if(costalTissue)expectedSource=costalFingerprint(expectedSource,worldInfo.world_fingerprint);
        require(
            info.model_source_fingerprint == expectedSource,
            "runtime model fingerprint does not bind exact source payloads");
        auto mutatedSupportPayload = supportPayload;
        require(
            mutatedSupportPayload.size() > 56u,
            "support payload is too small for its NHCNT1 header");
        mutatedSupportPayload[56u] ^= 1u;
        require(
            info.model_source_fingerprint != fullBodySourceFingerprint(
                rigidPayload, musclePayload, mutatedSupportPayload),
            "support-contact payload mutation did not change model identity");

        id<MTLBuffer> headerBuffer = [device
            newBufferWithLength:sizeof(MRNumanXBrainMotorOutputHeaderGPU)
                       options:MTLResourceStorageModeShared];
        id<MTLBuffer> excitationBuffer = [device
            newBufferWithLength:416u * sizeof(float)
                       options:MTLResourceStorageModeShared];
        id<MTLBuffer> autonomicBuffer = [device
            newBufferWithLength:MR_NUMANX_BRAIN_AUTONOMIC_COMMAND_BYTE_COUNT
                       options:MTLResourceStorageModeShared];
        id<MTLBuffer> activeBuffer = [device
            newBufferWithLength:
                MR_NUMANX_BRAIN_ACTIVE_SENSING_COMMAND_BYTE_COUNT
                       options:MTLResourceStorageModeShared];
        id<MTLBuffer> gateBuffer = [device
            newBufferWithLength:sizeof(MRNumanXBrainMotorReadyGateGPU)
                       options:MTLResourceStorageModeShared];
        id<MTLSharedEvent> readyEvent = [device newSharedEvent];
        require(headerBuffer != nil && excitationBuffer != nil &&
                    autonomicBuffer != nil && activeBuffer != nil &&
                    gateBuffer != nil && readyEvent != nil,
                "fixture Metal resources unavailable");
        auto* excitation = static_cast<float*>(excitationBuffer.contents);
        for (std::uint32_t index = 0u; index < 416u; ++index) {
            excitation[index] = 0.05f +
                0.1f * static_cast<float>(index % 7u) / 6.0f;
        }
        std::memset(autonomicBuffer.contents, 0, autonomicBuffer.length);
        std::memset(activeBuffer.contents, 0, activeBuffer.length);

        mrnx_physical_root_request_v1 request{};
        request.abi_version = MRNX_BRIDGE_ABI_V1;
        request.struct_size = sizeof(request);
        request.root.format_version =
            MR_NUMANX_BRAIN_JOINT_TRANSACTION_VERSION;
        request.root.environment_identifier = 0u;
        request.root.episode_identifier = 1u;
        request.root.control_step_identifier = 1u;
        request.root.parameter_version_fingerprint = 2u;
        request.root.base_brain_generation = 0u;
        request.root.base_physics_generation = 0u;
        request.root.committed_timestamp_microseconds = kStartMicros;
        request.root.target_timestamp_microseconds =
            kStartMicros + durationMicros;
        request.root.shadow_generation = 1u;
        request.root.random_counter_generation = 3u;
        MRNumanXBrainJointTransactionToken nativeRoot{};
        std::memcpy(&nativeRoot, &request.root, sizeof(nativeRoot));
        request.root.transaction_fingerprint =
            metalrobo::metalNumanXBrainJointTransactionFingerprint(nativeRoot);

        request.substep.transaction_fingerprint =
            request.root.transaction_fingerprint;
        request.substep.substep_index = 0u;
        request.substep.attempt_index = 0u;
        request.substep.start_timestamp_microseconds = kStartMicros;
        request.substep.duration_microseconds = durationMicros;
        request.substep.candidate_timestamp_microseconds =
            kStartMicros + durationMicros;
        request.substep.shadow_generation = request.root.shadow_generation;
        request.substep.random_counter_generation =
            request.root.random_counter_generation;
        MRNumanXBrainJointSubstepToken nativeSubstep{};
        std::memcpy(&nativeSubstep, &request.substep, sizeof(nativeSubstep));
        request.substep.substep_fingerprint =
            metalrobo::metalNumanXBrainJointSubstepFingerprint(nativeSubstep);

        request.candidate.format_version =
            MR_NUMANX_BRAIN_MOTOR_CANDIDATE_VERSION;
        request.candidate.flags =
            MR_NUMANX_BRAIN_MOTOR_CANDIDATE_VALID |
            MR_NUMANX_BRAIN_MOTOR_CANDIDATE_DECISION_SHADOW;
        request.candidate.transaction_fingerprint =
            request.root.transaction_fingerprint;
        request.candidate.substep_fingerprint =
            request.substep.substep_fingerprint;
        request.candidate.accepted_brain_timestamp_microseconds =
            kStartMicros;
        request.candidate.brain_generation = request.root.shadow_generation;
        request.candidate.motor_profile_fingerprint = 4u;
        request.candidate.motor_output_header_gpu_address =
            headerBuffer.gpuAddress;
        request.candidate.muscle_excitation_gpu_address =
            excitationBuffer.gpuAddress;
        request.candidate.random_counter_generation =
            request.root.random_counter_generation;
        request.candidate.motor_output_header_byte_count =
            headerBuffer.length;
        request.candidate.muscle_excitation_byte_count =
            excitationBuffer.length;
        request.candidate.muscle_count = 416u;
        request.candidate.environment_identifier = 0u;
        request.candidate.autonomic_command_gpu_address =
            autonomicBuffer.gpuAddress;
        request.candidate.autonomic_command_byte_count =
            autonomicBuffer.length;
        request.candidate.autonomic_command_count = 1u;
        request.candidate.active_sensing_command_gpu_address =
            activeBuffer.gpuAddress;
        request.candidate.active_sensing_command_byte_count =
            activeBuffer.length;
        request.candidate.active_sensing_command_count = 1u;
        request.candidate.actuator_command_kind =
            MR_NUMANX_BRAIN_ACTUATOR_MUSCLE_EXCITATION;
        request.candidate.species_template_fingerprint = 5u;
        request.candidate.compiled_species_template_fingerprint = 6u;
        MRNumanXBrainMotorCandidate nativeCandidate{};
        std::memcpy(
            &nativeCandidate, &request.candidate, sizeof(nativeCandidate));
        request.candidate.candidate_fingerprint =
            metalrobo::metalNumanXBrainMotorCandidateFingerprint(
                nativeCandidate);

        auto* header = static_cast<MRNumanXBrainMotorOutputHeaderGPU*>(
            headerBuffer.contents);
        *header = {};
        header->formatVersion = MR_NUMANX_BRAIN_MOTOR_OUTPUT_VERSION;
        header->flags = MR_NUMANX_BRAIN_MOTOR_OUTPUT_VALID;
        header->timestampMicroseconds = kStartMicros;
        header->brainGeneration = request.root.shadow_generation;
        header->profileFingerprint =
            request.candidate.motor_profile_fingerprint;
        header->protectiveCommandFingerprint = 7u;
        header->muscleCount = 416u;
        header->environmentIdentifier = 0u;
        header->motorInhibition = 0.1f;
        header->autonomicArousal = 0.2f;
        header->actuatorCommandKind =
            MR_NUMANX_BRAIN_ACTUATOR_MUSCLE_EXCITATION;
        header->outputMinimum = 0.0f;
        header->outputMaximum = 1.0f;
        header->outputFingerprint = motorOutputFingerprint(
            *header, excitation);

        auto* gate = static_cast<MRNumanXBrainMotorReadyGateGPU*>(
            gateBuffer.contents);
        *gate = {};
        gate->abiVersion = MR_NUMANX_BRAIN_MOTOR_READY_ABI_VERSION;
        gate->structBytes = sizeof(*gate);
        gate->status = MR_NUMANX_BRAIN_READY_GATE_SUCCESS;
        gate->environment = 0u;
        gate->substepIndex = 0u;
        gate->attemptIndex = 0u;
        gate->muscleCount = 416u;
        gate->actuatorCommandKind =
            MR_NUMANX_BRAIN_ACTUATOR_MUSCLE_EXCITATION;
        gate->controlStep = request.root.control_step_identifier;
        gate->transactionFingerprint = request.root.transaction_fingerprint;
        gate->substepFingerprint = request.substep.substep_fingerprint;
        gate->candidateFingerprint = request.candidate.candidate_fingerprint;
        gate->motorOutputFingerprint = header->outputFingerprint;
        gate->motorProfileFingerprint =
            request.candidate.motor_profile_fingerprint;
        gate->brainGeneration = request.root.shadow_generation;
        gate->acceptedBrainTimestampMicroseconds = kStartMicros;
        gate->randomCounterGeneration =
            request.root.random_counter_generation;
        gate->speciesTemplateFingerprint =
            request.candidate.species_template_fingerprint;
        gate->compiledSpeciesTemplateFingerprint =
            request.candidate.compiled_species_template_fingerprint;
        gate->brainProgramFingerprint = 8u;
        gate->fastProgramFingerprint = 9u;
        gate->decisionGateFingerprint = 10u;
        gate->gateFingerprint = readyGateFingerprint(*gate);

        request.motor_header = range(
            headerBuffer, MRNX_ELEMENT_RAW_BYTES_V1, 1u);
        request.muscle_excitation = range(
            excitationBuffer, MRNX_ELEMENT_FLOAT32_V1, sizeof(float));
        request.autonomic_command = range(
            autonomicBuffer, MRNX_ELEMENT_RAW_BYTES_V1, 1u);
        request.active_sensing_command = range(
            activeBuffer, MRNX_ELEMENT_RAW_BYTES_V1, 1u);
        request.motor_ready_gate = range(
            gateBuffer, MRNX_ELEMENT_RAW_BYTES_V1, 1u);
        request.motor_ready.abi_version = MRNX_BRIDGE_ABI_V1;
        request.motor_ready.struct_size = sizeof(request.motor_ready);
        request.motor_ready.shared_event = (__bridge void*)readyEvent;
        request.motor_ready.value = 1u;
        request.motor_ready.device_registry_id = device.registryID;

        std::memcpy(&nativeRoot, &request.root, sizeof(nativeRoot));
        std::memcpy(&nativeSubstep, &request.substep, sizeof(nativeSubstep));
        std::memcpy(
            &nativeCandidate, &request.candidate, sizeof(nativeCandidate));
        require(request.root.transaction_fingerprint ==
                    metalrobo::metalNumanXBrainJointTransactionFingerprint(
                        nativeRoot),
                "fixture root fingerprint mismatch");
        require(request.substep.substep_fingerprint ==
                    metalrobo::metalNumanXBrainJointSubstepFingerprint(
                        nativeSubstep),
                "fixture substep fingerprint mismatch");
        require(request.candidate.candidate_fingerprint ==
                    metalrobo::metalNumanXBrainMotorCandidateFingerprint(
                        nativeCandidate),
                "fixture candidate fingerprint mismatch");

        auto overflow = request;
        overflow.root.control_step_identifier =
            static_cast<std::uint64_t>(
                std::numeric_limits<std::uint32_t>::max()) + 1u;
        require(!mrnx_bridge_v1_runtime_begin_physical_root(
                    runtime, &overflow, nullptr, &settled),
                "UInt64 control-step overflow was admitted");
        Completion completion{};
        if (!mrnx_bridge_v1_runtime_begin_physical_root(
                runtime, &request, &completion, &settled)) {
            mrnx_runtime_info_v1 failedInfo{};
            failedInfo.abi_version = MRNX_BRIDGE_ABI_V1;
            failedInfo.struct_size = sizeof(failedInfo);
            (void)mrnx_bridge_v1_runtime_copy_info(runtime, &failedInfo);
            throw std::runtime_error(
                "full-body physical root was not armed status=" +
                std::to_string(failedInfo.status) + " stage=" +
                std::to_string(failedInfo.request_failure_stage));
        }
        require(completion.count.load(std::memory_order_acquire) == 0u,
                "physical root ignored the unsignaled motor-ready event");
        readyEvent.signaledValue = 1u;
        waitForCompletion(completion,costalTissue?60u:10u);
        if (completion.status.load(std::memory_order_acquire) !=
                MRNX_COMPLETION_READY_V1 ||
            completion.prepared == nullptr || completion.candidate == nullptr ||
            completion.root.q_coordinate_count != 129u ||
            completion.root.dof_count != 128u) {
            mrnx_runtime_info_v1 failedInfo{};
            failedInfo.abi_version = MRNX_BRIDGE_ABI_V1;
            failedInfo.struct_size = sizeof(failedInfo);
            (void)mrnx_bridge_v1_runtime_copy_info(runtime, &failedInfo);
            throw std::runtime_error(
                "real full-body physical root did not prepare status=" +
                std::to_string(completion.status.load(
                    std::memory_order_acquire)) + " stage=" +
                std::to_string(failedInfo.request_failure_stage) +
                " prepared=" +
                std::to_string(completion.prepared != nullptr) +
                " candidate=" +
                std::to_string(completion.candidate != nullptr) +
                " nq=" +
                std::to_string(completion.root.q_coordinate_count) +
                " nv=" + std::to_string(completion.root.dof_count));
        }
        mrnx_wire_lease_v1 physicalGate{};
        physicalGate.abi_version = MRNX_BRIDGE_ABI_V1;
        physicalGate.struct_size = sizeof(physicalGate);
        require(mrnx_bridge_v1_prepared_copy_physical_gate(
                    completion.prepared, &physicalGate) &&
                    physicalGate.record.byte_count == 64u &&
                    physicalGate.ready.value != 0u,
                "prepared physical gate is unavailable");
        mrnx_culture_prepared_view_v1 culturePrepared{};
        culturePrepared.abi_version = MRNX_CULTURE_PREPARED_VIEW_ABI_V1;
        culturePrepared.struct_size = sizeof(culturePrepared);
        require(mrnx_bridge_v1_prepared_copy_culture_view(
                    completion.prepared, &culturePrepared) &&
                    culturePrepared.culture_fingerprint ==
                        compiledCulture.fingerprint() &&
                    culturePrepared.accepted_generation == 0u &&
                    culturePrepared.prepared_generation == 1u &&
                    culturePrepared.source_root_fingerprint ==
                        completion.root.transaction_fingerprint &&
                    culturePrepared.receipt_fingerprint != 0u &&
                    culturePrepared.ready.value != 0u,
                "prepared culture receipt is unavailable or stale");
        mrnx_candidate_view_v1 sensor{};
        sensor.abi_version = MRNX_BRIDGE_ABI_V1;
        sensor.struct_size = sizeof(sensor);
        mrnx_candidate_channel_v1 proprioception{};
        proprioception.abi_version = MRNX_BRIDGE_ABI_V1;
        proprioception.struct_size = sizeof(proprioception);
        mrnx_candidate_channel_v1 interoception{};
        interoception.abi_version = MRNX_BRIDGE_ABI_V1;
        interoception.struct_size = sizeof(interoception);
        mrnx_candidate_channel_v1 supplemental[5]{};
        for (auto& channel : supplemental) {
            channel.abi_version = MRNX_BRIDGE_ABI_V1;
            channel.struct_size = sizeof(channel);
        }
        mrnx_candidate_timing_v1 timing{};
        timing.abi_version = MRNX_BRIDGE_ABI_V1;
        timing.struct_size = sizeof(timing);
        require(mrnx_bridge_v1_candidate_copy_view(
                    completion.candidate, &sensor) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 0u, &proprioception) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 1u, &interoception) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 2u, &supplemental[0]) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 3u, &supplemental[1]) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 4u, &supplemental[2]) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 5u, &supplemental[3]) &&
                    mrnx_bridge_v1_candidate_copy_channel(
                        completion.candidate, 6u, &supplemental[4]) &&
                    mrnx_bridge_v1_candidate_copy_timing(
                        completion.candidate, &timing) &&
                    sensor.channel_count == 7u &&
                    sensor.accepted_brain_generation == 1u &&
                    sensor.key.sensor_generation == 1u &&
                    proprioception.modality ==
                        MRNX_CANDIDATE_MODALITY_PROPRIOCEPTION_V1 &&
                    proprioception.receptor_count == 416u &&
                    proprioception.feature_dimension == 10u &&
                    proprioception.receptor_timestamp_microseconds ==
                        kStartMicros &&
                    interoception.modality ==
                        MRNX_CANDIDATE_MODALITY_INTEROCEPTION_V1 &&
                    interoception.receptor_count == 416u &&
                    interoception.feature_dimension == 6u &&
                    interoception.receptor_timestamp_microseconds ==
                        kStartMicros &&
                    supplemental[0].modality ==
                        MRNX_CANDIDATE_MODALITY_KINESTHESIA_V1 &&
                    supplemental[0].receptor_count == 128u &&
                    supplemental[0].feature_dimension == 7u &&
                    supplemental[1].modality ==
                        MRNX_CANDIDATE_MODALITY_VESTIBULAR_V1 &&
                    supplemental[1].receptor_count == 1u &&
                    supplemental[1].feature_dimension == 22u &&
                    supplemental[2].modality ==
                        MRNX_CANDIDATE_MODALITY_AUDITION_V1 &&
                    supplemental[2].receptor_count == 24u &&
                    supplemental[2].feature_dimension == 8u &&
                    supplemental[3].modality ==
                        MRNX_CANDIDATE_MODALITY_VISION_V1 &&
                    supplemental[3].receptor_count == 64u * 48u &&
                    supplemental[3].feature_dimension == 8u &&
                    supplemental[4].modality ==
                        MRNX_CANDIDATE_MODALITY_TOUCH_V1 &&
                    supplemental[4].receptor_count == 10u &&
                    supplemental[4].feature_dimension == 7u &&
                    timing.capture_timestamp_microseconds == kStartMicros &&
                    timing.delivery_timestamp_microseconds ==
                        kStartMicros + durationMicros &&
                    timing.latency_microseconds == durationMicros &&
                    timing.sample_interval_microseconds == durationMicros &&
                    timing.timing_fingerprint == timingFingerprint(timing),
                "causal HumanIO candidate is not the exact full-body view");
        __unsafe_unretained id<MTLBuffer> touchValues =
            (__bridge id<MTLBuffer>)supplemental[4].values.metal_buffer;
        __unsafe_unretained id<MTLBuffer> touchValidity =
            (__bridge id<MTLBuffer>)supplemental[4].validity.metal_buffer;
        require(touchValues != nil && touchValidity != nil &&
                    supplemental[4].values.byte_count ==
                        10u * 7u * sizeof(float) &&
                    supplemental[4].validity.byte_count ==
                        10u * sizeof(std::uint32_t),
                "touch consequence buffers have the wrong exact layout");
        id<MTLBuffer> touchReadback = [device
            newBufferWithLength:supplemental[4].values.byte_count
                + supplemental[4].validity.byte_count +
                    sizeof(MRNumanXAcceptedPhysicsStateTokenGPU)
                         options:MTLResourceStorageModeShared];
        id<MTLCommandQueue> readbackQueue = [device newCommandQueue];
        id<MTLCommandBuffer> readbackCommand =
            [readbackQueue commandBuffer];
        id<MTLBlitCommandEncoder> readback =
            [readbackCommand blitCommandEncoder];
        require(touchReadback != nil && readbackQueue != nil &&
                    readbackCommand != nil && readback != nil,
                "touch consequence diagnostic readback allocation failed");
        [readback copyFromBuffer:touchValues
                    sourceOffset:supplemental[4].values.byte_offset
                        toBuffer:touchReadback destinationOffset:0u
                            size:supplemental[4].values.byte_count];
        [readback copyFromBuffer:touchValidity
                    sourceOffset:supplemental[4].validity.byte_offset
                        toBuffer:touchReadback
               destinationOffset:supplemental[4].values.byte_count
                            size:supplemental[4].validity.byte_count];
        __unsafe_unretained id<MTLBuffer> physicalTokenBuffer =
            (__bridge id<MTLBuffer>)physicalGate.record.metal_buffer;
        [readback copyFromBuffer:physicalTokenBuffer
                    sourceOffset:physicalGate.record.byte_offset
                        toBuffer:touchReadback
               destinationOffset:supplemental[4].values.byte_count +
                    supplemental[4].validity.byte_count
                            size:sizeof(
                                MRNumanXAcceptedPhysicsStateTokenGPU)];
        [readback endEncoding];
        [readbackCommand commit];
        [readbackCommand waitUntilCompleted];
        require(readbackCommand.status == MTLCommandBufferStatusCompleted,
                "touch consequence diagnostic readback failed");
        const auto* touch = static_cast<const float*>(touchReadback.contents);
        const auto* validity = reinterpret_cast<const std::uint32_t*>(
            static_cast<const std::uint8_t*>(touchReadback.contents) +
            supplemental[4].values.byte_count);
        const auto* acceptedToken =
            reinterpret_cast<const MRNumanXAcceptedPhysicsStateTokenGPU*>(
                static_cast<const std::uint8_t*>(touchReadback.contents) +
                supplemental[4].values.byte_count +
                supplemental[4].validity.byte_count);
        require(acceptedToken->transactionFingerprint ==
                    completion.root.transaction_fingerprint &&
                    acceptedToken->substepFingerprint != 0u &&
                    acceptedToken->physicsStateFingerprint != 0u &&
                    acceptedToken->physicsGeneration == 1u &&
                    acceptedToken->environmentIdentifier == 0u &&
                    acceptedToken->reserved == 0u &&
                    acceptedToken->tokenFingerprint != 0u,
                "accepted token did not bind the proved Human/Matter state");
        bool observedSupportGeometry = false;
        for (std::uint32_t row = 0u; row < 10u; ++row) {
            const float separation = touch[row * 7u + 3u];
            const float normalForce = touch[row * 7u + 4u];
            const float frictionForce = touch[row * 7u + 5u];
            const float slipSpeed = touch[row * 7u + 6u];
            const bool rowValid = validity[row] ==
                    MR_NUMANX_HUMAN_TOUCH_VALIDITY_ALL &&
                std::isfinite(separation) &&
                std::isfinite(normalForce) && normalForce >= 0.0f &&
                std::isfinite(frictionForce) && frictionForce >= 0.0f &&
                std::isfinite(slipSpeed) && slipSpeed >= 0.0f;
            if (!rowValid) {
                std::fprintf(stderr,
                    "support_row=%u validity=%u separation=%g normal=%g "
                    "friction=%g slip=%g\n", row, validity[row], separation,
                    normalForce, frictionForce, slipSpeed);
            }
            require(rowValid, "Matter support consequence is invalid");
            observedSupportGeometry = observedSupportGeometry ||
                std::abs(separation) < 0.1f;
        }
        require(observedSupportGeometry,
                "NHCNT rows produced no solver-owned support geometry");
        mrnx_aggregate_snapshot_v1 aggregate{};
        aggregate.abi_version = MRNX_BRIDGE_ABI_V1;
        aggregate.struct_size = sizeof(aggregate);
        require(!mrnx_bridge_v1_runtime_copy_aggregate_snapshot(
                    runtime, &aggregate),
                "unpublished full-body root escaped the aggregate reader");
        mrnx_aggregate_snapshot_v2 aggregateV2{};
        aggregateV2.abi_version = MRNX_AGGREGATE_SNAPSHOT_ABI_V2;
        aggregateV2.struct_size = sizeof(aggregateV2);
        mrnx_aggregate_snapshot_v3 aggregateV3{};
        aggregateV3.abi_version = MRNX_AGGREGATE_SNAPSHOT_ABI_V3;
        aggregateV3.struct_size = sizeof(aggregateV3);
        mrnx_aggregate_snapshot_v4 aggregateV4{};
        aggregateV4.abi_version = MRNX_AGGREGATE_SNAPSHOT_ABI_V4;
        aggregateV4.struct_size = sizeof(aggregateV4);
        require(!mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v2(
                    runtime, &aggregateV2) &&
                    !mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v3(
                        runtime, &aggregateV3) &&
                    !mrnx_bridge_v1_runtime_copy_aggregate_snapshot_v4(
                        runtime, &aggregateV4),
                "unpublished root escaped an extensible aggregate reader");
        require(mrnx_bridge_v1_quarantine_timeout(completion.prepared),
                "prepared-only qualification did not quarantine on timeout");
        mrnx_bridge_v1_candidate_drop(completion.candidate);
        mrnx_bridge_v1_prepared_drop(completion.prepared);
        mrnx_bridge_v1_runtime_drop(runtime);
        std::filesystem::remove(culturePath);
        std::printf(
            "numanx_fullbody_bridge_probe=pass bodies=%u nq=%u nv=%u "
            "muscles=%u motor_wait=ordered physical=prepared "
            "sensor=unpublished timeout=quarantined\n",
            info.body_count, info.q_coordinate_count, info.dof_count,
            info.muscle_count);
        return 0;
    }
}

} // namespace

int main(int argc, char** argv) {
    try {
        if (argc==2 && std::string(argv[1])=="--touch-aggregation-only") {
            @autoreleasepool {qualifyTouchAggregation(MTLCreateSystemDefaultDevice());return 0;}
        }
        if ((argc==7 || argc==8 || argc==9) && (std::string(argv[1])=="--prepared-stance-fixture" || std::string(argv[1])=="--prepared-state-fixture")) {
            std::uint64_t timestep = 100u;
            if (argc >= 8) {
                const std::string value(argv[7]);
                require(!value.empty() && value.find_first_not_of("0123456789") == std::string::npos,
                    "prepared fixture timestep must be an unsigned integer");
                timestep = std::stoull(value);
            }
            std::uint32_t iterations = 16u;
            if (argc == 9) {
                const std::string value(argv[8]);
                require(!value.empty() && value.find_first_not_of("0123456789") == std::string::npos,
                    "Newton iteration budget must be an unsigned integer");
                const auto parsed = std::stoull(value);
                require(parsed > 0u && parsed <= 128u, "invalid Newton iteration budget");
                iterations = static_cast<std::uint32_t>(parsed);
            }
            return writePreparedStanceFixture(argv[2],argv[3],argv[4],argv[5],argv[6],timestep,
                std::string(argv[1])=="--prepared-state-fixture",iterations);
        }
        if (argc==2 && std::string(argv[1])=="--support-only") {
            @autoreleasepool {
                id<MTLDevice> device=MTLCreateSystemDefaultDevice();
                require(device!=nil,"Metal device unavailable");
                for (unsigned shape=0;shape<3;++shape) qualifyHumanSupportKKT(device,shape);
                std::puts("numanx_support_surface_probe=pass shapes=point,sphere,ellipsoid rollback=exact");
                return 0;
            }
        }
        require(argc == 1 || (argc == 2 &&
                    (std::string(argv[1]) == "--authored-world" ||
                     std::string(argv[1]) == "--source-equalities" ||
                     std::string(argv[1]) == "--costal-tissue")),
                "usage: numanx_fullbody_bridge_probe [--authored-world|--source-equalities|--costal-tissue|--support-only]");
        const bool costal=argc==2&&std::string(argv[1])=="--costal-tissue";
        return run(argc == 2, costal||(argc == 2 && std::string(argv[1]) == "--source-equalities"),costal);
    } catch (const std::exception& error) {
        std::fprintf(stderr, "%s\n", error.what());
        return 1;
    }
}
