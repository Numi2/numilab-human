import Foundation
import Metal
import XCTest

@testable import NumiBrainCore
@_spi(NumanXInterop) @testable import NumiBrainMetal
import NumiBrainMLX
import NumiBrainMetalBridgeABI

@available(macOS 26.0, *)
final class MetalNumanXBridgeV1EndToEndTests: XCTestCase {
  /// Physical controller transport qualification. NHMYO oracle lengths bind the
  /// authored low-gain candidate; these are not independently calibrated gains.
  func testActiveMuscleLocomotorAcceptedRoots() throws {
    let paths = try bridgePaths()
    let device = try XCTUnwrap(MTLCreateSystemDefaultDevice())
    let native = try makeNativeRuntime(paths: paths, device: device, timestepMicroseconds: 100)
    let compiled = try NumanXFullBodyTransportTemplate.compile(latencyMicroseconds: 100,
      anatomy: native.fullBodyAnatomy())
    let publication = try BrainParameterPublication.developmentalSeedV1(species: compiled.species,
      tissueParameters: .corticalSheetV0)
    let payload = try Data(contentsOf: URL(fileURLWithPath: paths.muscle))
    func word(_ offset: Int) -> UInt32 { payload.withUnsafeBytes { UInt32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self)) } }
    XCTAssertEqual(word(16), 416)
    let muscleOffset = 76 + Int(word(20)) * 16 + Int(word(24)) * 64 + Int(word(28)) * 16
    let channels = (UInt32(0)..<416).map { id in
      MuscleLocomotorChannel(muscleIdentifier: id,
        referenceLengthMeters: Float(bitPattern: word(muscleOffset + Int(id) * 164 + 16 + 35 * 4)),
        tonicExcitation: 0.03, lengthGain: 0.4, velocityGainSeconds: 0.02,
        // An explicit one-channel periodic transport probe; no gait claim.
        gaitSine: id == 0 ? 0.02 : 0)
    }
    let program = MuscleLocomotorProgram(modelSourceFingerprint: native.info.modelSourceFingerprint,
      sensoryProfileFingerprint: compiled.sensoryProfile.fingerprint,
      calibrationArtifactSHA256: BrainPolicyEvidenceArtifact.sha256(payload),
      periodMicroseconds: 1_000_000, channels: channels)
    try program.validate(template: compiled)
    if let output = ProcessInfo.processInfo.environment["NUMANX_LOCOMOTOR_EVIDENCE_DIR"] {
      let directory = URL(fileURLWithPath: output, isDirectory: true)
      try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
      let encoder = JSONEncoder(); encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
      try encoder.encode(program).write(to: directory.appendingPathComponent("native-periodic-probe.json"), options: .atomic)
    }
    let active = try runAcceptedScenario(paths: paths, contactPath: paths.contacts,
      compiled: compiled, publication: publication, device: device, rootCount: 4,
      timestepMicroseconds: 100, muscleLocomotor: program)
    let replay = try runAcceptedScenario(paths: paths, contactPath: paths.contacts,
      compiled: compiled, publication: publication, device: device, rootCount: 4,
      timestepMicroseconds: 100, muscleLocomotor: program)
    let unavailable = try runAcceptedScenario(paths: paths, contactPath: paths.contacts,
      compiled: compiled, publication: publication, device: device, rootCount: 4,
      timestepMicroseconds: 100, muscleLocomotor: program, sensorIntervention: .ablated(.proprioception))
    XCTAssertEqual(active.motorExcitationsByGeneration.first!, [Float](repeating: 0, count: 416),
      "bootstrap is unavailable; no synthetic first-root excitation")
    let peak = active.motorExcitationsByGeneration.dropFirst().flatMap { $0 }.max() ?? 0
    XCTAssertGreaterThan(peak, 0)
    XCTAssertEqual(active.motorExcitationsByGeneration, replay.motorExcitationsByGeneration)
    XCTAssertEqual(active.sensorFingerprints, replay.sensorFingerprints)
    XCTAssertTrue(unavailable.motorExcitationsByGeneration.flatMap { $0 }.allSatisfy { $0 == 0 })
    XCTAssertNotEqual(active.sensorFingerprints, unavailable.sensorFingerprints)
    // Require native state and force response, not just the echoed excitation
    // channel. NHMYO2 activation previously froze once fibre length was set.
    func feature(_ scenario: AcceptedScenario, _ index: Int) throws -> [[Float]] {
      try scenario.sensorValuesByGeneration.map { frame in
        let values = try XCTUnwrap(frame[.proprioception])
        return stride(from: index, to: values.count, by: 10).map { values[$0] }
      }
    }
    // The admitted compliant architecture reports the applied signed tendon
    // force in feature 6 and positive tension in feature 7, both in newtons.
    for (forces, tensions) in zip(try feature(active, 6), try feature(active, 7)) {
      for (force, tension) in zip(forces, tensions) {
        XCTAssertEqual(tension, max(-force, 0), accuracy: 1e-5)
      }
    }
    let activation = try feature(active, 1)
    XCTAssertTrue(activation.dropFirst().allSatisfy { ($0.max() ?? 0) > 0 },
      "activation must advance and persist in initialized fibres")
    XCTAssertTrue(try feature(unavailable, 1).flatMap { $0 }.allSatisfy { $0 == 0 })
    XCTAssertNotEqual(try feature(active, 6), try feature(unavailable, 6),
      "applied musculotendon force must respond, not only command metadata")
    for (label, scenario) in [("active", active), ("unavailable", unavailable)] {
      for (index, frame) in scenario.sensorValuesByGeneration.enumerated() {
        let proprio = try XCTUnwrap(frame[.proprioception])
        let peaks = [0, 1, 6, 7].map { feature in
          stride(from: feature, to: proprio.count, by: 10).map { abs(proprio[$0]) }.max() ?? 0
        }
        print("locomotor_physical mode=\(label) root=\(index+1) excitation_activation_appliedforceN_tensionN=\(peaks)")
      }
    }
    print("muscle_locomotor_native=observed device=\(device.name) roots=4 timestep_us=100 peak_excitation=\(peak) replay=byte_exact unavailable=zero boundary=controller_transport_not_standing_or_walking")
  }

  /// Equal-duration controller comparison at the native-admitted prepared pose.
  /// The independent loaded-equilibrium and behavior gates remain separate.
  func testPreparedRecruitmentAcceptedRoots() throws {
    try qualifyPreparedRecruitment(rootCount: 4)
  }

  func testPreparedRecruitmentSixMillisecondHorizon() throws {
    try qualifyPreparedRecruitment(rootCount: 64)
  }

  private func qualifyPreparedRecruitment(rootCount: UInt64) throws {
    guard let programPath = ProcessInfo.processInfo.environment["NUMANX_PREPARED_RECRUITMENT"] else {
      throw XCTSkip("prepared recruitment program is not configured")
    }
    let world = try configuredAuthoredWorld()
    let initial = try XCTUnwrap(world.preparedInitialState)
    let paths = try bridgePaths(), device = try XCTUnwrap(MTLCreateSystemDefaultDevice())
    let native = try makeNativeRuntime(paths: paths, device: device, timestepMicroseconds: 100, authoredWorld: world)
    let compiled = try NumanXFullBodyTransportTemplate.compile(latencyMicroseconds: 100, anatomy: native.fullBodyAnatomy())
    let program = try JSONDecoder().decode(MuscleLocomotorProgram.self, from: Data(contentsOf: URL(fileURLWithPath: programPath)))
    try program.validate(template: compiled)
    XCTAssertEqual(program.calibrationArtifactSHA256,
      BrainPolicyEvidenceArtifact.sha256(try Data(contentsOf: URL(fileURLWithPath: initial.payloadPath))))
    XCTAssertEqual(program.channels.map(\.tonicExcitation).max(), 1)
    XCTAssertTrue(program.channels.allSatisfy { $0.lengthGain == 0 && $0.velocityGainSeconds == 0 })
    let publication = try BrainParameterPublication.developmentalSeedV1(species: compiled.species, tissueParameters: .corticalSheetV0)
    func run(_ controller: MuscleLocomotorProgram?, unavailable: Bool = false) throws -> AcceptedScenario {
      try runAcceptedScenario(paths: paths, contactPath: paths.contacts, compiled: compiled,
        publication: publication, device: device, rootCount: rootCount, timestepMicroseconds: 100,
        muscleLocomotor: controller, sensorIntervention: unavailable ? .ablated(.proprioception) : nil,
        authoredWorld: world)
    }
    // Preserve every completed scenario even if a later one fails or times out.
    let active = try run(program)
    try emitPreparedTrace("recruited", active)
    let replay = try run(program)
    try emitPreparedTrace("replay", replay)
    let zero = try run(nil)
    try emitPreparedTrace("zero", zero)
    let unavailable = try run(program, unavailable: true)
    try emitPreparedTrace("unavailable", unavailable)
    XCTAssertEqual(active.motorExcitationsByGeneration, replay.motorExcitationsByGeneration)
    XCTAssertEqual(active.sensorFingerprints, replay.sensorFingerprints)
    XCTAssertTrue(active.motorExcitationsByGeneration[0].allSatisfy { $0 == 0 })
    XCTAssertTrue(active.motorExcitationsByGeneration.dropFirst().allSatisfy { ($0.max() ?? 0) > 0 })
    XCTAssertTrue(active.motorExcitationsByGeneration.flatMap { $0 }.allSatisfy { $0.isFinite && (0...1).contains($0) })
    XCTAssertTrue(unavailable.motorExcitationsByGeneration.flatMap { $0 }.allSatisfy { $0 == 0 })
    XCTAssertTrue(zero.motorExcitationsByGeneration.flatMap { $0 }.allSatisfy { $0 == 0 })
    for modality in [SensoryModality.kinesthesia, .vestibular, .proprioception, .touch] {
      XCTAssertEqual(active.sensorValuesByGeneration[0][modality], zero.sensorValuesByGeneration[0][modality],
        "identical initial state and zero first command must reproduce physical state")
      for index in 0..<Int(rootCount) {
        XCTAssertEqual(zero.sensorValuesByGeneration[index][modality], unavailable.sensorValuesByGeneration[index][modality],
          "zero-command physical state must survive receptor ablation at root \(index + 1)")
      }
    }
    func muscleFeature(_ scenario: AcceptedScenario, _ feature: Int) throws -> [Float] {
      stride(from: feature, to: 4160, by: 10).map { scenario.finalSensorValuesByModality[.proprioception]![$0] }
    }
    XCTAssertNotEqual(try muscleFeature(active, 1), try muscleFeature(zero, 1), "activation must respond")
    XCTAssertNotEqual(try muscleFeature(active, 6), try muscleFeature(zero, 6), "applied force must respond")
    print("prepared_recruitment=observed roots_per_scenario=\(rootCount) timestep_us=100 replay=bitwise unavailable=zero boundary=controller_transport_not_loaded_equilibrium_or_standing")
  }

  private func emitPreparedTrace(_ label: String, _ scenario: AcceptedScenario, timestepMicroseconds: UInt32 = 100) throws {
    for (index, frame) in scenario.sensorValuesByGeneration.enumerated() {
      try emitPreparedFrame(label, rootIndex: index + 1, frame: frame,
        motorExcitations: scenario.motorExcitationsByGeneration[index], timestepMicroseconds: timestepMicroseconds)
    }
  }

  private func emitPreparedFrame(_ label: String, rootIndex: Int,
    frame: [SensoryModality: [Float]], motorExcitations: [Float], timestepMicroseconds: UInt32) throws {
    let root = try XCTUnwrap(frame[.vestibular]), k = try XCTUnwrap(frame[.kinesthesia])
    let q = Array(root.prefix(7)) + (6..<128).map { k[7 * $0] }
    let v = (0..<128).map { k[7 * $0 + 1] }
    func packed(_ values: [Float]) -> String {
      var bytes = Data()
      for value in values { var word = value.bitPattern.littleEndian; withUnsafeBytes(of: &word) { bytes.append(contentsOf: $0) } }
      return bytes.base64EncodedString()
    }
    let proprioception = try XCTUnwrap(frame[.proprioception])
    // Feature 6 is signed applied force; feature 7 is positive tendon
    // tension. Retain the fibre/path fields to locate physical drift.
    let muscleFields = [("activation", 1), ("fiber_length", 2), ("fiber_velocity", 3),
                        ("path_length", 4), ("path_velocity", 5), ("applied_force", 6),
                        ("tendon_tension", 7), ("fiber_residual", 9)].map { name, feature in
      (name, stride(from: feature, to: proprioception.count, by: 10).map { proprioception[$0] })
    }
    // Separate bounded records preserve state, command and force bytes atomically.
    for (kind, values) in [("qv", q + v), ("motor", motorExcitations)] + muscleFields {
      let object: [String: Any] = ["schema": "numi.human.prepared-recruitment-trace.v2", "scenario": label,
        "root": rootIndex, "elapsed_microseconds": rootIndex * Int(timestepMicroseconds), "kind": kind,
        "fp32_le_base64": packed(values)]
      let data = try JSONSerialization.data(withJSONObject: object, options: [.sortedKeys])
      let line = Data(("prepared_recruitment=" + String(decoding: data, as: UTF8.self) + "\n").utf8)
      XCTAssertLessThan(line.count, 4096)
      XCTAssertEqual(line.withUnsafeBytes { Darwin.write(STDOUT_FILENO, $0.baseAddress, $0.count) }, line.count)
    }
  }

  /// Equal physical duration, zero delivered command and the identical prepared
  /// q/v/fibre payload. Cross-timestep convergence is checked by the retained
  /// independent trace reducer; this test qualifies execution and replay only.
  func testPreparedNativeTimestepTrajectory() throws {
    let environment = ProcessInfo.processInfo.environment
    guard let rawTimestep = environment["NUMANX_PREPARED_TIMESTEP_US"] else {
      throw XCTSkip("prepared timestep trajectory is not configured")
    }
    let timestep = try XCTUnwrap(UInt32(rawTimestep))
    let duration = try XCTUnwrap(UInt32(environment["NUMANX_PREPARED_DURATION_US"] ?? "1600"))
    guard timestep > 0, duration > 0, duration % timestep == 0, duration / timestep <= 256 else {
      XCTFail("invalid bounded timestep trajectory duration"); return
    }
    let world = try configuredAuthoredWorld()
    _ = try XCTUnwrap(world.preparedInitialState)
    let paths = try bridgePaths(), device = try XCTUnwrap(MTLCreateSystemDefaultDevice())
    let native = try makeNativeRuntime(paths: paths, device: device,
      timestepMicroseconds: timestep, authoredWorld: world)
    // The current native receptor contract has one-root latency. Every motor
    // command is zero, so this delay change cannot drive the physics comparison.
    let compiled = try NumanXFullBodyTransportTemplate.compile(latencyMicroseconds: timestep,
      anatomy: native.fullBodyAnatomy())
    let publication = try BrainParameterPublication.developmentalSeedV1(species: compiled.species,
      tissueParameters: .corticalSheetV0)
    func run(_ label: String) throws -> AcceptedScenario {
      try runAcceptedScenario(paths: paths, contactPath: paths.contacts, compiled: compiled,
        publication: publication, device: device, rootCount: UInt64(duration / timestep),
        timestepMicroseconds: timestep, authoredWorld: world,
        initialTimestampMicroseconds: 100, preparedTraceLabel: label)
    }
    let zero = try run("zero")
    let replay = try run("replay")
    XCTAssertTrue(zero.motorExcitationsByGeneration.flatMap { $0 }.allSatisfy { $0 == 0 })
    XCTAssertEqual(zero.sensorFingerprints, replay.sensorFingerprints)
    XCTAssertEqual(zero.sensorValuesByGeneration, replay.sensorValuesByGeneration)
    print("prepared_timestep=observed roots_per_scenario=\(duration / timestep) timestep_us=\(timestep) duration_us=\(duration) replay=bitwise boundary=bounded_native_trajectory")
  }

  func testAuthoredMatterDescriptorRejectsMissingIdentity() throws {
    typealias World = MetalNumanXBridgeV1Runtime.AuthoredMatterWorld
    XCTAssertThrowsError(try World(packagePath: "", humanSourceFingerprint: 1, worldFingerprint: 2))
    XCTAssertThrowsError(try World(packagePath: "world\0other", humanSourceFingerprint: 1, worldFingerprint: 2))
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 0, worldFingerprint: 2))
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 1, worldFingerprint: 0))
    let world = try World(packagePath: "world", humanSourceFingerprint: 1, worldFingerprint: 2)
    XCTAssertEqual(world.humanSourceFingerprint, 1)
    XCTAssertEqual(world.worldFingerprint, 2)
  }

  func testSourceJointEqualitiesDescriptorAndConfigurationV4Layout() throws {
    typealias Equalities = MetalNumanXBridgeV1Runtime.SourceJointEqualities
    XCTAssertThrowsError(try Equalities(payloadPath: "", fingerprint: 1))
    XCTAssertThrowsError(try Equalities(payloadPath: "source\0other", fingerprint: 1))
    XCTAssertThrowsError(try Equalities(payloadPath: "source.nheq", fingerprint: 0))
    let equalities = try Equalities(payloadPath: "source.nheq", fingerprint: 0x4e48455132)
    let world = try MetalNumanXBridgeV1Runtime.AuthoredMatterWorld(
      packagePath: "world", humanSourceFingerprint: 1, worldFingerprint: 2,
      sourceJointEqualities: equalities)
    XCTAssertEqual(world.sourceJointEqualities?.payloadPath, "source.nheq")
    XCTAssertEqual(world.sourceJointEqualities?.fingerprint, 0x4e48455132)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v3>.stride, 168)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v4>.stride, 192)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v4>.offset(of: \.runtime), 8)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v4>.offset(of: \.joint_equality_payload_path), 176)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v4>.offset(of: \.expected_joint_equality_fingerprint), 184)
  }

  func testSourceJointLimitsRequireSourceOwnerAndV6Layout() throws {
    typealias Limits = MetalNumanXBridgeV1Runtime.SourceJointLimits
    typealias World = MetalNumanXBridgeV1Runtime.AuthoredMatterWorld
    XCTAssertThrowsError(try Limits(payloadPath: "", fingerprint: 1))
    XCTAssertThrowsError(try Limits(payloadPath: "source\0other", fingerprint: 1))
    XCTAssertThrowsError(try Limits(payloadPath: "source.nhlim", fingerprint: 0))
    let limits = try Limits(payloadPath: "source.nhlim", fingerprint: 5)
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 1,
      worldFingerprint: 2, sourceJointLimits: limits))
    let world = try World(packagePath: "world", humanSourceFingerprint: 1, worldFingerprint: 2,
      sourceJointEqualities: .init(payloadPath: "source.nheq", fingerprint: 4), sourceJointLimits: limits)
    XCTAssertEqual(world.sourceJointLimits?.fingerprint, 5)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.stride, 240)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.offset(of: \.joint_limit_payload_path), 200)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.offset(of: \.expected_joint_limit_fingerprint), 208)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.offset(of: \.costal_cartilage_payload_path), 216)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.offset(of: \.costal_binding_payload_path), 224)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v6>.offset(of: \.expected_costal_binding_fingerprint), 232)
  }

  func testPreparedInitialStateRequiresCompleteSourceOwnerAndV7Layout() throws {
    typealias Initial = MetalNumanXBridgeV1Runtime.PreparedInitialState
    typealias World = MetalNumanXBridgeV1Runtime.AuthoredMatterWorld
    XCTAssertThrowsError(try Initial(payloadPath: "", fingerprint: 1))
    XCTAssertThrowsError(try Initial(payloadPath: "initial\0other", fingerprint: 1))
    XCTAssertThrowsError(try Initial(payloadPath: "initial.nhinit", fingerprint: 0))
    let initial = try Initial(payloadPath: "initial.nhinit", fingerprint: 8)
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 1,
      worldFingerprint: 2, preparedInitialState: initial))
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 1,
      worldFingerprint: 2, sourceJointEqualities: .init(payloadPath: "eq", fingerprint: 3),
      preparedInitialState: initial))
    let world = try World(packagePath: "world", humanSourceFingerprint: 1, worldFingerprint: 2,
      sourceJointEqualities: .init(payloadPath: "eq", fingerprint: 3),
      sourceJointLimits: .init(payloadPath: "limit", fingerprint: 4), preparedInitialState: initial)
    XCTAssertEqual(world.preparedInitialState?.fingerprint, 8)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v7>.stride, 264)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v7>.offset(of: \.initial_state_payload_path), 248)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v7>.offset(of: \.expected_initial_state_fingerprint), 256)
  }

  func testCostalOwnershipRequiresConstrainedWorldAndV5Layout() throws {
    typealias Tissue = MetalNumanXBridgeV1Runtime.CostalTissueOwnership
    typealias World = MetalNumanXBridgeV1Runtime.AuthoredMatterWorld
    XCTAssertThrowsError(try Tissue(cartilagePayloadPath: "", bindingPayloadPath: "binding", bindingFingerprint: 1))
    XCTAssertThrowsError(try Tissue(cartilagePayloadPath: "cartilage", bindingPayloadPath: "binding\0other", bindingFingerprint: 1))
    XCTAssertThrowsError(try Tissue(cartilagePayloadPath: "cartilage", bindingPayloadPath: "binding", bindingFingerprint: 0))
    let tissue = try Tissue(cartilagePayloadPath: "cartilage", bindingPayloadPath: "binding", bindingFingerprint: 3)
    XCTAssertThrowsError(try World(packagePath: "world", humanSourceFingerprint: 1,
      worldFingerprint: 2, costalTissueOwnership: tissue))
    let world = try World(packagePath: "world", humanSourceFingerprint: 1,
      worldFingerprint: 2, sourceJointEqualities: .init(payloadPath: "equalities", fingerprint: 4),
      costalTissueOwnership: tissue)
    XCTAssertEqual(world.costalTissueOwnership?.bindingFingerprint, 3)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v5>.stride, 224)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v5>.offset(of: \.runtime), 8)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v5>.offset(of: \.costal_cartilage_payload_path), 200)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v5>.offset(of: \.costal_binding_payload_path), 208)
    XCTAssertEqual(MemoryLayout<mrnx_runtime_config_v5>.offset(of: \.expected_costal_binding_fingerprint), 216)
  }

  func testGateBAcceptedDevelopmentEnablesAutonomousPhysicalGaze() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let capabilityCodes = compiled.species.development
      .dropFirst()
      .flatMap(\.capabilityGateCodes)
    XCTAssertEqual(capabilityCodes, Array(UInt64(1)...UInt64(11)))

    let immature = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7
    )
    let mature = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7,
      developmentalCapabilityCodes: capabilityCodes
    )
    let replay = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7,
      developmentalCapabilityCodes: capabilityCodes
    )
    XCTAssertEqual(immature.activeVisionCommands, [Float](repeating: 0, count: 7))
    XCTAssertEqual(mature.activeVisionCommands.count, 7)
    XCTAssertTrue(mature.activeVisionCommands.allSatisfy(\.isFinite))
    XCTAssertEqual(Array(mature.activeVisionCommands.prefix(6)), [Float](repeating: 0, count: 6))
    XCTAssertGreaterThan(abs(try XCTUnwrap(mature.activeVisionCommands.last)), 1.0e-6)
    XCTAssertGreaterThan(try XCTUnwrap(mature.activeVisionConfidences.last), 0)
    XCTAssertEqual(mature.activeVisionCommands, replay.activeVisionCommands)
    XCTAssertEqual(mature.activeVisionConfidences, replay.activeVisionConfidences)
    XCTAssertEqual(mature.sensorFingerprints, replay.sensorFingerprints)
    XCTAssertEqual(mature.finalSensorValuesByModality, replay.finalSensorValuesByModality)
    let visionDelta = maximumAbsoluteDelta(
      try XCTUnwrap(immature.finalSensorValuesByModality[.vision]),
      try XCTUnwrap(mature.finalSensorValuesByModality[.vision])
    )
    XCTAssertGreaterThan(visionDelta, 1.0e-6)
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      print(
        "gate_b_autonomous_gaze=pass command=\(try XCTUnwrap(mature.activeVisionCommands.last)) "
          + "confidence=\(try XCTUnwrap(mature.activeVisionConfidences.last)) "
          + "vision_delta=\(visionDelta) replay=byte_exact"
      )
    }
  }

  func testGateBRejectedDevelopmentDoesNotUnlockAutonomousGazeEarly() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let capabilityCodes = compiled.species.development
      .dropFirst()
      .flatMap(\.capabilityGateCodes)
    let parameters = TissueParameters.corticalSheetV0
    let brain = try MetalNumiBrainRuntime.makeRuntime(
      configuration: MetalNumiBrainConfiguration(
        initialTissueState: try CPUTissueDynamics.makeRestingGrid(
          width: 8, height: 8, parameters: parameters
        ),
        tissueParameters: parameters,
        tissueStimulus: .none,
        compiledSpeciesTemplate: compiled,
        randomContext: TissueRandomContext(
          seed: 0x4e55_4d49,
          environmentIdentifier: 0,
          episodeIdentifier: 1
        ),
        schedulerEnvironmentIdentifier: 0,
        maximumEncodedSubsteps: 1
      ),
      publication: publication,
      device: device
    )
    let native = try MetalNumanXBridgeV1Runtime(
      libraryPath: paths.library,
      device: device,
      configuration: .init(
        rigidPayloadPath: paths.rigid,
        musclePayloadPath: paths.muscle,
        supportContactPayloadPath: paths.contacts,
        visualPackPath: paths.visualPack,
        visionProfilePath: paths.visionProfile,
        metalRoboMetallibPath: paths.metalRoboMetallib,
        matterMetallibPath: paths.matterMetallib,
        matterMaterialPath: paths.material,
        timestepMicroseconds: 1_000,
        transactionSlotCount: 2
      )
    )
    var aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot?
    var acceptedCommands: [Float] = []

    func transaction(_ controlStep: UInt64)
      throws -> MetalNumiBrainRuntime.ControlTransaction
    {
      try brain.beginControl(
        controlStepIdentifier: controlStep,
        basePhysicsGeneration: aggregate?.physicsGeneration ?? 0,
        committedTimestamp: BrainTimestamp(
          microseconds: controlStep * 1_000
        ),
        targetTimestamp: BrainTimestamp(
          microseconds: (controlStep + 1) * 1_000
        ),
        cachedDecisionFingerprint: 0x4e58_4742_524a_0000 | controlStep
      )
    }

    func sensors(
      for transaction: MetalNumiBrainRuntime.ControlTransaction
    ) throws -> NumanXSensorPacketLease {
      if let aggregate {
        return try aggregate.sensorPacket(
          for: transaction.token,
          compiledSpeciesTemplate: compiled
        )
      }
      return try bootstrapSensorPacket(
        device: device,
        compiled: compiled,
        transaction: transaction.token
      )
    }

    func accept(_ controlStep: UInt64) throws {
      let transaction = try transaction(controlStep)
      let published = try publishRoot(
        brain: brain,
        native: native,
        transaction: transaction,
        sensors: try sensors(for: transaction),
        device: device,
        developmentalCapabilityCodes: capabilityCodes
      )
      aggregate = published.aggregate
      acceptedCommands.append(published.activeVisionCommand)
    }

    for controlStep in UInt64(1)...UInt64(4) {
      try accept(controlStep)
    }
    XCTAssertEqual(acceptedCommands, [Float](repeating: 0, count: 4))

    // Encode all capability claims into the private developmental shadow, then
    // reject the exact physical root. None may become committed authority.
    let rejectedTransaction = try transaction(5)
    let rejected = try prepareRoot(
      brain: brain,
      native: native,
      transaction: rejectedTransaction,
      sensors: try sensors(for: rejectedTransaction),
      device: device,
      developmentalCapabilityCodes: capabilityCodes
    )
    XCTAssertEqual(rejected.activeVisionCommand, 0)
    XCTAssertTrue(rejected.physical.quarantineTimeout())
    let proposalLatch = AsyncResultLatch<MetalNumanXHumanMatterProposalLease>()
    try rejected.physical.submitTimeoutRejectProposal {
      proposalLatch.complete($0)
    }
    _ = try proposalLatch.wait()
    try rejected.physical.reserveTimeoutRejectApplication(
      brain: rejected.prepared
    )
    let applyLatch = AsyncResultLatch<MetalNumanXHumanMatterAppliedLease>()
    try rejected.physical.submitTimeoutRejectApply {
      applyLatch.complete($0)
    }
    XCTAssertEqual(
      try applyLatch.wait().commandDisposition,
      .rejectedReleased
    )
    XCTAssertTrue(rejected.physical.releaseRejected())
    try brain.abortNumanXPreparedControl(rejected.prepared)
    XCTAssertFalse(brain.hasOpenControl)
    XCTAssertEqual(brain.committedGeneration, 4)
    let afterReject = try XCTUnwrap(native.aggregateSnapshotIfAvailable())
    XCTAssertEqual(afterReject.brainGeneration, 4)
    XCTAssertEqual(afterReject.physicsGeneration, 4)
    aggregate = afterReject

    // If the rejected claims had advanced maturity, step 6 would already see
    // stage 6 and emit gaze. The retry and step 6 must remain silent; only the
    // next decision, after six accepted roots, may actuate the physical camera.
    try accept(5)
    try accept(6)
    XCTAssertEqual(Array(acceptedCommands.suffix(2)), [0, 0])
    try accept(7)
    let matureCommand = try XCTUnwrap(acceptedCommands.last)
    XCTAssertGreaterThan(abs(matureCommand), 1.0e-6)
    XCTAssertEqual(brain.committedGeneration, 7)
    XCTAssertEqual(aggregate?.physicsGeneration, 7)
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      print(
        "gate_b_rejected_development=pass committed_after_reject=4 "
          + "step6_command=0.0 step7_command=\(matureCommand)"
      )
    }
  }

  func testGateBMalformedDevelopmentalIntentCannotUnlockGaze() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let capabilityCodes = compiled.species.development
      .dropFirst()
      .flatMap(\.capabilityGateCodes)
    let malformed = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7,
      developmentalCapabilityCodes: capabilityCodes,
      developmentalIntentFingerprintXor: 1
    )
    XCTAssertEqual(malformed.activeVisionCommands, [Float](repeating: 0, count: 7))
    XCTAssertEqual(malformed.activeVisionConfidences, [Float](repeating: 0, count: 7))
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      print("gate_b_malformed_developmental_intent=pass gaze_locked=true")
    }
  }

  func testGateBAutonomousGazeImprovesPredeclaredVisualSearchCoverage() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let capabilityCodes = compiled.species.development
      .dropFirst()
      .flatMap(\.capabilityGateCodes)

    // Predeclared outcome: maximize physically valid RGB-D geometry coverage
    // in the seventh root. The ablation scales only the active-sensing record
    // to zero before the ordinary decision-ready proof hashes it.
    let intact = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7,
      developmentalCapabilityCodes: capabilityCodes
    )
    let ablated = try runAcceptedScenario(
      paths: paths,
      contactPath: paths.contacts,
      compiled: compiled,
      publication: publication,
      device: device,
      rootCount: 7,
      developmentalCapabilityCodes: capabilityCodes,
      activeSensingCommandScale: 0
    )
    XCTAssertGreaterThan(abs(try XCTUnwrap(intact.activeVisionCommands.last)), 0)
    XCTAssertEqual(ablated.activeVisionCommands, [Float](repeating: 0, count: 7))
    XCTAssertEqual(ablated.activeVisionConfidences, [Float](repeating: 0, count: 7))
    XCTAssertEqual(
      intact.motorExcitationsByGeneration,
      ablated.motorExcitationsByGeneration
    )
    XCTAssertEqual(
      intact.descendingSomaticByGeneration,
      ablated.descendingSomaticByGeneration
    )
    XCTAssertEqual(
      Array(intact.visionDepthValidCounts.prefix(6)),
      Array(ablated.visionDepthValidCounts.prefix(6))
    )
    XCTAssertEqual(
      Array(intact.visionGeometryValidCounts.prefix(6)),
      Array(ablated.visionGeometryValidCounts.prefix(6))
    )
    let intactDepth = try XCTUnwrap(intact.visionDepthValidCounts.last)
    let ablatedDepth = try XCTUnwrap(ablated.visionDepthValidCounts.last)
    let intactGeometry = try XCTUnwrap(intact.visionGeometryValidCounts.last)
    let ablatedGeometry = try XCTUnwrap(ablated.visionGeometryValidCounts.last)
    XCTAssertGreaterThan(intactDepth, ablatedDepth)
    XCTAssertGreaterThan(intactGeometry, ablatedGeometry)
    for modality in compiled.species.senses.map(\.modality) where modality != .vision {
      XCTAssertEqual(
        intact.finalSensorValuesByModality[modality],
        ablated.finalSensorValuesByModality[modality],
        "active-gaze command ablation perturbed nonvisual \(modality)"
      )
    }
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      print(
        "gate_b_gaze_search_benefit=pass depth=\(ablatedDepth)->\(intactDepth) "
          + "geometry=\(ablatedGeometry)->\(intactGeometry) "
          + "nonvisual=byte_exact"
      )
    }
  }

  func testGateBExternalTaskOptionAdmission() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let heldoutTilt = try tiltedSupportContactAsset(
      sourcePath: paths.contacts, degrees: 0.1
    )
    defer { try? FileManager.default.removeItem(at: heldoutTilt) }
    var target = [Float](repeating: 0, count: 16)
    target[12] = 0.05
    target[13] = 0.05
    target[14] = 0.05
    let scenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      externalGoal: { controlStep in
        try self.supportStabilityGoal(target: target, controlStep: controlStep)
      }
    )
    let accepted = try acceptedTransitionEvidence(scenario.batch)
    XCTAssertEqual(accepted.count, 3)
    XCTAssertTrue(accepted.allSatisfy { $0.activeGoalIdentifier != 0 })
    XCTAssertTrue(accepted.allSatisfy { $0.activeOptionIdentifier >> 60 == 0x6 })
    XCTAssertTrue(accepted.allSatisfy { $0.damageCVaR <= 1 })
    XCTAssertTrue(accepted.allSatisfy { ($0.actions.map(abs).max() ?? 0) > 0 })
    XCTAssertGreaterThan(
      scenario.descendingSomaticByGeneration.dropFirst().flatMap { $0 }
        .map(abs).max() ?? 0,
      1.0e-6
    )
    let evidence = try XCTUnwrap(accepted.last)
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      let descending = try XCTUnwrap(
        scenario.descendingSomaticByGeneration.last
      )
      let groupMaxima = (0..<16).map { synergy in
        stride(from: synergy, to: descending.count, by: 16)
          .map { descending[$0] }.max() ?? 0
      }
      print(
        "GateB external-task admission goal=\(evidence.activeGoalIdentifier) "
          + "option=\(evidence.activeOptionIdentifier) "
          + "score=\(evidence.selectedScore) damage=\(evidence.damageCVaR) "
          + "actions=\(evidence.actions) "
          + "descendingGroupMaxima=\(groupMaxima)"
      )
    }
  }

  func testGateCExternalTaskUsesExactTargetBody() throws {
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    // This assertion targets the native head body (23). Compile the Brain
    // transport from the same immutable anatomy that the physical owner will
    // use; the default helper is intentionally a two-body synthetic fixture
    // for transport-only tests and cannot represent body 23.
    // Gate C qualification uses the production 100 µs physical cadence. A
    // millisecond step is useful for transport-only fixtures, but is too
    // coarse for this articulated Matter contact state and can make the
    // native factorization reject an otherwise valid zero-command retry.
    let gateCTimestepMicroseconds: UInt32 = 100
    let anatomyRuntime = try makeNativeRuntime(
      paths: paths,
      device: device,
      timestepMicroseconds: gateCTimestepMicroseconds
    )
    let compiled = try NumanXFullBodyTransportTemplate.compile(
      latencyMicroseconds: gateCTimestepMicroseconds,
      anatomy: try anatomyRuntime.fullBodyAnatomy()
    )
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    var target = [Float](repeating: 0, count: 16)
    target[2] = 0.25
    target[6] = 0.10
    target[10] = 0.05
    target[14] = 0.20
    let head = try runAcceptedScenario(
      paths: paths, contactPath: paths.contacts,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      timestepMicroseconds: gateCTimestepMicroseconds,
      externalGoal: { controlStep in
        try self.supportStabilityGoal(
          target: target,
          controlStep: controlStep,
          targetBodyIdentifier: 23,
          timestepMicroseconds: gateCTimestepMicroseconds
        )
      }
    )
    let root = try runAcceptedScenario(
      paths: paths, contactPath: paths.contacts,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      timestepMicroseconds: gateCTimestepMicroseconds,
      externalGoal: { controlStep in
        try self.supportStabilityGoal(
          target: target,
          controlStep: controlStep,
          targetBodyIdentifier: 0,
          timestepMicroseconds: gateCTimestepMicroseconds
        )
      }
    )
    let headDescending = head.descendingSomaticByGeneration.flatMap { $0 }
    let rootDescending = root.descendingSomaticByGeneration.flatMap { $0 }
    let targetBodyMotorDelta = maximumAbsoluteDelta(
      headDescending, rootDescending
    )
    XCTAssertGreaterThan(
      targetBodyMotorDelta, 1.0e-6,
      "changing only the authenticated target body did not change any motor output"
    )
    // The signed physical objective must deterministically reach the exact
    // slow motor gains consumed by this target-body path.
    let sourceRunHash = BrainPolicyEvidenceArtifact.sha256(
      Data("head-posture-learner-fixture".utf8)
    )
    let objective = try BrainPolicyNumanXHeadPostureLearningArtifact(
      sourceRunArtifactSHA256: sourceRunHash,
      coordinates: try BrainPolicyNumanXDatasetCoordinates(
        datasetSourceIdentifier: "head-posture-learner-fixture",
        datasetSourceRevision: "training",
        episodeIdentifier: 1,
        taskFingerprint: 1,
        sceneFingerprint: 2,
        objectFingerprint: 3,
        embodimentFingerprint: 4
      ),
      timestepMicroseconds: 100,
      objectiveWeight: 4,
      observation: try BrainPolicyNumanXHeadPostureObservation(
        runArtifactSHA256: sourceRunHash,
        rootCount: 100,
        initialControlStep: 2,
        terminalControlStep: 100,
        initialSampleSHA256: BrainPolicyEvidenceArtifact.sha256(
          Data("head-posture-initial".utf8)
        ),
        terminalSampleSHA256: BrainPolicyEvidenceArtifact.sha256(
          Data("head-posture-terminal".utf8)
        ),
        initialRelativeHeadHeightMeters: -0.33,
        terminalRelativeHeadHeightMeters: -0.330_093_45,
        meanActuatorCommand: 0.01,
        peakActuatorCommand: 0.3
      )
    )
    let foundation = MLXBrainLearnerConfiguration.foundationV1
    let learner = MLXBrainLearner(configuration:
      try MLXBrainLearnerConfiguration(
        learningRate: 0.1,
        gradientNormLimit: foundation.gradientNormLimit,
        parameterMagnitudeLimit: foundation.parameterMagnitudeLimit,
        lossWeights: foundation.lossWeights,
        headPostureObjectiveWeight: objective.objectiveWeight
      ))
    let update = try learner.update(
      parentPublication: publication,
      batch: head.batch,
      headPosture: objective
    )
    XCTAssertEqual(try learner.update(
      parentPublication: publication,
      batch: head.batch,
      headPosture: objective
    ), update)
    let successor = try BrainParameterPublication(
      parentVersion: publication.version,
      learnerUpdate: update
    )
    func motorParameters(_ source: BrainParameterPublication) -> [Float] {
      source.sharedArtifact.payload(.motor).data.withUnsafeBytes { raw in
        stride(from: 0, to: raw.count, by: MemoryLayout<UInt32>.stride).map {
          Float(bitPattern: UInt32(littleEndian: raw.loadUnaligned(
            fromByteOffset: $0, as: UInt32.self
          )))
        }
      }
    }
    let parentMotor = motorParameters(publication)
    let learnedMotor = motorParameters(successor)
    for kind in BrainSharedParameterArtifact.requiredKinds where kind != .motor {
      XCTAssertEqual(
        successor.sharedArtifact.payload(kind).data,
        publication.sharedArtifact.payload(kind).data,
        "head-posture intervention changed non-motor component \(kind)"
      )
    }
    for index in parentMotor.indices where ![3, 4].contains(index) {
      XCTAssertEqual(
        learnedMotor[index], parentMotor[index],
        "head-posture intervention changed motor scalar \(index)"
      )
    }
    XCTAssertEqual(learnedMotor[0], parentMotor[0])
    XCTAssertGreaterThan(learnedMotor[3], parentMotor[3])
    XCTAssertGreaterThan(learnedMotor[4], parentMotor[4])
    let calibratedObjective = try
      BrainPolicyNumanXHeadPostureLearningArtifact(
        sourceRunArtifactSHA256: sourceRunHash,
        coordinates: try BrainPolicyNumanXDatasetCoordinates(
          datasetSourceIdentifier: "head-posture-learner-fixture",
          datasetSourceRevision: "training",
          episodeIdentifier: 1,
          taskFingerprint: 1,
          sceneFingerprint: 2,
          objectFingerprint: 3,
          embodimentFingerprint: 4
        ),
        timestepMicroseconds: 100,
        objectiveWeight: 4,
        observation: objective.observation,
        calibrationEvaluationArtifactSHA256:
          BrainPolicyEvidenceArtifact.sha256(Data("negative-probe".utf8)),
        responseGainDirection: -1
      )
    let calibratedUpdate = try learner.update(
      parentPublication: publication,
      batch: head.batch,
      headPosture: calibratedObjective
    )
    XCTAssertEqual(try learner.update(
      parentPublication: publication,
      batch: head.batch,
      headPosture: calibratedObjective
    ), calibratedUpdate)
    let calibratedSuccessor = try BrainParameterPublication(
      parentVersion: publication.version,
      learnerUpdate: calibratedUpdate
    )
    let calibratedMotor = motorParameters(calibratedSuccessor)
    for kind in BrainSharedParameterArtifact.requiredKinds where kind != .motor {
      XCTAssertEqual(
        calibratedSuccessor.sharedArtifact.payload(kind).data,
        publication.sharedArtifact.payload(kind).data,
        "calibrated intervention changed non-motor component \(kind)"
      )
    }
    for index in parentMotor.indices where ![3, 4].contains(index) {
      XCTAssertEqual(
        calibratedMotor[index], parentMotor[index],
        "calibrated intervention changed motor scalar \(index)"
      )
    }
    XCTAssertEqual(calibratedMotor[0], parentMotor[0])
    XCTAssertLessThan(calibratedMotor[3], parentMotor[3])
    XCTAssertLessThan(calibratedMotor[4], parentMotor[4])
  }

  func testZZGateBHeldOutSupportTiltPolicyInterventions() throws {
    guard ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1"
    else {
      throw XCTSkip(
        "the Gate B causal cohort is an explicit isolated qualification"
      )
    }
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate()
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: .corticalSheetV0
    )
    let negativeTilt = try tiltedSupportContactAsset(
      sourcePath: paths.contacts, degrees: -2
    )
    let positiveTilt = try tiltedSupportContactAsset(
      sourcePath: paths.contacts, degrees: 2
    )
    let heldoutTilt = try tiltedSupportContactAsset(
      sourcePath: paths.contacts, degrees: 0.5
    )
    defer {
      try? FileManager.default.removeItem(at: negativeTilt)
      try? FileManager.default.removeItem(at: positiveTilt)
      try? FileManager.default.removeItem(at: heldoutTilt)
    }
    // The causal learner must observe accepted task actions. A passive tilted
    // cohort has different sensors but identically zero actions and therefore
    // cannot teach any sensory channel an action consequence.
    let selectedInterventionName = ProcessInfo.processInfo.environment[
      "NUMANX_GATE_B_INTERVENTION_MODALITY"
    ] ?? "audition"
    var stableTaskTarget = [Float](repeating: 0, count: 16)
    stableTaskTarget[12] = 0.05
    stableTaskTarget[13] = 0.05
    stableTaskTarget[14] = 0.05
    XCTAssertEqual(stableTaskTarget.count, 16)
    let taskGoal: (UInt64) throws -> ActiveGoal = { controlStep in
      try self.supportStabilityGoal(
        target: stableTaskTarget, controlStep: controlStep
      )
    }
    let negativeScenario = try runAcceptedScenario(
      paths: paths, contactPath: negativeTilt.path,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      externalGoal: taskGoal
    )
    let positiveScenario = try runAcceptedScenario(
      paths: paths, contactPath: positiveTilt.path,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      externalGoal: taskGoal
    )
    let cohort = try MetalLearningCohortBatch(members: [
      try MetalLearningCohortMember(
        mindIdentifier: 0x4e58_4742_0000_0001, batch: negativeScenario.batch
      ),
      try MetalLearningCohortMember(
        mindIdentifier: 0x4e58_4742_0000_0002, batch: positiveScenario.batch
      ),
    ])
    let negativeEvidence = try acceptedTransitionEvidence(negativeScenario.batch)
    let positiveEvidence = try acceptedTransitionEvidence(positiveScenario.batch)
    XCTAssertEqual(negativeEvidence.count, 3)
    XCTAssertEqual(positiveEvidence.count, 3)
    let cohortObservationDelta = maximumAbsoluteDelta(
      negativeEvidence.flatMap(\.observations),
      positiveEvidence.flatMap(\.observations)
    )
    let cohortActionDelta = maximumAbsoluteDelta(
      negativeEvidence.flatMap(\.actions),
      positiveEvidence.flatMap(\.actions)
    )
    let cohortSensorDelta = maximumAbsoluteDelta(
      negativeScenario.finalSensorValues,
      positiveScenario.finalSensorValues
    )
    let modalitySensorDeltas = Dictionary(uniqueKeysWithValues:
      negativeScenario.finalSensorValuesByModality.keys.map { modality in
        (
          modality,
          maximumAbsoluteDelta(
            negativeScenario.finalSensorValuesByModality[modality] ?? [],
            positiveScenario.finalSensorValuesByModality[modality] ?? []
          )
        )
      }
    )
    let firstSensorDivergence = Array(zip(
      negativeScenario.sensorFingerprints,
      positiveScenario.sensorFingerprints
    )).firstIndex { pair in pair.0 != pair.1 }.map { $0 + 1 }
    let firstCandidateSensorDivergence = Array(zip(
      negativeScenario.candidateSensorFingerprints,
      positiveScenario.candidateSensorFingerprints
    )).firstIndex { pair in pair.0 != pair.1 }.map { $0 + 1 }
    let foundationLearner = MLXBrainLearnerConfiguration.foundationV1
    let learner = MLXBrainLearner(configuration: try MLXBrainLearnerConfiguration(
      learningRate: 0.01,
      gradientNormLimit: foundationLearner.gradientNormLimit,
      parameterMagnitudeLimit: foundationLearner.parameterMagnitudeLimit,
      lossWeights: foundationLearner.lossWeights
    ))
    let update = try learner.update(
      parentPublication: publication, cohort: cohort
    )
    XCTAssertEqual(
      try learner.update(
        parentPublication: publication, cohort: cohort
      ),
      update
    )
    let successor = try BrainParameterPublication(
      parentVersion: publication.version,
      learnerUpdate: update
    )
    let heldoutScenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: publication,
      device: device, rootCount: 11
    )
    let taskParentScenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: publication,
      device: device, rootCount: 3,
      externalGoal: taskGoal
    )
    let taskLearnedScenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: successor,
      device: device, rootCount: 3,
      externalGoal: taskGoal
    )
    let selectedIntervention: (
      modality: SensoryModality,
      intervention: ClosedLoopSensorIntervention,
      outcomeModality: SensoryModality,
      label: String
    ) = switch selectedInterventionName {
    case "audition": (
      .audition, .scaled(.audition, 0.9), .vestibular, "scaled0.9"
    )
    case "vestibular": (
      .vestibular, .ablated(.vestibular), .vestibular, "ablated"
    )
    case "touch": (.touch, .ablated(.touch), .touch, "ablated")
    case "proprioception": (
      .proprioception,
      .ablated(.proprioception),
      .proprioception,
      "ablated"
    )
    case "interoception": (
      .interoception,
      .ablated(.interoception),
      .proprioception,
      "ablated"
    )
    case "kinesthesia": (
      .kinesthesia,
      .ablated(.kinesthesia),
      .kinesthesia,
      "ablated"
    )
    case "vision": (.vision, .ablated(.vision), .vestibular, "ablated")
    case let name:
      throw TissueError.transaction(
        "unsupported Gate B closed-loop intervention modality \(name)"
      )
    }
    let taskIntervenedScenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: successor,
      device: device, rootCount: 3,
      externalGoal: taskGoal,
      sensorIntervention: selectedIntervention.intervention
    )
    let taskParentEvidence = try acceptedTransitionEvidence(
      taskParentScenario.batch
    )
    let taskLearnedEvidence = try acceptedTransitionEvidence(
      taskLearnedScenario.batch
    )
    let taskActionDelta = maximumAbsoluteDelta(
      taskParentEvidence.flatMap(\.actions),
      taskLearnedEvidence.flatMap(\.actions)
    )
    let taskSensorDelta = maximumAbsoluteDelta(
      taskParentScenario.finalSensorValues,
      taskLearnedScenario.finalSensorValues
    )
    let taskIntervenedEvidence = try acceptedTransitionEvidence(
      taskIntervenedScenario.batch
    )
    let interventionActionDelta = maximumAbsoluteDelta(
      taskLearnedEvidence.flatMap(\.actions),
      taskIntervenedEvidence.flatMap(\.actions)
    )
    let interventionPhysicalDelta = maximumAbsoluteDelta(
      taskLearnedScenario.finalSensorValues,
      taskIntervenedScenario.finalSensorValues
    )
    let interventionPhysicalDeltas = Dictionary(uniqueKeysWithValues:
      taskLearnedScenario.finalSensorValuesByModality.keys.map { modality in
        (
          modality,
          maximumAbsoluteDelta(
            taskLearnedScenario.finalSensorValuesByModality[modality] ?? [],
            taskIntervenedScenario
              .finalSensorValuesByModality[modality] ?? []
          )
        )
      }
    )
    let interventionMotorDelta = maximumAbsoluteDelta(
      taskLearnedScenario.motorExcitationsByGeneration.flatMap { $0 },
      taskIntervenedScenario.motorExcitationsByGeneration.flatMap { $0 }
    )
    let interventionDescendingDelta = maximumAbsoluteDelta(
      taskLearnedScenario.descendingSomaticByGeneration.flatMap { $0 },
      taskIntervenedScenario.descendingSomaticByGeneration.flatMap { $0 }
    )
    let intactTaskCost = selectedIntervention.modality == .interoception
      ? proprioceptiveActivationDeficit(taskLearnedScenario)
      : modalityDriftCost(
        taskLearnedScenario, modality: selectedIntervention.outcomeModality
      )
    let interventionTaskCost = selectedIntervention.modality == .interoception
      ? proprioceptiveActivationDeficit(taskIntervenedScenario)
      : modalityDriftCost(
        taskIntervenedScenario, modality: selectedIntervention.outcomeModality
      )
    let intactInteroceptiveMeans = interoceptiveFeatureMeans(
      taskLearnedScenario
    )
    let interventionInteroceptiveMeans = interoceptiveFeatureMeans(
      taskIntervenedScenario
    )
    let learnedHeldoutScenario = try runAcceptedScenario(
      paths: paths, contactPath: heldoutTilt.path,
      compiled: compiled, publication: successor,
      device: device, rootCount: 11
    )
    let heldoutEvidence = try acceptedTransitionEvidence(heldoutScenario.batch)
    let learnedHeldoutEvidence = try acceptedTransitionEvidence(
      learnedHeldoutScenario.batch
    )
    let learnedClosedLoopActionDelta = maximumAbsoluteDelta(
      heldoutEvidence.flatMap(\.actions),
      learnedHeldoutEvidence.flatMap(\.actions)
    )
    let learnedClosedLoopSensorDelta = maximumAbsoluteDelta(
      heldoutScenario.finalSensorValues,
      learnedHeldoutScenario.finalSensorValues
    )
    let learnedClosedLoopPhysicsChanged = zip(
      heldoutEvidence, learnedHeldoutEvidence
    ).contains {
      $0.physicsStateFingerprint != $1.physicsStateFingerprint
    }
    let evaluator = MLXGateBCausalEvaluator()
    var evaluations: [NumanXGateBPolicyHeadEvaluation] = []
    for modality in compiled.species.senses.filter(\.enabled).map(\.modality) {
      let first = try evaluator.evaluate(
        publication: successor,
        batch: heldoutScenario.batch,
        species: compiled.species,
        modality: modality,
        minimumGeneration: 10,
        maximumGeneration: 11,
        shuffleSeed: 0x4e58_4742_5449_4c54
      )
      XCTAssertEqual(
        try evaluator.evaluate(
          publication: successor,
          batch: heldoutScenario.batch,
          species: compiled.species,
          modality: modality,
          minimumGeneration: 10,
          maximumGeneration: 11,
          shuffleSeed: 0x4e58_4742_5449_4c54
        ),
        first
      )
      evaluations.append(contentsOf: first)
    }
    XCTAssertEqual(evaluations.count, 28)
    XCTAssertEqual(firstSensorDivergence, 1)
    XCTAssertEqual(firstCandidateSensorDivergence, 1)
    XCTAssertGreaterThan(cohortSensorDelta, 0)
    XCTAssertGreaterThan(cohortObservationDelta, 0)
    XCTAssertTrue((negativeEvidence + positiveEvidence).allSatisfy {
      ($0.actions.map(abs).max() ?? 0) > 0
    })
    XCTAssertTrue(taskParentEvidence.allSatisfy {
      $0.activeOptionIdentifier >> 60 == 0x6
        && ($0.actions.map(abs).max() ?? 0) > 0
    })
    XCTAssertTrue(taskLearnedEvidence.allSatisfy {
      $0.activeOptionIdentifier >> 60 == 0x6
        && ($0.actions.map(abs).max() ?? 0) > 0
    })
    XCTAssertEqual(taskIntervenedEvidence.count, 3)
    XCTAssertEqual(
      taskIntervenedEvidence.map(\.activeGoalIdentifier),
      taskLearnedEvidence.map(\.activeGoalIdentifier)
    )
    XCTAssertEqual(
      taskIntervenedEvidence.map(\.activeOptionIdentifier),
      taskLearnedEvidence.map(\.activeOptionIdentifier)
    )
    XCTAssertGreaterThan(taskActionDelta, 0)
    XCTAssertGreaterThan(taskSensorDelta, 0)
    XCTAssertGreaterThan(interventionActionDelta, 1.0e-7)
    XCTAssertGreaterThan(interventionDescendingDelta, 1.0e-8)
    XCTAssertGreaterThan(interventionMotorDelta, 1.0e-8)
    XCTAssertGreaterThan(interventionPhysicalDelta, 1.0e-8)
    XCTAssertGreaterThan(
      interventionTaskCost,
      intactTaskCost + 1.0e-4
    )
    XCTAssertTrue(interventionPhysicalDeltas.contains {
      $0.key != selectedIntervention.modality && $0.value > 1.0e-8
    })
    XCTAssertTrue(evaluations.filter {
      $0.intervention == .intact
    }.allSatisfy { $0.actionDeltaFromIntact == 0 })
    XCTAssertTrue(evaluations.contains {
      $0.intervention == .valueShuffled && $0.actionDeltaFromIntact > 0
    })
    XCTAssertTrue(evaluations.contains {
      $0.intervention == .timestampShifted && $0.actionDeltaFromIntact > 0
    })
    XCTAssertEqual(
      Set(evaluations.filter {
        $0.intervention == .ablated && $0.actionDeltaFromIntact > 0
      }.map(\.modality)),
      Set(compiled.species.senses.filter(\.enabled).map(\.modality))
    )
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      let firstSensorDivergenceDescription = firstSensorDivergence.map {
        String($0)
      } ?? "none"
      let firstCandidateSensorDivergenceDescription =
        firstCandidateSensorDivergence.map { String($0) } ?? "none"
      print(
        "GateB tilted cohort physicalFingerprintsDiffer="
          + "\(zip(negativeEvidence, positiveEvidence).contains { $0.physicsStateFingerprint != $1.physicsStateFingerprint }) "
          + "sensorMaxDelta=\(cohortSensorDelta) "
          + "firstSensorDivergence=\(firstSensorDivergenceDescription) "
          + "firstCandidateSensorDivergence="
          + "\(firstCandidateSensorDivergenceDescription) "
          + "observationMaxDelta=\(cohortObservationDelta) "
          + "actionMaxDelta=\(cohortActionDelta)"
      )
      print(
        "GateB learned heldout physicalFingerprintsDiffer="
          + "\(learnedClosedLoopPhysicsChanged) "
          + "sensorMaxDelta=\(learnedClosedLoopSensorDelta) "
          + "actionMaxDelta=\(learnedClosedLoopActionDelta)"
      )
      print(
        "GateB task heldout sensorMaxDelta=\(taskSensorDelta) "
          + "actionMaxDelta=\(taskActionDelta) "
          + "parentGoalOptions=\(taskParentEvidence.map { "\($0.activeGoalIdentifier):\($0.activeOptionIdentifier)" }) "
          + "learnedGoalOptions=\(taskLearnedEvidence.map { "\($0.activeGoalIdentifier):\($0.activeOptionIdentifier)" })"
      )
      print(
        "GateB task closed-loop modality=\(selectedIntervention.modality) "
          + "intervention=\(selectedIntervention.label) "
          + "actionMaxDelta=\(interventionActionDelta) "
          + "descendingMaxDelta=\(interventionDescendingDelta) "
          + "motorMaxDelta=\(interventionMotorDelta) "
          + "intactMotorMax=\(taskLearnedScenario.motorExcitationsByGeneration.flatMap { $0 }.max() ?? .nan) "
          + "intervenedMotorMax=\(taskIntervenedScenario.motorExcitationsByGeneration.flatMap { $0 }.max() ?? .nan) "
          + "physicalSensorMaxDelta=\(interventionPhysicalDelta) "
          + "outcomeModality=\(selectedIntervention.outcomeModality) "
          + "intactOutcomeCost=\(intactTaskCost) "
          + "intervenedOutcomeCost=\(interventionTaskCost) "
          + "intactInteroceptiveMeans=\(intactInteroceptiveMeans) "
          + "intervenedInteroceptiveMeans=\(interventionInteroceptiveMeans) "
          + "intactFinalProprioceptiveMeans="
          + "\(proprioceptiveFeatureMeans(taskLearnedScenario)) "
          + "intervenedFinalProprioceptiveMeans="
          + "\(proprioceptiveFeatureMeans(taskIntervenedScenario))"
      )
      for modality in interventionPhysicalDeltas.keys.sorted(by: {
        $0.rawValue < $1.rawValue
      }) {
        print(
          "GateB task intervention=\(selectedIntervention.modality) "
            + "physical modality=\(modality) "
            + "maxDelta=\(interventionPhysicalDeltas[modality] ?? .infinity)"
        )
      }
      for modality in modalitySensorDeltas.keys.sorted(by: {
        $0.rawValue < $1.rawValue
      }) {
        print(
          "GateB tilted sensor modality=\(modality) "
            + "maxDelta=\(modalitySensorDeltas[modality] ?? .infinity)"
        )
      }
      for result in evaluations.sorted(by: {
        ($0.modality.rawValue, $0.intervention.rawValue)
          < ($1.modality.rawValue, $1.intervention.rawValue)
      }) {
        print(
          "GateB tilted policy-head modality=\(result.modality) "
            + "intervention=\(result.intervention) "
            + "mse=\(result.actionMeanSquaredError) "
            + "delta=\(result.actionDeltaFromIntact)"
        )
      }
    }
  }

  private struct AcceptedTransitionEvidence {
    let generation: UInt64
    let physicsStateFingerprint: UInt64
    let activeGoalIdentifier: UInt64
    let activeOptionIdentifier: UInt64
    let selectedScore: Float
    let damageCVaR: Float
    let posteriorState: [Float]
    let observations: [Float]
    let actions: [Float]
  }

  private func acceptedTransitionEvidence(
    _ batch: MetalLearningBatch
  ) throws -> [AcceptedTransitionEvidence] {
    let lease = try batch.makeSharedStorageLease()
    var result: [AcceptedTransitionEvidence] = []
    for index in 0..<batch.transitionCapacity {
      let record = lease.baseAddress.advanced(
        by: index * batch.transitionStride
      )
      let identifier = record.load(as: UInt64.self)
      let generation = record.advanced(by: 32).load(as: UInt64.self)
      let format = record.advanced(by: 64).load(as: UInt32.self)
      let flags = record.advanced(by: 68).load(as: UInt32.self)
      guard identifier > 0, generation > 0,
        format == MetalLearningBatch.transitionRecordVersion,
        (flags & 1) == 1
      else { continue }
      let observations = Array(
        UnsafeBufferPointer(
          start: record.advanced(by: 320).assumingMemoryBound(to: Float.self),
          count: 24
        )
      )
      let posteriorState = Array(
        UnsafeBufferPointer(
          start: record.advanced(by: 224).assumingMemoryBound(to: Float.self),
          count: 24
        )
      )
      let actions = Array(
        UnsafeBufferPointer(
          start: record.advanced(by: 416).assumingMemoryBound(to: Float.self),
          count: 16
        )
      )
      result.append(AcceptedTransitionEvidence(
        generation: generation,
        physicsStateFingerprint: record.advanced(by: 40).load(as: UInt64.self),
        activeGoalIdentifier: record.advanced(by: 48).load(as: UInt64.self),
        activeOptionIdentifier: record.advanced(by: 56).load(as: UInt64.self),
        selectedScore: record.advanced(by: 96).load(as: Float.self),
        damageCVaR: record.advanced(by: 100).load(as: Float.self),
        posteriorState: posteriorState,
        observations: observations,
        actions: actions
      ))
    }
    return result.sorted { $0.generation < $1.generation }
  }

  private func maximumAbsoluteDelta(
    _ lhs: [Float], _ rhs: [Float]
  ) -> Float {
    guard lhs.count == rhs.count else { return .infinity }
    return zip(lhs, rhs).reduce(Float(0)) {
      max($0, abs($1.0 - $1.1))
    }
  }

  func testRealFullBodyBrainProposalApplyAndJointPublication() throws {
    try runFullBodyJointPublication(authoredWorld: nil)
  }

  func testAuthoredMatterBrainProposalApplyAndJointPublication() throws {
    try runFullBodyJointPublication(authoredWorld: configuredAuthoredWorld())
  }

  private func configuredAuthoredWorld() throws -> MetalNumanXBridgeV1Runtime.AuthoredMatterWorld {
    let environment = ProcessInfo.processInfo.environment
    guard let path = environment["NUMANX_MATTER_WORLD_PACKAGE"],
      let human = environment["NUMANX_HUMAN_SOURCE_FP"].flatMap({ UInt64($0, radix: 16) }),
      let world = environment["NUMANX_MATTER_WORLD_FP"].flatMap({ UInt64($0, radix: 16) }) else {
      throw XCTSkip("authored Matter package and identities are not configured")
    }
    var equalities: MetalNumanXBridgeV1Runtime.SourceJointEqualities?
    if environment["NUMANX_JOINT_EQUALITIES"] != nil || environment["NUMANX_JOINT_EQUALITY_FP"] != nil {
      let equalityPath = try XCTUnwrap(environment["NUMANX_JOINT_EQUALITIES"])
      let equalityFingerprint = try XCTUnwrap(environment["NUMANX_JOINT_EQUALITY_FP"]
        .flatMap { UInt64($0, radix: 16) })
      equalities = try .init(payloadPath: equalityPath, fingerprint: equalityFingerprint)
    }
    var limits: MetalNumanXBridgeV1Runtime.SourceJointLimits?
    if environment["NUMANX_JOINT_LIMITS"] != nil || environment["NUMANX_JOINT_LIMIT_FP"] != nil {
      limits = try .init(payloadPath: XCTUnwrap(environment["NUMANX_JOINT_LIMITS"]),
        fingerprint: XCTUnwrap(environment["NUMANX_JOINT_LIMIT_FP"].flatMap { UInt64($0, radix: 16) }))
    }
    var tissue: MetalNumanXBridgeV1Runtime.CostalTissueOwnership?
    let tissueKeys = ["NUMANX_COSTAL_CARTILAGE", "NUMANX_COSTAL_BINDING", "NUMANX_COSTAL_BINDING_FP"]
    if tissueKeys.contains(where: { environment[$0] != nil }) {
      tissue = try .init(cartilagePayloadPath: XCTUnwrap(environment[tissueKeys[0]]),
        bindingPayloadPath: XCTUnwrap(environment[tissueKeys[1]]),
        bindingFingerprint: XCTUnwrap(environment[tissueKeys[2]].flatMap { UInt64($0, radix: 16) }))
    }
    var initial: MetalNumanXBridgeV1Runtime.PreparedInitialState?
    if environment["NUMANX_INITIAL_STATE"] != nil || environment["NUMANX_INITIAL_STATE_FP"] != nil {
      initial = try .init(payloadPath: XCTUnwrap(environment["NUMANX_INITIAL_STATE"]),
        fingerprint: XCTUnwrap(environment["NUMANX_INITIAL_STATE_FP"].flatMap { UInt64($0, radix: 16) }))
    }
    return try .init(packagePath: path,
      humanSourceFingerprint: human, worldFingerprint: world,
      sourceJointEqualities: equalities, sourceJointLimits: limits, costalTissueOwnership: tissue,
      preparedInitialState: initial)
  }

  func testPreparedInitialStateNativeAdmissionRejectsPayloadDrift() throws {
    let world = try configuredAuthoredWorld()
    guard let initial = world.preparedInitialState, world.costalTissueOwnership == nil else {
      throw XCTSkip("NHINIT1 prepared small authored fixture is not configured")
    }
    let paths = try bridgePaths()
    let device = try XCTUnwrap(MTLCreateSystemDefaultDevice())
    let original = try Data(contentsOf: URL(fileURLWithPath: initial.payloadPath))
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    func make(_ state: MetalNumanXBridgeV1Runtime.PreparedInitialState?) throws -> MetalNumanXBridgeV1Runtime {
      let candidate = try MetalNumanXBridgeV1Runtime.AuthoredMatterWorld(
        packagePath: world.packagePath, humanSourceFingerprint: world.humanSourceFingerprint,
        worldFingerprint: world.worldFingerprint, sourceJointEqualities: world.sourceJointEqualities,
        sourceJointLimits: world.sourceJointLimits, preparedInitialState: state)
      return try MetalNumanXBridgeV1Runtime(libraryPath: paths.library, device: device,
        configuration: .init(rigidPayloadPath: paths.rigid, musclePayloadPath: paths.muscle,
          supportContactPayloadPath: paths.contacts, visualPackPath: paths.visualPack,
          visionProfilePath: paths.visionProfile, metalRoboMetallibPath: paths.metalRoboMetallib,
          matterMetallibPath: paths.matterMetallib, timestepMicroseconds: 100,
          maximumRetainedBytes: 1 << 30, transactionSlotCount: 2, authoredMatterWorld: candidate))
    }
    let valid = try make(initial)
    XCTAssertEqual(try valid.currentWorldInfo().worldFingerprint, world.worldFingerprint)
    // Omitting the prepared state must not silently relocate the cooked nodes.
    XCTAssertThrowsError(try make(nil))
    let mutations: [(String, Int?, UInt8)] = [
      ("fingerprint", nil, 0), ("magic", 0, 1), ("abi", 8, 1), ("dimension", 16, 1),
      ("flags", 32, 1), ("reserved", 36, 1), ("human", 40, 1), ("world", 48, 1),
      ("clock", 56, 1), ("archive", 64, 1), ("root-frame", 99, 16),
      ("root-quaternion", 123, 32), ("activation", 1131, 64), ("fiber", 1135, 128)
    ]
    for (name, offset, mask) in mutations {
      var payload = original
      if let offset { payload[offset] ^= mask }
      let url = directory.appendingPathComponent(name + ".nhinit")
      try payload.write(to: url)
      let fingerprint = payload.reduce(UInt64(0xcbf29ce484222325)) { ($0 ^ UInt64($1)) &* 0x100000001b3 }
      XCTAssertThrowsError(try make(.init(payloadPath: url.path,
        fingerprint: offset == nil ? fingerprint ^ 1 : fingerprint)), name)
    }
  }

  func testSourceJointLimitNativeAdmissionRejectsPayloadDrift() throws {
    let world = try configuredAuthoredWorld()
    guard let limits = world.sourceJointLimits, world.costalTissueOwnership == nil else {
      throw XCTSkip("NHLIM1 small authored admission fixture is not configured")
    }
    let paths = try bridgePaths()
    let device = try XCTUnwrap(MTLCreateSystemDefaultDevice())
    let original = try Data(contentsOf: URL(fileURLWithPath: limits.payloadPath))
    let directory = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
    defer { try? FileManager.default.removeItem(at: directory) }
    let mutations: [(String, Int?, UInt8)] = [
      ("fingerprint", nil, 0), ("source", 48, 1), ("policy", 32, 1),
      ("flags", 36, 1), ("reserved", 40, 1), ("coordinate", 80, 1),
      ("row-reserved", 92, 1), ("source-weight", 111, 128)
    ]
    for (name, offset, mask) in mutations {
      var payload = original
      if let offset { payload[offset] ^= mask }
      let url = directory.appendingPathComponent(name + ".nhlim")
      try payload.write(to: url)
      let fingerprint = payload.reduce(UInt64(0xcbf29ce484222325)) { ($0 ^ UInt64($1)) &* 0x100000001b3 }
      let rejected = try MetalNumanXBridgeV1Runtime.AuthoredMatterWorld(
        packagePath: world.packagePath, humanSourceFingerprint: world.humanSourceFingerprint,
        worldFingerprint: world.worldFingerprint, sourceJointEqualities: world.sourceJointEqualities,
        sourceJointLimits: .init(payloadPath: url.path, fingerprint: offset == nil ? fingerprint ^ 1 : fingerprint))
      XCTAssertThrowsError(try MetalNumanXBridgeV1Runtime(libraryPath: paths.library, device: device,
        configuration: .init(rigidPayloadPath: paths.rigid, musclePayloadPath: paths.muscle,
          supportContactPayloadPath: paths.contacts, visualPackPath: paths.visualPack,
          visionProfilePath: paths.visionProfile, metalRoboMetallibPath: paths.metalRoboMetallib,
          matterMetallibPath: paths.matterMetallib, matterMaterialPath: "", timestepMicroseconds: 100,
          maximumRetainedBytes: 1 << 30, transactionSlotCount: 2, authoredMatterWorld: rejected)), name)
    }
  }

  private func runFullBodyJointPublication(
    authoredWorld: MetalNumanXBridgeV1Runtime.AuthoredMatterWorld?
  ) throws {
    let gateBTimestepMicroseconds: UInt64 = authoredWorld?.costalTissueOwnership == nil ? 100 : 10
    func recordPreparedState(_ aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot, device: any MTLDevice) throws {
      guard authoredWorld?.preparedInitialState != nil,
        ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" else { return }
      let kinesthesia = try XCTUnwrap(aggregate.channels.first { $0.modality == .kinesthesia })
      let vestibular = try XCTUnwrap(aggregate.channels.first { $0.modality == .vestibular })
      let k = try qualificationUInt32s(from: qualificationReadback(kinesthesia.values, device: device))
        .map { Float(bitPattern: $0) }
      let root = try qualificationUInt32s(from: qualificationReadback(vestibular.values, device: device))
        .map { Float(bitPattern: $0) }
      let q = Array(root.prefix(7)) + (6..<128).map { k[7 * $0] }
      let v = (0..<128).map { k[7 * $0 + 1] }
      var packed = Data()
      for value in q + v {
        var word = value.bitPattern.littleEndian
        withUnsafeBytes(of: &word) { packed.append(contentsOf: $0) }
      }
      let record: [String: Any] = ["schema": "numi.human.accepted-prepared-state.v1",
        "physics_generation": aggregate.physicsGeneration,
        "elapsed_microseconds": aggregate.physicsGeneration * gateBTimestepMicroseconds,
        "nq": 129, "nv": 128, "q_v_fp32_le_base64": packed.base64EncodedString()]
      let data = try JSONSerialization.data(withJSONObject: record, options: [.sortedKeys])
      // One write below PIPE_BUF avoids interleaving native stderr diagnostics
      // into a long JSON array through xctest's merged output pipe.
      let line = Data(("prepared_accepted_state=" + String(decoding: data, as: UTF8.self) + "\n").utf8)
      XCTAssertLessThan(line.count, 4096)
      let count = line.withUnsafeBytes { Darwin.write(STDOUT_FILENO, $0.baseAddress, $0.count) }
      XCTAssertEqual(count, line.count, "accepted-state evidence write was incomplete")
    }
    let initialCommittedTimestampMicroseconds: UInt64 = 1_000
    func gateBTimestamp(_ boundary: UInt64) -> BrainTimestamp {
      BrainTimestamp(
        microseconds: initialCommittedTimestampMicroseconds
          + (boundary - 1) * gateBTimestepMicroseconds
      )
    }
    let paths = try bridgePaths()
    guard let device = MTLCreateSystemDefaultDevice(),
      device.makeMTL4CommandQueue() != nil,
      device.makeCommandAllocator() != nil,
      device.makeCommandBuffer() != nil
    else {
      throw XCTSkip("Metal 4 execution is unavailable")
    }
    let parameters = TissueParameters.corticalSheetV0
    let compiled = try makeNumanXFullBodyTransportCompiledTemplate(
      latencyMicroseconds: UInt32(gateBTimestepMicroseconds)
    )
    XCTAssertEqual(compiled.species.activeSensingChannels.count, 1)
    XCTAssertEqual(
      compiled.species.activeSensingChannels.first?.modality, .vision
    )
    let publication = try BrainParameterPublication.developmentalSeedV1(
      species: compiled.species,
      tissueParameters: parameters
    )
    let initial = try CPUTissueDynamics.makeRestingGrid(
      width: 8,
      height: 8,
      parameters: parameters
    )
    let brainConfiguration = MetalNumiBrainConfiguration(
      initialTissueState: initial,
      tissueParameters: parameters,
      tissueStimulus: .none,
      compiledSpeciesTemplate: compiled,
      randomContext: TissueRandomContext(
        seed: 0x4e55_4d49,
        environmentIdentifier: 0,
        episodeIdentifier: 1
      ),
      schedulerEnvironmentIdentifier: 0,
      maximumEncodedSubsteps: 1
    )
    let brain = try MetalNumiBrainRuntime.makeRuntime(
      configuration: brainConfiguration,
      publication: publication,
      device: device
    )
    let culturePack = ProcessInfo.processInfo.environment["NUMANX_CULTURE_PACK"]
    let native = try MetalNumanXBridgeV1Runtime(
      libraryPath: paths.library,
      device: device,
      configuration: .init(
        rigidPayloadPath: paths.rigid,
        musclePayloadPath: paths.muscle,
        supportContactPayloadPath: paths.contacts,
        visualPackPath: paths.visualPack,
        visionProfilePath: paths.visionProfile,
        metalRoboMetallibPath: paths.metalRoboMetallib,
        matterMetallibPath: paths.matterMetallib,
        matterMaterialPath: authoredWorld == nil ? paths.material : "",
        timestepMicroseconds: gateBTimestepMicroseconds,
        maximumRetainedBytes: authoredWorld?.costalTissueOwnership == nil ? 1 << 30 : 2 << 30,
        transactionSlotCount: 2,
        culturePackPath: culturePack,
        authoredMatterWorld: authoredWorld
      )
    )
    XCTAssertEqual(native.info.bodyCount, 157)
    XCTAssertEqual(native.info.qCoordinateCount, 129)
    XCTAssertEqual(native.info.dofCount, 128)
    XCTAssertEqual(native.info.muscleCount, 416)
    XCTAssertEqual(native.info.residentContinuationCount, 0)
    if let limits = authoredWorld?.sourceJointLimits {
      let anatomy = try native.fullBodyAnatomy()
      let coordinates = anatomy.jointTopologyCatalog.joints.flatMap(\.coordinates)
      let payload = try Data(contentsOf: URL(fileURLWithPath: limits.payloadPath))
      func word(_ offset: Int) -> UInt32 {
        payload.withUnsafeBytes { UInt32(littleEndian: $0.loadUnaligned(fromByteOffset: offset, as: UInt32.self)) }
      }
      let count = Int(word(20))
      XCTAssertEqual(coordinates.filter(\.sourceCompliantLimit).count, count)
      for index in 0..<count {
        let offset = 80 + 80 * index
        let coordinate = try XCTUnwrap(coordinates.first { $0.kinesthesiaReceptorIndex == word(offset + 4) })
        XCTAssertTrue(coordinate.sourceCompliantLimit)
        XCTAssertEqual(coordinate.minimumPosition.bitPattern, word(offset + 16))
        XCTAssertEqual(coordinate.maximumPosition.bitPattern, word(offset + 20))
      }
      XCTAssertTrue(coordinates.contains { $0.sourceCompliantLimit && $0.restPosition < $0.minimumPosition },
        "Source reset offsets must survive anatomy transport without clamping")
    }
    if let authoredWorld {
      let world = try native.currentWorldInfo()
      XCTAssertTrue(world.authoredPackage)
      XCTAssertEqual(world.worldFingerprint, authoredWorld.worldFingerprint)
      if let equalities = authoredWorld.sourceJointEqualities {
        let fnvOffset: UInt64 = 0xcbf29ce484222325
        let fnvPrime: UInt64 = 0x100000001b3
        let domain = "NHEQ2".utf8.reduce(fnvOffset) { ($0 ^ UInt64($1)) &* fnvPrime }
        var expectedSource = ((authoredWorld.humanSourceFingerprint ^ domain) &* fnvPrime
          ^ equalities.fingerprint) &* fnvPrime
        if expectedSource == 0 { expectedSource = fnvOffset }
        if let limits = authoredWorld.sourceJointLimits {
          let limitDomain = "NHLIM1".utf8.reduce(fnvOffset) { ($0 ^ UInt64($1)) &* fnvPrime }
          expectedSource = ((expectedSource ^ limitDomain) &* fnvPrime ^ limits.fingerprint) &* fnvPrime
          if expectedSource == 0 { expectedSource = fnvOffset }
        }
        if let tissue = authoredWorld.costalTissueOwnership {
          for byte in "NHTMASS1".utf8 { expectedSource = (expectedSource ^ UInt64(byte)) &* fnvPrime }
          for value in [tissue.bindingFingerprint, authoredWorld.worldFingerprint] {
            for shift in stride(from: 0, to: 64, by: 8) {
              expectedSource = (expectedSource ^ ((value >> shift) & 0xff)) &* fnvPrime
            }
          }
        }
        if let initial = authoredWorld.preparedInitialState {
          for byte in "NHINIT1".utf8 { expectedSource = (expectedSource ^ UInt64(byte)) &* fnvPrime }
          for shift in stride(from: 0, to: 64, by: 8) {
            expectedSource = (expectedSource ^ ((initial.fingerprint >> shift) & 0xff)) &* fnvPrime
          }
        }
        XCTAssertEqual(native.info.modelSourceFingerprint, expectedSource,
          "The source equality program must participate in the runtime model identity")
        if let expected = ProcessInfo.processInfo.environment["NUMANX_CONSTRAINED_HUMAN_SOURCE_FP"] {
          XCTAssertEqual(native.info.modelSourceFingerprint, try XCTUnwrap(UInt64(expected, radix: 16)))
        }
      } else {
        XCTAssertEqual(native.info.modelSourceFingerprint, authoredWorld.humanSourceFingerprint)
      }
      XCTAssertEqual(world.objectCount, authoredWorld.costalTissueOwnership == nil ? 3 : 1)
      XCTAssertEqual(world.femAttachmentCount, authoredWorld.costalTissueOwnership == nil ? 12 : 2871)
    }
    XCTAssertNil(try native.aggregateSnapshotIfAvailable())

    let transaction = try brain.beginControl(
      controlStepIdentifier: 1,
      basePhysicsGeneration: 0,
      committedTimestamp: gateBTimestamp(1),
      targetTimestamp: gateBTimestamp(2),
      cachedDecisionFingerprint: 0x4e58_4445_4349_5349
    )
    // Generation zero is the canonical first deterministic random stream; it
    // is an authenticated value, not an absent identity.
    XCTAssertEqual(transaction.token.randomCounterGeneration, 0)
    let initialSensors = try bootstrapSensorPacket(
      device: device,
      compiled: compiled,
      transaction: transaction.token
    )
    let first = try publishRoot(
      brain: brain,
      native: native,
      transaction: transaction,
      sensors: initialSensors,
      device: device
    )
    let physical = first.physical
    let aggregate = first.aggregate
    try recordPreparedState(aggregate, device: device)
    XCTAssertNil(first.cultureActionGeneration)
    XCTAssertEqual(aggregate.publicationEpoch, 1)
    XCTAssertEqual(aggregate.brainGeneration, brain.committedGeneration)
    XCTAssertEqual(aggregate.physicsGeneration, 1)
    XCTAssertEqual(aggregate.sensorGeneration, 1)
    XCTAssertEqual(aggregate.identity, physical.identity)
    var acceptedCulture:
      MetalNumanXBridgeV1Runtime.AggregateSnapshotV4? = nil
    if culturePack != nil {
      XCTAssertNotNil(physical.culture)
      let aggregateV4 = try XCTUnwrap(native.aggregateSnapshotV4IfAvailable())
      XCTAssertEqual(aggregateV4.base.publicationEpoch, aggregate.publicationEpoch)
      XCTAssertEqual(aggregateV4.culture.generation, 1)
      XCTAssertEqual(aggregateV4.culture.buffers.count, 11)
      XCTAssertEqual(
        aggregateV4.culture.sourceRootFingerprint,
        aggregateV4.base.identity.transactionFingerprint
      )
      XCTAssertEqual(
        aggregateV4.culture.receiptFingerprint,
        physical.culture?.receiptFingerprint
      )
      XCTAssertEqual(
        physical.culture?.preparedGeneration,
        aggregateV4.culture.generation
      )
      let counts = try qualificationUInt32s(
        from: qualificationReadback(
          aggregateV4.culture.buffers[8].buffer,
          device: device
        )
      )
      XCTAssertEqual(counts.count, 60)
      XCTAssertGreaterThan(counts.reduce(UInt64(0)) { $0 + UInt64($1) }, 0)
      var electrode = 0
      var weightedX: Int64 = 0
      var weightedY: Int64 = 0
      for row in 0..<8 {
        for column in 0..<8 {
          if (row == 0 || row == 7) && (column == 0 || column == 7) {
            continue
          }
          let count = Int64(counts[electrode])
          weightedX += count * Int64(2 * column - 7)
          weightedY += count * Int64(2 * row - 7)
          electrode += 1
        }
      }
      XCTAssertNotEqual(weightedX, 0)
      XCTAssertNotEqual(weightedY, 0)
      acceptedCulture = aggregateV4
    }
    XCTAssertEqual(aggregate.proprioception.receptorCount, 416)
    XCTAssertEqual(aggregate.proprioception.featureDimension, 10)
    XCTAssertEqual(aggregate.interoception.receptorCount, 416)
    XCTAssertEqual(aggregate.interoception.featureDimension, 6)
    XCTAssertEqual(aggregate.channels.count, 7)
    XCTAssertEqual(aggregate.touch.receptorCount, 10)
    XCTAssertEqual(aggregate.touch.featureDimension, 7)
    let kinesthesia = try XCTUnwrap(
      aggregate.channels.first { $0.modality == .kinesthesia }
    )
    XCTAssertEqual(kinesthesia.receptorCount, 128)
    XCTAssertEqual(kinesthesia.featureDimension, 7)
    let vestibular = try XCTUnwrap(
      aggregate.channels.first { $0.modality == .vestibular }
    )
    XCTAssertEqual(vestibular.receptorCount, 1)
    XCTAssertEqual(vestibular.featureDimension, 22)
    XCTAssertEqual(aggregate.audition.receptorCount, 24)
    XCTAssertEqual(aggregate.audition.featureDimension, 8)
    let firstAuditionValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        aggregate.audition.validity!, device: device
      )
    )
    XCTAssertEqual(firstAuditionValidity.count, 24)
    XCTAssertTrue(
      firstAuditionValidity.allSatisfy { $0 == 0xfb },
      "first audition masks: \(firstAuditionValidity)"
    )
    let firstTouchValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        aggregate.touch.validity!, device: device
      )
    )
    let firstProprioceptionValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        aggregate.proprioception.validity!, device: device
      )
    )
    XCTAssertTrue(
      firstTouchValidity.allSatisfy { $0 == 0x7f },
      "first touch masks: \(firstTouchValidity)"
    )
    XCTAssertTrue(
      firstProprioceptionValidity.allSatisfy { $0 == 0x3ff },
      "first proprio masks: \(firstProprioceptionValidity.prefix(8))"
    )
    let vision = try XCTUnwrap(
      aggregate.channels.first { $0.modality == .vision }
    )
    XCTAssertEqual(vision.receptorCount, 64 * 48)
    XCTAssertEqual(vision.featureDimension, 8)
    XCTAssertEqual(
      vision.receptorTimestamp,
      gateBTimestamp(1)
    )
    for channel in aggregate.channels {
      XCTAssertEqual(
        channel.receptorTimestamp,
        gateBTimestamp(1)
      )
      XCTAssertEqual(
        channel.deliveryTimestamp,
        gateBTimestamp(2)
      )
      XCTAssertEqual(
        channel.latencyMicroseconds,
        UInt32(gateBTimestepMicroseconds)
      )
      XCTAssertEqual(
        channel.sampleIntervalMicroseconds,
        UInt32(gateBTimestepMicroseconds)
      )
    }
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 0)

    let secondTransaction = try brain.beginControl(
      controlStepIdentifier: 2,
      basePhysicsGeneration: aggregate.physicsGeneration,
      committedTimestamp: gateBTimestamp(2),
      targetTimestamp: gateBTimestamp(3),
      cachedDecisionFingerprint: 0x4e58_4445_4349_534a
    )
    let publishedSensors = try aggregate.sensorPacket(
      for: secondTransaction.token,
      compiledSpeciesTemplate: compiled
    )
    let second = try publishRoot(
      brain: brain,
      native: native,
      transaction: secondTransaction,
      sensors: publishedSensors,
      device: device,
      acceptedCulture: acceptedCulture
    )
    XCTAssertEqual(second.cultureActionGeneration, acceptedCulture?.culture.generation)
    if acceptedCulture != nil {
      XCTAssertNotEqual(second.motorExcitations, first.motorExcitations)
    }
    XCTAssertEqual(second.physical.identity.controlStep, 2)
    try recordPreparedState(second.aggregate, device: device)
    XCTAssertEqual(second.aggregate.publicationEpoch, 2)
    XCTAssertEqual(second.aggregate.brainGeneration, 2)
    XCTAssertEqual(second.aggregate.physicsGeneration, 2)
    XCTAssertEqual(second.aggregate.sensorGeneration, 2)
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 1)
    XCTAssertEqual(
      second.aggregate.identity.transactionFingerprint,
      secondTransaction.token.fingerprint
    )
    XCTAssertEqual(second.aggregate.proprioception.receptorTimestamp,
                   gateBTimestamp(2))
    XCTAssertEqual(second.aggregate.interoception.receptorTimestamp,
                   gateBTimestamp(2))
    XCTAssertTrue(second.aggregate.channels.allSatisfy {
      $0.deliveryTimestamp == gateBTimestamp(3)
        && $0.latencyMicroseconds == UInt32(gateBTimestepMicroseconds)
        && $0.sampleIntervalMicroseconds == UInt32(gateBTimestepMicroseconds)
    })
    let secondAuditionValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        second.aggregate.audition.validity!, device: device
      )
    )
    XCTAssertEqual(secondAuditionValidity.count, 24)
    let secondTouchValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        second.aggregate.touch.validity!, device: device
      )
    )
    let secondProprioceptionValidity = try qualificationUInt32s(
      from: try qualificationReadback(
        second.aggregate.proprioception.validity!, device: device
      )
    )
    XCTAssertTrue(secondAuditionValidity.allSatisfy { $0 == 0xff })
    XCTAssertTrue(secondTouchValidity.allSatisfy { $0 == 0x7f })
    XCTAssertTrue(secondProprioceptionValidity.allSatisfy { $0 == 0x3ff })
    // The copied epoch-1 metadata remains an immutable value even though the
    // native runtime has advanced its sole public aggregate root.
    XCTAssertEqual(aggregate.publicationEpoch, 1)
    XCTAssertEqual(aggregate.physicsGeneration, 1)

    // A fully valid Brain/motor root with a stale physics predecessor is
    // rejected by the native causal-chain gate before it consumes a runtime
    // slot or touches the resident Human state.
    let staleTransaction = try brain.beginControl(
      controlStepIdentifier: 3,
      basePhysicsGeneration: 1,
      committedTimestamp: gateBTimestamp(3),
      targetTimestamp: gateBTimestamp(4),
      cachedDecisionFingerprint: 0x4e58_5354_414c_4501
    )
    let staleSensors = try bootstrapSensorPacket(
      device: device,
      compiled: compiled,
      transaction: staleTransaction.token
    )
    let staleDecision = try brain.submitInferAndDecide(
      staleTransaction,
      numanXSensors: staleSensors,
      signal: point(device, value: 1)
    )
    let staleMotor = try brain.submitNumanXMotorCandidate(
      staleDecision,
      transaction: staleTransaction,
      candidateDurationMicroseconds: gateBTimestepMicroseconds,
      signal: point(device, value: 1)
    )
    XCTAssertThrowsError(
      try native.beginPhysicalRoot(
        transaction: staleTransaction.token,
        motor: staleMotor
      ) { _ in
        XCTFail("stale native root unexpectedly armed a completion")
      }
    )
    _ = try brain.finishNumanXMotorSubmission(
      staleMotor,
      transaction: staleTransaction,
      timeoutMilliseconds: 10_000
    )
    try brain.abortControl(staleTransaction)
    XCTAssertEqual(
      try XCTUnwrap(native.aggregateSnapshotIfAvailable()).publicationEpoch,
      2
    )
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 1)

    // The exact successor is still admissible and receives generation 3,
    // proving the failed stale request did not consume native generation or
    // sensor-publication authority.
    let thirdTransaction = try brain.beginControl(
      controlStepIdentifier: 3,
      basePhysicsGeneration: second.aggregate.physicsGeneration,
      committedTimestamp: gateBTimestamp(3),
      targetTimestamp: gateBTimestamp(4),
      cachedDecisionFingerprint: 0x4e58_4445_4349_534b
    )
    let thirdSensors = try second.aggregate.sensorPacket(
      for: thirdTransaction.token,
      compiledSpeciesTemplate: compiled
    )
    let third = try publishRoot(
      brain: brain,
      native: native,
      transaction: thirdTransaction,
      sensors: thirdSensors,
      device: device
    )
    try recordPreparedState(third.aggregate, device: device)
    XCTAssertEqual(third.aggregate.publicationEpoch, 3)
    XCTAssertEqual(third.aggregate.brainGeneration, 3)
    XCTAssertEqual(third.aggregate.physicsGeneration, 3)
    XCTAssertEqual(third.aggregate.sensorGeneration, 3)
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 2)

    let cultureBeforeReject: MetalNumanXBridgeV1Runtime.AggregateSnapshotV4?
    let cultureBytesBeforeReject: [[UInt8]]?
    if culturePack != nil {
      cultureBeforeReject = try XCTUnwrap(native.aggregateSnapshotV4IfAvailable())
      cultureBytesBeforeReject = try cultureBeforeReject?.culture.buffers.map {
        try qualificationReadback($0, device: device)
      }
      XCTAssertEqual(cultureBeforeReject?.culture.generation, 3)
    } else {
      cultureBeforeReject = nil
      cultureBytesBeforeReject = nil
    }

    let rejectedTransaction = try brain.beginControl(
      controlStepIdentifier: 4,
      basePhysicsGeneration: third.aggregate.physicsGeneration,
      committedTimestamp: gateBTimestamp(4),
      targetTimestamp: gateBTimestamp(5),
      cachedDecisionFingerprint: 0x4e58_5245_4a45_4354
    )
    let rejectedSensors = try third.aggregate.sensorPacket(
      for: rejectedTransaction.token,
      compiledSpeciesTemplate: compiled
    )
    let rejected = try prepareRoot(
      brain: brain,
      native: native,
      transaction: rejectedTransaction,
      sensors: rejectedSensors,
      device: device,
      acceptedCulture: cultureBeforeReject
    )
    XCTAssertEqual(
      rejected.cultureActionGeneration,
      cultureBeforeReject?.culture.generation
    )
    let rejectedAcceptedToken = try acceptedGateBytes(
      rejected.physical.acceptedPhysicsGate
    )
    let rejectedSensorPayload = try sensorPayloadBytes(
      rejected.physical.sensorCandidate,
      device: device
    )
    XCTAssertTrue(rejected.physical.quarantineTimeout())
    let rejectProposalLatch =
      AsyncResultLatch<MetalNumanXHumanMatterProposalLease>()
    try rejected.physical.submitTimeoutRejectProposal {
      rejectProposalLatch.complete($0)
    }
    _ = try rejectProposalLatch.wait()
    try rejected.physical.reserveTimeoutRejectApplication(
      brain: rejected.prepared
    )
    let rejectApplyLatch =
      AsyncResultLatch<MetalNumanXHumanMatterAppliedLease>()
    try rejected.physical.submitTimeoutRejectApply {
      rejectApplyLatch.complete($0)
    }
    let rejectedApplied = try rejectApplyLatch.wait()
    XCTAssertEqual(rejectedApplied.commandDisposition, .rejectedReleased)
    XCTAssertTrue(rejected.physical.releaseRejected())
    try brain.abortNumanXPreparedControl(rejected.prepared)
    XCTAssertFalse(brain.hasOpenControl)
    XCTAssertEqual(brain.committedGeneration, 3)
    let afterReject = try XCTUnwrap(native.aggregateSnapshotIfAvailable())
    XCTAssertEqual(afterReject.publicationEpoch, 3)
    XCTAssertEqual(afterReject.physicsGeneration, 3)
    XCTAssertEqual(afterReject.sensorGeneration, 3)
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 3)
    if let cultureBeforeReject, let cultureBytesBeforeReject {
      let cultureAfterReject = try XCTUnwrap(native.aggregateSnapshotV4IfAvailable())
      XCTAssertEqual(
        cultureAfterReject.culture.generation,
        cultureBeforeReject.culture.generation
      )
      XCTAssertEqual(
        cultureAfterReject.culture.receiptFingerprint,
        cultureBeforeReject.culture.receiptFingerprint
      )
      XCTAssertEqual(
        try cultureAfterReject.culture.buffers.map {
          try qualificationReadback($0, device: device)
        },
        cultureBytesBeforeReject
      )
    }

    // Retry the rejected causal step. Physics generation is reused from the
    // restored predecessor, while the private HumanIO sensor generation stays
    // monotonic and therefore skips the rejected candidate's generation 4.
    let retryTransaction = try brain.beginControl(
      controlStepIdentifier: 4,
      basePhysicsGeneration: afterReject.physicsGeneration,
      committedTimestamp: gateBTimestamp(4),
      targetTimestamp: gateBTimestamp(5),
      cachedDecisionFingerprint: 0x4e58_5245_4a45_4354
    )
    XCTAssertEqual(
      retryTransaction.token.fingerprint,
      rejectedTransaction.token.fingerprint
    )
    let retrySensors = try afterReject.sensorPacket(
      for: retryTransaction.token,
      compiledSpeciesTemplate: compiled
    )
    let retried = try publishRoot(
      brain: brain,
      native: native,
      transaction: retryTransaction,
      sensors: retrySensors,
      device: device,
      acceptedCulture: cultureBeforeReject
    )
    XCTAssertEqual(
      retried.cultureActionGeneration,
      cultureBeforeReject?.culture.generation
    )
    try recordPreparedState(retried.aggregate, device: device)
    XCTAssertEqual(retried.aggregate.publicationEpoch, 4)
    XCTAssertEqual(retried.aggregate.brainGeneration, 4)
    XCTAssertEqual(retried.aggregate.physicsGeneration, 4)
    XCTAssertEqual(retried.aggregate.sensorGeneration, 5)
    XCTAssertEqual(try native.currentInfo().residentContinuationCount, 4)
    if let cultureBeforeReject {
      let cultureAfterRetry = try XCTUnwrap(native.aggregateSnapshotV4IfAvailable())
      XCTAssertEqual(
        cultureAfterRetry.culture.generation,
        cultureBeforeReject.culture.generation + 1
      )
    }
    XCTAssertEqual(
      try acceptedGateBytes(retried.physical.acceptedPhysicsGate),
      rejectedAcceptedToken
    )
    XCTAssertEqual(
      try sensorPayloadBytes(retried.physical.sensorCandidate, device: device),
      rejectedSensorPayload
    )

    // The accepted full-body roots are learner authority, not merely an
    // inference fixture. Freeze their immutable committed batch, perform the
    // real off-rollout MLX update, and materialize the exact successor on the
    // same Apple GPU. Held-out causal sensor intervention remains a separate
    // Gate B qualification; this establishes the production root-to-learner
    // and learner-to-runtime boundary it depends on.
    let learningBatch = try brain.makeLearningBatch()
    XCTAssertEqual(learningBatch.sourceGeneration, retried.aggregate.brainGeneration)
    XCTAssertEqual(
      learningBatch.parameterVersionFingerprint,
      publication.version.fingerprint
    )
    try assertAcceptedLearningRecordCoversEveryModality(
      learningBatch,
      compiled: compiled,
      sourceGeneration: retried.aggregate.brainGeneration
    )
    let learnerUpdate = try MLXBrainLearner().update(
      parentPublication: publication,
      batch: learningBatch
    )
    let replayedLearnerUpdate = try MLXBrainLearner().update(
      parentPublication: publication,
      batch: learningBatch
    )
    XCTAssertEqual(replayedLearnerUpdate, learnerUpdate)
    XCTAssertEqual(learnerUpdate.sourceMindCount, 1)
    XCTAssertEqual(learnerUpdate.sourceGeneration, retried.aggregate.brainGeneration)
    XCTAssertEqual(
      Set(learnerUpdate.losses.map(\.kind)),
      Set(BrainSlowLossKind.allCases)
    )
    XCTAssertTrue(learnerUpdate.losses.allSatisfy {
      $0.value.isFinite && $0.weight.isFinite
    })
    let learnedPublication = try BrainParameterPublication(
      parentVersion: publication.version,
      learnerUpdate: learnerUpdate
    )
    XCTAssertNotEqual(
      learnedPublication.version.fingerprint,
      publication.version.fingerprint
    )
    XCTAssertNotEqual(
      learnedPublication.sharedArtifact.artifactFingerprint,
      publication.sharedArtifact.artifactFingerprint
    )
    XCTAssertEqual(
      learnedPublication.sourceBatchFingerprint,
      learningBatch.batchFingerprint
    )
    let learnedBrain = try MetalNumiBrainRuntime.makeRuntime(
      configuration: brainConfiguration,
      publication: learnedPublication,
      device: device
    )
    XCTAssertEqual(learnedBrain.committedGeneration, 0)
    XCTAssertEqual(
      learnedBrain.parameterVersionFingerprint,
      learnedPublication.version.fingerprint
    )
    XCTAssertEqual(learnedBrain.deviceRegistryID, device.registryID)

    // Keep rollout on the immutable parent for four later accepted roots. The
    // successor never saw generations 5...8 during optimization, so they form
    // an exact temporal holdout for the first versioned intervention runner.
    var heldoutAggregate = retried.aggregate
    for controlStep in UInt64(5)...UInt64(8) {
      let transaction = try brain.beginControl(
        controlStepIdentifier: controlStep,
        basePhysicsGeneration: heldoutAggregate.physicsGeneration,
        committedTimestamp: gateBTimestamp(controlStep),
        targetTimestamp: gateBTimestamp(controlStep + 1),
        cachedDecisionFingerprint: 0x4e58_484f_4c44_0000 | controlStep
      )
      let sensors = try heldoutAggregate.sensorPacket(
        for: transaction.token,
        compiledSpeciesTemplate: compiled
      )
      heldoutAggregate = try publishRoot(
        brain: brain,
        native: native,
        transaction: transaction,
        sensors: sensors,
        device: device
      ).aggregate
      try recordPreparedState(heldoutAggregate, device: device)
    }
    XCTAssertEqual(heldoutAggregate.brainGeneration, 8)
    let heldoutBatch = try brain.makeLearningBatch()
    let evaluator = MLXGateBCausalEvaluator()
    var evaluations: [NumanXGateBPolicyHeadEvaluation] = []
    for modality in compiled.species.senses.filter(\.enabled).map(\.modality) {
      let first = try evaluator.evaluate(
        publication: learnedPublication,
        batch: heldoutBatch,
        species: compiled.species,
        modality: modality,
        minimumGeneration: 5,
        maximumGeneration: 8,
        shuffleSeed: 0x4e58_4741_5445_4201
      )
      let replay = try evaluator.evaluate(
        publication: learnedPublication,
        batch: heldoutBatch,
        species: compiled.species,
        modality: modality,
        minimumGeneration: 5,
        maximumGeneration: 8,
        shuffleSeed: 0x4e58_4741_5445_4201
      )
      XCTAssertEqual(first, replay)
      XCTAssertEqual(Set(first.map(\.intervention)), Set(
        NumanXGateBInterventionKind.allCases
      ))
      XCTAssertTrue(first.allSatisfy {
        $0.transitionCount == 4
          && $0.minimumGeneration == 5
          && $0.maximumGeneration == 8
      })
      evaluations.append(contentsOf: first)
    }
    XCTAssertEqual(evaluations.count, 7 * 4)
    XCTAssertTrue(evaluations.filter {
      $0.intervention == .intact
    }.allSatisfy { $0.actionDeltaFromIntact == 0 })
    XCTAssertTrue(evaluations.contains {
      $0.intervention == .ablated && $0.actionDeltaFromIntact > 0
    })
    XCTAssertThrowsError(try evaluator.evaluate(
      publication: learnedPublication,
      batch: heldoutBatch,
      species: compiled.species,
      modality: .vision,
      minimumGeneration: 4,
      maximumGeneration: 8
    ))
    XCTAssertThrowsError(try evaluator.evaluate(
      publication: learnedPublication,
      batch: heldoutBatch,
      species: compiled.species,
      modality: .olfaction,
      minimumGeneration: 5,
      maximumGeneration: 8
    ))
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      for result in evaluations.sorted(by: {
        ($0.modality.rawValue, $0.intervention.rawValue)
          < ($1.modality.rawValue, $1.intervention.rawValue)
      }) {
        print(
          "GateB policy-head modality=\(result.modality) "
            + "intervention=\(result.intervention) "
            + "mse=\(result.actionMeanSquaredError) "
            + "delta=\(result.actionDeltaFromIntact)"
        )
      }
    }
  }

  private func publishRoot(
    brain: MetalNumiBrainRuntime,
    native: MetalNumanXBridgeV1Runtime,
    transaction: MetalNumiBrainRuntime.ControlTransaction,
    sensors: NumanXSensorPacketLease,
    device: any MTLDevice,
    acceptedCulture: MetalNumanXBridgeV1Runtime.AggregateSnapshotV4? = nil,
    externalGoal: ActiveGoal? = nil,
    developmentalCapabilityCodes: [UInt64] = [],
    developmentalIntentFingerprintXor: UInt64 = 0,
    activeSensingCommandScale: Float = 1
  ) throws -> (
    physical: MetalNumanXBridgeV1PreparedRoot,
    aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot,
    candidateSensorValues: [Float],
    motorExcitations: [Float],
    descendingSomatic: [Float],
    activeVisionCommand: Float,
    activeVisionConfidence: Float,
    cultureActionGeneration: UInt64?
  ) {
    let staged = try prepareRoot(
      brain: brain,
      native: native,
      transaction: transaction,
      sensors: sensors,
      device: device,
      acceptedCulture: acceptedCulture,
      externalGoal: externalGoal,
      developmentalCapabilityCodes: developmentalCapabilityCodes,
      developmentalIntentFingerprintXor: developmentalIntentFingerprintXor,
      activeSensingCommandScale: activeSensingCommandScale
    )
    let physical = staged.physical
    let prepared = staged.prepared
    let candidateSensorValues = try qualificationSensorValues(
      physical.sensorCandidate, device: device
    )
    let proposalLatch = AsyncResultLatch<MetalNumanXHumanMatterProposalLease>()
    try physical.submitProposal(brain: prepared) { proposalLatch.complete($0) }

    _ = try prepared.waitUntilBrainPrepareCompleted(timeoutMilliseconds: 10_000)
    let proposal = try proposalLatch.wait()
    let preflightStatus = waitForPreflight(prepared)
    guard preflightStatus == .numanXPreflightReady else {
      throw TissueError.transaction(
        prepared.preflightFailureDescription
          ?? "NumanX preflight settled as \(preflightStatus)"
      )
    }
    let jointCommitFingerprint = try brain.numanXPreparedJointCommitFingerprint(
      for: prepared,
      identity: physical.identity
    )
    try physical.reserveApplication(brain: prepared)

    let ackPoint = try point(device, value: 1)
    let ack = try brain.submitNumanXBrainAck(
      prepared,
      proposal: proposal,
      signal: ackPoint
    )
    let appliedLatch = AsyncResultLatch<MetalNumanXHumanMatterAppliedLease>()
    try physical.submitApply(ack: ack) { appliedLatch.complete($0) }
    let applied = try appliedLatch.wait()
    XCTAssertEqual(applied.commandDisposition, .acceptedPendingPublication)

    let resolution = try physical.makeResolution(
      proposal: proposal,
      applied: applied,
      jointCommitFingerprint: jointCommitFingerprint,
      brainGeneration: transaction.token.shadowGeneration
    )
    let validationPoint = try point(device, value: 1)
    _ = try brain.validateNumanXAppliedRoot(
      prepared,
      ack: ack,
      applied: applied,
      resolution: resolution,
      signal: validationPoint
    )
    XCTAssertEqual(waitForClose(prepared), .committed)
    XCTAssertFalse(brain.hasOpenControl)
    XCTAssertEqual(brain.committedGeneration, transaction.token.shadowGeneration)
    return (
      physical,
      try XCTUnwrap(native.aggregateSnapshotIfAvailable()),
      candidateSensorValues,
      staged.motorExcitations,
      staged.descendingSomatic,
      staged.activeVisionCommand,
      staged.activeVisionConfidence,
      staged.cultureActionGeneration
    )
  }

  private struct AcceptedScenario {
    let batch: MetalLearningBatch
    let finalSensorValues: [Float]
    let finalSensorValuesByModality: [SensoryModality: [Float]]
    let sensorValuesByGeneration: [[SensoryModality: [Float]]]
    let sensorFingerprints: [UInt64]
    let candidateSensorFingerprints: [UInt64]
    let motorExcitationsByGeneration: [[Float]]
    let descendingSomaticByGeneration: [[Float]]
    let activeVisionCommands: [Float]
    let activeVisionConfidences: [Float]
    let visionDepthValidCounts: [Int]
    let visionGeometryValidCounts: [Int]
  }

  private enum ClosedLoopSensorIntervention {
    case ablated(SensoryModality)
    case scaled(SensoryModality, Float)
  }

  private func runAcceptedScenario(
    paths: BridgePaths,
    contactPath: String,
    compiled: CompiledSpeciesTemplate,
    publication: BrainParameterPublication,
    device: any MTLDevice,
    rootCount: UInt64,
    timestepMicroseconds: UInt32 = 1_000,
    externalGoal: ((UInt64) throws -> ActiveGoal)? = nil,
    muscleLocomotor: MuscleLocomotorProgram? = nil,
    sensorIntervention: ClosedLoopSensorIntervention? = nil,
    developmentalCapabilityCodes: [UInt64] = [],
    developmentalIntentFingerprintXor: UInt64 = 0,
    activeSensingCommandScale: Float = 1,
    authoredWorld: MetalNumanXBridgeV1Runtime.AuthoredMatterWorld? = nil,
    initialTimestampMicroseconds: UInt64? = nil,
    preparedTraceLabel: String? = nil
  ) throws -> AcceptedScenario {
    guard rootCount > 0 else {
      throw TissueError.transaction("Gate B scenario requires accepted roots")
    }
    let parameters = TissueParameters.corticalSheetV0
    let brain = try MetalNumiBrainRuntime.makeRuntime(
      configuration: MetalNumiBrainConfiguration(
        initialTissueState: try CPUTissueDynamics.makeRestingGrid(
          width: 8, height: 8, parameters: parameters
        ),
        tissueParameters: parameters,
        tissueStimulus: .none,
        compiledSpeciesTemplate: compiled,
        randomContext: TissueRandomContext(
          seed: 0x4e55_4d49,
          environmentIdentifier: 0,
          episodeIdentifier: 1
        ),
        schedulerEnvironmentIdentifier: 0,
        maximumEncodedSubsteps: 1,
        muscleLocomotor: muscleLocomotor
      ),
      publication: publication,
      device: device
    )
    let native = try makeNativeRuntime(
      paths: paths,
      device: device,
      supportContactPath: contactPath,
      timestepMicroseconds: timestepMicroseconds, authoredWorld: authoredWorld
    )
    var aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot?
    var sensorFingerprints: [UInt64] = []
    var candidateSensorFingerprints: [UInt64] = []
    var finalSensorValues: [Float] = []
    var finalSensorValuesByModality: [SensoryModality: [Float]] = [:]
    var sensorValuesByGeneration: [[SensoryModality: [Float]]] = []
    var motorExcitationsByGeneration: [[Float]] = []
    var descendingSomaticByGeneration: [[Float]] = []
    var activeVisionCommands: [Float] = []
    var activeVisionConfidences: [Float] = []
    var visionDepthValidCounts: [Int] = []
    var visionGeometryValidCounts: [Int] = []
    let initialTimestamp = initialTimestampMicroseconds ?? UInt64(timestepMicroseconds)
    for controlStep in UInt64(1)...rootCount {
      let transaction = try brain.beginControl(
        controlStepIdentifier: controlStep,
        basePhysicsGeneration: aggregate?.physicsGeneration ?? 0,
        committedTimestamp: BrainTimestamp(
          microseconds: initialTimestamp + (controlStep - 1) * UInt64(timestepMicroseconds)
        ),
        targetTimestamp: BrainTimestamp(
          microseconds: initialTimestamp + controlStep * UInt64(timestepMicroseconds)
        ),
        cachedDecisionFingerprint: 0x4e58_4742_0000_0000 | controlStep
      )
      let sensors = if let aggregate {
        if let sensorIntervention {
          try qualificationIntervenedSensorPacket(
            aggregate: aggregate,
            transaction: transaction.token,
            compiled: compiled,
            intervention: sensorIntervention,
            device: device
          )
        } else {
          try aggregate.sensorPacket(
            for: transaction.token,
            compiledSpeciesTemplate: compiled
          )
        }
      } else {
        try bootstrapSensorPacket(
          device: device,
          compiled: compiled,
          transaction: transaction.token,
          observationsAvailable: muscleLocomotor == nil
        )
      }
      do {
        let published = try publishRoot(
          brain: brain,
          native: native,
          transaction: transaction,
          sensors: sensors,
          device: device,
          externalGoal: try externalGoal?(controlStep),
          developmentalCapabilityCodes: developmentalCapabilityCodes,
          developmentalIntentFingerprintXor: developmentalIntentFingerprintXor,
          activeSensingCommandScale: activeSensingCommandScale
        )
        aggregate = published.aggregate
        candidateSensorFingerprints.append(
          fingerprint(published.candidateSensorValues)
        )
        finalSensorValuesByModality = try qualificationSensorValuesByModality(
          try XCTUnwrap(aggregate), device: device
        )
        finalSensorValues = finalSensorValuesByModality.keys.sorted(by: {
          $0.rawValue < $1.rawValue
        }).flatMap { finalSensorValuesByModality[$0] ?? [] }
        sensorValuesByGeneration.append(finalSensorValuesByModality)
        sensorFingerprints.append(fingerprint(finalSensorValues))
        motorExcitationsByGeneration.append(published.motorExcitations)
        if let label = preparedTraceLabel {
          try emitPreparedFrame(label, rootIndex: Int(controlStep), frame: finalSensorValuesByModality,
            motorExcitations: published.motorExcitations, timestepMicroseconds: timestepMicroseconds)
        }
        descendingSomaticByGeneration.append(published.descendingSomatic)
        activeVisionCommands.append(published.activeVisionCommand)
        activeVisionConfidences.append(published.activeVisionConfidence)
        let vision = try XCTUnwrap(
          aggregate?.channels.first { $0.modality == .vision }
        )
        let visionValidity = try qualificationUInt32s(
          from: try qualificationReadback(
            try XCTUnwrap(vision.validity), device: device
          )
        )
        visionDepthValidCounts.append(
          visionValidity.count { ($0 & 0x08) != 0 }
        )
        visionGeometryValidCounts.append(
          visionValidity.count { ($0 & 0x70) == 0x70 }
        )
      } catch {
        throw TissueError.transaction(
          "Gate B scenario \(contactPath) root \(controlStep) failed: \(error)"
        )
      }
    }
    XCTAssertEqual(aggregate?.brainGeneration, rootCount)
    XCTAssertEqual(aggregate?.physicsGeneration, rootCount)
    _ = try XCTUnwrap(aggregate)
    return AcceptedScenario(
      batch: try brain.makeLearningBatch(),
      finalSensorValues: finalSensorValues,
      finalSensorValuesByModality: finalSensorValuesByModality,
      sensorValuesByGeneration: sensorValuesByGeneration,
      sensorFingerprints: sensorFingerprints,
      candidateSensorFingerprints: candidateSensorFingerprints,
      motorExcitationsByGeneration: motorExcitationsByGeneration,
      descendingSomaticByGeneration: descendingSomaticByGeneration,
      activeVisionCommands: activeVisionCommands,
      activeVisionConfidences: activeVisionConfidences,
      visionDepthValidCounts: visionDepthValidCounts,
      visionGeometryValidCounts: visionGeometryValidCounts
    )
  }

  // Qualification-only intervention laboratory. The production path remains
  // zero-copy; this helper copies one accepted channel into a separately owned
  // same-device buffer and changes only the named modality before the next
  // Brain root. Published physical sensors are still read back independently
  // after that root, so intervention input never substitutes outcome evidence.
  private func qualificationIntervenedSensorPacket(
    aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot,
    transaction: BrainJointTransactionToken,
    compiled: CompiledSpeciesTemplate,
    intervention: ClosedLoopSensorIntervention,
    device: any MTLDevice
  ) throws -> NumanXSensorPacketLease {
    guard transaction.baseBrainGeneration == aggregate.brainGeneration,
      transaction.basePhysicsGeneration == aggregate.physicsGeneration
    else {
      throw TissueError.transaction(
        "Gate B intervention does not immediately follow its accepted root"
      )
    }
    let target: SensoryModality
    let scale: Float
    let invalidate: Bool
    switch intervention {
    case .ablated(let modality):
      target = modality
      scale = 0
      invalidate = true
    case .scaled(let modality, let factor):
      guard factor.isFinite, factor >= 0, factor <= 1 else {
        throw TissueError.transaction(
          "Gate B intervention scale must be finite and normalized"
        )
      }
      target = modality
      scale = factor
      invalidate = false
    }
    var replaced = false
    let sensors = try aggregate.channels.map { channel in
      guard channel.modality == target else { return channel.rawSensor }
      replaced = true
      guard let buffer = device.makeBuffer(
        length: channel.values.byteCount,
        options: [.storageModeShared, .hazardTrackingModeTracked]
      ) else {
        throw TissueError.metal("failed to allocate Gate B intervention buffer")
      }
      let source = try qualificationReadback(channel.rawSensor.buffer, device: device)
      guard source.count >= channel.values.byteCount else {
        throw TissueError.transaction(
          "Gate B intervention source range is truncated"
        )
      }
      let destination = buffer.contents().assumingMemoryBound(to: Float.self)
      let scalarCount = channel.values.byteCount / MemoryLayout<Float>.stride
      source.withUnsafeBytes { raw in
        let values = raw.bindMemory(to: Float.self)
        for index in 0..<scalarCount {
          destination[index] = values[index] * scale
        }
      }
      let validityBuffer: (any MTLBuffer)?
      if invalidate {
        let validityByteCount = channel.rawSensor.validityBuffer?.length
          ?? scalarCount * MemoryLayout<UInt32>.stride
        guard let invalid = device.makeBuffer(
          length: validityByteCount,
          options: [.storageModeShared, .hazardTrackingModeTracked]
        ) else {
          throw TissueError.metal(
            "failed to allocate Gate B intervention validity buffer"
          )
        }
        memset(invalid.contents(), 0, validityByteCount)
        validityBuffer = invalid
      } else {
        validityBuffer = channel.rawSensor.validityBuffer
      }
      return try MetalRawSensorBufferLease(
        buffer: buffer,
        modality: channel.modality,
        receptorTimestamp: channel.receptorTimestamp,
        receptorCount: channel.receptorCount,
        featureDimension: channel.featureDimension,
        validityBuffer: validityBuffer
      )
    }
    guard replaced else {
      throw TissueError.transaction(
        "Gate B intervention modality is absent from the aggregate root"
      )
    }
    return try NumanXSensorPacketLease(
      transaction: transaction,
      compiledSpeciesTemplate: compiled,
      rawSensors: sensors
    )
  }

  private func modalityDriftCost(
    _ scenario: AcceptedScenario,
    modality: SensoryModality
  ) -> Float {
    guard let first = scenario.sensorValuesByGeneration.first?[modality],
      let last = scenario.sensorValuesByGeneration.last?[modality],
      first.count == last.count, !first.isEmpty
    else { return .infinity }
    return zip(first, last).reduce(Float(0)) {
      let delta = $1.0 - $1.1
      return $0 + delta * delta
    } / Float(first.count)
  }

  private func interoceptiveFeatureMeans(
    _ scenario: AcceptedScenario
  ) -> [[Float]] {
    scenario.sensorValuesByGeneration.compactMap { channels in
      guard let values = channels[.interoception],
        !values.isEmpty, values.count % 6 == 0
      else { return nil }
      let receptorCount = values.count / 6
      return (0..<6).map { feature in
        stride(from: feature, to: values.count, by: 6).reduce(Float(0)) {
          $0 + values[$1]
        } / Float(receptorCount)
      }
    }
  }

  private func proprioceptiveActivationDeficit(
    _ scenario: AcceptedScenario
  ) -> Float {
    let features = proprioceptiveFeatureMeans(scenario)
    guard features.count == 10 else { return .infinity }
    return 1 - min(max(features[1], 0), 1)
  }

  private func proprioceptiveFeatureMeans(
    _ scenario: AcceptedScenario
  ) -> [Float] {
    guard let values = scenario.sensorValuesByGeneration.last?[.proprioception],
      !values.isEmpty, values.count % 10 == 0
    else { return [] }
    let receptorCount = values.count / 10
    return (0..<10).map { feature in
      stride(from: feature, to: values.count, by: 10).reduce(Float(0)) {
        $0 + values[$1]
      } / Float(receptorCount)
    }
  }

  private func qualificationSensorValues(
    _ candidate: MetalNumanXPendingSensorCandidateLease,
    device: any MTLDevice
  ) throws -> [Float] {
    try candidate.rawSensors
      .sorted { $0.view.modality.rawValue < $1.view.modality.rawValue }
      .flatMap { sensor -> [Float] in
        let bytes = try qualificationReadback(sensor.buffer, device: device)
        let scalarCount = Int(sensor.view.receptorCount)
          * Int(sensor.view.featureDimension)
        let logicalByteCount = scalarCount * MemoryLayout<Float>.stride
        guard bytes.count >= logicalByteCount else {
          throw TissueError.transaction(
            "Gate B unpublished sensor qualification range is malformed"
          )
        }
        return bytes.prefix(logicalByteCount).withUnsafeBytes { raw in
          stride(from: 0, to: logicalByteCount, by: MemoryLayout<Float>.stride).map {
            raw.loadUnaligned(fromByteOffset: $0, as: Float.self)
          }
        }
      }
  }

  private func qualificationSensorValuesByModality(
    _ aggregate: MetalNumanXBridgeV1Runtime.AggregateSnapshot,
    device: any MTLDevice
  ) throws -> [SensoryModality: [Float]] {
    try Dictionary(uniqueKeysWithValues: aggregate.channels.map { channel in
        let bytes = try qualificationReadback(channel.values, device: device)
        let scalarCount = Int(channel.receptorCount)
          * Int(channel.featureDimension)
        let logicalByteCount = scalarCount * MemoryLayout<Float>.stride
        guard bytes.count >= logicalByteCount else {
          throw TissueError.transaction(
            "Gate B sensor qualification range is malformed"
          )
        }
        let values = bytes.prefix(logicalByteCount).withUnsafeBytes { raw in
          stride(from: 0, to: logicalByteCount, by: MemoryLayout<Float>.stride).map {
            raw.loadUnaligned(fromByteOffset: $0, as: Float.self)
          }
        }
        return (channel.modality, values)
      })
  }

  private func fingerprint(_ values: [Float]) -> UInt64 {
    values.withUnsafeBytes { bytes in
      bytes.reduce(UInt64(14_695_981_039_346_656_037)) {
        ($0 ^ UInt64($1)) &* 1_099_511_628_211
      }
    }
  }

  private func tiltedSupportContactAsset(
    sourcePath: String,
    degrees: Float
  ) throws -> URL {
    guard degrees.isFinite, abs(degrees) <= 15 else {
      throw TissueError.transaction("Gate B support tilt is outside its range")
    }
    var bytes = [UInt8](try Data(contentsOf: URL(fileURLWithPath: sourcePath)))
    guard bytes.count >= 84 else {
      throw TissueError.transaction("Gate B support-contact asset is truncated")
    }
    func loadUInt32(_ offset: Int) -> UInt32 {
      UInt32(bytes[offset])
        | UInt32(bytes[offset + 1]) << 8
        | UInt32(bytes[offset + 2]) << 16
        | UInt32(bytes[offset + 3]) << 24
    }
    func loadFloat(_ offset: Int) -> Float {
      Float(bitPattern: loadUInt32(offset))
    }
    func storeUInt32(_ value: UInt32, _ offset: Int) {
      bytes[offset] = UInt8(truncatingIfNeeded: value)
      bytes[offset + 1] = UInt8(truncatingIfNeeded: value >> 8)
      bytes[offset + 2] = UInt8(truncatingIfNeeded: value >> 16)
      bytes[offset + 3] = UInt8(truncatingIfNeeded: value >> 24)
    }
    func storeFloat(_ value: Float, _ offset: Int) {
      storeUInt32(value.bitPattern, offset)
    }
    let magic = Array("NHCNT1\0\0".utf8)
    let supportCount = Int(loadUInt32(16))
    guard Array(bytes[0..<8]) == magic,
      loadUInt32(8) == 1, supportCount == 10, loadUInt32(20) == 0,
      bytes.count == 84 + supportCount * 48
    else {
      throw TissueError.transaction(
        "Gate B support-contact asset has unexpected provenance"
      )
    }
    let point = (0..<3).map { loadFloat(56 + $0 * 4) }
    let oldNormal = (0..<3).map { loadFloat(68 + $0 * 4) }
    let radians = degrees * .pi / 180
    let newNormal: [Float] = [sin(radians), 0, cos(radians)]
    for index in 0..<supportCount {
      let record = 84 + index * 48
      let witness = (0..<3).map { loadFloat(record + 20 + $0 * 4) }
      let oldDistance = loadFloat(record + 36)
      let sourceWorld = (0..<3).map {
        witness[$0] + oldDistance * oldNormal[$0]
      }
      let newDistance = (0..<3).reduce(Float(0)) {
        $0 + (sourceWorld[$1] - point[$1]) * newNormal[$1]
      }
      storeFloat(newDistance, record + 36)
      for axis in 0..<3 {
        storeFloat(
          sourceWorld[axis] - newDistance * newNormal[axis],
          record + 20 + axis * 4
        )
      }
    }
    for axis in 0..<3 {
      storeFloat(newNormal[axis], 68 + axis * 4)
    }
    let url = FileManager.default.temporaryDirectory.appendingPathComponent(
      "numanx-gate-b-support-\(UUID().uuidString).nhcnt"
    )
    try Data(bytes).write(to: url, options: .atomic)
    return url
  }

  private func supportStabilityGoal(
    target: [Float],
    controlStep: UInt64,
    targetBodyIdentifier: UInt32? = nil,
    timestepMicroseconds: UInt32 = 1_000
  ) throws -> ActiveGoal {
    guard target.count == 16, controlStep > 0 else {
      throw TissueError.transaction(
        "Gate B support-stability goal has invalid target or control step"
      )
    }
    let committedTimestamp = BrainTimestamp(
      microseconds: controlStep * UInt64(timestepMicroseconds)
    )
    return try ActiveGoal(
      identifier: 0x0047_4253_5441_0000 | controlStep,
      origin: .externalTask,
      targetState: BrainLatentVector(values: target, expectedCount: 16),
      priority: 10,
      deadline: BrainTimestamp(
        microseconds: (controlStep + 1) * UInt64(timestepMicroseconds)
      ),
      successModel: BrainLatentVector(values: target, expectedCount: 16),
      failureModel: BrainLatentVector(
        values: target.map { -$0 }, expectedCount: 16
      ),
      // This qualification goal must remain admissible whenever the global
      // hyperdirect safety stop has not fired. The runtime's independent
      // safety > 0.8 stop remains authoritative; this per-goal budget only
      // prevents ordinary counterfactual pruning from hiding the task option.
      damageRiskBudget: 1.0,
      persistence: 1,
      createdTimestamp: committedTimestamp,
      targetBodyIdentifier: targetBodyIdentifier
    )
  }

  private func assertAcceptedLearningRecordCoversEveryModality(
    _ batch: MetalLearningBatch,
    compiled: CompiledSpeciesTemplate,
    sourceGeneration: UInt64
  ) throws {
    let enabledModalities = compiled.species.senses
      .filter(\.enabled)
      .sorted { $0.modality.rawValue < $1.modality.rawValue }
      .map(\.modality)
    XCTAssertLessThanOrEqual(enabledModalities.count, 8)
    let storage = try batch.makeSharedStorageLease()
    var matchingRecordCount = 0
    for index in 0..<batch.transitionCapacity {
      let record = storage.baseAddress.advanced(
        by: index * batch.transitionStride
      )
      let identifier = record.load(as: UInt64.self)
      let generation = record.advanced(by: 32).load(as: UInt64.self)
      guard identifier != 0, generation == sourceGeneration else { continue }
      matchingRecordCount += 1
      XCTAssertEqual(
        record.advanced(by: 64).load(as: UInt32.self),
        MetalLearningBatch.transitionRecordVersion
      )
      let validityMask = record.advanced(by: 92).load(as: UInt32.self)
      let observations = record.advanced(by: 320)
        .assumingMemoryBound(to: Float.self)
      for (slot, modality) in enabledModalities.enumerated() {
        let component = slot * 3
        XCTAssertEqual(
          validityMask & (UInt32(7) << UInt32(component)),
          UInt32(7) << UInt32(component),
          "accepted learning record omitted \(modality)"
        )
        XCTAssertTrue(observations[component].isFinite)
        XCTAssertTrue(observations[component + 1].isFinite)
        XCTAssertTrue(observations[component + 2].isFinite)
      }
    }
    XCTAssertGreaterThan(matchingRecordCount, 0)
  }

  private func prepareRoot(
    brain: MetalNumiBrainRuntime,
    native: MetalNumanXBridgeV1Runtime,
    transaction: MetalNumiBrainRuntime.ControlTransaction,
    sensors: NumanXSensorPacketLease,
    device: any MTLDevice,
    acceptedCulture: MetalNumanXBridgeV1Runtime.AggregateSnapshotV4? = nil,
    externalGoal: ActiveGoal? = nil,
    developmentalCapabilityCodes: [UInt64] = [],
    developmentalIntentFingerprintXor: UInt64 = 0,
    activeSensingCommandScale: Float = 1
  ) throws -> (
    physical: MetalNumanXBridgeV1PreparedRoot,
    prepared: MetalNumiBrainRuntime.NumanXPreparedControlTicket,
    motorExcitations: [Float],
    descendingSomatic: [Float],
    activeVisionCommand: Float,
    activeVisionConfidence: Float,
    cultureActionGeneration: UInt64?
  ) {
    let decisionPoint = try point(device, value: 1)
    let motorPoint = try point(device, value: 1)
    let decision = try brain.submitInferAndDecide(
      transaction,
      numanXSensors: sensors,
      externalGoal: externalGoal,
      activeSensingCommandScale: activeSensingCommandScale,
      signal: decisionPoint
    )
    guard transaction.token.targetTimestamp.rawValue
        > transaction.token.committedTimestamp.rawValue
    else {
      throw TissueError.transaction(
        "Gate B transaction has no positive motor duration"
      )
    }
    let candidateDurationMicroseconds =
      transaction.token.targetTimestamp.rawValue
        - transaction.token.committedTimestamp.rawValue
    let motor = try brain.submitNumanXMotorCandidate(
      decision,
      transaction: transaction,
      candidateDurationMicroseconds: candidateDurationMicroseconds,
      acceptedCulture: acceptedCulture,
      signal: motorPoint
    )
    let rootLatch = AsyncResultLatch<MetalNumanXBridgeV1PreparedRoot>()
    try native.beginPhysicalRoot(transaction: transaction.token, motor: motor) {
      rootLatch.complete($0)
    }
    // The anatomical costal fixture has 46,278 tetrahedra. This is only a
    // hardware completion deadline; neither its 10 us timestep nor physical
    // solver admission tolerances change.
    let physical = try rootLatch.wait(timeout:
      ProcessInfo.processInfo.environment["NUMANX_COSTAL_BINDING"] == nil ? 10 : 60)

    // Diagnostic settlement only: the physical queue already consumed the
    // GPU motor gate without a host wait. This advances Brain's host phase
    // after both exact terminal feedbacks are available.
    _ = try brain.finishNumanXMotorSubmission(
      motor,
      transaction: transaction,
      timeoutMilliseconds: 10_000
    )
    XCTAssertEqual(
      physical.identity.transactionFingerprint,
      transaction.token.fingerprint
    )
    let motorExcitations = try qualificationUInt32s(
      from: qualificationReadback(motor.buffers.excitationBuffer, device: device)
    ).map { Float(bitPattern: $0) }
    let activeSensingByteCount = Int(motor.candidate.activeSensingCommandByteCount)
    guard activeSensingByteCount <= motor.buffers.activeSensingBuffer.length else {
      throw TissueError.transaction(
        "Gate B active-sensing command exceeds its retained buffer"
      )
    }
    let activeSensingWords = try qualificationUInt32s(
      from: qualificationReadback(
        motor.buffers.activeSensingBuffer,
        byteOffset: 0, byteCount: activeSensingByteCount, device: device
      )
    )
    guard activeSensingWords.count == 4 else {
      throw TissueError.transaction(
        "Gate B active-sensing command has the wrong ABI size"
      )
    }
    let activeSensingCommand = Float(bitPattern: activeSensingWords[0])
    let activeSensingConfidence = Float(bitPattern: activeSensingWords[1])
    XCTAssertTrue(activeSensingCommand.isFinite)
    XCTAssertTrue((-1...1).contains(activeSensingCommand))
    XCTAssertTrue((0...1).contains(activeSensingConfidence))
    XCTAssertEqual(
      activeSensingWords[3] & 0xff,
      UInt32(SensoryModality.vision.rawValue)
    )
    XCTAssertNotEqual(activeSensingWords[3] & (1 << 16), 0)
    let decisionSource = motor.motorTicket.motorEvaluation
      .decisionEvaluation.sourceBuffer
    guard motor.decision.descendingSomaticBaselineGPUAddress
        >= decisionSource.gpuAddress,
      let descendingStart = Int(exactly:
        motor.decision.descendingSomaticBaselineGPUAddress
          - decisionSource.gpuAddress
      )
    else {
      throw TissueError.transaction(
        "Gate B descending somatic address is outside its retained decision buffer"
      )
    }
    let descendingEnd = descendingStart
      + motor.decision.descendingSomaticBaselineByteCount
    let decisionBytes = try qualificationReadback(decisionSource, device: device)
    guard descendingStart >= 0, descendingEnd <= decisionBytes.count else {
      throw TissueError.transaction(
        "Gate B descending somatic range is truncated"
      )
    }
    let descendingSomatic = decisionBytes[descendingStart..<descendingEnd]
      .withUnsafeBytes { raw in
        Array(raw.bindMemory(to: Float.self))
      }
    guard motor.decision.motorCommandGPUAddress >= decisionSource.gpuAddress,
      let motorCommandStart = Int(exactly:
        motor.decision.motorCommandGPUAddress - decisionSource.gpuAddress
      )
    else {
      throw TissueError.transaction(
        "Gate B motor command address is outside its retained decision buffer"
      )
    }
    let motorCommandByteCount = motor.decision.motorCommandCount * 32
    let motorCommandEnd = motorCommandStart + motorCommandByteCount
    guard motorCommandStart >= 0, motorCommandEnd <= decisionBytes.count else {
      throw TissueError.transaction(
        "Gate B motor command range is truncated"
      )
    }
    let motorCommandWords = try qualificationUInt32s(
      from: Array(decisionBytes[motorCommandStart..<motorCommandEnd])
    )
    let commandExcitations = stride(
      from: 0, to: motorCommandWords.count, by: 8
    ).map { Float(bitPattern: motorCommandWords[$0]) }
    let riskInhibitions = stride(
      from: 5, to: motorCommandWords.count, by: 8
    ).map { Float(bitPattern: motorCommandWords[$0]) }
    guard motor.decision.activeControlGPUAddress >= decisionSource.gpuAddress,
      let controlStart = Int(exactly:
        motor.decision.activeControlGPUAddress - decisionSource.gpuAddress
      )
    else {
      throw TissueError.transaction(
        "Gate B control header is outside its retained decision buffer"
      )
    }
    let controlEnd = controlStart + motor.decision.activeControlByteCount
    guard controlStart >= 0, controlEnd <= decisionBytes.count else {
      throw TissueError.transaction("Gate B control header is truncated")
    }
    let controlWords = try qualificationUInt32s(
      from: Array(decisionBytes[controlStart..<controlEnd])
    )
    let controlMode = controlWords[8]
    let controlFlags = controlWords[11]
    let predictedInformationGain = Float(bitPattern: controlWords[21])
    let unsupportedUncertainty = Float(bitPattern: controlWords[22])
    guard motor.decision.internalActionGPUAddress >= decisionSource.gpuAddress,
      let internalActionStart = Int(exactly:
        motor.decision.internalActionGPUAddress - decisionSource.gpuAddress
      )
    else {
      throw TissueError.transaction(
        "Gate B internal actions are outside their retained decision buffer"
      )
    }
    let internalActionByteCount = motor.decision.internalActionCount * 64
    let internalActionEnd = internalActionStart + internalActionByteCount
    guard internalActionStart >= 0, internalActionEnd <= decisionBytes.count else {
      throw TissueError.transaction("Gate B internal actions are truncated")
    }
    let internalActionWords = try qualificationUInt32s(
      from: Array(decisionBytes[internalActionStart..<internalActionEnd])
    )
    let inhibitionActionBase = 6 * 16
    let inhibitionActionKind = internalActionWords[inhibitionActionBase + 4]
    let inhibitionActionFlags = internalActionWords[inhibitionActionBase + 5]
    let inhibitionActionPriority = Float(
      bitPattern: internalActionWords[inhibitionActionBase + 8]
    )
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      let layout = brain.cognitive.agentStateRuntime.arena.layout
      func peakRisk(_ kind: MetalAgentHotSection, _ features: [Int]) -> String {
        let section = layout.section(kind)
        var peak: Float = 0; var location = "none"
        for row in 0..<section.elementCount {
          for feature in features {
            let offset = section.byteOffset + row * section.elementStride + feature * 4
            if offset + 4 <= decisionBytes.count {
              let value = decisionBytes.withUnsafeBytes { $0.loadUnaligned(fromByteOffset: offset, as: Float.self) }
              if abs(value) > peak { peak = abs(value); location = "row=\(row):feature=\(feature)" }
            }
          }
        }
        return "\(location):value=\(peak)"
      }
      print("GateB risk-diagnostics body=\(peakRisk(.bodyBelief, [24,25,30])) joint=\(peakRisk(.jointBelief, [24,25,26,27,28,29,31])) drives=\(peakRisk(.drives, [0]))")
      print(
        "GateB motor-command excitationMax=\(commandExcitations.max() ?? .nan) "
          + "riskMin=\(riskInhibitions.min() ?? .nan) "
          + "riskMax=\(riskInhibitions.max() ?? .nan) "
          + "controlMode=\(controlMode) controlFlags=0x\(String(controlFlags, radix: 16)) "
          + "inhibitionKind=\(inhibitionActionKind) "
          + "inhibitionFlags=0x\(String(inhibitionActionFlags, radix: 16)) "
          + "inhibitionPriority=\(inhibitionActionPriority) "
          + "predictedInformation=\(predictedInformationGain) "
          + "unsupportedUncertainty=\(unsupportedUncertainty) "
          + "activeVisionCommand=\(activeSensingCommand) "
          + "activeVisionConfidence=\(activeSensingConfidence)"
      )
    }
    XCTAssertEqual(physical.sensorCandidate.rawSensors.count, 7)
    if ProcessInfo.processInfo.environment["NUMANX_GATE_B_EVIDENCE"] == "1" {
      let gateBytes = try qualificationReadback(
        physical.acceptedPhysicsGate.buffer, device: device
      )
      let gateWords = gateBytes.withUnsafeBytes {
        Array($0.bindMemory(to: UInt64.self).prefix(8))
      }
      print(
        "GateB physical-token words="
          + gateWords.map { String(format: "%016llx", $0) }.joined(separator: ",")
      )
      if let proprioception = physical.sensorCandidate.rawSensors.first(where: {
        $0.view.modality == .proprioception
      }), let validity = proprioception.validityBuffer {
        let validityWords = try qualificationUInt32s(
          from: qualificationReadback(validity, device: device)
        )
        print(
          "GateB physical-proprio-validity="
            + validityWords.prefix(8).map(String.init).joined(separator: ",")
        )
      }
    }

    let fastPoint = try point(device, value: 1)
    let brainPoint = try point(device, value: 1)
    let preflightPoint = try point(device, value: 1)
    let fast = try brain.submitProvisionalAcceptedFastRoot(
      transaction,
      waitFor: physical.physicalPreparedPoint,
      signal: fastPoint
    )
    let developmentalIntents = try developmentalIntentLease(
      device: device,
      codes: developmentalCapabilityCodes,
      timestamp: transaction.token.targetTimestamp,
      fingerprintXor: developmentalIntentFingerprintXor
    )
    let prepared = try brain.submitNumanXPreparedControl(
      transaction,
      provisionalFast: fast,
      identity: physical.identity,
      acceptedPhysicsGate: physical.acceptedPhysicsGate,
      sensorCandidate: physical.sensorCandidate,
      culturePrepared: physical.culture,
      developmentalIntents: developmentalIntents,
      signal: brainPoint,
      thenSignal: preflightPoint
    )
    _ = try prepared.waitUntilBrainPrepareCompleted(timeoutMilliseconds: 10_000)
    let preflightStatus = waitForPreflight(prepared)
    guard preflightStatus == .numanXPreflightReady else {
      throw TissueError.transaction(
        prepared.preflightFailureDescription
          ?? "NumanX preflight settled as \(preflightStatus)"
      )
    }
    return (
      physical,
      prepared,
      motorExcitations,
      descendingSomatic,
      activeSensingCommand,
      activeSensingConfidence,
      motor.acceptedCultureActionGeneration
    )
  }

  private func developmentalIntentLease(
    device: any MTLDevice,
    codes: [UInt64],
    timestamp: BrainTimestamp,
    fingerprintXor: UInt64 = 0
  ) throws -> MetalDevelopmentalCapabilityIntentBufferLease? {
    guard !codes.isEmpty else { return nil }
    let records = try codes.map { code in
      var record = try MetalDevelopmentalCapabilityIntentRecord(
        code: code,
        timestamp: timestamp,
        confidence: 1
      )
      record.intentFingerprint ^= fingerprintXor
      return record
    }
    let byteCount = records.count
      * MetalDevelopmentalCapabilityIntentRecord.byteCount
    guard let buffer = device.makeBuffer(
      length: byteCount,
      options: [.storageModeShared, .hazardTrackingModeTracked]
    ) else {
      throw TissueError.metal("failed to allocate developmental intent buffer")
    }
    records.withUnsafeBytes { bytes in
      if let source = bytes.baseAddress {
        buffer.contents().copyMemory(from: source, byteCount: bytes.count)
      }
    }
    return try MetalDevelopmentalCapabilityIntentBufferLease(
      buffer: buffer,
      intentCount: records.count,
      timestamp: timestamp
    )
  }

  private struct BridgePaths {
    let library: String
    let rigid: String
    let muscle: String
    let contacts: String
    let visualPack: String
    let visionProfile: String
    let metalRoboMetallib: String
    let matterMetallib: String
    let material: String
  }

  private func makeNativeRuntime(
    paths: BridgePaths,
    device: any MTLDevice,
    supportContactPath: String? = nil,
    timestepMicroseconds: UInt32 = 1_000,
    authoredWorld: MetalNumanXBridgeV1Runtime.AuthoredMatterWorld? = nil
  ) throws -> MetalNumanXBridgeV1Runtime {
    try MetalNumanXBridgeV1Runtime(
      libraryPath: paths.library,
      device: device,
      configuration: .init(
        rigidPayloadPath: paths.rigid,
        musclePayloadPath: paths.muscle,
        supportContactPayloadPath: supportContactPath ?? paths.contacts,
        visualPackPath: paths.visualPack,
        visionProfilePath: paths.visionProfile,
        metalRoboMetallibPath: paths.metalRoboMetallib,
        matterMetallibPath: paths.matterMetallib,
        matterMaterialPath: authoredWorld == nil ? paths.material : "",
        timestepMicroseconds: UInt64(timestepMicroseconds),
        maximumRetainedBytes: 1 << 30,
        transactionSlotCount: 2, authoredMatterWorld: authoredWorld
      )
    )
  }

  private func bridgePaths() throws -> BridgePaths {
    let environment = ProcessInfo.processInfo.environment
    let keys = [
      "NUMANX_METALROBO_LIBRARY", "NUMANX_FULLBODY_RIGID",
      "NUMANX_FULLBODY_MUSCLE", "NUMANX_METALROBO_METALLIB",
      "NUMANX_FULLBODY_CONTACT", "NUMANX_MATTER_METALLIB",
      "NUMANX_FULLBODY_VISUAL_PACK", "NUMANX_FULLBODY_VISION_PROFILE",
      "NUMANX_MATTER_MATERIAL",
    ]
    guard keys.allSatisfy({ !(environment[$0] ?? "").isEmpty }) else {
      throw XCTSkip("real NumanX bridge paths are not configured")
    }
    return BridgePaths(
      library: environment[keys[0]]!, rigid: environment[keys[1]]!,
      muscle: environment[keys[2]]!, contacts: environment[keys[4]]!,
      visualPack: environment[keys[6]]!, visionProfile: environment[keys[7]]!,
      metalRoboMetallib: environment[keys[3]]!,
      matterMetallib: environment[keys[5]]!, material: environment[keys[8]]!
    )
  }

  private func point(
    _ device: any MTLDevice,
    value: UInt64
  ) throws -> MetalSharedEventPoint {
    guard let event = device.makeSharedEvent() else {
      throw TissueError.metal("failed to allocate NumanX test event")
    }
    return try MetalSharedEventPoint(event: event, value: value)
  }

  // Test-only replay evidence after the producing root has completed. Native
  // accepted gates may be private; retain GPU ownership and copy only this range
  // through the same bounded diagnostic path used for private sensor evidence.
  private func acceptedGateBytes(
    _ gate: MetalAcceptedPhysicsGateLease
  ) throws -> [UInt8] {
    try qualificationReadback(
      gate.buffer, byteOffset: gate.byteOffset,
      byteCount: MetalAcceptedPhysicsGateLease.byteCount, device: gate.buffer.device
    )
  }

  // Test-only evidence for private native sensor bytes. Production consumers
  // retain and bind these ranges on GPU; they never synchronize or copy them
  // through the host.
  private func qualificationReadback(
    _ range: MetalNumanXHumanIOCandidateRangeLease,
    device: any MTLDevice
  ) throws -> [UInt8] {
    try qualificationReadback(
      range.buffer, byteOffset: range.byteOffset, byteCount: range.byteCount,
      device: device
    )
  }

  private func qualificationReadback(
    _ buffer: any MTLBuffer,
    byteOffset: Int = 0,
    byteCount: Int? = nil,
    device: any MTLDevice
  ) throws -> [UInt8] {
    let count = byteCount ?? buffer.length
    let (end, overflow) = byteOffset.addingReportingOverflow(count)
    guard byteOffset >= 0, count > 0, !overflow, end <= buffer.length,
      buffer.device.registryID == device.registryID else {
      throw TissueError.transaction("qualification readback range or device is invalid")
    }
    guard let staging = device.makeBuffer(
      length: count,
      options: [.storageModeShared, .hazardTrackingModeTracked]
    ), let queue = device.makeCommandQueue(),
      let commandBuffer = queue.makeCommandBuffer(),
      let blit = commandBuffer.makeBlitCommandEncoder()
    else {
      throw TissueError.metal("failed to allocate qualification readback")
    }
    blit.copy(
      from: buffer, sourceOffset: byteOffset,
      to: staging, destinationOffset: 0, size: count
    )
    blit.endEncoding()
    commandBuffer.commit()
    commandBuffer.waitUntilCompleted()
    guard commandBuffer.status == .completed else {
      throw TissueError.metal("qualification readback command failed")
    }
    return Array(UnsafeRawBufferPointer(
      start: staging.contents(), count: staging.length
    ))
  }

  private func qualificationUInt32s(from bytes: [UInt8]) throws -> [UInt32] {
    guard bytes.count.isMultiple(of: MemoryLayout<UInt32>.stride) else {
      throw TissueError.transaction("qualification UInt32 range is malformed")
    }
    return bytes.withUnsafeBytes { raw in
      stride(from: 0, to: raw.count, by: MemoryLayout<UInt32>.stride).map {
        raw.loadUnaligned(fromByteOffset: $0, as: UInt32.self)
      }
    }
  }

  private func sensorPayloadBytes(
    _ candidate: MetalNumanXPendingSensorCandidateLease,
    device: any MTLDevice
  ) throws -> [UInt8] {
    try candidate.rawSensors.reduce(into: [UInt8]()) { result, sensor in
      let valueRange = try MetalNumanXHumanIOCandidateRangeLease(
        buffer: sensor.buffer,
        metalBufferObject: Unmanaged.passUnretained(
          sensor.buffer as AnyObject
        ).toOpaque(),
        gpuAddress: sensor.view.gpuAddress,
        byteOffset: 0,
        byteCount: sensor.view.byteCount,
        elementType: MetalNumanXHumanIOCandidateRangeLease.float32ElementType,
        elementByteCount: UInt32(MemoryLayout<Float>.stride)
      )
      result.append(contentsOf: try qualificationReadback(
        valueRange, device: device
      ))
      if let validity = sensor.validityBuffer {
        let validityRange = try MetalNumanXHumanIOCandidateRangeLease(
          buffer: validity,
          metalBufferObject: Unmanaged.passUnretained(
            validity as AnyObject
          ).toOpaque(),
          gpuAddress: sensor.view.validityGPUAddress,
          byteOffset: 0,
          byteCount: sensor.view.validityByteCount,
          elementType: MetalNumanXHumanIOCandidateRangeLease.uint32ElementType,
          elementByteCount: UInt32(MemoryLayout<UInt32>.stride)
        )
        result.append(contentsOf: try qualificationReadback(
          validityRange, device: device
        ))
      }
    }
  }

  private func bootstrapSensorPacket(
    device: any MTLDevice,
    compiled: CompiledSpeciesTemplate,
    transaction: BrainJointTransactionToken,
    observationsAvailable: Bool = true
  ) throws -> NumanXSensorPacketLease {
    let sensors = try compiled.species.senses.filter(\.enabled).map { topology in
      guard transaction.committedTimestamp.rawValue >= UInt64(topology.latencyMicroseconds) else {
        throw TissueError.transaction("bootstrap timestamp precedes the authored receptor latency")
      }
      let scalarCount = Int(topology.receptorCount)
        * Int(topology.observationDimension)
      guard let values = device.makeBuffer(
        length: scalarCount * MemoryLayout<Float>.stride,
        options: [.storageModeShared, .hazardTrackingModeTracked]
      ), let validity = device.makeBuffer(
        length: Int(topology.receptorCount) * MemoryLayout<UInt32>.stride,
        options: [.storageModeShared, .hazardTrackingModeTracked]
      ) else {
        throw TissueError.metal("failed to allocate bootstrap HumanIO sensors")
      }
      values.contents().assumingMemoryBound(to: Float.self).initialize(
        repeating: topology.modality == .proprioception ? 0.25 : 0.5,
        count: scalarCount
      )
      validity.contents().assumingMemoryBound(to: UInt32.self).initialize(
        repeating: observationsAvailable ? 1 : 0,
        count: Int(topology.receptorCount)
      )
      return try MetalRawSensorBufferLease(
        buffer: values,
        modality: topology.modality,
        receptorTimestamp: BrainTimestamp(
          microseconds: transaction.committedTimestamp.rawValue
            - UInt64(topology.latencyMicroseconds)
        ),
        receptorCount: topology.receptorCount,
        featureDimension: topology.observationDimension,
        validityBuffer: validity
      )
    }
    return try NumanXSensorPacketLease(
      transaction: transaction,
      compiledSpeciesTemplate: compiled,
      rawSensors: sensors
    )
  }

  private func waitForPreflight(
    _ ticket: MetalNumiBrainRuntime.NumanXPreparedControlTicket
  ) -> MetalNumiBrainRuntime.ControlTransaction.Status {
    let deadline = Date(timeIntervalSinceNow: 10)
    var status = ticket.status
    while status == .numanXPrepareSubmitted, Date() < deadline {
      Thread.sleep(forTimeInterval: 0.001)
      status = ticket.status
    }
    return status
  }

  private func waitForClose(
    _ ticket: MetalNumiBrainRuntime.NumanXPreparedControlTicket
  ) -> MetalNumiBrainRuntime.ControlTransaction.Status {
    let deadline = Date(timeIntervalSinceNow: 10)
    var status = ticket.status
    while status != .committed, status != .aborted,
      status != .terminalQuarantined,
      status != .numanXAppliedValidationRetryRequired,
      Date() < deadline
    {
      Thread.sleep(forTimeInterval: 0.001)
      status = ticket.status
    }
    return status
  }
}

@available(macOS 26.0, *)
private final class AsyncResultLatch<Value: Sendable>: @unchecked Sendable {
  private let condition = NSCondition()
  private var result: Result<Value, Error>?

  func complete(_ value: Result<Value, Error>) {
    condition.lock()
    guard result == nil else {
      condition.unlock()
      return
    }
    result = value
    condition.broadcast()
    condition.unlock()
  }

  func wait(timeout: TimeInterval = 10) throws -> Value {
    condition.lock()
    defer { condition.unlock() }
    let deadline = Date(timeIntervalSinceNow: timeout)
    while result == nil, condition.wait(until: deadline) {}
    guard let result else {
      throw TissueError.transaction("NumanX callback did not settle before timeout")
    }
    return try result.get()
  }
}
