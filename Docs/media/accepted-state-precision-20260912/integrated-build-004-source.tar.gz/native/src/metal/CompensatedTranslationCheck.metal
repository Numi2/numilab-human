#include <metal_stdlib>
using namespace metal;
#include "metalrobo/compensated_translation_gpu.h"

// Numerical qualification of the exact production helper. This is not an
// alternative dynamics path: input velocities are manufactured test vectors.
kernel void mr_compensated_translation_check(
    device const MRCompensatedRootTranslationGPU* initial [[buffer(0)]],
    device const float4* velocityAndDt [[buffer(1)]],
    device const uint* repetitions [[buffer(2)]],
    device MRCompensatedRootTranslationGPU* result [[buffer(3)]],
    device float4* projection [[buffer(4)]],
    device MRCompensatedPositionGPU* pairedPosition [[buffer(5)]],
    constant uint& count [[buffer(6)]],
    uint i [[thread_position_in_grid]]) {
    if (i >= count) return;
    auto state = initial[i];
    for (uint n=0u; n<repetitions[i]; ++n)
        state = mrCompensatedTranslationAdvance(state, velocityAndDt[i], velocityAndDt[i].w);
    result[i] = state;
    projection[i] = mrCompensatedTranslationProjection(state);
    pairedPosition[i] = mrCompensatedTranslationPosition(state, float4(0.0f));
}
