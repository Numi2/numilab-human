#include <metal_stdlib>

#include "metalrobo/engine_types.h"
#include "metalrobo/opensim_spatial_transform_gpu.h"

using namespace metal;

#ifndef MR_ARTICULATED_OPERATOR_KERNEL_NAME
#define MR_ARTICULATED_OPERATOR_KERNEL_NAME mr_articulated_operator
#endif

#ifndef MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
#define MR_ARTICULATED_OPERATOR_BODY_PARAMETERS 0
#endif

namespace {

constant float kQuaternionTolerance = 2.0e-5f;
constant float kQuaternionMinimum = 1.0e-12f;
constant float kFloatEpsilon = 1.1920928955078125e-7f;
constant float kFactorAbsolutePivotFloor = 1.0e-12f;
constant float kInertiaSymmetryTolerance = 1.0e-6f;
constant float kInverseConsistencyTolerance = 2.0e-4f;

struct MotionColumn {
    float3 linear;
    float3 angular;
};

// This is the in-kernel form of one immutable OpenSim FunctionBased joint.
// The GPU program ABI remains identical to the independently qualified
// spatial-transform kernel; this operator consumes the same packed source
// table rather than approximating it as a serial chain.
struct FunctionBasedJointKinematics {
    float4 rotation;
    float3 translation;
    float3 angular[MR_OPENSIM_SPATIAL_MAX_COORDINATES];
    float3 linear[MR_OPENSIM_SPATIAL_MAX_COORDINATES];
    uint coordinateCount;
};

inline float opensimPackedScalar(
    thread const mr_float4* blocks,
    const uint index
) {
    return blocks[index >> 2u][index & 3u];
}

inline bool finite3(const float3 value) {
    return all(isfinite(value));
}

inline bool finite4(const float4 value) {
    return all(isfinite(value));
}

inline float maximumAbsolute3(const float3 value) {
    return max(max(abs(value.x), abs(value.y)), abs(value.z));
}

inline float4 quaternionConjugate(const float4 value) {
    return float4(-value.xyz, value.w);
}

inline float4 quaternionMultiply(
    const float4 left,
    const float4 right
) {
    return float4(
        left.w * right.x + left.x * right.w +
            left.y * right.z - left.z * right.y,
        left.w * right.y - left.x * right.z +
            left.y * right.w + left.z * right.x,
        left.w * right.z + left.x * right.y -
            left.y * right.x + left.z * right.w,
        left.w * right.w - dot(left.xyz, right.xyz)
    );
}

inline float3 quaternionRotate(
    const float4 quaternion,
    const float3 value
) {
    const float3 doubledCross =
        2.0f * cross(quaternion.xyz, value);
    return value +
        quaternion.w * doubledCross +
        cross(quaternion.xyz, doubledCross);
}

inline bool normalizedQuaternion(
    const float4 input,
    thread float4& output,
    const bool requireUnitInput
) {
    if (!finite4(input)) {
        return false;
    }
    const float normSquared = dot(input, input);
    if (!(normSquared > kQuaternionMinimum) ||
        !isfinite(normSquared)) {
        return false;
    }
    const float norm = sqrt(normSquared);
    if (requireUnitInput &&
        abs(norm - 1.0f) > kQuaternionTolerance) {
        return false;
    }
    output = input / norm;
    return finite4(output);
}

inline float4 axisAngleQuaternion(
    const float3 normalizedAxis,
    const float angle
) {
    const float halfAngle = 0.5f * angle;
    return float4(
        normalizedAxis * sin(halfAngle),
        cos(halfAngle)
    );
}

inline bool evaluateOpenSimFunction(
    thread const MROpenSimFunctionGPU& function,
    const float argument,
    thread float3& result
) {
    if (!isfinite(argument)) {
        return false;
    }
    const uint coefficientCount = function.coefficientCount;
    const uint knotCount = function.knotCount;
    if (function.kind == MR_OPENSIM_FUNCTION_CONSTANT) {
        if (coefficientCount != 1u || knotCount != 0u) {
            return false;
        }
        result = float3(
            opensimPackedScalar(function.coefficients, 0u),
            0.0f,
            0.0f
        );
        return isfinite(result.x);
    }
    if (function.kind == MR_OPENSIM_FUNCTION_LINEAR) {
        if (coefficientCount != 2u || knotCount != 0u) {
            return false;
        }
        const float slope = opensimPackedScalar(function.coefficients, 0u);
        result = float3(
            slope * argument +
                opensimPackedScalar(function.coefficients, 1u),
            slope,
            0.0f
        );
        return finite3(result);
    }
    if (function.kind == MR_OPENSIM_FUNCTION_POLYNOMIAL) {
        if (coefficientCount == 0u ||
            coefficientCount > MR_OPENSIM_SPATIAL_MAX_COEFFICIENTS ||
            knotCount != 0u) {
            return false;
        }
        float value = 0.0f;
        float derivative = 0.0f;
        float secondDerivative = 0.0f;
        for (uint index = 0u; index < coefficientCount; ++index) {
            secondDerivative =
                secondDerivative * argument + 2.0f * derivative;
            derivative = derivative * argument + value;
            value = value * argument +
                opensimPackedScalar(function.coefficients, index);
        }
        result = float3(value, derivative, secondDerivative);
        return finite3(result);
    }
    if (function.kind != MR_OPENSIM_FUNCTION_SIMM_SPLINE ||
        coefficientCount != 0u || knotCount < 2u ||
        knotCount > MR_OPENSIM_SPATIAL_MAX_KNOTS) {
        return false;
    }
    for (uint index = 0u; index < knotCount; ++index) {
        const float x = opensimPackedScalar(function.abscissae, index);
        const float y = opensimPackedScalar(function.ordinates, index);
        const float slope = opensimPackedScalar(function.splineSlope, index);
        const float quadratic = opensimPackedScalar(
            function.splineQuadratic,
            index
        );
        const float cubic = opensimPackedScalar(function.splineCubic, index);
        if (!isfinite(x) || !isfinite(y) || !isfinite(slope) ||
            !isfinite(quadratic) || !isfinite(cubic) ||
            (index > 0u && !(x > opensimPackedScalar(
                function.abscissae,
                index - 1u
            )))) {
            return false;
        }
    }
    const uint final = knotCount - 1u;
    const float firstX = opensimPackedScalar(function.abscissae, 0u);
    const float finalX = opensimPackedScalar(function.abscissae, final);
    if (argument < firstX || argument > finalX) {
        const uint endpoint = argument < firstX ? 0u : final;
        const float x = opensimPackedScalar(function.abscissae, endpoint);
        const float y = opensimPackedScalar(function.ordinates, endpoint);
        const float slope = opensimPackedScalar(function.splineSlope, endpoint);
        result = float3(y + (argument - x) * slope, slope, 0.0f);
        return finite3(result);
    }
    uint low = 0u;
    uint high = final;
    uint interval = 0u;
    for (uint iteration = 0u; iteration < 5u; ++iteration) {
        interval = (low + high) >> 1u;
        if (argument < opensimPackedScalar(function.abscissae, interval)) {
            high = interval;
        } else if (argument > opensimPackedScalar(
                       function.abscissae,
                       interval + 1u
                   )) {
            low = interval;
        } else {
            break;
        }
    }
    const float delta = argument -
        opensimPackedScalar(function.abscissae, interval);
    const float slope = opensimPackedScalar(function.splineSlope, interval);
    const float quadratic = opensimPackedScalar(
        function.splineQuadratic,
        interval
    );
    const float cubic = opensimPackedScalar(function.splineCubic, interval);
    result = float3(
        opensimPackedScalar(function.ordinates, interval) + delta *
            (slope + delta * (quadratic + delta * cubic)),
        slope + delta * (2.0f * quadratic + 3.0f * delta * cubic),
        2.0f * quadratic + 6.0f * delta * cubic
    );
    return finite3(result);
}

inline bool evaluateFunctionBasedJoint(
    device const MROpenSimSpatialTransformGPU& program,
    device const float* coordinates,
    thread FunctionBasedJointKinematics& result
) {
    result = {};
    if (program.abiVersion != MR_OPENSIM_SPATIAL_TRANSFORM_GPU_ABI_VERSION ||
        program.coordinateCount == 0u ||
        program.coordinateCount > MR_OPENSIM_SPATIAL_MAX_COORDINATES ||
        program.reserved0 != 0u || program.reserved1 != 0u) {
        return false;
    }
    float3 values[6];
    float3 axes[6];
    uint coordinateIndex[6];
    for (uint index = 0u; index < 6u; ++index) {
        const MROpenSimFunctionGPU function = program.axes[index];
        const bool functionIsConstant =
            function.kind == MR_OPENSIM_FUNCTION_CONSTANT;
        if ((functionIsConstant &&
             function.coordinateIndex != MR_OPENSIM_SPATIAL_NO_COORDINATE) ||
            (!functionIsConstant &&
             (function.coordinateIndex == MR_OPENSIM_SPATIAL_NO_COORDINATE ||
              function.coordinateIndex >= program.coordinateCount)) ||
            !finite4(function.axis) || function.axis.w != 0.0f ||
            !(dot(function.axis.xyz, function.axis.xyz) > 1.0e-10f)) {
            return false;
        }
        coordinateIndex[index] = function.coordinateIndex;
        axes[index] = normalize(function.axis.xyz);
        const float argument = functionIsConstant
            ? 0.0f
            : coordinates[function.coordinateIndex];
        if (!evaluateOpenSimFunction(function, argument, values[index])) {
            return false;
        }
    }
    const float4 rotation0 = axisAngleQuaternion(axes[0], values[0].x);
    const float4 rotation01 = quaternionMultiply(
        rotation0,
        axisAngleQuaternion(axes[1], values[1].x)
    );
    result.rotation = quaternionMultiply(
        rotation01,
        axisAngleQuaternion(axes[2], values[2].x)
    );
    result.translation =
        axes[3] * values[3].x +
        axes[4] * values[4].x +
        axes[5] * values[5].x;
    const float3 angularAxes[3] = {
        axes[0],
        quaternionRotate(rotation0, axes[1]),
        quaternionRotate(rotation01, axes[2]),
    };
    for (uint index = 0u; index < 6u; ++index) {
        const uint coordinate = coordinateIndex[index];
        if (coordinate == MR_OPENSIM_SPATIAL_NO_COORDINATE) {
            continue;
        }
        if (index < 3u) {
            result.angular[coordinate] += angularAxes[index] * values[index].y;
        } else {
            result.linear[coordinate] += axes[index] * values[index].y;
        }
    }
    result.coordinateCount = program.coordinateCount;
    return finite4(result.rotation) && finite3(result.translation);
}

inline float3 inertiaMultiply(
    device const MRBodyPropertiesGPU& body,
    const float3 bodyAngular
) {
    return float3(
        dot(body.inertiaRow0.xyz, bodyAngular),
        dot(body.inertiaRow1.xyz, bodyAngular),
        dot(body.inertiaRow2.xyz, bodyAngular)
    );
}

inline bool symmetricInertia(
    const float3 row0,
    const float3 row1,
    const float3 row2
) {
    return
        abs(row0.y - row1.x) <=
            kInertiaSymmetryTolerance &&
        abs(row0.z - row2.x) <=
            kInertiaSymmetryTolerance &&
        abs(row1.z - row2.y) <=
            kInertiaSymmetryTolerance;
}

inline bool positiveDefiniteInertia(
    const float3 input0,
    const float3 input1,
    const float3 input2
) {
    // Scale before evaluating Sylvester's criterion. Canonical CPU records
    // are FP32, but their products need not fit FP32 without scaling.
    const float scale = max(
        maximumAbsolute3(input0),
        max(
            maximumAbsolute3(input1),
            maximumAbsolute3(input2)
        )
    );
    if (!(scale > 0.0f) || !isfinite(scale)) {
        return false;
    }
    const float3 row0 = input0 / scale;
    const float3 row1 = input1 / scale;
    const float3 row2 = input2 / scale;
    const float firstMinor = row0.x;
    const float secondMinor =
        row0.x * row1.y - row0.y * row1.x;
    const float determinant = dot(row0, cross(row1, row2));
    return
        firstMinor > 0.0f &&
        secondMinor > 0.0f &&
        determinant > 0.0f &&
        isfinite(secondMinor) &&
        isfinite(determinant);
}

inline bool inverseConsistentInertia(
    const float3 inertia0,
    const float3 inertia1,
    const float3 inertia2,
    const float3 inverse0,
    const float3 inverse1,
    const float3 inverse2
) {
    const float3 column0 =
        float3(inverse0.x, inverse1.x, inverse2.x);
    const float3 column1 =
        float3(inverse0.y, inverse1.y, inverse2.y);
    const float3 column2 =
        float3(inverse0.z, inverse1.z, inverse2.z);
    const float3 product0 = float3(
        dot(inertia0, column0),
        dot(inertia0, column1),
        dot(inertia0, column2)
    );
    const float3 product1 = float3(
        dot(inertia1, column0),
        dot(inertia1, column1),
        dot(inertia1, column2)
    );
    const float3 product2 = float3(
        dot(inertia2, column0),
        dot(inertia2, column1),
        dot(inertia2, column2)
    );
    return
        finite3(product0) &&
        finite3(product1) &&
        finite3(product2) &&
        all(abs(product0 - float3(1.0f, 0.0f, 0.0f)) <=
            float3(kInverseConsistencyTolerance)) &&
        all(abs(product1 - float3(0.0f, 1.0f, 0.0f)) <=
            float3(kInverseConsistencyTolerance)) &&
        all(abs(product2 - float3(0.0f, 0.0f, 1.0f)) <=
            float3(kInverseConsistencyTolerance));
}

inline bool validBodyInertia(
    device const MRBodyPropertiesGPU& body
) {
    if (!finite4(body.inertiaRow0) ||
        !finite4(body.inertiaRow1) ||
        !finite4(body.inertiaRow2) ||
        !finite4(body.inverseInertiaRow0) ||
        !finite4(body.inverseInertiaRow1) ||
        !finite4(body.inverseInertiaRow2)) {
        return false;
    }
    const float3 inertia0 = body.inertiaRow0.xyz;
    const float3 inertia1 = body.inertiaRow1.xyz;
    const float3 inertia2 = body.inertiaRow2.xyz;
    const float3 inverse0 = body.inverseInertiaRow0.xyz;
    const float3 inverse1 = body.inverseInertiaRow1.xyz;
    const float3 inverse2 = body.inverseInertiaRow2.xyz;
    return
        symmetricInertia(inertia0, inertia1, inertia2) &&
        symmetricInertia(inverse0, inverse1, inverse2) &&
        positiveDefiniteInertia(inertia0, inertia1, inertia2) &&
        positiveDefiniteInertia(inverse0, inverse1, inverse2) &&
        inverseConsistentInertia(
            inertia0,
            inertia1,
            inertia2,
            inverse0,
            inverse1,
            inverse2
        );
}

inline bool zero4(const float4 value) {
    return all(value == float4(0.0f));
}

inline bool validZeroInertiaTransformCarrier(
    device const MRBodyPropertiesGPU& body
) {
    return
        body.motionType == MR_MOTION_STATIC &&
        body.massAndInverseMass.x == 0.0f &&
        body.massAndInverseMass.y == 0.0f &&
        zero4(body.inertiaRow0) &&
        zero4(body.inertiaRow1) &&
        zero4(body.inertiaRow2) &&
        zero4(body.inverseInertiaRow0) &&
        zero4(body.inverseInertiaRow1) &&
        zero4(body.inverseInertiaRow2);
}

inline uint alignedThreadgroupOffset(const uint value) {
    return (value + 15u) & ~15u;
}

inline bool validDofParameters(
    device const MRDofPropertiesGPU& dof,
    const bool root,
    const uint jointType
) {
    constexpr uint knownFlags =
        MR_DOF_FLAG_ROOT |
        MR_DOF_FLAG_ACTUATED |
        MR_DOF_FLAG_POSITION_LIMIT |
        MR_DOF_FLAG_VELOCITY_LIMIT |
        MR_DOF_FLAG_EFFORT_LIMIT |
        MR_DOF_FLAG_DRIVE;
    if (!finite4(dof.limits) ||
        !finite4(dof.drive) ||
        dof.reserved0 != 0u ||
        dof.reserved1 != 0u ||
        (dof.flags & ~knownFlags) != 0u ||
        any(dof.drive < float4(0.0f))) {
        return false;
    }
    if (root) {
        return dof.flags == MR_DOF_FLAG_ROOT &&
            zero4(dof.limits) &&
            zero4(dof.drive);
    }
    if ((dof.flags & MR_DOF_FLAG_ROOT) != 0u) {
        return false;
    }
    const bool actuated =
        (dof.flags & MR_DOF_FLAG_ACTUATED) != 0u;
    const bool positionLimited =
        (dof.flags & MR_DOF_FLAG_POSITION_LIMIT) != 0u;
    const bool velocityLimited =
        (dof.flags & MR_DOF_FLAG_VELOCITY_LIMIT) != 0u;
    const bool effortLimited =
        (dof.flags & MR_DOF_FLAG_EFFORT_LIMIT) != 0u;
    const bool driven =
        (dof.flags & MR_DOF_FLAG_DRIVE) != 0u;
    return
        (actuated || (!effortLimited && !driven)) &&
        (!driven || actuated) &&
        (driven || dof.drive.x == 0.0f) &&
        (!positionLimited ||
         (dof.qIndex != MR_INVALID_INDEX &&
          jointType != MR_JOINT_CONTINUOUS &&
          dof.limits.x <= dof.limits.y)) &&
        (positionLimited ||
         (dof.limits.x == 0.0f && dof.limits.y == 0.0f)) &&
        (velocityLimited
             ? dof.limits.z > 0.0f
             : dof.limits.z == 0.0f) &&
        (effortLimited
             ? dof.limits.w > 0.0f
             : dof.limits.w == 0.0f);
}

inline void setFailure(
    thread MRArticulatedOperatorStatusGPU& status,
    const uint code,
    const uint failingIndex
) {
    status.code = code;
    status.failingIndex = failingIndex;
}

inline MotionColumn bodyMotionForDof(
    const uint localBody,
    const uint dof,
    device const MRArticulationGPU& articulation,
    device const MRJointDescriptorGPU* joints,
    device const MROpenSimSpatialTransformGPU* functionPrograms,
    device const float* q,
    threadgroup const float3* bodyPosition,
    threadgroup const float4* bodyRotation,
    threadgroup const float3* jointPosition,
    threadgroup const float3* jointAxis,
    threadgroup const uint* inboundJoint,
    threadgroup const uint* parentLocal,
    const uint knownAncestor = MR_INVALID_INDEX
) {
    MotionColumn result;
    result.linear = float3(0.0f);
    result.angular = float3(0.0f);

    const uint rootLocal =
        articulation.rootBody - articulation.firstBody;
    if (articulation.rootType == MR_ROOT_FLOATING) {
        if (dof < 3u) {
            result.linear[dof] = 1.0f;
            return result;
        }
        if (dof < 6u) {
            result.angular[dof - 3u] = 1.0f;
            result.linear = cross(
                result.angular,
                bodyPosition[localBody] - bodyPosition[rootLocal]
            );
            return result;
        }
    }

    uint cursor = knownAncestor == MR_INVALID_INDEX ? localBody : knownAncestor;
    for (uint depth = 0u;
         depth < articulation.bodyCount && cursor != rootLocal;
         ++depth) {
        const uint globalJoint = inboundJoint[cursor];
        if (globalJoint == MR_INVALID_INDEX) {
            return result;
        }
        device const MRJointDescriptorGPU& joint =
            joints[globalJoint];
        const uint jointLocalV =
            joint.vOffset - articulation.vOffset;
        if (joint.jointType == MR_JOINT_FUNCTION_BASED &&
            dof >= jointLocalV && dof - jointLocalV < joint.nv) {
            FunctionBasedJointKinematics functionState;
            const uint localQ = joint.qOffset - articulation.qOffset;
            if (!evaluateFunctionBasedJoint(
                    functionPrograms[globalJoint],
                    q + localQ,
                    functionState
                ) || functionState.coordinateCount != joint.nv) {
                return result;
            }
            const float4 parentToJointRotation = quaternionMultiply(
                bodyRotation[parentLocal[cursor]],
                joint.parentRotation
            );
            const uint localDof = dof - jointLocalV;
            result.angular = quaternionRotate(
                parentToJointRotation,
                functionState.angular[localDof]
            );
            result.linear = quaternionRotate(
                parentToJointRotation,
                functionState.linear[localDof]
            ) + cross(
                result.angular,
                bodyPosition[localBody] - jointPosition[cursor]
            );
            return result;
        }
        if (joint.nv == 1u &&
            jointLocalV == dof) {
            if (joint.jointType == MR_JOINT_PRISMATIC) {
                result.linear = jointAxis[cursor];
            } else {
                result.angular = jointAxis[cursor];
                result.linear = cross(
                    result.angular,
                    bodyPosition[localBody] -
                        jointPosition[cursor]
                );
            }
            return result;
        }
        cursor = parentLocal[cursor];
    }
    return result;
}

inline float massElement(
    const uint row,
    const uint column,
    device const MRArticulationGPU& articulation,
    device const MRJointDescriptorGPU* joints,
    device const MROpenSimSpatialTransformGPU* functionPrograms,
    device const float* q,
    device const MRBodyPropertiesGPU* bodies,
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
    device const float4* bodyParameters,
    const uint bodyParameterBase,
#endif
    threadgroup const float3* bodyPosition,
    threadgroup const float4* bodyRotation,
    threadgroup const float3* jointPosition,
    threadgroup const float3* jointAxis,
    threadgroup const uint* inboundJoint,
    threadgroup const uint* parentLocal
) {
    float value = 0.0f;
    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        const MotionColumn left = bodyMotionForDof(
            localBody,
            row,
            articulation,
            joints,
            functionPrograms,
            q,
            bodyPosition,
            bodyRotation,
            jointPosition,
            jointAxis,
            inboundJoint,
            parentLocal
        );
        const MotionColumn right = bodyMotionForDof(
            localBody,
            column,
            articulation,
            joints,
            functionPrograms,
            q,
            bodyPosition,
            bodyRotation,
            jointPosition,
            jointAxis,
            inboundJoint,
            parentLocal
        );
        device const MRBodyPropertiesGPU& body =
            bodies[articulation.firstBody + localBody];
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
        const float4 physical = bodyParameters[
            bodyParameterBase +
            articulation.firstBody +
            localBody
        ];
        const float massScale = max(physical.x, 1.0e-4f);
        // Preserve the mass/friction/restitution/damping ABI. Uniform mass
        // scaling also scales the articulated inertia tensor.
        const float inertiaScale = massScale;
#else
        constexpr float massScale = 1.0f;
        constexpr float inertiaScale = 1.0f;
#endif
        const float3 leftBodyAngular = quaternionRotate(
            quaternionConjugate(bodyRotation[localBody]),
            left.angular
        );
        const float3 rightBodyAngular = quaternionRotate(
            quaternionConjugate(bodyRotation[localBody]),
            right.angular
        );
        value +=
            massScale * body.massAndInverseMass.x *
                dot(left.linear, right.linear) +
            inertiaScale * dot(
                leftBodyAngular,
                inertiaMultiply(body, rightBodyAngular)
            );
    }
    return value;
}

inline bool validDispatch(
    device const MRWorldGPU& world,
    device const MRArticulatedOperatorDispatchGPU& dispatch,
    thread MRArticulatedOperatorStatusGPU& status
) {
    if (world.abiVersion != MR_ENGINE_ABI_VERSION ||
        dispatch.articulationIndex >= world.articulationCount ||
        dispatch.environmentCount == 0u ||
        dispatch.reserved0 != 0u ||
        (dispatch.flags &
         ~(
             MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS |
             MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR |
             MR_ARTICULATED_OPERATOR_KINEMATICS_ONLY |
             MR_ARTICULATED_OPERATOR_IMPLICIT_DRIVES |
             MR_ARTICULATED_OPERATOR_KINEMATICS_JACOBIANS_ONLY |
             MR_ARTICULATED_OPERATOR_IGNORE_FOREIGN_POINTS
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
             | MR_ARTICULATED_OPERATOR_COMPENSATED_TRANSLATION
#endif
         )) != 0u ||
        ((dispatch.flags &
          MR_ARTICULATED_OPERATOR_IGNORE_FOREIGN_POINTS) != 0u &&
         (dispatch.flags &
          MR_ARTICULATED_OPERATOR_KINEMATICS_JACOBIANS_ONLY) == 0u) ||
        ((dispatch.flags &
          MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS) != 0u &&
         (dispatch.flags &
          MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR) != 0u) ||
        ((dispatch.flags &
          MR_ARTICULATED_OPERATOR_KINEMATICS_ONLY) != 0u &&
         (dispatch.pointCount != 0u ||
          (dispatch.flags &
           (
               MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS |
               MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR
           )) != 0u))) {
        setFailure(
            status,
            MR_ARTICULATED_OPERATOR_INVALID_DISPATCH,
            MR_INVALID_INDEX
        );
        return false;
    }
    if ((dispatch.flags &
         MR_ARTICULATED_OPERATOR_KINEMATICS_JACOBIANS_ONLY) != 0u &&
        (dispatch.flags &
         (
             MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS |
             MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR |
             MR_ARTICULATED_OPERATOR_KINEMATICS_ONLY |
             MR_ARTICULATED_OPERATOR_IMPLICIT_DRIVES
         )) != 0u) {
        setFailure(
            status,
            MR_ARTICULATED_OPERATOR_INVALID_DISPATCH,
            MR_INVALID_INDEX
        );
        return false;
    }
    return true;
}

inline bool validModelAndLayout(
    device const MRWorldGPU& world,
    device const MRArticulationGPU& articulation,
    device const MRJointDescriptorGPU* joints,
    device const MROpenSimSpatialTransformGPU* functionPrograms,
    device const MRDofPropertiesGPU* dofs,
    device const MRBodyPropertiesGPU* bodies,
    device const MRArticulatedOperatorDispatchGPU& dispatch,
    threadgroup uint* inboundJoint,
    threadgroup uint* parentLocal,
    threadgroup uchar* known,
    thread MRArticulatedOperatorStatusGPU& status
) {
    const bool pointJacobiansOnly =
        (dispatch.flags &
         MR_ARTICULATED_OPERATOR_KINEMATICS_JACOBIANS_ONLY) != 0u;
    const uint maximumBodies = pointJacobiansOnly
        ? MR_ARTICULATED_OPERATOR_KINEMATICS_MAX_BODIES
        : MR_ARTICULATED_OPERATOR_MAX_BODIES;
    const uint maximumDofs = pointJacobiansOnly
        ? MR_ARTICULATED_OPERATOR_KINEMATICS_MAX_DOFS
        : MR_ARTICULATED_OPERATOR_MAX_DOFS;
    if ((articulation.rootType != MR_ROOT_FIXED &&
         articulation.rootType != MR_ROOT_FLOATING) ||
        articulation.bodyCount == 0u ||
        articulation.bodyCount > maximumBodies ||
        articulation.nv == 0u ||
        articulation.nv > maximumDofs ||
        articulation.firstBody > world.bodyCount ||
        articulation.bodyCount >
            world.bodyCount - articulation.firstBody ||
        articulation.firstJoint > world.jointCount ||
        articulation.jointCount >
            world.jointCount - articulation.firstJoint ||
        articulation.qOffset > world.nq ||
        articulation.nq > world.nq - articulation.qOffset ||
        articulation.vOffset > world.nv ||
        articulation.nv > world.nv - articulation.vOffset ||
        articulation.rootBody < articulation.firstBody ||
        articulation.rootBody >=
            articulation.firstBody + articulation.bodyCount ||
        articulation.jointCount + 1u != articulation.bodyCount) {
        setFailure(
            status,
            articulation.bodyCount > maximumBodies ||
                articulation.nv > maximumDofs
                ? MR_ARTICULATED_OPERATOR_CAPACITY_OVERFLOW
                : MR_ARTICULATED_OPERATOR_INVALID_MODEL,
            MR_INVALID_INDEX
        );
        return false;
    }

    const uint rootQ =
        articulation.rootType == MR_ROOT_FLOATING ? 7u : 0u;
    const uint rootV =
        articulation.rootType == MR_ROOT_FLOATING ? 6u : 0u;
    uint expectedNq = rootQ;
    uint expectedNv = rootV;
    const uint rootLocal =
        articulation.rootBody - articulation.firstBody;
    for (uint localDof = 0u;
         localDof < rootV;
         ++localDof) {
        const uint globalV =
            articulation.vOffset + localDof;
        const uint expectedQ =
            localDof < 3u
                ? articulation.qOffset + localDof
                : MR_INVALID_INDEX;
        device const MRDofPropertiesGPU& dof = dofs[globalV];
        if (dof.articulationIndex !=
                dispatch.articulationIndex ||
            dof.jointIndex != MR_INVALID_INDEX ||
            dof.qIndex != expectedQ ||
            dof.vIndex != globalV ||
            dof.localDof != localDof ||
            !validDofParameters(dof, true, MR_JOINT_FREE)) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalV
            );
            return false;
        }
    }
    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        inboundJoint[localBody] = MR_INVALID_INDEX;
        parentLocal[localBody] = MR_INVALID_INDEX;
        known[localBody] = 0u;
    }

    for (uint localJoint = 0u;
         localJoint < articulation.jointCount;
         ++localJoint) {
        const uint globalJoint =
            articulation.firstJoint + localJoint;
        device const MRJointDescriptorGPU& joint =
            joints[globalJoint];
        if (joint.parentBody < articulation.firstBody ||
            joint.parentBody >=
                articulation.firstBody + articulation.bodyCount ||
            joint.childBody < articulation.firstBody ||
            joint.childBody >=
                articulation.firstBody + articulation.bodyCount ||
            joint.childBody == articulation.rootBody ||
            joint.parentBody == joint.childBody ||
            joint.flags != 0u ||
            !finite4(joint.parentAnchor) ||
            !finite4(joint.childAnchor) ||
            !finite4(joint.parentRotation) ||
            !finite4(joint.childRotation)) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalJoint
            );
            return false;
        }

        uint jointNq = 0u;
        uint jointNv = 0u;
        if (joint.jointType == MR_JOINT_REVOLUTE ||
            joint.jointType == MR_JOINT_CONTINUOUS ||
            joint.jointType == MR_JOINT_PRISMATIC) {
            jointNq = 1u;
            jointNv = 1u;
        } else if (joint.jointType == MR_JOINT_FUNCTION_BASED) {
            if (functionPrograms == nullptr) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_UNSUPPORTED_TOPOLOGY,
                    globalJoint
                );
                return false;
            }
            const MROpenSimSpatialTransformGPU program =
                functionPrograms[globalJoint];
            if (program.abiVersion !=
                    MR_OPENSIM_SPATIAL_TRANSFORM_GPU_ABI_VERSION ||
                program.coordinateCount == 0u ||
                program.coordinateCount >
                    MR_OPENSIM_SPATIAL_MAX_COORDINATES ||
                program.coordinateCount != joint.nq) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                    globalJoint
                );
                return false;
            }
            jointNq = joint.nq;
            jointNv = joint.nv;
        } else if (joint.jointType != MR_JOINT_FIXED) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_UNSUPPORTED_TOPOLOGY,
                globalJoint
            );
            return false;
        }
        if (joint.nq != jointNq ||
            joint.nv != jointNv ||
            expectedNq > articulation.nq ||
            jointNq > articulation.nq - expectedNq ||
            expectedNv > articulation.nv ||
            jointNv > articulation.nv - expectedNv ||
            joint.qOffset != articulation.qOffset + expectedNq ||
            joint.vOffset != articulation.vOffset + expectedNv) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalJoint
            );
            return false;
        }
        if (jointNv == 1u &&
            joint.jointType != MR_JOINT_FUNCTION_BASED) {
            const float axisNormSquared =
                dot(joint.axis0.xyz, joint.axis0.xyz);
            if (!finite4(joint.axis0) ||
                !(axisNormSquared > kQuaternionMinimum)) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                    globalJoint
                );
                return false;
            }
            device const MRDofPropertiesGPU& dof = dofs[joint.vOffset];
            if (dof.articulationIndex !=
                    dispatch.articulationIndex ||
                dof.jointIndex != globalJoint ||
                dof.qIndex != joint.qOffset ||
                dof.vIndex != joint.vOffset ||
                dof.localDof != 0u ||
                !validDofParameters(
                    dof,
                    false,
                    joint.jointType
                )) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                    joint.vOffset
                );
                return false;
            }
        }
        if (joint.jointType == MR_JOINT_FUNCTION_BASED) {
            for (uint localDof = 0u; localDof < jointNv; ++localDof) {
                device const MRDofPropertiesGPU& dof =
                    dofs[joint.vOffset + localDof];
                if (dof.articulationIndex != dispatch.articulationIndex ||
                    dof.jointIndex != globalJoint ||
                    dof.qIndex != joint.qOffset + localDof ||
                    dof.vIndex != joint.vOffset + localDof ||
                    dof.localDof != localDof ||
                    !validDofParameters(
                        dof,
                        false,
                        joint.jointType
                    )) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                        joint.vOffset + localDof
                    );
                    return false;
                }
            }
        }
        float4 checkedRotation;
        if (!normalizedQuaternion(
                joint.parentRotation,
                checkedRotation,
                true
            ) ||
            !normalizedQuaternion(
                joint.childRotation,
                checkedRotation,
                true
            )) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalJoint
            );
            return false;
        }

        const uint localChild =
            joint.childBody - articulation.firstBody;
        if (inboundJoint[localChild] != MR_INVALID_INDEX) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_UNSUPPORTED_TOPOLOGY,
                joint.childBody
            );
            return false;
        }
        inboundJoint[localChild] = globalJoint;
        parentLocal[localChild] =
            joint.parentBody - articulation.firstBody;
        expectedNq += jointNq;
        expectedNv += jointNv;
    }

    if (expectedNq != articulation.nq ||
        expectedNv != articulation.nv ||
        inboundJoint[rootLocal] != MR_INVALID_INDEX ||
        dispatch.qStride < articulation.nq ||
        dispatch.pointStride < dispatch.pointCount ||
        dispatch.bodyPoseStride < articulation.bodyCount ||
        dispatch.pointWorldStride < dispatch.pointCount ||
        static_cast<ulong>(dispatch.pointJacobianStride) <
            static_cast<ulong>(dispatch.pointCount) * 3ul *
                static_cast<ulong>(articulation.nv) ||
        dispatch.generalizedStride < articulation.nv ||
        ((dispatch.flags &
          (
              MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS |
              MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR
          )) != 0u &&
         dispatch.massMatrixStride <
            articulation.nv * articulation.nv)) {
        setFailure(
            status,
            MR_ARTICULATED_OPERATOR_INVALID_DISPATCH,
            MR_INVALID_INDEX
        );
        return false;
    }

    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        const uint globalBody =
            articulation.firstBody + localBody;
        device const MRBodyPropertiesGPU& body = bodies[globalBody];
        const bool dynamicBody =
            body.motionType == MR_MOTION_DYNAMIC &&
            body.massAndInverseMass.x > 0.0f &&
            body.massAndInverseMass.y > 0.0f &&
            abs(
                body.massAndInverseMass.x *
                    body.massAndInverseMass.y -
                1.0f
            ) <= 3.0e-5f &&
            validBodyInertia(body);
        // MyoSim encodes several serial source joints on a single body. The
        // native tree inserts a massless transform carrier for each preceding
        // joint. It owns kinematics but must contribute exactly zero spatial
        // inertia; admitting only this exact form cannot turn an arbitrary
        // static body into an articulation member.
        const bool transformCarrier = validZeroInertiaTransformCarrier(body);
        if (body.articulationIndex !=
                dispatch.articulationIndex ||
            !finite4(body.massAndInverseMass) ||
            !finite4(body.centerOfMass) ||
            (!dynamicBody && !transformCarrier) ||
            !finite4(body.dampingAndSpeedLimits) ||
            any(body.dampingAndSpeedLimits < float4(0.0f))) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalBody
            );
            return false;
        }
        if (localBody == rootLocal) {
            if (body.parentBody != MR_INVALID_INDEX ||
                body.inboundJoint != MR_INVALID_INDEX) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                    globalBody
                );
                return false;
            }
        } else if (inboundJoint[localBody] == MR_INVALID_INDEX ||
                   body.parentBody !=
                       articulation.firstBody +
                           parentLocal[localBody] ||
                   body.inboundJoint != inboundJoint[localBody]) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                globalBody
            );
            return false;
        }
    }
    return true;
}

inline bool buildKinematics(
    device const MRArticulationGPU& articulation,
    device const MRJointDescriptorGPU* joints,
    device const MROpenSimSpatialTransformGPU* functionPrograms,
    device const float* q,
    threadgroup float3* bodyPosition,
    threadgroup float4* bodyRotation,
    threadgroup float3* jointPosition,
    threadgroup float3* jointAxis,
    threadgroup uchar* known,
    thread MRArticulatedOperatorStatusGPU& status
) {
    const uint rootLocal =
        articulation.rootBody - articulation.firstBody;
    if (articulation.rootType == MR_ROOT_FLOATING) {
        float4 checkedRootRotation;
        if (!finite3(float3(q[0], q[1], q[2])) ||
            !normalizedQuaternion(
                float4(q[3], q[4], q[5], q[6]),
                checkedRootRotation,
                true
            )) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_INPUT,
                0u
            );
            return false;
        }
        // The internal frame follows root translation. World translation is
        // applied only when publishing poses and points, avoiding cumulative
        // rounding at every joint in a tall articulated tree.
        bodyPosition[rootLocal] = float3(0.0f);
        bodyRotation[rootLocal] = checkedRootRotation;
    } else {
        bodyPosition[rootLocal] = float3(0.0f);
        bodyRotation[rootLocal] =
            float4(0.0f, 0.0f, 0.0f, 1.0f);
    }
    known[rootLocal] = 1u;

    uint discovered = 1u;
    for (uint pass = 0u;
         pass < articulation.bodyCount && discovered <
             articulation.bodyCount;
         ++pass) {
        bool progressed = false;
        for (uint localJoint = 0u;
             localJoint < articulation.jointCount;
             ++localJoint) {
            const uint globalJoint =
                articulation.firstJoint + localJoint;
            device const MRJointDescriptorGPU& joint =
                joints[globalJoint];
            const uint localParent =
                joint.parentBody - articulation.firstBody;
            const uint localChild =
                joint.childBody - articulation.firstBody;
            if (known[localParent] == 0u ||
                known[localChild] != 0u) {
                continue;
            }

            float4 parentJointRotation;
            float4 childJointRotation;
            if (!normalizedQuaternion(
                    joint.parentRotation,
                    parentJointRotation,
                    true
                ) ||
                !normalizedQuaternion(
                    joint.childRotation,
                    childJointRotation,
                    true
                )) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                    globalJoint
                );
                return false;
            }
            const float4 parentToJointRotation =
                quaternionMultiply(
                    bodyRotation[localParent],
                    parentJointRotation
                );
            float4 motionRotation =
                float4(0.0f, 0.0f, 0.0f, 1.0f);
            float3 axisInJoint = float3(1.0f, 0.0f, 0.0f);
            float3 translationInJoint = float3(0.0f);
            float jointCoordinate = 0.0f;
            if (joint.jointType == MR_JOINT_FUNCTION_BASED) {
                const uint localQ =
                    joint.qOffset - articulation.qOffset;
                FunctionBasedJointKinematics functionState;
                if (!evaluateFunctionBasedJoint(
                        functionPrograms[globalJoint],
                        q + localQ,
                        functionState
                    ) || functionState.coordinateCount != joint.nq) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_INVALID_MODEL,
                        globalJoint
                    );
                    return false;
                }
                motionRotation = functionState.rotation;
                translationInJoint = functionState.translation;
            } else if (joint.nv == 1u) {
                const float axisMagnitude =
                    length(joint.axis0.xyz);
                axisInJoint = joint.axis0.xyz / axisMagnitude;
                const uint localQ =
                    joint.qOffset - articulation.qOffset;
                if (!isfinite(q[localQ])) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_NONFINITE_INPUT,
                        localQ
                    );
                    return false;
                }
                jointCoordinate = q[localQ];
                if (joint.jointType == MR_JOINT_REVOLUTE ||
                    joint.jointType == MR_JOINT_CONTINUOUS) {
                    motionRotation = axisAngleQuaternion(
                        axisInJoint,
                        jointCoordinate
                    );
                }
            }

            const float4 candidateRotation = quaternionMultiply(
                quaternionMultiply(
                    parentToJointRotation,
                    motionRotation
                ),
                quaternionConjugate(childJointRotation)
            );
            float4 checkedChildRotation;
            if (!normalizedQuaternion(
                    candidateRotation,
                    checkedChildRotation,
                    false
                )) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                    joint.childBody
                );
                return false;
            }
            bodyRotation[localChild] = checkedChildRotation;
            jointAxis[localChild] = quaternionRotate(
                parentToJointRotation,
                axisInJoint
            );
            const float3 parentToJointOffset =
                quaternionRotate(
                    bodyRotation[localParent],
                    joint.parentAnchor.xyz
                ) +
                (joint.jointType == MR_JOINT_FUNCTION_BASED
                    ? quaternionRotate(
                        parentToJointRotation,
                        translationInJoint
                    )
                    : (joint.jointType == MR_JOINT_PRISMATIC
                        ? jointAxis[localChild] * jointCoordinate
                        : float3(0.0f)));
            jointPosition[localChild] = bodyPosition[localParent] + parentToJointOffset;
            // Compose the COM-relative displacement before adding the world
            // translation. Avoid rounding an intermediate large world anchor
            // and then subtracting its child offset at every carrier joint.
            const float3 parentToChildOffset = parentToJointOffset -
                quaternionRotate(
                    bodyRotation[localChild],
                    joint.childAnchor.xyz
                );
            bodyPosition[localChild] = bodyPosition[localParent] + parentToChildOffset;
            if (!finite3(jointPosition[localChild]) ||
                !finite3(jointAxis[localChild]) ||
                !finite3(bodyPosition[localChild]) ||
                (articulation.rootType == MR_ROOT_FLOATING &&
                 !finite3(float3(q[0], q[1], q[2]) + bodyPosition[localChild]))) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                    joint.childBody
                );
                return false;
            }
            known[localChild] = 1u;
            ++discovered;
            progressed = true;
        }
        if (!progressed) {
            break;
        }
    }

    if (discovered != articulation.bodyCount) {
        setFailure(
            status,
            MR_ARTICULATED_OPERATOR_UNSUPPORTED_TOPOLOGY,
            MR_INVALID_INDEX
        );
        return false;
    }
    return true;
}

#if !MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
inline bool buildBodyVelocities(
    device const MRArticulationGPU& articulation,
    device const MRJointDescriptorGPU* joints,
    device const float* v,
    threadgroup const float3* bodyPosition,
    threadgroup const float3* jointPosition,
    threadgroup const float3* jointAxis,
    threadgroup float3* bodyLinearVelocity,
    threadgroup float3* bodyAngularVelocity,
    threadgroup uchar* velocityKnown,
    thread MRArticulatedOperatorStatusGPU& status
) {
    for (uint dof = 0u; dof < articulation.nv; ++dof) {
        if (!isfinite(v[dof])) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_INPUT,
                dof
            );
            return false;
        }
    }
    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        velocityKnown[localBody] = 0u;
    }

    const uint rootLocal =
        articulation.rootBody - articulation.firstBody;
    if (articulation.rootType == MR_ROOT_FLOATING) {
        bodyLinearVelocity[rootLocal] =
            float3(v[0], v[1], v[2]);
        bodyAngularVelocity[rootLocal] =
            float3(v[3], v[4], v[5]);
    } else {
        bodyLinearVelocity[rootLocal] = float3(0.0f);
        bodyAngularVelocity[rootLocal] = float3(0.0f);
    }
    velocityKnown[rootLocal] = 1u;

    uint discovered = 1u;
    for (uint pass = 0u;
         pass < articulation.bodyCount &&
             discovered < articulation.bodyCount;
         ++pass) {
        bool progressed = false;
        for (uint localJoint = 0u;
             localJoint < articulation.jointCount;
             ++localJoint) {
            const uint globalJoint =
                articulation.firstJoint + localJoint;
            device const MRJointDescriptorGPU& joint =
                joints[globalJoint];
            const uint localParent =
                joint.parentBody - articulation.firstBody;
            const uint localChild =
                joint.childBody - articulation.firstBody;
            if (velocityKnown[localParent] == 0u ||
                velocityKnown[localChild] != 0u) {
                continue;
            }

            const float3 parentToJoint =
                jointPosition[localChild] -
                bodyPosition[localParent];
            float3 jointLinear =
                bodyLinearVelocity[localParent] +
                cross(
                    bodyAngularVelocity[localParent],
                    parentToJoint
                );
            float3 angular =
                bodyAngularVelocity[localParent];
            if (joint.nv == 1u) {
                const uint localDof =
                    joint.vOffset - articulation.vOffset;
                const float rate = v[localDof];
                const float3 jointMotion =
                    rate * jointAxis[localChild];
                if (joint.jointType == MR_JOINT_PRISMATIC) {
                    jointLinear += jointMotion;
                } else {
                    angular += jointMotion;
                }
            }
            const float3 childAnchor =
                jointPosition[localChild] -
                bodyPosition[localChild];
            const float3 linear =
                jointLinear - cross(angular, childAnchor);
            if (!finite3(linear) || !finite3(angular)) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                    joint.childBody
                );
                return false;
            }
            bodyLinearVelocity[localChild] = linear;
            bodyAngularVelocity[localChild] = angular;
            velocityKnown[localChild] = 1u;
            ++discovered;
            progressed = true;
        }
        if (!progressed) {
            break;
        }
    }
    if (discovered != articulation.bodyCount) {
        setFailure(
            status,
            MR_ARTICULATED_OPERATOR_UNSUPPORTED_TOPOLOGY,
            MR_INVALID_INDEX
        );
        return false;
    }
    return true;
}
#endif

inline float3 pointSurfaceOffset(
    const float4 rotation, device const MRArticulatedPointImpulseGPU& query
) {
    const float3 centre = quaternionRotate(rotation, query.localPoint.xyz);
    if ((query.flags & MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT) != 0u) {
        const float4 shape = quaternionMultiply(rotation, query.supportOrientation);
        const float3 direction = quaternionRotate(quaternionConjugate(shape), query.supportPlaneNormalAndRadius.xyz);
        const float3 scaled = query.supportRadii.xyz * direction;
        return centre - quaternionRotate(shape, query.supportRadii.xyz * scaled / length(scaled));
    }
    return centre - query.supportPlaneNormalAndRadius.w * query.supportPlaneNormalAndRadius.xyz;
}

inline bool validatePoints(
    const uint environment,
    device const MRArticulationGPU& articulation,
    device const MRArticulatedOperatorDispatchGPU& dispatch,
    device const MRArticulatedPointImpulseGPU* points,
    thread MRArticulatedOperatorStatusGPU& status
) {
    const uint base = environment * dispatch.pointStride;
    for (uint point = 0u; point < dispatch.pointCount; ++point) {
        device const MRArticulatedPointImpulseGPU& query =
            points[base + point];
        const bool foreign =
            query.bodyIndex < articulation.firstBody ||
            query.bodyIndex >=
                articulation.firstBody + articulation.bodyCount;
        const bool allowForeign =
            (dispatch.flags &
             MR_ARTICULATED_OPERATOR_IGNORE_FOREIGN_POINTS) != 0u;
        if ((!allowForeign && foreign) ||
            (query.flags & ~(MR_ARTICULATED_POINT_INACTIVE | MR_ARTICULATED_POINT_SPHERE_SUPPORT | MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT)) != 0u ||
            !finite4(query.supportPlaneNormalAndRadius) || !finite4(query.supportRadii) || !finite4(query.supportOrientation) ||
            (((query.flags & MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT) != 0u)
                ? ((query.flags & MR_ARTICULATED_POINT_SPHERE_SUPPORT) != 0u ||
                   query.supportPlaneNormalAndRadius.w != 0.0f || any(query.supportRadii.xyz <= 0.0f) ||
                   query.supportRadii.w != 0.0f || abs(dot(query.supportOrientation,query.supportOrientation)-1.0f)>1.0e-5f)
                : (any(query.supportRadii != float4(0.0f)) || any(query.supportOrientation != float4(0.0f)))) ||
            (((query.flags & (MR_ARTICULATED_POINT_SPHERE_SUPPORT | MR_ARTICULATED_POINT_ELLIPSOID_SUPPORT)) != 0u)
                ? (abs(dot(query.supportPlaneNormalAndRadius.xyz,query.supportPlaneNormalAndRadius.xyz)-1.0f)>1.0e-5f ||
                   ((query.flags & MR_ARTICULATED_POINT_SPHERE_SUPPORT) != 0u && !(query.supportPlaneNormalAndRadius.w>0.0f)))
                : any(query.supportPlaneNormalAndRadius != float4(0.0f))) ||
            query.reserved0 != 0u ||
            query.reserved1 != 0u ||
            !finite4(query.localPoint) ||
            !finite4(query.worldImpulse) ||
            query.localPoint.w != 0.0f ||
            query.worldImpulse.w != 0.0f) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_INPUT,
                point
            );
            return false;
        }
    }
    return true;
}

} // namespace

// Generic batched articulated operator. One threadgroup owns one environment.
// Model/kinematic validation, Cholesky, and publication remain lane-zero
// ordered so their status and transactional semantics stay exact. Dense mass
// assembly is independent per symmetric matrix entry and is distributed over
// the group; every entry retains the same deterministic body-order reduction.
kernel void MR_ARTICULATED_OPERATOR_KERNEL_NAME(
    device const MRWorldGPU* worlds [[buffer(0)]],
    device const MRArticulationGPU* articulations [[buffer(1)]],
    device const MRJointDescriptorGPU* joints [[buffer(2)]],
    device const MRDofPropertiesGPU* dofs [[buffer(3)]],
    device const MRBodyPropertiesGPU* bodies [[buffer(4)]],
    device const MRArticulatedOperatorDispatchGPU& dispatch [[buffer(5)]],
    device const float* q [[buffer(6)]],
    device const MRArticulatedPointImpulseGPU* points [[buffer(7)]],
    device MRArticulatedBodyPoseGPU* bodyPoses [[buffer(8)]],
    device MRArticulatedPointWorldGPU* pointWorld [[buffer(9)]],
    device float* diagnosticMassMatrix [[buffer(10)]],
    device float* pointJacobians [[buffer(11)]],
    device float* generalizedImpulse [[buffer(12)]],
    device float* deltaVelocity [[buffer(13)]],
    device MRArticulatedOperatorStatusGPU* statuses [[buffer(14)]],
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
    device const float4* bodyParameters [[buffer(15)]],
    device const float4* controllerParameters [[buffer(16)]],
#else
    device const MROpenSimSpatialTransformGPU* functionPrograms
        [[buffer(15)]],
#endif
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
    device const MRCompensatedRootTranslationGPU* rootTranslations [[buffer(17)]],
    device float4* bodyPositionLow [[buffer(18)]],
    device float4* pointPositionLow [[buffer(19)]],
#endif
    threadgroup uchar* scratch [[threadgroup(0)]],
    uint environment [[threadgroup_position_in_grid]],
    uint lane [[thread_index_in_threadgroup]],
    uint threadsPerThreadgroup [[threads_per_threadgroup]]
) {
    if (environment >= dispatch.environmentCount) {
        return;
    }

    threadgroup uint initializationSucceeded;
    MRArticulatedOperatorStatusGPU status = {};
    status.code = MR_ARTICULATED_OPERATOR_SUCCESS;
    status.environment = environment;
    status.articulationIndex = dispatch.articulationIndex;
    status.failingIndex = MR_INVALID_INDEX;

    if (lane == 0u) {
        initializationSucceeded = 0u;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    device const MRWorldGPU& world = worlds[0];
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
    // Parameterized world paths retain their existing FunctionBased host
    // rejection. This null program is never dereferenced in that mode.
    device const MROpenSimSpatialTransformGPU* functionPrograms = nullptr;
#endif
    if (lane == 0u) {
        initializationSucceeded =
            validDispatch(world, dispatch, status) ? 1u : 0u;
        if (initializationSucceeded == 0u) {
            statuses[environment] = status;
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (initializationSucceeded == 0u) {
        return;
    }

    device const MRArticulationGPU& articulation =
        articulations[dispatch.articulationIndex];
    uint scratchOffset = 0u;
    threadgroup float3* bodyPosition =
        reinterpret_cast<threadgroup float3*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(float3)
    );
    threadgroup float4* bodyRotation =
        reinterpret_cast<threadgroup float4*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(float4)
    );
    threadgroup float3* jointPosition =
        reinterpret_cast<threadgroup float3*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(float3)
    );
    threadgroup float3* jointAxis =
        reinterpret_cast<threadgroup float3*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(float3)
    );
    threadgroup uint* inboundJoint =
        reinterpret_cast<threadgroup uint*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(uint)
    );
    threadgroup uint* parentLocal =
        reinterpret_cast<threadgroup uint*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(uint)
    );
    threadgroup uchar* known = scratch + scratchOffset;
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.bodyCount * sizeof(uchar)
    );
    threadgroup float* factor =
        reinterpret_cast<threadgroup float*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset +
        articulation.nv * articulation.nv * sizeof(float)
    );
    threadgroup float* rightHandSide =
        reinterpret_cast<threadgroup float*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset + articulation.nv * sizeof(float)
    );
    threadgroup float* intermediate =
        reinterpret_cast<threadgroup float*>(
            scratch + scratchOffset
        );
    scratchOffset = alignedThreadgroupOffset(
        scratchOffset + articulation.nv * sizeof(float)
    );
    threadgroup float* solution =
        reinterpret_cast<threadgroup float*>(
            scratch + scratchOffset
        );
    const uint factorStride = articulation.nv;
    device const float* environmentQ =
        q + environment * dispatch.qStride;
    if (lane == 0u) {
        status.bodyCount = articulation.bodyCount;
        status.nq = articulation.nq;
        status.nv = articulation.nv;
        status.pointCount = dispatch.pointCount;
        initializationSucceeded =
            validModelAndLayout(
                world,
                articulation,
                joints,
                functionPrograms,
                dofs,
                bodies,
                dispatch,
                inboundJoint,
                parentLocal,
                known,
                status
            ) &&
            buildKinematics(
                articulation,
                joints,
                functionPrograms,
                environmentQ,
                bodyPosition,
                bodyRotation,
                jointPosition,
                jointAxis,
                known,
                status
            ) &&
            validatePoints(
                environment,
                articulation,
                dispatch,
                points,
                status
            )
            ? 1u
            : 0u;
        if (initializationSucceeded == 0u) {
            statuses[environment] = status;
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (initializationSucceeded == 0u) {
        return;
    }

#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
    const bool compensatedTranslation =
        (dispatch.flags & MR_ARTICULATED_OPERATOR_COMPENSATED_TRANSLATION) != 0u;
    MRCompensatedRootTranslationGPU translation = mrCompensatedTranslationFromProjection(
        articulation.rootType == MR_ROOT_FLOATING
            ? float4(environmentQ[0], environmentQ[1], environmentQ[2], 0.0f)
            : float4(0.0f));
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
    if (compensatedTranslation) {
        translation = rootTranslations[environment];
        if (articulation.rootType != MR_ROOT_FLOATING || !mrCompensatedTranslationValid(translation)) {
            if (lane == 0u) {
                setFailure(status, MR_ARTICULATED_OPERATOR_NONFINITE_INPUT, 0u);
                statuses[environment] = status;
            }
            return;
        }
    }
#endif
#endif
    const float3 worldTranslation = articulation.rootType == MR_ROOT_FLOATING
        ? float3(environmentQ[0], environmentQ[1], environmentQ[2]) : float3(0.0f);
    const bool posesOnly =
        (dispatch.flags &
         MR_ARTICULATED_OPERATOR_KINEMATICS_ONLY) != 0u;
    const bool pointJacobiansOnly =
        (dispatch.flags &
         MR_ARTICULATED_OPERATOR_KINEMATICS_JACOBIANS_ONLY) != 0u;
    if (posesOnly || pointJacobiansOnly) {
        const uint poseBase =
            environment * dispatch.bodyPoseStride;
        for (uint localBody = lane;
             localBody < articulation.bodyCount;
             localBody += threadsPerThreadgroup) {
            MRArticulatedBodyPoseGPU pose;
            pose.position =
                float4(worldTranslation + bodyPosition[localBody], 1.0f);
            pose.orientation = bodyRotation[localBody];
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
            if (compensatedTranslation) {
                const auto paired = mrCompensatedTranslationPosition(translation,
                    float4(bodyPosition[localBody], 0.0f));
                pose.position = float4(paired.high.xyz, 1.0f);
                bodyPositionLow[poseBase + localBody] = paired.low;
            }
#endif
            bodyPoses[poseBase + localBody] = pose;
        }
        if (pointJacobiansOnly) {
            // The same body is queried at its COM and several local points.
            // Resolve ancestry once per body, then reuse the authoritative
            // motion-column calculation at the owning joint. No candidate
            // data survives this dispatch or bypasses model validation.
            const uint ancestryWords = (articulation.nv + 31u) / 32u;
            threadgroup uint* ancestors = reinterpret_cast<threadgroup uint*>(factor);
            for (uint body = lane; body < articulation.bodyCount; body += threadsPerThreadgroup) {
                threadgroup uint* mask = ancestors + body * ancestryWords;
                for (uint word = 0u; word < ancestryWords; ++word) mask[word] = 0u;
                if (articulation.rootType == MR_ROOT_FLOATING) mask[0] = 63u;
                uint cursor = body;
                const uint rootLocal = articulation.rootBody - articulation.firstBody;
                for (uint depth = 0u; depth < articulation.bodyCount && cursor != rootLocal; ++depth) {
                    const uint jointIndex = inboundJoint[cursor];
                    if (jointIndex == MR_INVALID_INDEX) break;
                    device const MRJointDescriptorGPU& joint = joints[jointIndex];
                    for (uint local = 0u; local < joint.nv; ++local) {
                        const uint dof = joint.vOffset - articulation.vOffset + local;
                        mask[dof >> 5u] |= 1u << (dof & 31u);
                    }
                    cursor = parentLocal[cursor];
                }
            }
            threadgroup_barrier(mem_flags::mem_threadgroup);
            const uint pointBase =
                environment * dispatch.pointStride;
            const uint pointWorldBase =
                environment * dispatch.pointWorldStride;
            const uint jacobianBase =
                environment * dispatch.pointJacobianStride;
            const uint entryCount =
                dispatch.pointCount * articulation.nv;
            for (uint entry = lane;
                 entry < entryCount;
                 entry += threadsPerThreadgroup) {
                const uint point = entry / articulation.nv;
                const uint dof = entry -
                    point * articulation.nv;
                device const MRArticulatedPointImpulseGPU& query =
                    points[pointBase + point];
                const bool foreign =
                    query.bodyIndex < articulation.firstBody ||
                    query.bodyIndex - articulation.firstBody >=
                        articulation.bodyCount;
                const bool inactive =
                    (query.flags & MR_ARTICULATED_POINT_INACTIVE) != 0u ||
                    (((dispatch.flags &
                       MR_ARTICULATED_OPERATOR_IGNORE_FOREIGN_POINTS) != 0u) &&
                     foreign);
                const uint localBody = inactive
                    ? articulation.rootBody - articulation.firstBody
                    : query.bodyIndex - articulation.firstBody;
                const float3 pointOffset = pointSurfaceOffset(bodyRotation[localBody], query);
                const bool affectsBody = !inactive &&
                    (ancestors[localBody * ancestryWords + (dof >> 5u)] & (1u << (dof & 31u))) != 0u;
                const uint owningJoint = affectsBody ? dofs[articulation.vOffset + dof].jointIndex : MR_INVALID_INDEX;
                const uint knownAncestor = owningJoint == MR_INVALID_INDEX
                    ? MR_INVALID_INDEX : joints[owningJoint].childBody - articulation.firstBody;
                const MotionColumn bodyMotion = !affectsBody
                    ? MotionColumn{float3(0.0f), float3(0.0f)}
                    : bodyMotionForDof(
                        localBody,
                        dof,
                        articulation,
                        joints,
                        functionPrograms,
                        environmentQ,
                        bodyPosition,
                        bodyRotation,
                        jointPosition,
                        jointAxis,
                        inboundJoint,
                        parentLocal,
                        knownAncestor
                    );
                const float3 pointLinear =
                    bodyMotion.linear +
                    cross(bodyMotion.angular, pointOffset);
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 0u) * articulation.nv +
                    dof
                ] = pointLinear.x;
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 1u) * articulation.nv +
                    dof
                ] = pointLinear.y;
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 2u) * articulation.nv +
                    dof
                ] = pointLinear.z;
                if (dof == 0u) {
                    MRArticulatedPointWorldGPU worldPoint;
                    worldPoint.position = float4(
                        worldTranslation + (bodyPosition[localBody] + pointOffset),
                        1.0f
                    );
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
                    if (compensatedTranslation) {
                        const auto paired = mrCompensatedTranslationPosition(translation,
                            float4(bodyPosition[localBody] + pointOffset, 0.0f));
                        worldPoint.position = float4(paired.high.xyz, worldPoint.position.w);
                        pointPositionLow[pointWorldBase + point] = paired.low;
                    }
#endif
                    pointWorld[
                        pointWorldBase + point
                    ] = worldPoint;
                }
            }
            const uint generalizedBase =
                environment * dispatch.generalizedStride;
            for (uint dof = lane;
                 dof < articulation.nv;
                 dof += threadsPerThreadgroup) {
                generalizedImpulse[
                    generalizedBase + dof
                ] = 0.0f;
                deltaVelocity[
                    generalizedBase + dof
                ] = 0.0f;
            }
        }
        threadgroup_barrier(mem_flags::mem_device);
        if (lane == 0u) {
            status.diagnostics = float4(0.0f);
            statuses[environment] = status;
        }
        return;
    }

    // A lower-triangular entry owns both symmetric destinations, so there are
    // no write races. The reduction inside massElement intentionally remains
    // serial and body ordered, preserving the previous bit pattern.
    const uint packedEntryCount =
        articulation.nv * (articulation.nv + 1u) / 2u;
    for (uint packedEntry = lane;
         packedEntry < packedEntryCount;
         packedEntry += threadsPerThreadgroup) {
        uint row = 0u;
        uint rowStart = 0u;
        while (packedEntry >= rowStart + row + 1u) {
            rowStart += row + 1u;
            ++row;
        }
        const uint column = packedEntry - rowStart;
        const float value = massElement(
            row,
            column,
            articulation,
            joints,
            functionPrograms,
            environmentQ,
            bodies,
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
            bodyParameters,
            environment * world.bodyCount,
#endif
            bodyPosition,
            bodyRotation,
            jointPosition,
            jointAxis,
            inboundJoint,
            parentLocal
        );
        factor[
            row * factorStride + column
        ] = value;
        factor[
            column * factorStride + row
        ] = value;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (lane != 0u) {
        return;
    }

    // Lane zero performs the deterministic validation/max reduction before
    // mutating the assembled matrix into its Cholesky factor.
    float maximumMass = 0.0f;
    for (uint row = 0u; row < articulation.nv; ++row) {
        for (uint column = 0u; column <= row; ++column) {
            const float value = factor[
                row * factorStride + column
            ];
            if (!isfinite(value)) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                    row
                );
                statuses[environment] = status;
                return;
            }
            maximumMass = max(maximumMass, abs(value));
        }
    }
    // Armature is generalized-coordinate inertia, independent of whether a
    // drive is enabled. Implicit-drive mode adds h D + h^2 K so contact
    // response uses the same effective operator as ABA.
    for (uint dof = 0u; dof < articulation.nv; ++dof) {
        device const MRDofPropertiesGPU& properties =
            dofs[articulation.vOffset + dof];
        float armature = properties.drive.z;
        if ((dispatch.flags &
             MR_ARTICULATED_OPERATOR_IMPLICIT_DRIVES) != 0u &&
            (properties.flags & MR_DOF_FLAG_DRIVE) != 0u) {
            const float timestep =
                world.gravityAndTimestep.w;
#if MR_ARTICULATED_OPERATOR_BODY_PARAMETERS
            const float4 controller =
                controllerParameters[environment];
            const float gainScale = max(controller.x, 0.0f);
            const float dampingScale = max(controller.y, 0.0f);
#else
            constexpr float gainScale = 1.0f;
            constexpr float dampingScale = 1.0f;
#endif
            armature +=
                timestep * dampingScale * properties.drive.y +
                timestep * timestep * gainScale *
                    properties.drive.x;
        }
        const uint diagonal =
            dof * factorStride + dof;
        const float value = factor[diagonal] + armature;
        if (!isfinite(value)) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                articulation.vOffset + dof
            );
            statuses[environment] = status;
            return;
        }
        factor[diagonal] = value;
        maximumMass = max(maximumMass, abs(value));
    }

    float minimumPivot = INFINITY;
    float maximumPivot = 0.0f;
    // A pivot is rejected relative to the matrix magnitude and FP32
    // roundoff, with an absolute floor only for the all-small regime. The
    // factor is consumed by the residual gate below, so use a square-root
    // dimension scale here rather than a linear worst-case summation bound:
    // otherwise physically valid light anatomical segments are rejected
    // before their actual solve accuracy can be measured.
    const float pivotFloor = max(
        kFactorAbsolutePivotFloor,
        maximumMass * 4.0f * sqrt(float(articulation.nv)) *
            kFloatEpsilon
    );
    for (uint row = 0u; row < articulation.nv; ++row) {
        for (uint column = 0u;
             column <= row;
             ++column) {
            float value = factor[
                row * factorStride + column
            ];
            for (uint inner = 0u; inner < column; ++inner) {
                value -=
                    factor[
                        row * factorStride +
                        inner
                    ] *
                    factor[
                        column * factorStride +
                        inner
                    ];
            }
            if (row == column) {
                if (!(value > pivotFloor) ||
                    !isfinite(value)) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_FACTORIZATION_FAILED,
                        row
                    );
                    status.diagnostics = float4(
                        minimumPivot,
                        maximumPivot,
                        0.0f,
                        maximumMass
                    );
                    statuses[environment] = status;
                    return;
                }
                const float pivot = sqrt(value);
                factor[
                    row * factorStride + row
                ] = pivot;
                minimumPivot = min(minimumPivot, pivot);
                maximumPivot = max(maximumPivot, pivot);
            } else {
                value /= factor[
                    column * factorStride +
                    column
                ];
                if (!isfinite(value)) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_FACTORIZATION_FAILED,
                        row
                    );
                    statuses[environment] = status;
                    return;
                }
                factor[
                    row * factorStride +
                    column
                ] = value;
            }
        }
    }

    for (uint dof = 0u; dof < articulation.nv; ++dof) {
        rightHandSide[dof] = 0.0f;
    }
    const uint pointBase = environment * dispatch.pointStride;
    for (uint point = 0u;
         point < dispatch.pointCount;
         ++point) {
        device const MRArticulatedPointImpulseGPU& query =
            points[pointBase + point];
        if ((query.flags & MR_ARTICULATED_POINT_INACTIVE) != 0u) {
            continue;
        }
        const uint localBody =
            query.bodyIndex - articulation.firstBody;
        const float3 pointOffset = pointSurfaceOffset(bodyRotation[localBody], query);
        for (uint dof = 0u; dof < articulation.nv; ++dof) {
            const MotionColumn bodyMotion = bodyMotionForDof(
                localBody,
                dof,
                articulation,
                joints,
                functionPrograms,
                environmentQ,
                bodyPosition,
                bodyRotation,
                jointPosition,
                jointAxis,
                inboundJoint,
                parentLocal
            );
            const float3 pointLinear =
                bodyMotion.linear +
                cross(bodyMotion.angular, pointOffset);
            rightHandSide[dof] +=
                dot(pointLinear, query.worldImpulse.xyz);
        }
    }

    for (uint row = 0u; row < articulation.nv; ++row) {
        float value = rightHandSide[row];
        for (uint column = 0u; column < row; ++column) {
            value -=
                factor[
                    row * factorStride +
                    column
                ] *
                intermediate[column];
        }
        intermediate[row] =
            value /
            factor[
                row * factorStride + row
            ];
    }
    for (uint reverse = 0u;
         reverse < articulation.nv;
         ++reverse) {
        const uint row = articulation.nv - 1u - reverse;
        float value = intermediate[row];
        for (uint column = row + 1u;
             column < articulation.nv;
             ++column) {
            value -=
                factor[
                    column * factorStride +
                    row
                ] *
                solution[column];
        }
        solution[row] =
            value /
            factor[
                row * factorStride + row
            ];
        if (!isfinite(solution[row])) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                row
            );
            statuses[environment] = status;
            return;
        }
    }

    // Reuse the checked Cholesky factor for the residual. This is both the
    // production operation being audited and substantially cheaper than
    // reassembling dense body Jacobians after the solve.
    for (uint row = 0u; row < articulation.nv; ++row) {
        float value = 0.0f;
        for (uint column = row;
             column < articulation.nv;
             ++column) {
            value +=
                factor[
                    column * factorStride + row
                ] *
                solution[column];
        }
        intermediate[row] = value;
    }
    float maximumResidual = 0.0f;
    float maximumRightHandSide = 0.0f;
    float maximumSolution = 0.0f;
    for (uint row = 0u; row < articulation.nv; ++row) {
        float action = 0.0f;
        for (uint column = 0u;
             column <= row;
             ++column) {
            action +=
                factor[
                    row * factorStride + column
                ] *
                intermediate[column];
        }
        maximumResidual = max(
            maximumResidual,
            abs(action - rightHandSide[row])
        );
        maximumRightHandSide = max(
            maximumRightHandSide,
            abs(rightHandSide[row])
        );
        maximumSolution = max(
            maximumSolution,
            abs(solution[row])
        );
    }
    const float residualDenominator =
        maximumRightHandSide +
        maximumMass * float(articulation.nv) * maximumSolution +
        1.0e-30f;
    const float relativeResidual =
        maximumResidual / residualDenominator;
    if (!isfinite(relativeResidual) ||
        relativeResidual >
            MR_ARTICULATED_OPERATOR_MAX_RELATIVE_RESIDUAL) {
        setFailure(
            status,
            isfinite(relativeResidual)
                ? MR_ARTICULATED_OPERATOR_ACCURACY_FAILED
                : MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
            MR_INVALID_INDEX
        );
        status.diagnostics = float4(
            minimumPivot,
            maximumPivot,
            relativeResidual,
            maximumMass
        );
        statuses[environment] = status;
        return;
    }

    // Audit every value that publication will materialize. These expressions
    // are intentionally evaluated again during commit: lane-zero validation
    // keeps the payload transactional without a second full output scratch
    // allocation.
    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        if (!finite3(worldTranslation + bodyPosition[localBody]) ||
            !finite4(bodyRotation[localBody])) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                articulation.firstBody + localBody
            );
            statuses[environment] = status;
            return;
        }
    }
    for (uint point = 0u;
         point < dispatch.pointCount;
         ++point) {
        device const MRArticulatedPointImpulseGPU& query =
            points[pointBase + point];
        if ((query.flags & MR_ARTICULATED_POINT_INACTIVE) != 0u) {
            continue;
        }
        const uint localBody =
            query.bodyIndex - articulation.firstBody;
        const float3 pointOffset = pointSurfaceOffset(bodyRotation[localBody], query);
        const float3 candidateWorld =
            worldTranslation + (bodyPosition[localBody] + pointOffset);
        if (!finite3(pointOffset) || !finite3(candidateWorld)) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                point
            );
            statuses[environment] = status;
            return;
        }
        for (uint dof = 0u; dof < articulation.nv; ++dof) {
            const MotionColumn bodyMotion = bodyMotionForDof(
                localBody,
                dof,
                articulation,
                joints,
                functionPrograms,
                environmentQ,
                bodyPosition,
                bodyRotation,
                jointPosition,
                jointAxis,
                inboundJoint,
                parentLocal
            );
            const float3 pointLinear =
                bodyMotion.linear +
                cross(bodyMotion.angular, pointOffset);
            if (!finite3(pointLinear)) {
                setFailure(
                    status,
                    MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                    point
                );
                statuses[environment] = status;
                return;
            }
        }
    }
    for (uint dof = 0u; dof < articulation.nv; ++dof) {
        if (!isfinite(rightHandSide[dof]) ||
            !isfinite(solution[dof])) {
            setFailure(
                status,
                MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                dof
            );
            statuses[environment] = status;
            return;
        }
    }
    if ((dispatch.flags &
         MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS) != 0u) {
        for (uint row = 0u; row < articulation.nv; ++row) {
            for (uint column = 0u;
                 column < articulation.nv;
                 ++column) {
                float value = 0.0f;
                const uint innerCount = min(row, column) + 1u;
                for (uint inner = 0u;
                     inner < innerCount;
                     ++inner) {
                    value +=
                        factor[
                            row * factorStride +
                            inner
                        ] *
                        factor[
                            column * factorStride +
                            inner
                        ];
                }
                if (!isfinite(value)) {
                    setFailure(
                        status,
                        MR_ARTICULATED_OPERATOR_NONFINITE_RESULT,
                        row
                    );
                    statuses[environment] = status;
                    return;
                }
            }
        }
    }

    // Publish only after validation, kinematics, factorization, solve, and
    // residual evaluation all succeed. Error paths above leave payloads
    // untouched and write only the per-environment status.
    const uint poseBase =
        environment * dispatch.bodyPoseStride;
    for (uint localBody = 0u;
         localBody < articulation.bodyCount;
         ++localBody) {
        MRArticulatedBodyPoseGPU pose;
        pose.position =
            float4(worldTranslation + bodyPosition[localBody], 1.0f);
        pose.orientation = bodyRotation[localBody];
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
        if (compensatedTranslation) {
            const auto paired = mrCompensatedTranslationPosition(translation,
                float4(bodyPosition[localBody], 0.0f));
            pose.position = float4(paired.high.xyz, 1.0f);
            bodyPositionLow[poseBase + localBody] = paired.low;
        }
#endif
        bodyPoses[poseBase + localBody] = pose;
    }

    const uint pointWorldBase =
        environment * dispatch.pointWorldStride;
    const uint jacobianBase =
        environment * dispatch.pointJacobianStride;
    for (uint point = 0u;
         point < dispatch.pointCount;
         ++point) {
        device const MRArticulatedPointImpulseGPU& query =
            points[pointBase + point];
        const uint localBody =
            query.bodyIndex - articulation.firstBody;
        const float3 pointOffset = pointSurfaceOffset(bodyRotation[localBody], query);
        MRArticulatedPointWorldGPU worldPoint;
        worldPoint.position = float4(
            worldTranslation + (bodyPosition[localBody] + pointOffset),
            1.0f
        );
#if MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
        if (compensatedTranslation) {
            const auto paired = mrCompensatedTranslationPosition(translation,
                float4(bodyPosition[localBody] + pointOffset, 0.0f));
            worldPoint.position = float4(paired.high.xyz, worldPoint.position.w);
            pointPositionLow[pointWorldBase + point] = paired.low;
        }
#endif
        pointWorld[pointWorldBase + point] = worldPoint;
        if ((query.flags & MR_ARTICULATED_POINT_INACTIVE) != 0u) {
            for (uint dof = 0u; dof < articulation.nv; ++dof) {
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 0u) * articulation.nv + dof
                ] = 0.0f;
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 1u) * articulation.nv + dof
                ] = 0.0f;
                pointJacobians[
                    jacobianBase +
                    (point * 3u + 2u) * articulation.nv + dof
                ] = 0.0f;
            }
            continue;
        }
        for (uint dof = 0u; dof < articulation.nv; ++dof) {
            const MotionColumn bodyMotion = bodyMotionForDof(
                localBody,
                dof,
                articulation,
                joints,
                functionPrograms,
                environmentQ,
                bodyPosition,
                bodyRotation,
                jointPosition,
                jointAxis,
                inboundJoint,
                parentLocal
            );
            const float3 pointLinear =
                bodyMotion.linear +
                cross(bodyMotion.angular, pointOffset);
            pointJacobians[
                jacobianBase +
                (point * 3u + 0u) * articulation.nv + dof
            ] = pointLinear.x;
            pointJacobians[
                jacobianBase +
                (point * 3u + 1u) * articulation.nv + dof
            ] = pointLinear.y;
            pointJacobians[
                jacobianBase +
                (point * 3u + 2u) * articulation.nv + dof
            ] = pointLinear.z;
        }
    }

    const uint generalizedBase =
        environment * dispatch.generalizedStride;
    for (uint dof = 0u; dof < articulation.nv; ++dof) {
        generalizedImpulse[generalizedBase + dof] =
            rightHandSide[dof];
        deltaVelocity[generalizedBase + dof] =
            solution[dof];
    }

    if ((dispatch.flags &
         MR_ARTICULATED_OPERATOR_WRITE_DIAGNOSTIC_MASS) != 0u) {
        const uint massBase =
            environment * dispatch.massMatrixStride;
        for (uint row = 0u; row < articulation.nv; ++row) {
            for (uint column = 0u;
                 column < articulation.nv;
                 ++column) {
                float value = 0.0f;
                const uint innerCount = min(row, column) + 1u;
                for (uint inner = 0u;
                     inner < innerCount;
                     ++inner) {
                    value +=
                        factor[
                            row * factorStride +
                            inner
                        ] *
                        factor[
                            column * factorStride +
                            inner
                        ];
                }
                diagnosticMassMatrix[
                    massBase + row * articulation.nv + column
                ] = value;
            }
        }
    } else if ((dispatch.flags &
                MR_ARTICULATED_OPERATOR_WRITE_CHOLESKY_FACTOR) != 0u) {
        const uint factorBase =
            environment * dispatch.massMatrixStride;
        for (uint row = 0u; row < articulation.nv; ++row) {
            for (uint column = 0u;
                 column < articulation.nv;
                 ++column) {
                diagnosticMassMatrix[
                    factorBase + row * articulation.nv + column
                ] = column <= row
                    ? factor[
                          row * factorStride +
                          column
                      ]
                    : 0.0f;
            }
        }
    }

    status.diagnostics = float4(
        minimumPivot,
        maximumPivot,
        relativeResidual,
        maximumMass
    );
    statuses[environment] = status;
}

#if !MR_ARTICULATED_OPERATOR_BODY_PARAMETERS && !MR_ARTICULATED_OPERATOR_HAS_COMPENSATED_TRANSLATION
// Materializes world-space rigid-body velocities from the same generalized
// state used by the solver. Tactile sampling needs point velocity at arbitrary
// atlas hits, so publishing only articulation poses would silently erase the
// angular component of surface-relative motion. One forward tree recursion
// computes every twist without expanding a body-by-DoF Jacobian; SIMD lanes
// only publish the finished body records.
kernel void mr_articulated_materialize_body_velocities(
    device const MRWorldGPU* worlds [[buffer(0)]],
    device const MRArticulationGPU* articulations [[buffer(1)]],
    device const MRJointDescriptorGPU* joints [[buffer(2)]],
    device const MRDofPropertiesGPU* dofs [[buffer(3)]],
    device const MRBodyPropertiesGPU* bodies [[buffer(4)]],
    device const MRArticulatedOperatorDispatchGPU& dispatch
        [[buffer(5)]],
    device const float* q [[buffer(6)]],
    device const float* v [[buffer(7)]],
    device MRBodyStateGPU* bodyStates [[buffer(8)]],
    device MRArticulatedOperatorStatusGPU* statuses [[buffer(9)]],
    uint environment [[threadgroup_position_in_grid]],
    uint lane [[thread_index_in_threadgroup]],
    uint threadsPerThreadgroup [[threads_per_threadgroup]]
) {
    if (environment >= dispatch.environmentCount) {
        return;
    }

    threadgroup uint initializationSucceeded;
    threadgroup float3 bodyPosition[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup float4 bodyRotation[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup float3 jointPosition[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup float3 jointAxis[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup uint inboundJoint[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup uint parentLocal[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup uchar known[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup float3 bodyLinearVelocity[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup float3 bodyAngularVelocity[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];
    threadgroup uchar bodyVelocityKnown[
        MR_ARTICULATED_OPERATOR_MAX_BODIES
    ];

    MRArticulatedOperatorStatusGPU status = {};
    status.code = MR_ARTICULATED_OPERATOR_SUCCESS;
    status.environment = environment;
    status.articulationIndex = dispatch.articulationIndex;
    status.failingIndex = MR_INVALID_INDEX;
    device const MRWorldGPU& world = worlds[0];

    if (lane == 0u) {
        initializationSucceeded = 0u;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (lane == 0u) {
        initializationSucceeded =
            validDispatch(world, dispatch, status) ? 1u : 0u;
        if (initializationSucceeded == 0u) {
            statuses[environment] = status;
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (initializationSucceeded == 0u) {
        return;
    }

    device const MRArticulationGPU& articulation =
        articulations[dispatch.articulationIndex];
    device const float* environmentQ =
        q + environment * dispatch.qStride;
    device const float* environmentV =
        v + environment * dispatch.generalizedStride;
    if (lane == 0u) {
        initializationSucceeded =
            validModelAndLayout(
                world,
                articulation,
                joints,
                nullptr,
                dofs,
                bodies,
                dispatch,
                inboundJoint,
                parentLocal,
                known,
                status
            ) &&
            buildKinematics(
                articulation,
                joints,
                nullptr,
                environmentQ,
                bodyPosition,
                bodyRotation,
                jointPosition,
                jointAxis,
                known,
                status
            ) &&
            buildBodyVelocities(
                articulation,
                joints,
                environmentV,
                bodyPosition,
                jointPosition,
                jointAxis,
                bodyLinearVelocity,
                bodyAngularVelocity,
                bodyVelocityKnown,
                status
            )
            ? 1u
            : 0u;
        if (initializationSucceeded == 0u) {
            statuses[environment] = status;
        }
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if (initializationSucceeded == 0u) {
        return;
    }

    const uint bodyBase =
        environment * dispatch.bodyPoseStride;
    for (uint localBody = lane;
         localBody < articulation.bodyCount;
         localBody += threadsPerThreadgroup) {
        device MRBodyStateGPU& state =
            bodyStates[bodyBase + localBody];
        state.linearVelocityAndInverseMass.xyz =
            bodyLinearVelocity[localBody];
        state.angularVelocity = float4(
            bodyAngularVelocity[localBody],
            0.0f
        );
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);

    if (lane != 0u) {
        return;
    }
    status.bodyCount = articulation.bodyCount;
    status.nq = articulation.nq;
    status.nv = articulation.nv;
    status.pointCount = 0u;
    statuses[environment] = status;
}
#endif
