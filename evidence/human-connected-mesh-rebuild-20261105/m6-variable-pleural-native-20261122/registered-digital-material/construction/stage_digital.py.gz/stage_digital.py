"""Retain the working native authoring path, tested patches and exact comparative witnesses."""
from pathlib import Path
import json,shutil,sys,subprocess
from retain_registered_support import retain
from material_context import sha
root,work,stage=map(lambda p:Path(p).resolve(),sys.argv[1:])
reg=stage/'tools/native_ligament_contact/registered_digit_material'
vol=stage/'tools/native_ligament_contact/registered_material_volume'
for d in (reg,vol):d.mkdir(parents=True,exist_ok=True)
ordinary=['accepted_digit_geometry.py','digital_clearance.py','fit_digital_corridor.py','digital_contact_constraints.py',
          'project_digit_material_field.py','digit_mass_constraints.py','target_digit_interfaces.py','localized_mass_field.py',
          'compare_digital_material_interfaces.py','emit_constrained_material.py','extensor_transfer.py','fit_extensor_branches.py',
          'check_extensor_interfaces.py','bind_registered_digit_pose.py','test_digital_registration.py']
for name in ordinary+['material_context.py']:shutil.copyfile(root/name,reg/name)
# Only the physical geometry operations of the rejected direct-shift experiment are used by the admitted solver.
text=(root/'fit_dorsal_material.py').read_text().split('def fit(run,out,millimeters):')[0]
(reg/'fit_dorsal_material.py').write_text(text.replace('from scipy.sparse import coo_matrix\n','').replace('from scipy.optimize import linprog\n','').replace('import json,sys','import json'))
for src,dst in [('rebuild_torso_native_role_support.py','rebuild_torso_native_role_support.py'),('sparse_digit_mass.py','rebalance_material_density_groups.py'),
               ('admit_current_volume.py','admit_current_volume.py'),('replay_registered_digit.sh','replay_registered_digit.sh')]:
    shutil.copy2(root/src,vol/dst)
# Preserve older scripts' small diffs. Format new code only.
subprocess.run([sys.executable,'-m','ruff','format',*[str(reg/v) for v in ordinary+['fit_dorsal_material.py']]],check=True)
case=root/'routed-target-1.5mm'
ev=stage/'evidence/human-connected-mesh-rebuild-20261105/m6-variable-pleural-native-20261122/registered-digital-material'
for p in ['geometry.json','site-clearance.json','corridor-fit.json','extensor-transfer.json','branch-transfer.json','branch-interfaces.json','unit.log']:
    retain(root/p,ev/'diagnosis')
for name in ['constrained-1.5mm','projected-1.5mm','local-mass-1.5mm']:
    for f in ['quality.json','field.npz','interfaces.json','corridor.json']:
        if (root/name/f).is_file():retain(root/name/f,ev/'earlier-fits'/name)
for f in ['mass-projection.log','target-mass.log']:retain(root/f,ev/'earlier-fits')
for f in ['field.npz','quality.json','interfaces.json','material-identity.json','carrier-balance.json','sparse-transfer/mass-transfer.json','material/native-role-verification.json',
          'mesh/current-child.labels.json','material/p1/rebuild.json','supported-registration.json','native-owner/identities.json','supported-launch.json','launch.json',
          'p1.log','surface.log','import-volume.log','sparse.log','carrier.log','material/native-role.log','build.log']:
    retain(case/f,ev/'material'/Path(f).parent)
for folder in ('archive','older-views'):
    for receipt in (root/folder).glob('*/*-verification.json'):retain(receipt,ev/'storage')
audit=json.loads((case/'supported-registration.json').read_text())
if any(r['invalid'] for r in audit['roles'].values()) or not json.loads((case/'material/native-role-verification.json').read_text())['passed']:
    raise ValueError('Material acceptance missing')
print(ev,flush=True)
