"""Reuse the compiled carrier transport solver with immutable compensation and actual native cell volumes."""
import json,sys,tempfile,subprocess
from pathlib import Path
import numpy as np
from material_context import sha

def run(case,baseline,dense,mesh,exe):
    name='current-density-closed-flow.npz';report=json.loads((baseline/'mass-transfer.json').read_text())
    if sha(baseline/name)!=report['flow_sha256']:raise ValueError('Unmatched native reference mass')
    f=dict(np.load(baseline/name));source=np.load(dense/name);c=f['carrier_row'];g=f['group'];cell=f['group_for_cell']
    if not np.array_equal(c,source['carrier_row']) or not np.array_equal(g,source['group']):raise ValueError('Different route ancestry')
    historical=f['archived_compensation'];before=f['mass_flow_kg'];allowed=((source['mass_flow_kg']>0)|(before>0))&~historical
    cc,gg=c[allowed],g[allowed];mass=before[allowed].copy()
    v=np.fromfile(case/'native.volumes',dtype='f8');t=np.loadtxt(mesh,skiprows=1,usecols=(1,2,3,4,5),dtype='i4')
    if len(v)!=len(t) or np.min(v)<=1e-18:raise ValueError('Native volume failed')
    _,first=np.unique(cell,return_index=True);role=t[first,4];assert np.array_equal(role[cell],t[:,4])
    vg=np.bincount(cell,weights=v);lo=np.where(role==15,900.,850.);hi=np.where(role==15,1100.,950.)
    fixed=np.bincount(g[~allowed],weights=before[~allowed],minlength=len(vg));quota=np.bincount(cc,weights=mass,minlength=int(c.max()+1))
    base=np.bincount(g,weights=before,minlength=len(vg));margin=np.maximum(1e-11*base,64*np.spacing(base))
    L=lo*vg+margin-fixed;H=hi*vg-margin-fixed;prior=mass.copy();history=[]
    lower=np.maximum(0,L);upper=np.maximum(0,H)
    if np.any(H<0) or np.any(upper<lower):raise ValueError('Fixed compensation alone exceeds group capacity')
    with tempfile.TemporaryDirectory(dir=case) as tmp:
        tmp=Path(tmp);problem=tmp/"route";out=tmp/"flow";cut=tmp/"cut"
        for it in range(3):
            current=np.bincount(gg,weights=mass,minlength=len(vg))
            # The owner returns early when the upper-capacity cut saturates. A
            # continuation then resolves reachable lower obligations independently.
            up=upper if it!=1 else np.maximum(upper,current+np.maximum(1e-15,1e-11*current))
            with problem.open("wb") as stream:
                for arr,dt in [([len(quota),len(vg),len(cc)],'u4'),(cc,'u4'),(gg,'u4'),(mass,'f8'),(quota,'f8'),(lower,'f8'),(up,'f8'),(np.zeros(len(cc)),'u1')]:
                    np.asarray(arr,dtype=dt).tofile(stream)
            result=subprocess.run([exe,problem,out,cut],capture_output=True,text=True,check=True)
            mass=np.fromfile(out,dtype='f8')
            history.extend(result.stdout.splitlines())
            now=np.bincount(gg,weights=mass,minlength=len(vg))+fixed
            if np.all((now/vg>=lo)&(now/vg<=hi)):break
        complete=before.copy();complete[allowed]=mass
        actual=np.bincount(g,weights=complete,minlength=len(vg));fail=(actual/vg<lo)|(actual/vg>hi)
        gap=np.maximum.reduce([lo*vg-actual,actual-hi*vg,np.zeros(len(vg))])
        carrier=np.max(abs(np.bincount(c,weights=complete)-np.bincount(c,weights=before)))
        result=dict(original_group_failures=int(np.sum((base/vg<lo)|(base/vg>hi))),failed_groups=int(fail.sum()),
                    unmet_kg=float(gap.sum()),maximum_unmet_kg=float(gap.max()),worst_group=int(gap.argmax()),
                    quota_error_kg=float(carrier),carrier_count=int(c.max()+1),eligible_edges=int(allowed.sum()),
                    changed_routes=int(np.count_nonzero(complete!=before)),mass_kg=float(complete.sum()),native_volume_sha256=sha(case/'native.volumes'),
                    source_flow_sha256=sha(baseline/name),eligible_dense_source_sha256=sha(dense/name),solver_sha256=sha(exe),
                    frozen_compensation_equal=bool(np.array_equal(complete[historical],before[historical])),phases=history)
        (case/'carrier-balance.json').write_text(json.dumps(result,indent=2)+'\n')
        if fail.any() or carrier>2e-17 or np.min(complete)<0:raise ValueError(str(result))
        em=f['element_mass_kg'].copy();cg=cell;avg=actual/vg;current=em*(actual/np.bincount(cg,weights=em))[cg]/v
        redo=np.union1d(np.unique(g[complete!=before]),cg[(current<lo[cg])|(current>hi[cg])|(em/v<lo[cg])|(em/v>hi[cg])])
        change=np.isin(cg,redo);em[change]=v[change]*avg[cg[change]];after=em*(actual/np.bincount(cg,weights=em))[cg]/v
        if np.any((after<lo[cg])|(after>hi[cg])|(em/v<lo[cg])|(em/v>hi[cg])):raise ValueError("Native child fractions outside permitted densities")
        f['mass_flow_kg']=complete;f['element_mass_kg']=em
        f['nodal_mass_kg']=sum(np.bincount(t[:,i]-1,weights=em*.25,minlength=len(f['nodal_mass_kg'])) for i in range(4))
        dest=case/'fine-mass-routed';dest.mkdir(exist_ok=True);np.savez_compressed(dest/name,**f)
        result.update(flow_sha256=sha(dest/name),geometry_sha256=sha(case/'proposal.npz'),admitted_route_distance_m=report['admitted_route_distance_m'],
                      density_outliers=0,range_kg_m3=[float(after.min()),float(after.max())],corrected_children=int(change.sum()))
        (dest/'mass-transfer.json').write_text(json.dumps(result,indent=2)+'\n')
        print(result['original_group_failures'],result['failed_groups'],carrier)
if __name__=='__main__':run(*(Path(v).resolve() for v in sys.argv[1:]))
