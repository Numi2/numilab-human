from __future__ import annotations
import hashlib, importlib.util, json, sys, time, traceback
from collections import Counter, defaultdict
from pathlib import Path
import numpy as np

P = Path('/Users/numi/Work/numi-human-connected-surface-069/D/connected-obstacle-207/physical-transfer-209')
ROOT = P/'reduced-physical-boundary-400/attempt-046-fine-role-simplification'
C = ROOT/'run-023/D-reduced-typed-runs-diagnostic.npz'
S = P/'geometry-worker/matched-nesting-390/run-044-native-f32-replay-185/cube2um-union/conditioning-run-007-source-retype/pair-geometry-014-linked-remesh/fine-I-bone-barrier-run-024/full-native-self-028/current-collar-plan-032/engine-20-ops-one-sided624-run-006/candidate-f32-linked-remesh-typed.npz'
PLAN = ROOT/'run-023/source-seam-classification-001/source-edge-patch-plan-002/source-edge-patch-plan.npz'
PLAN_REPORT = ROOT/'run-023/source-seam-classification-001/source-edge-patch-plan-002/report.json'
HELPER = ROOT/'run_joint_exact_audit_003.py'
OWNER = P/'deep-boundary-checkpoint-349/payload/exact-owner/numilab_human/cardiac_cavity_intersections.py'
OUT = ROOT/'run-066-D023-source-safe-splice-001'
PINS = {C:'c6757773c491499bd6e6950de2fa04f924a6f0a4e3e666295a548925d73f8c54',
        S:'c17794a1012f76924dcd9e4e754bb026c774deb5a3d37e2f1c79635ccfe9dc83',
        PLAN:'e2a69c79610f89526559518711efa85a4e3aa273b7b3830be691154e291c0748',
        PLAN_REPORT:'3571f6b6181df2c2ef83f3d24535351215da3f10d3f026a17bf0d74c6d37f847',
        HELPER:'b202f43adf921cea0faeb30f32d921f0979516ca2e5655d9da51c72856906d0a',
        OWNER:'f0c1d81bffb185565b174f293b67da01926db1dfa6f6b80cb5629828ccf08b6d'}
TAGS=('face_source_layer','face_source_body','face_source_bone','face_source_face_id','face_source_original_id','face_source_identity0','face_source_identity1')

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def load(p):
    with np.load(p,allow_pickle=False) as z: return {k:np.array(z[k],copy=True) for k in z.files}
def edges(faces):
    d=defaultdict(list)
    for i,(a,b,c) in enumerate(np.asarray(faces,np.int64)):
        a=int(a); b=int(b); c=int(c)
        d[tuple(sorted((a,b)))].append((i,a,b)); d[tuple(sorted((b,c)))].append((i,b,c)); d[tuple(sorted((c,a)))].append((i,c,a))
    return d
def boundary(rows,edge_map):
    keep=set(map(int,rows)); out=[]
    for uses in edge_map.values():
        q=[x for x in uses if x[0] in keep]
        if len(q)==1: out.append(q[0])
    return out
def cyclic(t): return min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
def structure(points,faces):
    p=np.asarray(points,np.float32); f=np.asarray(faces,np.int64)
    tri=p[f].astype(np.float64); cr=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
    zero=np.flatnonzero(np.all(cr==0,axis=1)); ei=edges(f); bd=[]; non=[]; same=[]
    for k,u in ei.items():
        if len(u)==1: bd.append((u[0][1],u[0][2]))
        elif len(u)>2: non.append((k,len(u)))
        elif (u[0][1],u[0][2])==(u[1][1],u[1][2]): same.append(k)
    counts=Counter(tuple(sorted(map(int,t))) for t in f); dup=[k for k,n in counts.items() if n>1]
    bv={v for e in bd for v in e}; inc=defaultdict(list)
    for a,b,c in f:
        inc[int(a)].append((int(b),int(c))); inc[int(b)].append((int(c),int(a))); inc[int(c)].append((int(a),int(b)))
    bad=[]
    for v,ts in inc.items():
        la=defaultdict(set)
        for a,b in ts: la[a].add(b); la[b].add(a)
        deg=Counter(len(x) for x in la.values())
        if any(n not in (1,2) for n in deg.values()) or (v in bv and deg[1]!=2) or (v not in bv and deg[1]!=0): bad.append((v,dict(deg)))
        if la:
            seen={next(iter(la))}; q=list(seen)
            while q:
                x=q.pop()
                for y in la[x]:
                    if y not in seen: seen.add(y); q.append(y)
            if len(seen)!=len(la): bad.append((v,{'disconnected_link_components':len(la)-len(seen)}))
    return {'zero_area_f32_rows':zero.astype(int).tolist(),'duplicate_face_count':len(dup),'boundary_edges':len(bd),'boundary_directed_rows':bd,'nonmanifold_edge_count':len(non),'same_direction_edge_count':len(same),'vertex_link_failure_count':len(bad),'vertex_link_witnesses':bad[:40]}

def main():
    if OUT.exists(): raise FileExistsError(OUT)
    for p,h in PINS.items():
        got=sha(p)
        if got!=h: raise ValueError(f'input hash mismatch {p}: {got}')
    OUT.mkdir(parents=True); started=time.monotonic()
    report={'schema':'numi.D023.source-safe-edge-patch-splice.v1','status':'RUNNING','physical_admission':False,'runtime':0,'accepted_steps':0,'geometry_modified':False,'input_pins':{str(p):sha(p) for p in PINS}}
    try:
        c=load(C); s=load(S); pl=load(PLAN)
        cf=np.asarray(c['faces'],np.int64); sf=np.asarray(s['faces'],np.int64)
        cp=np.asarray(c['points_world_m_f32'],np.float32); sp=np.asarray(s['points_world_m'],np.float32)
        csrc=np.asarray(c['vertex_parent_source_candidate_rows'],np.int64)
        if csrc.shape!=(len(cp),) or not np.array_equal(cp,sp[csrc]): raise ValueError('D023 point map is not exact D624 F32')
        po=np.asarray(pl['patch_candidate_offsets'],np.int64); pr=np.asarray(pl['patch_candidate_face_rows'],np.int64)
        so=np.asarray(pl['patch_source_offsets'],np.int64); sr=np.asarray(pl['patch_source_face_rows'],np.int64)
        if len(po)!=55 or len(so)!=55: raise ValueError('expected reviewed 54-patch plan')
        cpatch=[set(map(int,pr[po[i]:po[i+1]])) for i in range(54)]
        spatch=[set(map(int,sr[so[i]:so[i+1]])) for i in range(54)]
        remove=set().union(*cpatch); source_rows=set().union(*spatch)
        if len(remove)!=len(pr) or len(source_rows)!=len(sr): raise ValueError('overlapping rows in patch plan')
        ce=edges(cf); se=edges(sf); checks=[]
        for i in range(54):
            cb=boundary(cpatch[i],ce); sb=boundary(spatch[i],se)
            a=Counter((int(csrc[u]),int(csrc[v])) for _,u,v in cb); b=Counter((int(u),int(v)) for _,u,v in sb)
            if a!=b: raise ValueError(f'patch {i} boundary mismatch')
            checks.append({'patch_id':i,'candidate_faces':len(cpatch[i]),'source_faces':len(spatch[i]),'boundary_edges':len(cb),'directed_boundary_match':True})
        categories=json.loads(str(c['source_group_keys_json'][0]))
        cat={tuple(int(x[k]) for k in ('face_source_layer','face_source_body','face_source_bone','face_source_original_id')):i for i,x in enumerate(categories)}
        if len(cat)!=len(categories): raise ValueError('typed category key collision')
        for i in range(len(cf)):
            key=tuple(int(c[k][i]) for k in ('face_source_layer','face_source_body','face_source_bone','face_source_original_id'))
            if cat.get(key,-1)!=int(c['face_group_id'][i]): raise ValueError(f'candidate face {i} group/category mismatch')
        src_group=np.empty(len(sf),np.int64)
        for i in range(len(sf)):
            key=tuple(int(s[k][i]) for k in ('face_source_layer','face_source_body','face_source_bone','face_source_original_id'))
            if key not in cat: raise ValueError(f'D624 source face {i} missing typed category')
            src_group[i]=cat[key]
        keep=np.flatnonzero(~np.isin(np.arange(len(cf)),np.fromiter(remove,dtype=np.int64)))
        keep_tri=defaultdict(list)
        for fi in keep: keep_tri[tuple(sorted(map(int,csrc[cf[fi]])))].append(int(fi))
        represented_src={}; represented_out={}
        for fr in sorted(source_rows):
            st=tuple(map(int,sf[fr])); matches=keep_tri.get(tuple(sorted(st)),[])
            if len(matches)>1: raise ValueError(f'source face {fr} has duplicate retained candidate copies')
            if matches:
                cr=matches[0]
                if cyclic(tuple(map(int,csrc[cf[cr]])))!=cyclic(st): raise ValueError(f'source face {fr} retained reversed')
                if any(int(c[k][cr])!=int(s[k][fr]) for k in TAGS): raise ValueError(f'typed retained face mismatch at {cr}')
                represented_src[fr]=cr; represented_out[cr]=fr
        vfaces=defaultdict(set)
        for fi,tri in enumerate(cf):
            for v in tri: vfaces[int(v)].add(fi)
        points32=[]; points64=[]; new_src=[]; new_v_lineage=[]; new_patch_info=[]
        outfaces=[cf[i].copy() for i in keep]; face_origin=[int(i) for i in keep]
        face_source=[represented_out.get(int(i),-1) for i in keep]; face_patch=[-1]*len(keep)
        groups=[int(c['face_group_id'][i]) for i in keep]
        parent=[int(c['face_parent_source_face_rows'][i]) for i in keep]
        pdist=[float(c['face_parent_centroid_distance_m'][i]) for i in keep]
        for pid,(cp_rows,sp_rows) in enumerate(zip(cpatch,spatch)):
            vmap={}
            for _,u,v in boundary(cp_rows,ce):
                for old in (int(u),int(v)):
                    source=int(csrc[old])
                    if source in vmap and vmap[source]!=old: raise ValueError(f'patch {pid} boundary source vertex has multiple reduced rows')
                    vmap[source]=old
            source_tris=sf[sorted(sp_rows)]
            internal=sorted(set(map(int,source_tris.reshape(-1)))-set(vmap)); reused=[]; appended=[]
            for sv in internal:
                reps=np.flatnonzero(csrc==sv)
                local=[int(v) for v in reps if vfaces[int(v)] and vfaces[int(v)].issubset(cp_rows)]
                if len(local)==1:
                    vmap[sv]=local[0]; reused.append((sv,local[0]))
                else:
                    row=len(cp)+len(points32); points32.append(sp[sv].copy()); points64.append(np.asarray(s['points_world_m'],np.float64)[sv].copy()); new_src.append(sv)
                    vmap[sv]=row; appended.append((sv,row));
                    a=int(s['output_vertex_input_parent_offsets'][sv]); b=int(s['output_vertex_input_parent_offsets'][sv+1])
                    new_v_lineage.append(np.asarray(s['output_vertex_input_parent_rows'][a:b],np.int64).copy())
            added=[]
            for fr in sorted(sp_rows):
                if fr in represented_src: continue
                tri=np.asarray([vmap[int(v)] for v in sf[fr]],np.int64)
                if len(set(map(int,tri)))!=3: raise ValueError(f'patch {pid} collapses source face {fr}')
                outfaces.append(tri); face_origin.append(-1); face_source.append(fr); face_patch.append(pid); groups.append(int(src_group[fr])); parent.append(fr); pdist.append(0.0); added.append(fr)
            new_patch_info.append({'patch_id':pid,'candidate_faces':len(cp_rows),'source_faces':len(sp_rows),'reused_retired_vertices':reused,'appended_source_vertices':appended,'inserted_source_faces':len(added)})
        p32=np.concatenate((cp,np.asarray(points32,np.float32).reshape((-1,3))),axis=0) if points32 else cp.copy()
        p64=np.concatenate((np.asarray(c['points_world_m_f64'],np.float64),np.asarray(points64,np.float64).reshape((-1,3))),axis=0) if points64 else np.asarray(c['points_world_m_f64'],np.float64).copy()
        faces=np.asarray(outfaces,np.int64); outsrc=np.concatenate((csrc,np.asarray(new_src,np.int64)))
        if not np.array_equal(p32,sp[outsrc]): raise ValueError('output points not exact D624 F32 source rows')
        arrays={k:np.array(v,copy=True) for k,v in c.items()}
        arrays.update({'points_world_m_f32':p32,'points_world_m_f64':p64,'points_world_m':p32.copy(),'faces':faces,'face_group_id':np.asarray(groups,np.int64),'face_parent_source_face_rows':np.asarray(parent,np.int64),'face_parent_centroid_distance_m':np.asarray(pdist,np.float64)})
        for k in TAGS: arrays[k]=np.asarray([int(c[k][i]) if i>=0 else int(s[k][fr]) for i,fr in zip(face_origin,face_source)],np.int64)
        arrays['face_source_identity_schema_by_original_id_json']=np.asarray(s['face_source_identity_schema_by_original_id_json'])
        arrays['vertex_parent_source_candidate_offsets']=np.arange(len(outsrc)+1,dtype=np.int64); arrays['vertex_parent_source_candidate_rows']=outsrc.copy()
        arrays['source_candidate_sha256']=np.asarray([sha(S)])
        arrays['source_edge_rescue_output_face_origin_D023_row']=np.asarray(face_origin,np.int64)
        arrays['source_edge_rescue_output_face_D624_row']=np.asarray(face_source,np.int64)
        arrays['source_edge_rescue_output_face_patch_id']=np.asarray(face_patch,np.int64)
        added_out=np.flatnonzero(np.asarray(face_source)>=0); added_src=np.asarray(face_source,np.int64)[added_out]
        arrays['source_edge_rescue_added_face_output_rows']=added_out.astype(np.int64); arrays['source_edge_rescue_added_face_D624_rows']=added_src.copy()
        co=np.asarray(s['candidate_face_ancestry_offsets'],np.int64); cr=np.asarray(s['candidate_face_ancestry_rows'],np.int64)
        uo=np.asarray(s['union_face_ancestry_offsets'],np.int64); ur=np.asarray(s['union_face_ancestry_rows'],np.int64)
        uids=np.asarray(s['union_face_ancestry_run_original_ids'],np.int64); ufids=np.asarray(s['union_face_ancestry_face_ids'],np.int64)
        aco=[0]; acr=[]; auo=[0]; aur=[]; auids=[]; aufids=[]
        for fr in added_src:
            acr.extend(map(int,cr[co[fr]:co[fr+1]])); aco.append(len(acr))
            aur.extend(map(int,ur[uo[fr]:uo[fr+1]])); auids.extend(map(int,uids[uo[fr]:uo[fr+1]])); aufids.extend(map(int,ufids[uo[fr]:uo[fr+1]])); auo.append(len(aur))
        arrays['source_edge_rescue_added_face_candidate_ancestry_offsets']=np.asarray(aco,np.int64); arrays['source_edge_rescue_added_face_candidate_ancestry_rows']=np.asarray(acr,np.int64)
        arrays['source_edge_rescue_added_face_union_ancestry_offsets']=np.asarray(auo,np.int64); arrays['source_edge_rescue_added_face_union_ancestry_rows']=np.asarray(aur,np.int64)
        arrays['source_edge_rescue_added_face_union_ancestry_run_original_ids']=np.asarray(auids,np.int64); arrays['source_edge_rescue_added_face_union_ancestry_face_ids']=np.asarray(aufids,np.int64)
        arrays['source_edge_rescue_added_vertex_output_rows']=np.arange(len(cp),len(p32),dtype=np.int64); arrays['source_edge_rescue_added_vertex_D624_rows']=np.asarray(new_src,np.int64)
        vo=[0]; vr=[]
        for parent_rows in new_v_lineage: vr.extend(map(int,parent_rows)); vo.append(len(vr))
        arrays['source_edge_rescue_added_vertex_input_parent_offsets']=np.asarray(vo,np.int64); arrays['source_edge_rescue_added_vertex_input_parent_rows']=np.asarray(vr,np.int64)
        arrays['source_edge_rescue_contract_json']=np.asarray([json.dumps({'schema':'numi.D023.source-safe-edge-patch-splice.v1','source_D624_sha256':sha(S),'candidate_D023_sha256':sha(C),'patch_plan_sha256':sha(PLAN),'all_added_faces_exact_D624':True,'all_added_vertices_exact_D624_F32':True,'existing_coordinates_moved':False,'coordinate_welding':False,'D010_operational_14_incorporated':False,'unresolved_seed_components':[36,47]},sort_keys=True)])
        candidate=OUT/'candidate-D023-source-safe-patched.npz'; np.savez_compressed(candidate,**arrays)
        oldbd=boundary(range(len(cf)),ce); newbd=boundary(range(len(faces)),edges(faces))
        oldsource=Counter((int(csrc[u]),int(csrc[v])) for _,u,v in oldbd); newsource=Counter((int(outsrc[u]),int(outsrc[v])) for _,u,v in newbd)
        st=structure(p32,faces)
        report.update({'candidate_path':str(candidate),'candidate_sha256':sha(candidate),'candidate_written':True,'patch_count':54,'replaced_candidate_face_count':len(remove),'selected_source_face_count':len(source_rows),'retained_exact_source_faces':len(represented_src),'added_exact_source_faces':len(added_src),'added_exact_source_vertices':len(new_src),'output_points':len(p32),'output_faces':len(faces),'patch_boundary_checks':checks,'patch_vertex_actions':new_patch_info,'existing_point_coordinates_bitwise_unchanged':bool(np.array_equal(p32[:len(cp)].view(np.uint32),cp.view(np.uint32))),'all_output_points_exact_D624_source_rows':True,'structure':st,'input_outer_boundary':{'edges':len(oldbd),'output_edges':len(newbd),'same_directed_source_edge_multiset':oldsource==newsource}})
        (OUT/'progress.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        if st['zero_area_f32_rows'] or st['duplicate_face_count'] or st['boundary_edges']!=45 or st['nonmanifold_edge_count'] or st['same_direction_edge_count'] or st['vertex_link_failure_count'] or oldsource!=newsource:
            report['status']='FAIL_STRUCTURAL_GATE'; (OUT/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n'); return 2
        spec=importlib.util.spec_from_file_location('d023_audit_helpers',HELPER); helper=importlib.util.module_from_spec(spec); sys.modules[spec.name]=helper; spec.loader.exec_module(helper)
        owner=helper.load_owner()
        if sha(owner.__file__)!=PINS[OWNER]: raise ValueError('canonical exact owner changed')
        grouped=defaultdict(list)
        for vr,sr0 in enumerate(outsrc): grouped[int(sr0)].append(vr)
        seams=[v for v in grouped.values() if len(v)>1]
        records,_=owner.float32_surface_records(p32.astype(np.float64),faces,source_seam_groups=seams)
        idx=owner._prepare_surface_aabb(records)
        pairs=[(a,b) for a,b in owner._query_surface_aabb(records,idx) if int(a[3])<int(b[3])]
        res=owner._audit_record_pairs(pairs,same_surface=True)
        witness=np.asarray(res.get('triangle_pairs',[]),np.int64).reshape(-1,2)
        wp=OUT/'D-self-pairs-source-seam-aware.npz'; np.savez_compressed(wp,triangle_pairs=witness)
        report['exact_self']={'status':'PASS' if int(res.get('count',-1))==0 else 'FAIL','count':int(res.get('count',-1)),'aabb_candidate_pairs':int(res.get('aabb_candidate_pairs',len(pairs))),'allowed_shared_vertex_or_edge_pairs':int(res.get('allowed_shared_vertex_or_edge_pairs',0)),'face_count':len(records),'source_seam_group_count':len(seams),'witness_path':str(wp),'witness_sha256':sha(wp)}
        report['status']='PASS_D_SELF_ONLY_54_PATCHES' if report['exact_self']['count']==0 else 'FAIL_D_SELF_AFTER_54_PATCHES'
        report['limitations']=['54 source-edge-closed patches only; two true residual components (IDs 36 and 47) unchanged.','D010 operational 14-target geometry not incorporated.','No D-I, all185, TetGen, mass, native-import, or runtime admission claimed.']
        report['elapsed_s']=time.monotonic()-started; (OUT/'report.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'status':report['status'],'candidate_sha256':report['candidate_sha256'],'output_points':len(p32),'output_faces':len(faces),'replaced':len(remove),'added_source_faces':len(added_src),'exact_self':report['exact_self']['count'],'report_sha256':sha(OUT/'report.json')},sort_keys=True),flush=True)
        return 0 if report['exact_self']['count']==0 else 2
    except Exception as e:
        report.update({'status':'ERROR','error_type':type(e).__name__,'error':str(e),'traceback':traceback.format_exc(),'elapsed_s':time.monotonic()-started})
        (OUT/'failure.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
        print(json.dumps({'status':'ERROR','error':str(e),'failure_path':str(OUT/'failure.json')}),flush=True); return 2

if __name__=='__main__': raise SystemExit(main())
