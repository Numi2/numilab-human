from __future__ import annotations
import hashlib,importlib.util,json,sys,time,traceback
from collections import Counter,defaultdict
from pathlib import Path
import numpy as np
P=Path("/Users/numi/Work/numi-human-connected-surface-069/D/connected-obstacle-207/physical-transfer-209")
ROOT=P/"reduced-physical-boundary-400/attempt-046-fine-role-simplification"
C=ROOT/"run-066-D023-source-safe-splice-001/source-two-two-flip-002/candidate-D023-source-safe-flipped.npz"
S=P/"geometry-worker/matched-nesting-390/run-044-native-f32-replay-185/cube2um-union/conditioning-run-007-source-retype/pair-geometry-014-linked-remesh/fine-I-bone-barrier-run-024/full-native-self-028/current-collar-plan-032/engine-20-ops-one-sided624-run-006/candidate-f32-linked-remesh-typed.npz"
PLAN=ROOT/"run-069-bone60-source-edge-plan-003/plan.json"
W=ROOT/"run-066-D023-source-safe-splice-001/full-cross-gates-003/all185-pairs.npz"
O=P/"reduced-physical-boundary-400/attempt-046-fine-role-simplification/run-081-OI-local-topology-repair/candidate-O-self-and-OI-repaired.npz"
I=P/"geometry-worker/fixed-physical-O-local-nested-001/pilot-004-union/dnew-vs-i296-inventory-001/i328-cavity-audit-001/fill-003/I-f32-conditioning-367/condition-288-pair-connected-remesh-001-run-002/result/candidate-f32-typed.npz"
B=P/"geometry-worker/matched-nesting-390/run-044-native-f32-replay-185/all185-source-order-native-f32-replay.npz"
SP=Path("/private/tmp/repair_D023_source_safe_patch_066.py")
HC=ROOT/"run_joint_exact_audit_003.py"
OWNER=P/"deep-boundary-checkpoint-349/payload/exact-owner/numilab_human/cardiac_cavity_intersections.py"
LINK=Path("/private/tmp/d023_vertex_link_checker_067.py")
OUT=ROOT/"run-071-bone60-source-patch-apply-001"
CAND_OUT=OUT/"candidate-D023-bone60-source-patched.npz"
PINS={
 C:"d71ef0eff2f01836d4d9fd2efc9ef1a22c05ccbf1129e992d08d4780d5b6cdbc",
 S:"c17794a1012f76924dcd9e4e754bb026c774deb5a3d37e2f1c79635ccfe9dc83",
 PLAN:"73808d6e06ae742228dc57e9bde625476a720e7ae6b9d793e2140bcb9b7be471",
 W:"4d092f0412559d736e32ffb4504910332d9f0c7bdbcfb0b9dbf82c4004374a95",
 O:"c9074b9f54bfad16193cfd14dc52fbdcda0fcca86f01a34f9552529fc6bb6b72",
 I:"5d46ee99df2613e9f30a43075af95a6402beffe26392cd9f017d8c1a154bf410",
 B:"e9f0fffefa68f274e8d1c0a565d3d6cab1cfba31d13e085b8fdc79ca362185e5",
 HC:"b202f43adf921cea0faeb30f32d921f0979516ca2e5655d9da51c72856906d0a",
 SP:"4b9e136d3599301c92eaca2eb2919c5d807e4c48c7e43c52e3663600f31571e7",
 OWNER:"f0c1d81bffb185565b174f293b67da01926db1dfa6f6b80cb5629828ccf08b6d",
 LINK:"1ae9dc846f485539854615d9c3097e429f56217281d74f9e35aa5d3308d111fe"
}
TAGS=("face_source_layer","face_source_body","face_source_bone","face_source_face_id","face_source_original_id","face_source_identity0","face_source_identity1")
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def load(p):
 with np.load(p,allow_pickle=False) as z:return {k:np.array(z[k],copy=True) for k in z.files}
def atomic(p,obj):
 p=Path(p);tmp=p.with_suffix(p.suffix+".tmp");tmp.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n");tmp.replace(p)
def import_module(name,path):
 spec=importlib.util.spec_from_file_location(name,path)
 if spec is None or spec.loader is None:raise RuntimeError("cannot import "+str(path))
 mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
def points_faces(data,label,pointkeys,facekeys):
 pk=next((k for k in pointkeys if k in data),None);fk=next((k for k in facekeys if k in data),None)
 if pk is None or fk is None:raise ValueError(label+" missing surface point/face keys")
 p=np.asarray(data[pk],np.float32).astype(np.float64);f=np.asarray(data[fk],np.int64)
 if p.ndim!=2 or p.shape[1]!=3 or f.ndim!=2 or f.shape[1]!=3 or not len(f):raise ValueError(label+" invalid surface shape")
 if not np.isfinite(p).all() or np.any(f<0) or np.any(f>=len(p)):raise ValueError(label+" nonfinite or out-of-range surface")
 return p,f,pk,fk
def append_csr(old_offsets,old_values,keep,extra_rows):
 out=[0];vals=[]
 for old in keep:
  a=int(old_offsets[old]);b=int(old_offsets[old+1]);vals.extend(map(int,old_values[a:b]));out.append(len(vals))
 for row in extra_rows:
  vals.extend(map(int,row));out.append(len(vals))
 return np.asarray(out,np.int64),np.asarray(vals,np.int64)
def main():
 if OUT.exists():raise FileExistsError(OUT)
 for p,h in PINS.items():
  got=sha(p)
  if got!=h:raise ValueError("pinned input changed: "+str(p)+" "+got)
 OUT.mkdir(parents=True)
 started=time.monotonic()
 report={"schema":"numi.D023.bone60-source-face-patch.v1","status":"RUNNING","physical_admission":False,"runtime":0,"accepted_steps":0,"input_sha256":{str(p):sha(p) for p in PINS},"stages":[]}
 atomic(OUT/"progress.json",report)
 try:
  c=load(C);s=load(S);plan=json.loads(PLAN.read_text());w=load(W)
  cfaces=np.asarray(c["faces"],np.int64);sfaces=np.asarray(s["faces"],np.int64)
  cp=np.asarray(c["points_world_m_f32"],np.float32);sp=np.asarray(s["points_world_m"],np.float32)
  csrc=np.asarray(c["vertex_parent_source_candidate_rows"],np.int64)
  if len(csrc)!=len(cp) or not np.array_equal(cp,sp[csrc]):raise ValueError("candidate points are not exact D624 mapped F32")
  patch_rows=np.asarray(plan["candidate_patch_face_rows"],np.int64);source_rows=np.asarray(plan["source_fill_face_rows"],np.int64)
  if plan["candidate_sha256"]!=PINS[C] or plan["source_D624_sha256"]!=PINS[S]:raise ValueError("plan source pins mismatch")
  if plan["all185_witness_sha256"]!=PINS[W] or set(map(int,plan["seed_candidate_face_rows"]))!={72871,72873,72874,72875}:raise ValueError("plan witness seed mismatch")
  if len(set(map(int,patch_rows)))!=len(patch_rows) or len(set(map(int,source_rows)))!=len(source_rows):raise ValueError("duplicate face row in plan")
  if not np.array_equal(np.unique(np.asarray(w["D_output_face_row"],np.int64)),np.asarray([72871,72873,72874,72875],np.int64)):raise ValueError("all185 witness face rows changed")
  if not np.all(np.asarray(w["native_bone_bank_index"],np.int64)==60):raise ValueError("witness not confined to bank 60")
  splicer=import_module("established_d023_splicer",SP)
  helper=import_module("d023_exact_audit_helpers",HC)
  linkmod=import_module("d023_link_checker",LINK)
  owner=helper.load_owner()
  if sha(owner.__file__)!=PINS[OWNER]:raise ValueError("exact owner hash mismatch")
  ce=splicer.edges(cfaces);se=splicer.edges(sfaces)
  cb=splicer.boundary(patch_rows,ce);sb=splicer.boundary(source_rows,se)
  mapped=Counter((int(csrc[u]),int(csrc[v])) for _,u,v in cb)
  srcboundary=Counter((int(u),int(v)) for _,u,v in sb)
  if mapped!=srcboundary:raise ValueError("patch boundary differs from established 066 directed-boundary owner")
  report["stages"].append({"name":"source_edge_patch_preflight","status":"PASS","candidate_patch_faces":len(patch_rows),"D624_source_faces":len(source_rows),"directed_boundary_edges":sum(mapped.values()),"exact_directed_boundary_match":True,"source_fill_tags":plan["source_fill_typed_category_counts"]})
  # Keep the local replacement inside the exact typed source category.
  seed_tags=[int(c[k][int(plan["seed_candidate_face_rows"][0])]) for k in ("face_source_layer","face_source_body","face_source_bone","face_source_original_id")]
  source_tags=[[int(s[k][r]) for k in ("face_source_layer","face_source_body","face_source_bone","face_source_original_id")] for r in source_rows]
  if any(t!=seed_tags for t in source_tags):raise ValueError("source patch crosses the seed face typed category")
  # Localize each boundary source vertex to its exact current output vertex.
  vmap={}
  for _,u,v in cb:
   for vr in (int(u),int(v)):
    sv=int(csrc[vr])
    if sv in vmap and vmap[sv]!=vr:raise ValueError("patch boundary source vertex has ambiguous current row")
    vmap[sv]=vr
  removed=set(map(int,patch_rows));keep=np.asarray([r for r in range(len(cfaces)) if r not in removed],np.int64)
  old_to_new={int(r):i for i,r in enumerate(keep)}
  vfaces=defaultdict(set)
  for fi,tri in enumerate(cfaces):
   for v in tri:vfaces[int(v)].add(int(fi))
  source_tris=sfaces[source_rows]
  internal=sorted(set(map(int,source_tris.reshape(-1)))-set(vmap))
  appended_source_vertices=[];new_point_parent_rows=[]
  for sv in internal:
   reps=np.flatnonzero(csrc==sv)
   local=[int(v) for v in reps if vfaces[int(v)] and vfaces[int(v)].issubset(removed)]
   if len(local)==1:vmap[sv]=local[0]
   else:
    vmap[sv]=len(cp)+len(appended_source_vertices);appended_source_vertices.append(sv)
    a=int(s["output_vertex_input_parent_offsets"][sv]);b=int(s["output_vertex_input_parent_offsets"][sv+1])
    new_point_parent_rows.append(np.asarray(s["output_vertex_input_parent_rows"][a:b],np.int64))
  if any(len(set(map(int,vmap.keys())))!=len(vmap) for _ in [0]):raise ValueError("duplicate source row in patch vertex map")
  outfaces=[cfaces[r].copy() for r in keep]
  face_origin=np.asarray(c["source_edge_rescue_output_face_origin_D023_row"],np.int64)[keep].tolist()
  face_source=np.asarray(c["source_edge_rescue_output_face_D624_row"],np.int64)[keep].tolist()
  face_patch=np.asarray(c["source_edge_rescue_output_face_patch_id"],np.int64)[keep].tolist()
  new_patch_id=int(np.max(np.asarray(face_patch,np.int64),initial=-1))+1
  groups=np.asarray(c["face_group_id"],np.int64)[keep].tolist()
  parent=np.asarray(c["face_parent_source_face_rows"],np.int64)[keep].tolist()
  pdist=np.asarray(c["face_parent_centroid_distance_m"],np.float64)[keep].tolist()
  tag_arrays={k:np.asarray(c[k],np.int64)[keep].tolist() for k in TAGS}
  # Reuse already represented exact source faces where possible; otherwise append typed source faces.
  keep_by_source=defaultdict(list)
  for oi in keep:
   tri=tuple(sorted(map(int,csrc[cfaces[oi]])))
   keep_by_source[tri].append(int(oi))
  src_ancestry=np.asarray(s["candidate_face_ancestry_rows"],np.int64);src_anc_off=np.asarray(s["candidate_face_ancestry_offsets"],np.int64)
  src_union=np.asarray(s["union_face_ancestry_rows"],np.int64);src_union_off=np.asarray(s["union_face_ancestry_offsets"],np.int64)
  src_run=np.asarray(s["union_face_ancestry_run_original_ids"],np.int64);src_fid=np.asarray(s["union_face_ancestry_face_ids"],np.int64)
  categories=json.loads(str(c["source_group_keys_json"][0]))
  cat={tuple(int(x[k]) for k in ("face_source_layer","face_source_body","face_source_bone","face_source_original_id")):i for i,x in enumerate(categories)}
  if len(cat)!=len(categories):raise ValueError("typed source group key collision")
  new_source_rows=[];represented=[]
  for fr in map(int,source_rows):
   st=tuple(map(int,sfaces[fr]));key=tuple(sorted(st));matches=keep_by_source.get(key,[])
   if len(matches)>1:raise ValueError("source patch face is multiply represented outside removed patch")
   if matches:
    new_index=old_to_new[matches[0]]
    oldtri=tuple(map(int,csrc[cfaces[matches[0]]]))
    # require cyclic orientation equality under source point map
    cyc=lambda t:min(tuple(t),tuple(t[1:]+t[:1]),tuple(t[2:]+t[:2]))
    if cyc(oldtri)!=cyc(st):raise ValueError("retained exact source face has reversed winding")
    for k in TAGS:
     if int(c[k][matches[0]])!=int(s[k][fr]):raise ValueError("retained exact face typed tags differ")
    face_source[new_index]=fr
    represented.append(fr)
    continue
   tri=np.asarray([vmap[int(v)] for v in sfaces[fr]],np.int64)
   if len(set(map(int,tri)))!=3:raise ValueError("source patch face collapsed under exact point mapping")
   outfaces.append(tri);face_origin.append(-1);face_source.append(fr);face_patch.append(new_patch_id)
   typed=tuple(int(s[k][fr]) for k in ("face_source_layer","face_source_body","face_source_bone","face_source_original_id"))
   if typed not in cat:raise ValueError("source patch typed category absent from retained source group map")
   groups.append(cat[typed]);parent.append(fr);pdist.append(0.0)
   for k in TAGS:tag_arrays[k].append(int(s[k][fr]))
   new_source_rows.append(fr)
  outfaces=np.asarray(outfaces,np.int64)
  outsrc=np.concatenate((csrc,np.asarray(appended_source_vertices,np.int64)))
  p32=np.concatenate((cp,np.asarray([sp[r] for r in appended_source_vertices],np.float32).reshape((-1,3))),axis=0) if appended_source_vertices else cp.copy()
  p64=np.concatenate((np.asarray(c["points_world_m_f64"],np.float64),np.asarray([s["points_world_m"][r] for r in appended_source_vertices],np.float64).reshape((-1,3))),axis=0) if appended_source_vertices else np.asarray(c["points_world_m_f64"],np.float64).copy()
  if not np.array_equal(p32,sp[outsrc]):raise ValueError("patched vertices are not exact D624 F32 rows")
  # Structural checks use the corrected used-vertex link checker.
  tris=p32[outfaces].astype(np.float64);cross=np.cross(tris[:,1]-tris[:,0],tris[:,2]-tris[:,0])
  zero=np.flatnonzero(np.all(cross==0,axis=1))
  sorted_faces=np.sort(outfaces,axis=1);duplicate_count=len(outfaces)-len(np.unique(sorted_faces,axis=0))
  out_edges=splicer.edges(outfaces);boundary_edges=[];nonmanifold=[];same_direction=[]
  for key,uses in out_edges.items():
   if len(uses)==1:boundary_edges.append((uses[0][1],uses[0][2]))
   elif len(uses)>2:nonmanifold.append((key,len(uses)))
   elif (uses[0][1],uses[0][2])==(uses[1][1],uses[1][2]):same_direction.append(key)
  links=linkmod.audit_vertex_links(outfaces)
  input_boundary=splicer.boundary(range(len(cfaces)),ce);output_boundary=splicer.boundary(range(len(outfaces)),out_edges)
  oldbd=Counter((int(csrc[u]),int(csrc[v])) for _,u,v in input_boundary)
  newbd=Counter((int(outsrc[u]),int(outsrc[v])) for _,u,v in output_boundary)
  structure={"f32_zero_area_faces":zero.astype(int).tolist(),"duplicate_face_count":duplicate_count,"boundary_edge_count":len(boundary_edges),"nonmanifold_edge_count":len(nonmanifold),"same_direction_edge_count":len(same_direction),"corrected_invalid_vertex_link_count":links["invalid_link_vertex_count"],"vertex_link_check":links,"directed_source_boundary_unchanged":oldbd==newbd}
  report["structural"]={"status":"PASS" if not len(zero) and duplicate_count==0 and len(boundary_edges)==45 and not nonmanifold and not same_direction and links["invalid_link_vertex_count"]==0 and oldbd==newbd else "FAIL","input_points":len(cp),"output_points":len(p32),"input_faces":len(cfaces),"output_faces":len(outfaces),"replaced_faces":len(removed),"added_D624_faces":len(new_source_rows),"added_D624_vertices":len(appended_source_vertices),"source_face_rows":new_source_rows,"represented_source_rows":represented,"structure":structure}
  if report["structural"]["status"]!="PASS":
   report.update(status="FAIL_STRUCTURAL",elapsed_s=time.monotonic()-started);atomic(OUT/"report.json",report);return 2
  # Compose output metadata without changing old coordinates or prior lineage.
  arrays={k:np.array(v,copy=True) for k,v in c.items()}
  arrays.update({"points_world_m_f32":p32,"points_world_m_f64":p64,"points_world_m":p32.copy(),"faces":outfaces,"face_group_id":np.asarray(groups,np.int64),"face_parent_source_face_rows":np.asarray(parent,np.int64),"face_parent_centroid_distance_m":np.asarray(pdist,np.float64)})
  for k in TAGS:arrays[k]=np.asarray(tag_arrays[k],np.int64)
  arrays["vertex_parent_source_candidate_offsets"]=np.arange(len(outsrc)+1,dtype=np.int64)
  arrays["vertex_parent_source_candidate_rows"]=outsrc.copy();arrays["source_candidate_sha256"]=np.asarray([sha(S)])
  arrays["source_edge_rescue_output_face_origin_D023_row"]=np.asarray(face_origin,np.int64)
  arrays["source_edge_rescue_output_face_D624_row"]=np.asarray(face_source,np.int64)
  arrays["source_edge_rescue_output_face_patch_id"]=np.asarray(face_patch,np.int64)
  added_out=np.flatnonzero(np.asarray(face_source,np.int64)>=0).astype(np.int64);added_src=np.asarray(face_source,np.int64)[added_out]
  arrays["source_edge_rescue_added_face_output_rows"]=added_out;arrays["source_edge_rescue_added_face_D624_rows"]=added_src.copy()
  aco=[0];acr=[];auo=[0];aur=[];auids=[];aufids=[]
  for fr in added_src:
   a=int(src_anc_off[int(fr)]);b=int(src_anc_off[int(fr)+1]);acr.extend(map(int,src_ancestry[a:b]));aco.append(len(acr))
   a=int(src_union_off[int(fr)]);b=int(src_union_off[int(fr)+1]);aur.extend(map(int,src_union[a:b]));auids.extend(map(int,s["union_face_ancestry_run_original_ids"][a:b]));aufids.extend(map(int,src_fid[a:b]));auo.append(len(aur))
  arrays["source_edge_rescue_added_face_candidate_ancestry_offsets"]=np.asarray(aco,np.int64);arrays["source_edge_rescue_added_face_candidate_ancestry_rows"]=np.asarray(acr,np.int64)
  arrays["source_edge_rescue_added_face_union_ancestry_offsets"]=np.asarray(auo,np.int64);arrays["source_edge_rescue_added_face_union_ancestry_rows"]=np.asarray(aur,np.int64)
  arrays["source_edge_rescue_added_face_union_ancestry_run_original_ids"]=np.asarray(auids,np.int64);arrays["source_edge_rescue_added_face_union_ancestry_face_ids"]=np.asarray(aufids,np.int64)
  oldvrows=np.asarray(c["source_edge_rescue_added_vertex_output_rows"],np.int64);oldvsrc=np.asarray(c["source_edge_rescue_added_vertex_D624_rows"],np.int64)
  arrays["source_edge_rescue_added_vertex_output_rows"]=np.concatenate((oldvrows,np.arange(len(cp),len(p32),dtype=np.int64)))
  arrays["source_edge_rescue_added_vertex_D624_rows"]=np.concatenate((oldvsrc,np.asarray(appended_source_vertices,np.int64)))
  oldvo=np.asarray(c["source_edge_rescue_added_vertex_input_parent_offsets"],np.int64);oldvr=np.asarray(c["source_edge_rescue_added_vertex_input_parent_rows"],np.int64)
  vo=[0];vr=[]
  for j in range(len(oldvrows)):
   a=int(oldvo[j]);b=int(oldvo[j+1]);vr.extend(map(int,oldvr[a:b]));vo.append(len(vr))
  for arows in new_point_parent_rows:vr.extend(map(int,arows));vo.append(len(vr))
  arrays["source_edge_rescue_added_vertex_input_parent_offsets"]=np.asarray(vo,np.int64);arrays["source_edge_rescue_added_vertex_input_parent_rows"]=np.asarray(vr,np.int64)
  # Refresh full output-face ancestry CSR, preserving old rows and adding exact D624 ancestry for new faces.
  old_flip_rows=np.asarray(c["topology_flip_output_face_rows"],np.int64)
  dcsr=append_csr(c["topology_flip_parent_D624_face_offsets"],c["topology_flip_parent_D624_face_rows"],keep,[[int(fr)] for fr in new_source_rows])
  # Rebuild source-candidate and union CSR explicitly for the newly appended source faces.
  cextra=[]
  uextra=[];uextra_run=[];uextra_fid=[]
  for fr in new_source_rows:
   a=int(src_anc_off[fr]);b=int(src_anc_off[fr+1]);cextra.append(src_ancestry[a:b])
   a=int(src_union_off[fr]);b=int(src_union_off[fr+1]);uextra.append(src_union[a:b]);uextra_run.append(np.asarray(s["union_face_ancestry_run_original_ids"][a:b],np.int64));uextra_fid.append(src_fid[a:b])
  ccsr=append_csr(c["topology_flip_parent_candidate_face_offsets"],c["topology_flip_parent_candidate_face_rows"],keep,cextra)
  ucsr=append_csr(c["topology_flip_parent_union_offsets"],c["topology_flip_parent_union_run_original_ids"],keep,uextra_run)
  # union row IDs and stable face IDs share one CSR; store the two value arrays with the same offsets.
  _,uflat=append_csr(c["topology_flip_parent_union_offsets"],c["topology_flip_parent_union_face_ids"],keep,uextra_fid)
  arrays["topology_flip_parent_D624_face_offsets"],arrays["topology_flip_parent_D624_face_rows"]=dcsr
  arrays["topology_flip_parent_candidate_face_offsets"],arrays["topology_flip_parent_candidate_face_rows"]=ccsr
  arrays["topology_flip_parent_union_offsets"],arrays["topology_flip_parent_union_run_original_ids"]=ucsr
  arrays["topology_flip_parent_union_face_ids"]=uflat
  if len(old_flip_rows):
   if any(int(r) not in old_to_new for r in old_flip_rows):raise ValueError("new source patch removed a prior topology flip face")
   new_flip=np.asarray([old_to_new[int(r)] for r in old_flip_rows],np.int64)
   arrays["topology_flip_output_face_rows"]=new_flip
   op=json.loads(str(c["topology_flip_operation_json"][0]));op["edited_output_faces"]=new_flip.tolist()
   arrays["topology_flip_operation_json"]=np.asarray([json.dumps(op,sort_keys=True)])
  old_contract=json.loads(str(c["source_edge_rescue_contract_json"][0]))
  contract={"schema":"numi.D023.source-safe-bone-barrier-edge-patch.v1","prior_contract":old_contract,"prior_candidate_sha256":sha(C),"source_D624_sha256":sha(S),"patch_plan_sha256":sha(PLAN),"patch_candidate_face_rows":patch_rows.tolist(),"patch_source_D624_face_rows":source_rows.tolist(),"all_added_faces_exact_D624":True,"all_added_vertices_exact_D624_F32":True,"existing_point_coordinates_bitwise_unchanged":True,"coordinate_welding":False,"protected_targets_or_D010_anchors_incorporated":False,"physical_admission":False}
  arrays["source_edge_rescue_contract_json"]=np.asarray([json.dumps(contract,sort_keys=True)])
  # Check local patch against the same immutable static I/O/native-bank BVH indexes used for the full pass.
  odata=load(O);idata=load(I);bdata=load(B)
  op,of,_,_=points_faces(odata,"O081",("points_world_m_f32","points_world_m"),("faces","source_O_faces"))
  ip,inf,_,_=points_faces(idata,"I328",("points_world_m_f32","points_world_m"),("faces","source_I_faces"))
  bp,bf,_,_=points_faces(bdata,"all185",("points_world_f32",),("faces",))
  irec,_=owner.float32_surface_records(ip,inf,source_seam_groups=());orec,_=owner.float32_surface_records(op,of,source_seam_groups=());brec,_=owner.float32_surface_records(bp,bf,source_seam_groups=())
  if len(irec)!=len(inf) or len(orec)!=len(of) or len(brec)!=len(bf):raise ValueError("static barrier record construction dropped faces")
  iidx=owner._prepare_surface_aabb(irec);oidx=owner._prepare_surface_aabb(orec);bidx=owner._prepare_surface_aabb(brec)
  proposed_faces=np.asarray([np.asarray([vmap[int(v)] for v in sfaces[int(fr)]],np.int64) for fr in new_source_rows],np.int64)
  precords,_=owner.float32_surface_records(p32.astype(np.float64),proposed_faces,source_seam_groups=())
  local_barriers={}
  for name,idx in (("I328",iidx),("O081",oidx),("all185",bidx)):
   pairs=list(owner._query_surface_aabb(precords,idx));res=owner._audit_record_pairs(pairs,same_surface=False)
   local_barriers[name]={"status":"PASS" if int(res.get("count",-1))==0 else "FAIL","exact_pairs":int(res.get("count",-1)),"aabb_candidate_pairs":int(res.get("aabb_candidate_pairs",len(pairs)))}
   if len(pairs):
    local_barriers[name]["witnesses"]=[list(map(int,x)) for x in np.asarray(res.get("triangle_pairs",[]),np.int64).reshape(-1,2)[:100]]
  report["stages"].append({"name":"local_four_face_patch_vs_static_I_O_native185","status":"PASS" if all(x["status"]=="PASS" for x in local_barriers.values()) else "FAIL","barriers":local_barriers,"static_native185_faces":len(brec),"native_bank_count":185})
  if any(x["status"]!="PASS" for x in local_barriers.values()):
   report.update(status="FAIL_LOCAL_BARRIER",elapsed_s=time.monotonic()-started);atomic(OUT/"report.json",report);return 2
  # Persist candidate, then reopen and verify hashes/shape before complete global exact checks.
  np.savez_compressed(CAND_OUT,**arrays)
  out_sha=sha(CAND_OUT)
  reread=load(CAND_OUT)
  if sha(CAND_OUT)!=out_sha or not np.array_equal(reread["points_world_m_f32"],p32) or not np.array_equal(reread["faces"],outfaces):raise ValueError("candidate readback mismatch")
  report["candidate"]={"path":str(CAND_OUT),"sha256":out_sha,"points":len(p32),"faces":len(outfaces),"reopened_exact_arrays":True,"modified_point_coordinates":False,"removed_faces":len(removed),"added_source_faces":new_source_rows,"new_source_vertices":appended_source_vertices}
  atomic(OUT/"progress.json",report)
  # Full D self uses the authenticated D624 source-row seam groups; no point or face exemption beyond those groups.
  dsrc=np.asarray(reread["vertex_parent_source_candidate_rows"],np.int64)
  seam_map=defaultdict(list)
  for vr,sr in enumerate(dsrc):seam_map[int(sr)].append(vr)
  seams=[v for v in seam_map.values() if len(v)>1]
  dpoints=np.asarray(reread["points_world_m_f32"],np.float32).astype(np.float64);dfaces=np.asarray(reread["faces"],np.int64)
  drec,_=owner.float32_surface_records(dpoints,dfaces,source_seam_groups=seams)
  if len(drec)!=len(dfaces):raise ValueError("full D exact records dropped faces")
  didx=owner._prepare_surface_aabb(drec)
  dpairs=[(a,b) for a,b in owner._query_surface_aabb(drec,didx) if int(a[3])<int(b[3])]
  dres=owner._audit_record_pairs(dpairs,same_surface=True)
  dw=np.asarray(dres.get("triangle_pairs",[]),np.int64).reshape(-1,2);np.savez_compressed(OUT/"D-self-pairs.npz",triangle_pairs=dw)
  self_stage={"name":"D_self","status":"PASS" if int(dres.get("count",-1))==0 else "FAIL","exact_pairs":int(dres.get("count",-1)),"aabb_candidate_pairs":int(dres.get("aabb_candidate_pairs",len(dpairs))),"source_seam_group_count":len(seams),"witness_path":str(OUT/"D-self-pairs.npz"),"witness_sha256":sha(OUT/"D-self-pairs.npz")}
  report["stages"].append(self_stage);atomic(OUT/"progress.json",report)
  # Query complete candidate records against each already-prepared structure index; keep the all185 bank tree fixed.
  for name,idx in (("D_vs_I328",iidx),("D_vs_O081",oidx),("D_vs_all185",bidx)):
   pairs=list(owner._query_surface_aabb(drec,idx));res=owner._audit_record_pairs(pairs,same_surface=False)
   ww=np.asarray(res.get("triangle_pairs",[]),np.int64).reshape(-1,2);wpath=OUT/(name+"-pairs.npz");np.savez_compressed(wpath,triangle_pairs=ww)
   stage={"name":name,"status":"PASS" if int(res.get("count",-1))==0 else "FAIL","exact_pairs":int(res.get("count",-1)),"aabb_candidate_pairs":int(res.get("aabb_candidate_pairs",len(pairs))),"witness_path":str(wpath),"witness_sha256":sha(wpath)}
   if name=="D_vs_all185":
    bank_offsets=np.asarray(bdata["bank_face_offsets"],np.int64);body=np.asarray(bdata["bank_body"],np.int64);bone=np.asarray(bdata["bank_bone"],np.int64)
    bankids=np.searchsorted(bank_offsets[1:],ww[:,1],side="right") if len(ww) else np.empty((0,),np.int64)
    stage["banks_with_pairs"]=[]
    for bi in np.unique(bankids):
     stage["banks_with_pairs"].append({"bank_index":int(bi),"body":int(body[bi]),"bone":int(bone[bi]),"pair_count":int(np.sum(bankids==bi))})
    stage["banks_checked"]=185
   report["stages"].append(stage);atomic(OUT/"progress.json",report)
  passed=all(x["status"]=="PASS" for x in report["stages"])
  report.update(status="PASS_D_SELF_I_O_ALL185" if passed else "FAIL_EXACT_BARRIERS",elapsed_s=time.monotonic()-started,physical_admission=False,runtime=0,accepted_steps=0,limitations=["Source-local D surface topology repair only; not D010 anchor incorporation, TetGen, source330 mass transfer, native admission, or runtime qualification."])
  atomic(OUT/"report.json",report)
  print(json.dumps({"status":report["status"],"candidate_sha256":out_sha,"stages":[{"name":x["name"],"status":x["status"],"exact_pairs":x.get("exact_pairs")} for x in report["stages"]],"report_sha256":sha(OUT/"report.json")},sort_keys=True),flush=True)
  return 0 if passed else 2
 except Exception as e:
  report.update(status="ERROR",error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc(),elapsed_s=time.monotonic()-started,physical_admission=False,runtime=0,accepted_steps=0)
  atomic(OUT/"failure.json",report);print(json.dumps({"status":"ERROR","error":str(e),"failure_path":str(OUT/"failure.json")},sort_keys=True),flush=True);return 2
if __name__=="__main__":raise SystemExit(main())

