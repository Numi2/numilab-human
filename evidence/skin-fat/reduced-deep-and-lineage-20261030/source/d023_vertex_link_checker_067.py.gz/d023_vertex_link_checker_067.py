from __future__ import annotations
from collections import Counter, defaultdict, deque
import numpy as np

def audit_vertex_links(faces):
    """Count link failures on used vertices only; storage-only rows are ignored."""
    f=np.asarray(faces,dtype=np.int64)
    if f.ndim!=2 or f.shape[1]!=3 or np.any(f<0):
        raise ValueError('faces must be an Nx3 array of nonnegative vertex rows')
    incident=defaultdict(list)
    edge_uses=Counter()
    for tri in f:
        a,b,c=map(int,tri)
        incident[a].append((b,c));incident[b].append((c,a));incident[c].append((a,b))
        edge_uses[tuple(sorted((a,b)))]+=1
        edge_uses[tuple(sorted((b,c)))]+=1
        edge_uses[tuple(sorted((c,a)))]+=1
    boundary={v for e,n in edge_uses.items() if n==1 for v in e}
    failures=[]
    for v,triangles in sorted(incident.items()):
        link=defaultdict(list)
        for a,b in triangles:
            link[a].append(b);link[b].append(a)
        unseen=set(link);components=0
        while unseen:
            components+=1;start=min(unseen);unseen.remove(start);todo=[start]
            while todo:
                q=todo.pop()
                for n in link[q]:
                    if n in unseen:unseen.remove(n);todo.append(n)
        degree_counts=Counter(len(ns) for ns in link.values())
        degree_invalid=sum(n for d,n in degree_counts.items() if d not in (1,2))
        endpoints=degree_counts.get(1,0)
        expected_endpoints=2 if v in boundary else 0
        reasons=[]
        if components!=1:reasons.append('disconnected_link')
        if degree_invalid:reasons.append('link_degree_not_1_or_2')
        if endpoints!=expected_endpoints:reasons.append('boundary_endpoint_count')
        if reasons:
            failures.append({'vertex_row':int(v),'link_components':components,
                'link_node_count':len(link),'link_degree_histogram':dict(sorted(degree_counts.items())),
                'boundary_vertex':v in boundary,'reason_codes':reasons})
    return {'used_vertex_count':len(incident),'boundary_vertex_count':len(boundary),
        'invalid_link_vertex_count':len(failures),'invalid_link_vertices':failures}

def fixture_results():
    closed=np.array([[0,2,1],[0,1,3],[1,2,3],[2,0,3]],dtype=np.int64)
    openfan=np.array([[0,1,2],[0,2,3]],dtype=np.int64)
    bowtie=np.array([[0,1,2],[0,3,4]],dtype=np.int64)
    return {name:audit_vertex_links(faces) for name,faces in (
        ('closed_fan',closed),('open_boundary_fan',openfan),('disconnected_bowtie',bowtie))}
