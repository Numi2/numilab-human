#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,sys,importlib.util,time
import numpy as np

P=Path("/Users/numi/Work/numi-human-connected-surface-069/D/connected-obstacle-207/physical-transfer-209")
OUT=P/"canonical-D-boundary-binding-696/run-010-combined-operational-reference-candidate"
CAND=OUT/"candidate-D-canonical14-reference-remap.npz"
TARGETMAP=OUT/"candidate-operational-target-map.json"
I=P/"paired-head-reference-fit-684/run-014-witness-local-taper/candidate-I-f32-collapsed-ancestry.npz"
BONES=P/"geometry-worker/matched-nesting-390/run-044-native-f32-replay-185/all185-source-order-native-f32-replay.npz"
LOADER=P/"geometry-worker/fixed-physical-O-local-nested-001/pilot-004-union/D-witness-contract-001/run-042-abstract-cycle-coupled-remesh/remesh.py"
EXPECTED={
 "candidate":"7d8419bdc4ad1d3892a946c93ad7f0f9b2db2e4302f8f666480612166e25de2a",
 "targetmap":"ec76d258264df284e8d8aa15d35d5bd53a2277a457e0576005ecff87f2bb2f4b",
 "I":"7e40a870fffb6c29b34f300951d31e604d874874362ab620fd39f86d05fea36d",
 "loader":"f1d697b42fc9d97472fbd70cec2d8adfe178bb591d3513680609396ec4c204ad",
 "owner":"f0c1d81bffb185565b174f293b67da01926db1dfa6f6b80cb5629828ccf08b6d",
 "all185":"e9f0fffefa68f274e8d1c0a565d3d6cab1cfba31d13e085b8fdc79ca362185e5",
}
def sha(path):
 h=hashlib.sha256()
 with Path(path).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def verify(path,key):
 if not Path(path).is_file():raise FileNotFoundError(path)
 actual=sha(path)
 if actual!=EXPECTED[key]:raise ValueError(f"{key} SHA mismatch {actual}")
 return actual
verify(CAND,"candidate"); verify(TARGETMAP,"targetmap");verify(I,"I");verify(LOADER,"loader"); verify(BONES,"all185")
OUTG=OUT/"changed-exact-gates"
OUTG.mkdir(exist_ok=False)
sys.path.insert(0,str(LOADER.parent))
spec=importlib.util.spec_from_file_location("exact_owner_run010",LOADER)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
pred=m.load_exact_owner()
if sha(pred.__file__)!=EXPECTED["owner"]:raise ValueError("exact owner hash mismatch")
z=np.load(CAND,allow_pickle=False)
P0=np.asarray(z["points_world_m"],np.float32); F=np.asarray(z["faces"],np.int64)
proof=json.load(open(TARGETMAP)); changed=np.asarray(proof["modified_output_face_rows"],np.int64)
if len(changed)!=13 or np.any(changed<0) or np.any(changed>=len(F)):raise ValueError("changed face map mismatch")
records=pred.float32_surface_records(P0.astype(np.float64),F,source_seam_groups=())[0]
left=[records[int(r)] for r in changed]
if len(left)!=len(changed):raise ValueError("changed exact-record count mismatch")
def gate(name,right,same=False):
 ix=pred._prepare_surface_aabb(right)
 pairs=list(pred._query_surface_aabb(left,ix))
 if same:
  cset=set(map(int,changed))
  pairs=[(a,b) for a,b in pairs if int(a[3])!=int(b[3]) and
         (int(b[3]) not in cset or int(b[3])>int(a[3]))]
 res=pred._audit_record_pairs(pairs,same_surface=same)
 ppath=OUTG/(name+"-pairs.npz")
 prs=np.asarray(res.get("triangle_pairs",[]),np.int64).reshape(-1,2)
 np.savez_compressed(ppath,triangle_pairs=prs)
 report={k:v for k,v in res.items() if k!="triangle_pairs"}
 report.update({"name":name,"same_surface":same,"changed_face_rows":changed.tolist(),"pairs_path":str(ppath),
  "pairs_sha256":sha(ppath),"input_pair_count":len(pairs),"candidate_sha256":sha(CAND)})
 (OUTG/(name+".json")).write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"stage":"exact_gate","name":name,"count":report.get("count"),"aabb_candidate_pairs":report.get("aabb_candidate_pairs"),"pairs_sha256":report["pairs_sha256"]}),flush=True)
 return report
t0=time.monotonic()
allg=[]
selfg=gate("changed-D-self",records,True);allg.append(selfg)
if int(selfg.get("count",-1))!=0:
 status="FAIL_CHANGED_D_SELF"
else:
 iz=np.load(I,allow_pickle=False)
 ir=pred.float32_surface_records(np.asarray(iz["points_world_m"],np.float32).astype(np.float64),np.asarray(iz["faces"],np.int64),source_seam_groups=())[0]
 ig=gate("changed-D-vs-I014",ir,False);allg.append(ig)
 if int(ig.get("count",-1))!=0: status="FAIL_CHANGED_D_I014"
 else:
  bz=np.load(BONES,allow_pickle=False)
  br=pred.float32_surface_records(np.asarray(bz["points_world_f32"],np.float32).astype(np.float64),np.asarray(bz["faces"],np.int64),source_seam_groups=())[0]
  bg=gate("changed-D-vs-all185",br,False);allg.append(bg)
  status="PASS_CHANGED_FACES_SELF_I_ALL185" if int(bg.get("count",-1))==0 else "FAIL_CHANGED_D_ALL185"
summary={"schema":"numi.D.local-operational-reference-exact-changed-face-gates.v1","status":status,
 "candidate_path":str(CAND),"candidate_sha256":sha(CAND),"target_map_path":str(TARGETMAP),"target_map_sha256":sha(TARGETMAP),
 "I014_path":str(I),"I014_sha256":sha(I),"all185_path":str(BONES),"all185_sha256":sha(BONES),
 "exact_owner_loader_path":str(LOADER),"exact_owner_loader_sha256":sha(LOADER),"exact_owner_path":str(pred.__file__),"exact_owner_sha256":sha(pred.__file__),
 "changed_face_rows":changed.tolist(),"gates":allg,"elapsed_s":time.monotonic()-t0,
 "physical_admission":False,"tetgen":False,"runtime":0,"accepted_steps":0}
(OUTG/"summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
print(json.dumps({"stage":"done","status":status,"summary":str(OUTG/"summary.json"),"summary_sha256":sha(OUTG/"summary.json")}),flush=True)

