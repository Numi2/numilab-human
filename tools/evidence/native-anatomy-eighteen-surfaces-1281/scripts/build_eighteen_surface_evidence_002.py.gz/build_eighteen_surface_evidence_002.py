from pathlib import Path
import json,hashlib,gzip,csv
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");N=A/"eighteen-surface-native-composition-001"
repo=Path("/Users/n/numi-human-positive-winding-1279");O=A/"eighteen-surface-publication-002"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
checks=read(N/"native-verification-001/report.json");interfaces=read(N/"native-interface-verification-001/report.json");classified=read(N/"native-pronator-interface-classification-001/report.json")
assert checks["complete"] and checks["inputs_unchanged"] and checks["all_native_repaired_surface_checks_pass"] and checks["all_coupled_trace_rows_exact_baseline_prefix"]
assert interfaces["complete"] and interfaces["inputs_unchanged"] and len(interfaces["poses"])==8
for p in interfaces["poses"]:
 assert len(p["rows"])==18
 for r in p["rows"]:
  assert r["self_count"]==0 and r["external_targets_scanned"]==859
  assert r["new_triangle_pair_count"]==(4 if r["stable_id"]==128 else 0)
assert classified["complete"] and classified["inputs_unchanged"] and len(classified["poses"])==8
assert all(len(p["rows"])==1 and p["rows"][0]["intended_local_shared_insertion_classification_pass"] and p["rows"][0]["other_added_interface_pairs"]==0 for p in classified["poses"])
O.mkdir(exist_ok=False);inventory={}
def put(src,relative,compress=False):
 src=Path(src);dest=O/relative;dest.parent.mkdir(parents=True,exist_ok=True);raw=src.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
 inventory[relative]={"bytes":dest.stat().st_size,"encoding":"gzip" if compress else "identity","retained_path":str(src),"retained_sha256":hashlib.sha256(raw).hexdigest(),"sha256":sha(dest)}
for f in ["launch_arm.py","launch-guard.json","composition-result.json","source-resolution-bounds.json"]:put(N/f,"native/"+f)
for f in ["run-declaration.json","execution-start.json","execution.json"]:put(N/"baseline"/f,"native/baseline/"+f)
for f in ["invocation.json","run-metadata.json","resting-coupled.csv"]:put(N/"baseline/native-run"/f,"native/baseline/native-run/"+f)
for f in ["frame-skin.png","frame-muscles.png","frame-skeleton.png","frame-organs.png","native-viewer.mov"]:put(N/"baseline/native-run"/f,"viewer/"+f)
put(A/"eighteen-surface-movie-inspection-001.log","viewer/movie-inspection.log")
for name,src in [
 ("native-self-and-trace",N/"native-verification-001/report.json"),
 ("native-interfaces",N/"native-interface-verification-001/report.json"),
 ("native-shared-head-classification",N/"native-pronator-interface-classification-001/report.json"),
 ("heldout-shared-head-classification",A/"left-pronator-positive-late-classification-001/report.json"),
 ("early-shared-head-classification",A/"left-pronator-positive-early-classification-001/report.json"),
 ("heldout-pronator-interface-audit",A/"pronator-parent-positive-allpose-interface-audit-001/report.json"),
 ("early-pronator-interface-audit",A/"pronator-parent-positive-early-interface-audit-002/report.json")
]:put(src,"checks/"+name+".json")
put(A/"pronator-parent-positive-union-lift-001/report.json","derivation/parent-lift-report.json.gz",True)
put(A/"parent-positive-union-128-001/result.json","derivation/union-result.json")
put(A/"parent-positive-union-128-001/stable-128-exact-union.json","derivation/exact-union.json.gz",True)
put(A/"bounded-halfmm-source-resolution-001/stable-128-reference-resolution-row-patch.npz","derivation/collapsed-parent.npz")
r=next(x for x in read(A/"pronator-parent-positive-union-lift-001/report.json")["rows"] if x["stable_id"]==128)
put(Path(r["candidate_path"]),"patches/stable-128.npz")
for f in ["prepare_eighteen_surface_native_001.py","verify_eighteen_surface_native_001.py","verify_eighteen_surface_native_interfaces_001.py","verify_native_left_pronator_positive_001.py","classify_left_pronator_positive_late_001.py","classify_left_pronator_positive_early_001.py","prepare_pronator_parent_positive_union_lift_001.py"]:
 put(A/f,"scripts/"+f+".gz",True)
put(Path(__file__),"scripts/"+Path(__file__).name+".gz",True)
runtime=read(N/"baseline/native-run/run-metadata.json");trace=list(csv.DictReader((N/"baseline/native-run/resting-coupled.csv").open()))
sim=float(trace[-1][next(iter(trace[-1]))]);wall=runtime["wall_seconds"]
maxdist=max(x["maximum_distance_to_original_shared_crossing_segments_m"] for p in classified["poses"] for x in p["rows"])
summary={"anatomy_complete":False,"five_minute_final_anatomy_qualification":False,"accepted_steps":8000,"simulated_seconds":sim,"owner_wall_seconds":wall,"real_time_factor":sim/wall,"stable_ids":[35,36,55,56,57,58,105,106,107,108,115,116,124,128,147,148,149,150],"candidate_tissue_sha256":sha(N/"assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"),"device":"SSH macmini, Apple M4 Pro, 24 GB, macOS26.6","source_revisions":{"Numi2/numilab-human":"48f20699315f1039df770a4289360ef9419646d3","Numi2/numi-lab":"3a1cfffaeba4502d946cc0d4aeb8860a0075da79","Numi2/numi-brain":"a1cf7218fae5d26f9aed9d845047fc6c472ad596"},"code_revision_equivalence":{"human_positive_winding":"3493b44bf325a3106fed0d0377a15a43be748180","lab_native_build":"015ff2ebd7756247bb511319c8ef21295ba37273"},"native_left_pronator_shared_crossing_distance_upper_bound_m":maxdist,"prior_derivation_evidence":"../native-anatomy-seventeen-surfaces-1280/README.md","left_pronator_union_preparation_cwd":str(A)}
(O/"summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
previous=repo/"tools/evidence/native-anatomy-seventeen-surfaces-1280/reproduce.py"
(O/"reproduce.py").write_text(previous.read_text().replace("seventeen-surface","eighteen-surface"))
(O/"README.md").write_text("""# Eighteen repaired surfaces in the integrated native human

The left pronator teres ulnar head (128) joins the [previous seventeen repaired surfaces](../native-anatomy-seventeen-surfaces-1280/README.md). The existing resting human runs with mechanically driven breathing, cardiac pumping, circulation and gas exchange in the same native Metal runtime on the SSH Mac mini.

**Whole-body anatomy and the final five-minute qualification remain incomplete.** Performance optimization is paused. This is a tested anatomy increment.

## Reproduce

    /usr/bin/python3 tools/evidence/native-anatomy-eighteen-surfaces-1281/reproduce.py

The retained Mini runtime and asset paths are required. --prepare-only verifies every bound input and prepares a fresh run. The launch declaration retains exact command, assets, source bytes and configuration. Source revisions and measured timing are in summary.json.

## Local anatomical classification

The added surface is an explicitly reconstructed passive reference boundary: bounded source edge collapses, exact positive-winding partition and the existing parent-face attribute lift. Its original physical route, binding table and physical mass remain unchanged. The relative parent path in the original union report resolves from the preparation directory recorded in summary.json; the native preparation independently binds the absolute parent file and hash.

At eight actual native captures all eighteen repaired surfaces have zero self-intersections and pass closed oriented manifold checks. Seventeen add zero changed-region crossing pairs against all 859 surrounding structures.

Surface 128 changes exactly four source-lineage pairs against its own humeral head (126). Every added pair has an actual intersection witness within a conservative continuous 0.5 mm bound of the original shared crossing segments, restricted to the distal 10 percent of the source and dominant radius binding. These heads share the existing pronator actuator and distal insertion. The exact pair IDs, witnesses, bounds and source identities are retained; this is a local inferred shared-insertion classification, not a blanket muscle-intersection exemption or a measured clinical footprint. No additional crossing lineage occurs against other structures. Sixteen late and eight early offline poses also passed this classification before the native run.

Cadaveric descriptions supporting shared pronator insertion: [Caetano et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC5380802/) and [Olewnik et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC5797209/). The geometric 0.5 mm tolerance is an explicit engineering reference-resolution bound, not a literature-measured insertion extent.

The right pronator candidate remains excluded because it changes neighboring flexor-pollicis crossing lineage during settling. Its rejected native attempt is retained in the prior evidence bundle.

## Integrated evidence

All 1,000 rows and 60 coupled physiology/mechanics columns exactly match the unchanged baseline011 prefix. The native run accepted 8,000 steps, approximately 16 simulated seconds. The existing flat support plane and state/force owners remain unchanged.

The continuous framebuffer recording, seven-layer inspection log and four inspection frames are retained. Framebuffer evidence does not assert separate remote desktop visibility. Original BodyParts3D and MyoSim rights and the mixed-source reference status remain as recorded by the source receipts.

The scripts are losslessly gzip-compressed to preserve executed bytes. retained-files.json verifies encoded and decoded hashes.
""")
(O/"retained-files.json").write_text(json.dumps(inventory,indent=2,sort_keys=True)+"\n")
for rel,x in inventory.items():
 raw=(O/rel).read_bytes();assert hashlib.sha256(raw).hexdigest()==x["sha256"];decoded=gzip.decompress(raw) if x["encoding"]=="gzip" else raw;assert hashlib.sha256(decoded).hexdigest()==x["retained_sha256"]
print(json.dumps({"output":str(O),"retained_files":len(inventory),"summary":summary},indent=2))
