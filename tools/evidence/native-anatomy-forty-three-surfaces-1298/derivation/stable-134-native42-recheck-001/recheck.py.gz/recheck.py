#!/usr/bin/env python3
import hashlib, importlib.util, json, math, os, sys, time
from pathlib import Path
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
A=R/"anatomy-completion-1276"
RUN_DIR=A/"stable-134-native42-recheck-001"
OUT=A/"stable-134-pose-repair-001/current42-target-audit-003"
SEL_OUT=A/"stable-134-pose-repair-001/current42-selection-003"
H=A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
OLD_T=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
N42=A/"forty-two-surface-native-composition-001/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
OLD_M=OLD_T.with_suffix(".manifest.json"); N42_M=N42.with_suffix(".manifest.json")
CAND=A/"stable-134-pose-repair-001/local-reference-search-001/stable-134-unadmitted-local-reference.npz"
UNION=A/"remaining-limb-positive-union-lift-001/stable-134-reference-union-row-patch.npz"
SEARCH=A/"stable-134-pose-repair-001/local-reference-search-001/report.json"
PRIOR=A/"stable-134-pose-repair-001/target-audit-002/report.json"
NR=A/"forty-two-surface-native-composition-001/native-verification-001/report.json"
CR=A/"forty-two-surface-native-composition-001/composition-result.json"
CAP=A/"forty-two-surface-native-composition-001/baseline/native-run/accepted-geometry"
INV=Path("/Users/n/numi-human-resting-evidence-20261005/native-complete-skin-containment-audit-890/pair-summary-v3.csv")
STEPS=[0,4767,5023,5599,6207,6815,7423,8000]
CI=Path("/Users/n/numi-human-touching-loop-arrangement-1290/src/numilab_human/cardiac_cavity_intersections.py")
CG=Path("/Users/n/numi-human-touching-loop-arrangement-1290/src/numilab_human/cardiac_cavity_geometry.py")
CA=Path("/Users/n/numi-human-touching-loop-arrangement-1290/src/numilab_human/common_atlas_skin_clearance.py")
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(8*1024*1024),b""):h.update(b)
 return h.hexdigest()
def req(v,m):
 if not v:raise RuntimeError(m)
def arrsha(x):return hashlib.sha256(np.ascontiguousarray(x).tobytes()).hexdigest()
def area(p,f):
 p=np.asarray(p,dtype=np.float64);f=np.asarray(f,dtype=np.int64);c=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
 return math.fsum(.5*float(np.linalg.norm(x)) for x in c)
def volume(p,f):
 p=np.asarray(p,dtype=np.float64);f=np.asarray(f,dtype=np.int64)
 return math.fsum(map(float,np.einsum("ij,ij->i",p[f[:,0]],np.cross(p[f[:,1]],p[f[:,2]]))/6.))
def save(p,o):
 q=Path(str(p)+".tmp")
 with q.open("w") as f:json.dump(o,f,indent=2,sort_keys=True);f.write("\n");f.flush();os.fsync(f.fileno())
 q.replace(p)
req(not OUT.exists() and not SEL_OUT.exists(),"output already exists")
OUT.mkdir(parents=True); SEL_OUT.mkdir(parents=True)
sys.path.insert(0,"/Users/n/numi-human-touching-loop-arrangement-1290/src")
from numilab_human import cardiac_cavity_intersections as ci, cardiac_cavity_geometry as cg, common_atlas_skin_clearance as ca
req(sha(CI)=="90c7a7fb0ce4383397f97519dd5fe163201d86a0c97e18e3a9eb3fa9858cd561","predicate pin mismatch")
spec=importlib.util.spec_from_file_location("fw",H);h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h);h.TISS=N42;h.MAN=N42_M
old_t=h.load_tissue(OLD_T);tissue=h.load_tissue(N42);old=h.row_data(old_t,134);row=h.row_data(tissue,134)
for k in ("vertex_bytes","binding_bytes"):req(old[k]==row[k],f"old/native42 row134 {k} mismatch")
for k in ("positions","normals","local","weights","faces"):req(np.array_equal(old[k],row[k]),f"old/native42 row134 {k} mismatch")
req((old["vc"],old["bc"],old["ic"])==(row["vc"],row["bc"],row["ic"]),"old/native42 row134 counts mismatch")
z=np.load(CAND,allow_pickle=False);u=np.load(UNION,allow_pickle=False)
p=np.asarray(z["vertices6"][:,:3],dtype="<f4");local=np.asarray(z["binding_indices"],dtype="<u4");w=np.asarray(z["weights"],dtype="<f4")
f=np.asarray(z["faces"],dtype=np.int64);orig=np.asarray(z["face_origins"],dtype=np.int64)
up=np.asarray(u["vertices6"][:,:3],dtype="<f4");uf=np.asarray(u["faces"],dtype=np.int64);uo=np.asarray(u["face_origins"],dtype=np.int64)
req(p.shape==(len(local),3) and local.shape==w.shape and local.shape[1]==4,"candidate attr shape")
req(f.shape==(len(orig),3) and np.array_equal(f,uf) and np.array_equal(orig,uo),"candidate topology/ancestry differs from union")
req(np.all((orig>=0)&(orig<len(row["faces"]))),"candidate parent face index invalid")
req(np.all(local[w>0]<row["bc"]),"candidate active local binding index invalid")
req(np.isfinite(p).all() and np.isfinite(w).all() and np.all(w>=0),"candidate nonfinite/negative data")
werr=np.abs(w.astype(np.float64).sum(axis=1)-1);req(float(werr.max(initial=0))<1e-5,"candidate weight sums invalid")
def exact(pts,tris):
 pts=np.asarray(pts,dtype="<f4");tris=np.asarray(tris,dtype=np.int64);req(pts.ndim==2 and pts.shape[1]==3 and tris.ndim==2 and tris.shape[1]==3,"exact mesh shape")
 uq,inv=np.unique(pts,axis=0,return_inverse=True);qf=inv[tris]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in x)) for x in uq];deg=[]
 for i,t in enumerate(qf):
  n=ci._cross(ci._sub(lattice[int(t[1])],lattice[int(t[0])]),ci._sub(lattice[int(t[2])],lattice[int(t[0])]))
  if not any(n):deg.append(int(i))
 return (None,deg) if deg else (ci._records(lattice,qf.tolist()),[])
crec,cdeg=exact(p,f);cand_source_self=None if cdeg else int(ci._audit_pair(crec,crec,same_surface=True)["count"])
rrec,rdeg=exact(row["positions"],row["faces"]);raw_source_self=None if rdeg else int(ci._audit_pair(rrec,rrec,same_surface=True)["count"])
top=cg.analyze_topology(p.astype(float).tolist(),f.tolist());topok=bool(top.get("closed_oriented_manifold_candidate")) and not cdeg
def onehot(a):
 a=np.asarray(a,dtype="<f4");return np.flatnonzero(((a>0).sum(axis=1)==1)&(np.max(a,axis=1)==np.float32(1)))
spure=onehot(row["weights"]);cpure=onehot(w);bycoord={}
for i,x in enumerate(p):bycoord.setdefault(x.tobytes(),[]).append(i)
missing=[]
for i in spure:
 js=bycoord.get(row["positions"][i].tobytes(),[])
 if not any(np.array_equal(local[j],row["local"][i]) and np.array_equal(w[j],row["weights"][i]) for j in js):missing.append(int(i))
d=np.linalg.norm(p.astype(np.float64)-up.astype(np.float64),axis=1)
uniq,cnt=np.unique(orig,return_counts=True)
changed=(set(range(len(row["faces"])))-set(map(int,uniq)))|set(map(int,uniq[cnt!=1]))
same=np.zeros(len(orig),dtype=bool);rf=row["faces"][orig]
for s in range(3):
 cf=np.roll(f,s,axis=1)
 same|=(np.all(row["positions"][rf]==p[cf],axis=(1,2))&np.all(row["local"][rf]==local[cf],axis=(1,2))&np.all(row["weights"][rf]==w[cf],axis=(1,2)))
changed.update(map(int,orig[~same]))
before=np.asarray(sorted(changed),dtype=np.int64);after=np.flatnonzero(np.isin(orig,before))
req(len(before)>0 and len(after)>0,"empty changed parent star")
keys,*_=ca._load_target_inventory(INV);req(len(keys)==859 and (51005,134) in keys,"target inventory mismatch")
man=json.loads(N42_M.read_text());mrow=next(x for x in man["source"]["surfaces"] if int(x["stable_id"])==134)
du=np.linalg.norm(p.astype(np.float64)-up.astype(np.float64),axis=1)
report={"schema":"stable134-native42-current-predicate-selection.v1","scope":"Offline candidate selection recheck on eight actual native42 accepted captures. Candidate exact self at source and each sampled pose; changed/missing stable134 source face-star against every one of 859 external inventory targets. This is not composition, native admission, or whole-body qualification.",
 "rows":[{"stable_id":134,"candidate_path":str(CAND),"candidate_sha256":sha(CAND),"union_reference_path":str(UNION),"union_reference_sha256":sha(UNION),"search_report_path":str(SEARCH),"search_report_sha256":sha(SEARCH),"prior_24pose_report_path":str(PRIOR),"prior_24pose_report_sha256":sha(PRIOR),"member_id":mrow.get("member_id"),"member_sha256":mrow.get("member_sha256"),"label":mrow.get("label"),"candidate_face_origins_original_row_range":[int(orig.min()),int(orig.max())],"unique_parent_faces":int(len(uniq)),"original_source_face_count":int(len(row["faces"])),"changed_parent_face_count":int(len(before)),"changed_candidate_descendant_face_count":int(len(after)),
 "source_area_m2":area(row["positions"],row["faces"]),"candidate_area_m2":area(p,f),"source_signed_volume_m3":volume(row["positions"],row["faces"]),"candidate_signed_volume_m3":volume(p,f),"candidate_source_self_pair_count":cand_source_self,"candidate_source_degenerate_face_count":len(cdeg),"source_topology_closed_oriented":topok,"topology":{k:top.get(k) for k in ("closed_oriented_manifold_candidate","face_component_count","euler_characteristic","boundary_edge_count","nonmanifold_edge_count","orientation_conflict_edge_count")},"maximum_displacement_from_union_reference_m":float(du.max(initial=0)),"changed_union_reference_vertex_ids":np.flatnonzero(du>0).astype(int).tolist(),"pure_attachment_proxy_count":int(len(spure)),"candidate_pure_attachment_proxy_count":int(len(cpure)),"changed_or_missing_pure_attachment_proxies":{"source_ids":spure.astype(int).tolist(),"preserved_count":int(len(spure)-len(missing)),"changed_or_missing_source_ids":missing},
 "raw_source_exact_self_pair_count":raw_source_self,"raw_source_degenerate_face_count":len(rdeg),"old6579_native42_stable134_row_equal":{"vertex_records":True,"binding_records":True,"faces":True,"positions":True,"normals":True,"local_binding_ids":True,"weights":True,"vertex_records_sha256":arrsha(np.frombuffer(row["vertex_bytes"],dtype=np.uint8)),"binding_records_sha256":arrsha(np.frombuffer(row["binding_bytes"],dtype=np.uint8)),"local_faces_sha256":arrsha(row["faces"].astype("<i8")),"vertex_count":int(row["vc"]),"triangle_count":int(row["ic"]//3),"binding_count":int(row["bc"])},"route_bindings":mrow.get("body_bindings")}],
 "native42":{"composition_path":str(A/"forty-two-surface-native-composition-001"),"composition_report_sha256":sha(CR),"verification_report_path":str(NR),"verification_report_sha256":sha(NR),"capture_steps":STEPS,"target_inventory_path":str(INV),"target_key_count":len(keys),"external_target_keys_per_capture":859,"poses":[]},"complete":False,"source_and_sampled_pose_self_clear":False,"all859_changed_star_no_new_parent_pairs":False,"inputs_unchanged":False,"native_admitted":False}
pins={str(Path(x)):sha(x) for x in [Path(__file__),H,OLD_T,OLD_M,N42,N42_M,CAND,UNION,SEARCH,PRIOR,NR,CR,INV,CI,CG,CA]}
start=time.monotonic()
for step in STEPS:
 pack=CAP/f"step-{step}.mrvpack";receipt=CAP/f"step-{step}.receipt.json";rc=json.loads(receipt.read_text())
 req(int(rc.get("accepted_step",-1))==step and (rc.get("pack_file_sha256") or rc.get("accepted_pack_file_sha256"))==sha(pack),f"capture receipt mismatch {step}")
 pose_docs=rc.get("accepted_body_poses") or rc.get("accepted_registered_body_poses");req(len(pose_docs)==157,f"157 accepted poses absent {step}")
 poses={int(x["body_index"]):(np.asarray(x["position_m"],np.float32),np.asarray(x["quaternion_xyzw"],np.float32)) for x in pose_docs}
 world=h.forward(p,local,w,row,tissue,poses);wr,wd=exact(world,f)
 self_count=None if wd else int(ci._audit_pair(wr,wr,same_surface=True)["count"])
 pos,surf,meta=ca._pack_surfaces(pack,keys)
 req(set(keys).issubset(surf) and set(surf)-set(keys)=={(51007,1)},f"target keyset mismatch {step}")
 caprow=surf[(51005,134)];capf=np.asarray(caprow["faces"],dtype=np.int64);delta=capf-row["faces"]
 req(capf.shape==row["faces"].shape and np.all(delta==delta.flat[0]),f"stable134 capture row indexing mismatch {step}")
 actual=pos[int(delta.flat[0]):int(delta.flat[0])+int(row["vc"])]
 baseworld=h.forward(row["positions"],row["local"],row["weights"],row,tissue,poses);used=np.unique(row["faces"])
 replay=float(np.linalg.norm(baseworld[used].astype(np.float64)-actual[used].astype(np.float64),axis=1).max(initial=0))
 rec={"accepted_step":step,"pack_path":str(pack),"pack_sha256":sha(pack),"receipt_path":str(receipt),"receipt_sha256":sha(receipt),"accepted_body_pose_count":len(pose_docs),"candidate_self_pair_count":self_count,"candidate_degenerate_face_count":len(wd),"baseline_forward_capture_max_error_m":replay,"baseline_forward_capture_pass":replay<=3e-7,"external_target_keys_scanned":0,"added_parent_pair_count":0,"removed_parent_pair_count":0,"interfaces":[]}
 if self_count==0 and not wd and topok and replay<=3e-7:
  bref,bd=exact(actual,row["faces"][before]);arec,ad=exact(world,f[after]);req(not bd and not ad,f"changed star degenerate {step}")
  pts=np.concatenate([actual[np.unique(row["faces"][before])],world[np.unique(f[after])]],axis=0);lo=pts.min(axis=0);hi=pts.max(axis=0)
  for key,tgt in surf.items():
   if key==(51005,134):continue
   tf=np.asarray(tgt["faces"],dtype=np.int64);tri=pos[tf]
   sel=np.flatnonzero(np.all(tri.max(axis=1)>=lo,axis=1)&np.all(tri.min(axis=1)<=hi,axis=1))
   rec["external_target_keys_scanned"]+=1
   if not len(sel):continue
   tr,td=exact(pos,tf[sel]);req(not td,f"selected target contains degenerate face {key} {step}")
   ba=ci._audit_pair(bref,tr,same_surface=False);aa=ci._audit_pair(arec,tr,same_surface=False)
   bp={(int(before[x]),int(sel[y])) for x,y in ba["triangle_pairs"]}
   ap={(int(orig[after[x]]),int(sel[y])) for x,y in aa["triangle_pairs"]}
   add=sorted(ap-bp);rem=sorted(bp-ap)
   if add or rem:
    rec["interfaces"].append({"semantic":int(key[0]),"stable_id":int(key[1]),"label":tgt.get("body"),"baseline_parent_pairs":len(bp),"candidate_parent_pairs":len(ap),"added_parent_pairs":add,"removed_parent_pairs":rem})
    rec["added_parent_pair_count"]+=len(add);rec["removed_parent_pair_count"]+=len(rem)
  req(rec["external_target_keys_scanned"]==859,f"not all859 external targets visited at {step}")
  rec["all859_changed_star_no_new_parent_pairs"]=rec["added_parent_pair_count"]==0
 else:rec["all859_changed_star_no_new_parent_pairs"]=False;rec["external_status"]="skipped_self_topology_or_replay_gate"
 report["native42"]["poses"].append(rec);pins[str(pack)]=sha(pack);pins[str(receipt)]=sha(receipt)
 report["input_sha256"]=pins
 report["source_and_sampled_pose_self_clear"]=cand_source_self==0 and not cdeg and all(x["candidate_self_pair_count"]==0 and x["candidate_degenerate_face_count"]==0 for x in report["native42"]["poses"])
 report["all859_changed_star_no_new_parent_pairs"]=all(x.get("all859_changed_star_no_new_parent_pairs") is True for x in report["native42"]["poses"])
 report["complete"]=len(report["native42"]["poses"])==8 and all("all859_changed_star_no_new_parent_pairs" in x for x in report["native42"]["poses"])
 report["inputs_unchanged"]=all(sha(k)==v for k,v in pins.items());report["elapsed_seconds"]=time.monotonic()-start
 save(OUT/"report.json",{"schema":"stable134-native42-target-audit.v1","complete":False,"inputs_unchanged":False,"pins":pins,"poses":[{"accepted_step":x["accepted_step"],"rows":[{"stable_id":134,"self_count":x["candidate_self_pair_count"],"new_triangle_pair_count":x["added_parent_pair_count"],"external_targets_scanned":x["external_target_keys_scanned"],"all859_changed_star_no_new_parent_pairs":x.get("all859_changed_star_no_new_parent_pairs")}]} for x in report["native42"]["poses"]]})
 save(SEL_OUT/"report.json",report)
 with (OUT/"progress.jsonl").open("a") as f:
  f.write(json.dumps({"event":"pose_complete","step":step,"self":self_count,"targets":rec["external_target_keys_scanned"],"added":rec["added_parent_pair_count"],"removed":rec["removed_parent_pair_count"],"replay_m":replay},sort_keys=True)+"\n");f.flush();os.fsync(f.fileno())
 print(json.dumps({"step":step,"self":self_count,"targets":rec["external_target_keys_scanned"],"added":rec["added_parent_pair_count"],"removed":rec["removed_parent_pair_count"],"replay_m":replay},sort_keys=True),flush=True)
report["source_and_sampled_pose_self_clear"]=cand_source_self==0 and not cdeg and all(x["candidate_self_pair_count"]==0 and x["candidate_degenerate_face_count"]==0 for x in report["native42"]["poses"])
report["all859_changed_star_no_new_parent_pairs"]=all(x.get("all859_changed_star_no_new_parent_pairs") is True for x in report["native42"]["poses"])
report["complete"]=len(report["native42"]["poses"])==8 and all("all859_changed_star_no_new_parent_pairs" in x for x in report["native42"]["poses"])
report["inputs_unchanged"]=all(sha(k)==v for k,v in pins.items());report["input_sha256"]=pins;report["elapsed_seconds"]=time.monotonic()-start
save(OUT/"report.json",{"schema":"stable134-native42-target-audit.v1","complete":report["complete"],"inputs_unchanged":report["inputs_unchanged"],"pins":pins,"poses":[{"accepted_step":x["accepted_step"],"rows":[{"stable_id":134,"self_count":x["candidate_self_pair_count"],"new_triangle_pair_count":x["added_parent_pair_count"],"external_targets_scanned":x["external_target_keys_scanned"],"all859_changed_star_no_new_parent_pairs":x.get("all859_changed_star_no_new_parent_pairs")}]} for x in report["native42"]["poses"]]})
save(SEL_OUT/"report.json",report)
print(json.dumps({"complete":report["complete"],"self_clear":report["source_and_sampled_pose_self_clear"],"all859":report["all859_changed_star_no_new_parent_pairs"],"inputs_unchanged":report["inputs_unchanged"],"report":str(OUT/"selection-report.json")},sort_keys=True),flush=True)

