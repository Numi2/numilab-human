from pathlib import Path
import numpy as np,json,hashlib,importlib.util,sys
from scipy.optimize import minimize,LinearConstraint,linprog
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");R=A.parent;O=A/"vastus-joint-local-clearance-001";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-local-clearance-preservation-1280/src")
from numilab_human import cardiac_cavity_intersections as ci
H=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001/attempt-010/run_gluteus_union_010.py";G=H.parent.parent/"attempt-019/solve_terminal_self_pairs_019.py"
def imp(n,p):
 sp=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);return m
h=imp("h",H);g=imp("g",G);t=h.load_tissue(h.TISS)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [Path(__file__),H,G,h.TISS,h.MAN,Path(ci.__file__)]}
out={"scope":"Unadmitted offline source geometry proposal. Joint self and external SAT constraints use declared inferred candidate axes, not an accepted physical baseline. All inputs retain binding weights and topology. Native and all24/all859 checks remain required.","pins":pins,"rows":[],"complete":False}
def save():(O/"report.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
poses={}
for step in [0,155000]:
 rp=h.PAIR/"baseline/native-run/accepted-geometry"/f"step-{step}.receipt.json";rc=json.loads(rp.read_text());pins[str(rp)]=sha(rp);pk=rp.with_name(f"step-{step}.mrvpack");pins[str(pk)]=sha(pk);assert pins[str(pk)]==rc["pack_file_sha256"]
 poses[step]={x["body_index"]:(np.array(x["position_m"],np.float32),np.array(x["quaternion_xyzw"],np.float32)) for x in rc["accepted_registered_body_poses"]}
def axis_for(a,b):
 a=a.astype(float);b=b.astype(float);ea=np.roll(a,-1,axis=0)-a;eb=np.roll(b,-1,axis=0)-b
 ns=[np.cross(ea[0],ea[1]),np.cross(eb[0],eb[1])]
 axes=np.array(ns+[np.cross(x,y) for x in ea for y in eb]+[np.cross(n,e) for n in ns for e in [*ea,*eb]])
 axes=axes[np.linalg.norm(axes,axis=1)>1e-15];axes/=np.linalg.norm(axes,axis=1)[:,None];axes=np.concatenate((axes,-axes))
 gaps=(b@axes.T).min(0)-(a@axes.T).max(0);k=gaps.argmax();assert gaps[k]>0
 return axes[k],float(gaps[k])
def selfaudit(p,f):
 rec,deg=h.exact_rows(p,f,ci);return {"count":ci._audit_pair(rec,rec,same_surface=True)["count"] if not deg else None,"degenerate":deg}
for sid in [61,62]:
 pp=A/f"vastus-intermedius-source-union-lift-001/stable-{sid}-reference-union-row-patch.npz";cp=A/f"vastus-bounded-local-smoothing-002/stable-{sid}-alpha-0.06.npz"
 for pth in [pp,cp]:pins[str(pth)]=sha(pth)
 z=np.load(pp);p=z["vertices6"][:,:3];f=z["faces"];w=z["weights"];loc=z["binding_indices"];row=h.row_data(t,sid);smooth=np.load(cp)["vertices6"][:,:3]
 seeds=np.unique(f[[3118,3121,3133,3129,3134]]);vi={int(v):k for k,v in enumerate(seeds)};nv=3*len(seeds);other=h.row_data(t,sid+4);contexts=[]
 for step,pose in poses.items():
  world=h.forward(p,loc,w,row,t,pose);sw=h.forward(smooth,loc,w,row,t,pose);ow=h.forward(other["positions"],other["local"],other["weights"],other,t,pose);jac=g.pose_jacobians(p,loc,w,row,t,pose)
  contexts.append((step,pose,world,sw,ow,jac))
 cr={"stable_id":sid,"movable_vertices":seeds.tolist(),"trials":[]};out["rows"].append(cr);save()
 for floor_um in [.05,.2,1.0]:
  mat=[];rhs=[];witnesses=[]
  for step,pose,world,sw,ow,jac in contexts:
   for kind,aa,bb,ra,rb in [("self",f[3118],f[3121],sw[f[3118]],sw[f[3121]]),("external",f[3134],other["faces"][1128],world[f[3134]],ow[other["faces"][1128]])]:
    axis,gap=axis_for(ra,rb);floor=min(gap*.1,floor_um*1e-6);witnesses.append({"step":step,"kind":kind,"axis":axis.tolist(),"reference_gap_m":gap,"required_gap_m":floor})
    for ia in aa:
     for ib in bb:
      line=np.zeros(nv);line[3*vi[int(ia)]:3*vi[int(ia)]+3]-=axis@jac[ia]
      if kind=="self":
       line[3*vi[int(ib)]:3*vi[int(ib)]+3]+=axis@jac[ib];pb=world[ib]
      else:pb=ow[ib]
      mat.append(line);rhs.append((floor-axis@(pb.astype(float)-world[ia]))*1000+.00015*np.abs(line).sum())
  mat=np.array(mat);rhs=np.array(rhs);trial={"floor_um":floor_um,"witnesses":witnesses};cr["trials"].append(trial)
  feas=linprog(np.zeros(nv),A_ub=-mat,b_ub=-rhs,bounds=[(-.249,.249)]*nv,method="highs")
  trial["feasible"]=bool(feas.success)
  if not feas.success:trial["message"]=feas.message;save();continue
  sol=minimize(lambda x:.5*x@x,feas.x,jac=lambda x:x,constraints=[LinearConstraint(mat,rhs,np.inf)],bounds=[(-.249,.249)]*nv,method="SLSQP",options={"maxiter":500,"ftol":1e-12})
  trial["optimizer_success"]=bool(sol.success);trial["linear_residual_mm"]=float((mat@sol.x-rhs).min())
  q=p.copy();q[seeds]=(p[seeds].astype(float)+sol.x.reshape(-1,3)/1000).astype("<f4");trial["offset_max_m"]=float(np.linalg.norm(q.astype(float)-p,axis=1).max());trial["source"]=selfaudit(q,f);trial["poses"]=[]
  for step,pose,_,_,ow,_ in contexts:
   qw=h.forward(q,loc,w,row,t,pose);a,_=h.exact_rows(qw,f[[3134]],ci);b,_=h.exact_rows(ow,other["faces"][[1128]],ci);trial["poses"].append({"step":step,**selfaudit(qw,f),"external_count":ci._audit_pair(a,b,same_surface=False)["count"]})
  if trial["source"]["count"]==0 and all(x["count"]==0 and x["external_count"]==0 for x in trial["poses"]):
   dest=O/f"stable-{sid}-floor-{floor_um}um.npz";np.savez(dest,vertices6=np.column_stack((q,h.vertex_normals(q,f))).astype("<f4"),faces=f,weights=w,binding_indices=loc,face_origins=z["face_origins"]);trial["candidate_path"]=str(dest);trial["candidate_sha256"]=sha(dest)
  save();print(json.dumps({"sid":sid,**trial}),flush=True)
out["complete"]=True;out["inputs_unchanged"]=all(sha(p)==v for p,v in pins.items());save()
