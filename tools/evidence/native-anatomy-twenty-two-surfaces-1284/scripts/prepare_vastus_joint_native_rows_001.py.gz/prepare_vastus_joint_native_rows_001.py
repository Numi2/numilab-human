from pathlib import Path
import sys,json,hashlib,importlib.util
import numpy as np
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");O=A/"vastus-joint-native-ready-001";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-positive-winding-1279/src")
from numilab_human.cardiac_cavity_geometry import analyze_topology
from numilab_human import cardiac_cavity_intersections as ci
H=A.parent/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001/attempt-010/run_gluteus_union_010.py"
sp=importlib.util.spec_from_file_location("h",H);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
paths=[A/"vastus-joint-local-clearance-001/report.json",A/"vastus-joint-local-clearance-allpose-audit-001/report.json",A/"vastus-intermedius-source-union-lift-001/report.json",A/"propose_vastus_joint_local_clearance_001.py",A/"audit_vastus_joint_local_clearance_allpose_001.py",Path(__file__),H,h.TISS,h.MAN]
pins={str(p):sha(p) for p in paths};sm,ad,union=[json.loads(p.read_text()) for p in paths[:3]]
for d in [sm,ad,union]:assert d["complete"] and d["inputs_unchanged"]
assert len(ad["poses"])==24
t=h.load_tissue(h.TISS)
out={"scope":"Existing exact source union plus explicit local joint self/external SAT correction. No additional interface exceptions. Native verification pending. No physical routes, forces, mass or deformation bindings changed. Not whole-body qualification.","pins":pins,"rows":[],"complete":False}
for sid in [61,62]:
 sr=next(r for r in sm["rows"] if r["stable_id"]==sid);r=next(r for r in sr["trials"] if r["floor_um"]==1.0);p=Path(r["candidate_path"]);assert sha(p)==r["candidate_sha256"];pins[str(p)]=sha(p)
 rawpath=Path(next(r for r in union["rows"] if r["stable_id"]==sid)["candidate_path"]);pins[str(rawpath)]=sha(rawpath)
 z=np.load(p);raw=np.load(rawpath);row=h.row_data(t,sid)
 for k in ["faces","binding_indices","weights","face_origins"]:assert np.array_equal(z[k],raw[k])
 positions=raw["vertices6"][:,:3];faces=raw["faces"];seeds=np.asarray(sr["movable_vertices"],int)
 q=z["vertices6"][:,:3];outside=np.setdiff1d(np.arange(len(q)),seeds)
 assert np.array_equal(q[outside],positions[outside])
 assert r["optimizer_success"] and r["linear_residual_mm"]>-1e-8
 assert np.array_equal(h.vertex_normals(q,faces),z["vertices6"][:,3:])
 maximum=float(np.linalg.norm(q.astype(float)-positions,axis=1).max());assert maximum<.00005
 pure=np.flatnonzero(raw["weights"].max(1)>=.999999);assert np.array_equal(q[pure],positions[pure])
 referenced=np.unique(row["faces"]);originalpure=referenced[row["weights"][referenced].max(1)>=.999999]
 for v in originalpure:
  matches=np.flatnonzero(np.all(q==row["positions"][v],axis=1))
  assert any(np.array_equal(z["weights"][i],row["weights"][v]) and np.array_equal(z["binding_indices"][i],row["local"][v]) for i in matches)
 topo=analyze_topology(q.tolist(),faces.tolist());assert topo["closed_oriented_manifold_candidate"]
 rec,deg=h.exact_rows(q,faces,ci);assert not deg and ci._audit_pair(rec,rec,same_surface=True)["count"]==0
 verified=[]
 for pose in ad["poses"]:
  x=next(r for r in pose["rows"] if r["stable_id"]==sid)
  assert x["self_count"]==0 and x["closed_oriented_manifold_candidate"] and x["max_referenced_forward_error_m"]<1e-6 and x["external_targets_scanned"]==859
  assert x["new_triangle_pair_count"]==0
  verified.append({"arm":pose["arm"],"step":pose["step"],"self_count":0,"new_triangle_pair_count":0})
 cr={"stable_id":sid,"candidate_path":str(p),"candidate_sha256":sha(p),"source_and_sampled_pose_self_clear":True,"source_self_count":0,"closed_oriented_manifold_candidate":True,"changed_or_missing_pure_attachment_proxies":[],"pure_attachment_proxy_count":len(originalpure),"maximum_reference_offset_from_raw_union_m":maximum,"modified_source_vertices":seeds.tolist(),"binding_faces_and_weights_unchanged_from_union":True,"poses":verified,"late_pose_count":16,"early_pose_count":8,"raw_union_path":str(rawpath),"raw_union_sha256":sha(rawpath)}
 out["rows"].append(cr)
out["complete"]=True;out["inputs_unchanged"]=all(sha(p)==v for p,v in pins.items());assert out["inputs_unchanged"]
(O/"report.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
print(json.dumps({"output":str(O),"rows":[{"id":r["stable_id"],"offset_mm":r["maximum_reference_offset_from_raw_union_m"]*1000,"pure":r["pure_attachment_proxy_count"]} for r in out["rows"]]}))

