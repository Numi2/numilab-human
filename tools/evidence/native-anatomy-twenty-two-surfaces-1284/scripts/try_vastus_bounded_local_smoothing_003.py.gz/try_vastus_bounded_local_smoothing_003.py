from pathlib import Path
import sys,json,hashlib,importlib.util,time
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009");A=R/"anatomy-completion-1276";O=A/"vastus-bounded-local-smoothing-003";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-positive-winding-1279/src")
from numilab_human import cardiac_cavity_intersections as ci
from numilab_human.cardiac_cavity_geometry import analyze_topology
H=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001/attempt-010/run_gluteus_union_010.py"
sp=importlib.util.spec_from_file_location("h",H);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={"scope":"Unadmitted bounded local source smoothing around pose folds. Existing bindings, physical routes and pure attachment proxies unchanged. Not an accepted physical baseline.","pins":{str(p):sha(p) for p in [Path(__file__),H,h.TISS,h.MAN]},"rows":[]}
save=lambda:(O/"report.json").write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
t=h.load_tissue(h.TISS)
def audit(p,f):
 rec,deg=h.exact_rows(p,f,ci)
 return {"count":ci._audit_pair(rec,rec,same_surface=True)["count"] if not deg else None,"degenerate":deg}
poses={}
for step in (0,155000):
 path=h.PAIR/"baseline/native-run/accepted-geometry"/f"step-{step}.receipt.json";report["pins"][str(path)]=sha(path)
 d=json.loads(path.read_text());assert sha(path.with_name(f"step-{step}.mrvpack"))==d["pack_file_sha256"]
 poses[step]={int(x["body_index"]):(np.asarray(x["position_m"],np.float32),np.asarray(x["quaternion_xyzw"],np.float32)) for x in d["accepted_registered_body_poses"]}
for sid in (61,62):
 path=A/f"vastus-intermedius-source-union-lift-001/stable-{sid}-reference-union-row-patch.npz";report["pins"][str(path)]=sha(path)
 z=np.load(path);p=z["vertices6"][:,:3];f=z["faces"];local=z["binding_indices"];w=z["weights"];row=h.row_data(t,sid)
 seeds=np.unique(f[[3118,3121,3133,3129]]);pure=np.flatnonzero(w.max(1)>=.999999);assert not np.intersect1d(seeds,pure).size
 neighbors=[set() for _ in p]
 for tri in f:
  for v in tri:neighbors[v].update(int(x) for x in tri if x!=v)
 delta=np.zeros_like(p,dtype=float)
 for v in seeds:delta[v]=p[sorted(neighbors[v])].astype(float).mean(0)-p[v]
 cr={"stable_id":sid,"seeds":seeds.tolist(),"pure_proxy_count":len(pure),"trials":[]};report["rows"].append(cr);save()
 for alpha,restore in [(a,v) for a in (.06,.08) for v in ([1541],[1623],[1541,1623]) ] if sid==61 else [(a,v) for a in (.06,.08) for v in ([590],[508],[590,508])]:
  disp=delta*alpha;lengths=np.linalg.norm(disp,axis=1);disp*=np.minimum(1,.00025/np.maximum(lengths,1e-30))[:,None]
  q=np.asarray(p.astype(float)+disp,dtype="<f4");q[restore]=p[restore];assert np.array_equal(q[pure],p[pure])
  trial={"alpha":alpha,"restored_vertices":restore,"source_offset_max_m":float(np.linalg.norm(q.astype(float)-p,axis=1).max()),"source":audit(q,f),"poses":[]};cr["trials"].append(trial)
  if trial["source"]["count"]==0:
   for step,pose in poses.items():
    world=h.forward(q,local,w,row,t,pose);rr={"step":step,**audit(world,f)}
    other=h.row_data(t,sid+4);ow=h.forward(other["positions"],other["local"],other["weights"],other,t,pose)
    aa,_=h.exact_rows(world,f[[3134]],ci);bb,_=h.exact_rows(ow,other["faces"][[1128]],ci)
    rr["known_new_neighbor_pair_count"]=ci._audit_pair(aa,bb,same_surface=False)["count"]
    trial["poses"].append(rr)
   if all(x["count"]==0 and x["known_new_neighbor_pair_count"]==0 for x in trial["poses"]):
    dest=O/f"stable-{sid}-alpha-{alpha}-restore-{restore[0]}-{len(restore)}.npz";np.savez(dest,vertices6=np.concatenate([q,h.vertex_normals(q,f)],axis=1).astype("<f4"),faces=f,binding_indices=local,weights=w,face_origins=z["face_origins"])
    trial["candidate_path"]=str(dest);trial["candidate_sha256"]=sha(dest)
  save();print(json.dumps({"sid":sid,**trial}),flush=True)
report["inputs_unchanged"]=all(sha(p)==v for p,v in report["pins"].items());report["complete"]=True;save()

