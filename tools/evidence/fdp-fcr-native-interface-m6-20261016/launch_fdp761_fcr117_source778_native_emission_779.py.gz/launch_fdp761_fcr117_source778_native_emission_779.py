from pathlib import Path
import json,hashlib,subprocess,os,sys,shutil,time
R=Path('/Users/n/numi-human-retained-delivery-20261009');D=R/'anatomy-completion-1276/full-anatomy-delivery-audit-1378'
SOURCE=D/'thumb688-tendon693-existing-skin661-native-emission-699/native-run/invocation.json'
BUILD=R/'native-skin-capture-rib-hook-viewer-build-20261015-003'
OUT=D/'fdp761-fcr117-source778-native-emission-779';PIN=Path(__file__).with_suffix('.pins.json')
NEW_SKIN=D/'skin650-actual-folded-source-patch-export-661/bodyparts3d-myosim-skinned-shell.nhskin'
PAYLOAD_DIR=D/'thumb678-bones106-113-opposed-source-retirement-688/compiled'
NEW_RECEIPT=D/'fdp761-fcr117-native777-flip-source-778/resting-anatomy-receipt.json'
NEW_NHA=PAYLOAD_DIR/'resting-thorax.nhanatomy'
NEW_BONES=PAYLOAD_DIR/'bodyparts3d-myosim-major-bones.nhbones'
NEW_TENDON=D/'thumb598-bones688-tendon-equivalence-693/compiled/numi-human-tendon-attachments.nhtendon'
child=json.loads(NEW_RECEIPT.read_text())['provenance']['native_muscle_surfaces']
NEW_TISSUE=Path(child['payload_path']);NEW_TISSUE_MANIFEST=Path(child['manifest_path'])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(NEW_TISSUE)==child['sha256'] and sha(NEW_TISSUE_MANIFEST)==child['manifest_sha256']
base=json.loads(SOURCE.read_text());old=base['argv'][4]
args=[str(BUILD/'bin/numi-human-native'),*[x.replace(old,str(OUT/'native-run')) for x in base['argv'][1:]]]
args[args.index('--skin-payload')+1]=str(NEW_SKIN)
args[3]=str(NEW_BONES)
args[args.index('--soft-tissue-payload')+1]=str(NEW_TISSUE)
args[args.index('--tendon-payload')+1]=str(NEW_TENDON)
args[args.index('--torso-anatomy-payload')+1]=str(NEW_NHA)
args[args.index('--resting-anatomy-receipt')+1]=str(NEW_RECEIPT)
env={k:v.replace(old,str(OUT/'native-run')) for k,v in base['environment'].items()}
paths=[Path(__file__),SOURCE,BUILD/'build-report.json',BUILD/'bin/numi-human-native',NEW_SKIN,NEW_SKIN.parent/'source-preparation-report.json',NEW_SKIN.parent/'preparation.json',NEW_SKIN.parent/'refinement-proof.json',NEW_RECEIPT,*[NEW_RECEIPT.parent/p for p in ('common-cardiac-map-f32.bin','common-cardiac-domains-f32.bin','common-cardiac-volumes-f32.bin')],NEW_TISSUE,NEW_TISSUE_MANIFEST,NEW_NHA,NEW_BONES,NEW_BONES.with_suffix('.manifest.json'),PAYLOAD_DIR.parent/'source-preparation-report.json',PAYLOAD_DIR/'source-export005-partition-rebind.json',NEW_TENDON,NEW_TENDON.with_suffix('.manifest.json'),NEW_TENDON.parent.parent/'source-preparation-report.json']
for f,h in base['input_sha256'].items():
 assert sha(f)==h,(f,'old input drift');paths.append(Path(f))
pins={str(p):sha(p) for p in paths}
plan=dict(argv=args,environment=env,input_sha256=pins,scope='One-step actual Metal emission of connected FDP133/FCR117 reference partition761 exported765c, childfallbackrest766 and strict existingowner13row restconformance768 and positionpreserving actual770 fold repair777/export778. Preserve source753 FPL135/brachioradialis109 commonfullparentfield and retessellation; prior131/109/135 and all other parentterms retained. FDP remains4sourcecomponents; FCR1. Passive inferred mesh/material repair, unchangedMyoSim mechanicalroutes/mass/Brain/functionalphysiology/back/bones/tendon/skin. Need actual allnear/interface/motion gates; no anatomical admission or16/60qualification.')
assert args[args.index('--muscle-step-count')+1]=='1'
if sys.argv[1:]==['--prepare']:
 assert not PIN.exists() and not OUT.exists();PIN.write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n');print('PASS_COMPLETE_NATIVE_PREPARATION');raise SystemExit
assert sys.argv[1:]==['--execute'] and json.loads(PIN.read_text())==plan and not OUT.exists()
assert shutil.disk_usage(R).free>=12*1024**3
OUT.mkdir();run=OUT/'native-run';run.mkdir();(run/'invocation.json').write_text(json.dumps(plan,indent=2,sort_keys=True)+'\n');start=time.monotonic()
with (run/'native.log').open('wb') as f:result=subprocess.run(args,env={**os.environ,**env},stdout=f,stderr=subprocess.STDOUT,timeout=300)
doc=dict(exit_code=result.returncode,wall_seconds=time.monotonic()-start,anatomical_admission=False,native_qualification=False)
(OUT/'execution-result.json').write_text(json.dumps(doc,indent=2)+'\n');print(json.dumps(doc));raise SystemExit(result.returncode)

