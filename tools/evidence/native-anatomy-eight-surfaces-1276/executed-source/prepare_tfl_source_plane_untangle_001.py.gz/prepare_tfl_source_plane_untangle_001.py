from pathlib import Path
import sys,json,hashlib,importlib.util,time
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009");O=R/"anatomy-completion-1276/tfl-source-plane-untangle-001";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-anatomy-completion-1276/src")
from numilab_human import cardiac_cavity_intersections as ci
from numilab_human.muscle_tip_visual_untangle import _plane
from numilab_human.resting_anatomy_interface_patch import normals
from numilab_human.cardiac_cavity_geometry import analyze_topology
H=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001/attempt-010/run_gluteus_union_010.py"
sp=importlib.util.spec_from_file_location("prior",H);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [Path(__file__),H,h.TISS,h.MAN,Path(ci.__file__),Path(sys.modules[_plane.__module__].__file__)]}
t=h.load_tissue(h.TISS)
posemaps={}
for s in h.STEPS:
 p=h.PAIR/"baseline/native-run/accepted-geometry"/f"step-{s}.receipt.json";pins[str(p)]=sha(p)
 posemaps[s]={int(x["body_index"]):(np.array(x["position_m"],np.float32),np.array(x["quaternion_xyzw"],np.float32)) for x in json.loads(p.read_text())["accepted_registered_body_poses"]}
out={"scope":"Bounded point-group plane displacement reusing existing muscle-tip plane construction and exact intersection owners. Same source topology, binding maps and physical routes. Reference inference, not measurement or native qualification.","pins":pins,"rows":[],"complete":False}
def save():(O/"report.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
def audit(v,f):
 r,d=h.exact_rows(v,f,ci)
 if d:return {"count":99999,"degenerate_faces":d}
 return ci._audit_pair(r,r,same_surface=True)
for sid in [55,56,35,36,149,150]:
 start=time.monotonic();row=h.row_data(t,sid);raw=row["positions"];fraw=row["faces"]
 v,first,iv=np.unique(raw,axis=0,return_index=True,return_inverse=True);used=np.unique(iv[fraw]);mapping=np.full(len(v),-1);mapping[used]=np.arange(len(used))
 f=mapping[iv[fraw]];v=v[used];idx=row["local"][first[used]];w=row["weights"][first[used]];original=v.copy()
 protected=w.max(1)>=.999999
 assert np.all(w[w>0]>2e-6)
 def forward(x,s):return h.forward(x,idx,w,row,t,posemaps[s])
 def check(x):return {"source":audit(x,f),**{str(s):audit(forward(x,s),f) for s in [0,155000]}}
 cur=check(v);r={"stable_id":sid,"baseline_counts":{k:a["count"] for k,a in cur.items()},"operations":[],"trials":0};out["rows"].append(r);save()
 for iteration in range(8):
  if not cur["source"]["count"]:break
  oldtri=v[f].astype(float);oldn=np.cross(oldtri[:,1]-oldtri[:,0],oldtri[:,2]-oldtri[:,0])
  directions={}
  for a,b in cur["source"]["triangle_pairs"]:
   for moving,plane in [(a,b),(b,a)]:
    origin,n=_plane(v.astype(float),f,int(plane))
    for vi in set(map(int,f[moving]))-set(map(int,f[plane])):
     if protected[vi]:continue
     # Both signed source-plane moves are candidates; actual exact geometry decides.
     signed=float((v[vi].astype(float)-origin)@n)
     for distance in [1e-6,5e-6,20e-6,50e-6,100e-6,200e-6]:
      for sign in [-1,1]:
       move=(sign*distance)*n
       directions[(vi,tuple(move))]=(vi,move,int(moving),int(plane))
     for sign in [-1,1]:
      move=(-signed+sign*1e-6)*n
      directions[(vi,tuple(move))]=(vi,move,int(moving),int(plane))
  best=None
  for vi,move,a,b in directions.values():
   nv=v.copy();nv[vi]=(v[vi].astype(float)+move).astype(np.float32)
   bound=float(np.linalg.norm(nv.astype(float)-original.astype(float),axis=1).max())
   if bound>.00025:continue
   tri=nv[f].astype(float);nn=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0])
   dot=np.einsum("ij,ij->i",oldn,nn);den=np.linalg.norm(oldn,axis=1)*np.linalg.norm(nn,axis=1)
   if np.any(den<=0) or np.min(dot/den)<.2:continue
   source=audit(nv,f);r["trials"]+=1
   if source["count"]>=cur["source"]["count"]:continue
   zero=audit(forward(nv,0),f)
   if zero["count"]>cur["0"]["count"]:continue
   terminal=audit(forward(nv,155000),f)
   if terminal["count"]>cur["155000"]["count"]:continue
   score=(source["count"]+zero["count"]+terminal["count"],bound)
   if best is None or score<best[0]:best=(score,nv,{"source":source,"0":zero,"155000":terminal},{"compact_vertex":vi,"original_source_vertex":int(first[used[vi]]),"moving_face":a,"plane_face":b,"actual_increment_m":(nv[vi].astype(float)-v[vi].astype(float)).tolist(),"maximum_cumulative_source_displacement_m":bound,"minimum_face_normal_cosine":float(np.min(dot/den))})
   if score[0]==0:break
   if time.monotonic()-start>180:break
  if best is None:break
  _,v,cur,op=best;r["operations"].append(op);save()
  if time.monotonic()-start>180:break
 r["final"]={"source":audit(v,f),**{str(s):audit(forward(v,s),f) for s in h.STEPS}}
 r["source_and_sampled_pose_self_clear"]=all(x["count"]==0 for x in r["final"].values())
 r["topology"]=analyze_topology(v.astype(float).tolist(),f.tolist())
 if r["operations"]:
  p=O/f"stable-{sid}-reference-plane-row-patch.npz"
  np.savez(p,vertices6=np.column_stack((v,normals(v.astype(float),f))).astype(np.float32),binding_indices=idx,weights=w,faces=f.astype("<u4"),face_origins=np.arange(len(f)))
  r["candidate_path"]=str(p);r["candidate_sha256"]=sha(p)
 r["wall_seconds"]=time.monotonic()-start;save()
 print(json.dumps({"stable_id":sid,"ops":len(r["operations"]),"trials":r["trials"],"final":{k:a["count"] for k,a in r["final"].items()},"wall_seconds":r["wall_seconds"]}),flush=True)
out["complete"]=True;out["inputs_unchanged"]=all(sha(p)==x for p,x in pins.items());save()

