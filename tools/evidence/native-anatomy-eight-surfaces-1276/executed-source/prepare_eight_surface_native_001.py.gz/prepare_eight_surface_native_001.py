from pathlib import Path
import sys,json,hashlib,argparse,numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009");A=R/"anatomy-completion-1276"
O=A/"eight-surface-native-composition-001";O.mkdir(exist_ok=False)
SRC=Path("/Users/n/numi-human-anatomy-completion-1276/src");sys.path.insert(0,str(SRC))
from numilab_human import passive_attachment_composition as pc,resting_run as rr
from numilab_human.resting_lung_edge_repair import collapse_midpoint_edge
from numilab_human.resting_anatomy_interface_patch import normals
from numilab_human.cardiac_cavity_geometry import analyze_topology
T=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
B=R/"skin-resting-multipose-clearance-1218/package-preparation-005/composed-candidate-001"
P=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
proofpaths=[A/x/"report.json" for x in ["ecu-apl-allpose-interface-audit-002","tibialis-allpose-interface-audit-001","tfl-allpose-interface-audit-001"]]
for pp in proofpaths:
 d=json.loads(pp.read_text());assert d["complete"] and d["inputs_unchanged"] and len(d["poses"])==16
 assert all(x["self_count"]==x["new_triangle_pair_count"]==0 and x["external_targets_scanned"]==859 for p in d["poses"] for x in p["rows"])
def canon(ix,w,bc):
 out=np.zeros(bc,float)
 for i,x in zip(ix,w):
  if x>0:out[int(i)]+=float(x)
 return out
d=pc._read_nhtiss4(T);replacements=[];bounds={}
for name in ["ecu-source-resolution-001","apl-tfl-source-resolution-001","component-source-resolution-001","completed-tfl-row-excerpt-001"]:
 rp=A/name/"report.json";report=json.loads(rp.read_text());assert report["complete"] and report["inputs_unchanged"]
 for row in report["rows"]:
  if not row["source_and_sampled_pose_self_clear"]:continue
  sid=row["stable_id"];npz=Path(row["candidate_path"]);assert sha(npz)==row["candidate_sha256"]
  raw=pc._biceps_row_arrays(pc._row_slices(d,next(r for r in d["records"] if int(r[6])==sid)))
  u,first,iv=np.unique(raw["vertices6"][:,:3],axis=0,return_index=True,return_inverse=True)
  used=np.unique(iv[raw["faces"]]);mapping=np.full(len(u),-1);mapping[used]=np.arange(len(used))
  f=mapping[iv[raw["faces"]]];v=np.column_stack((u[used],normals(u[used].astype(float),f))).astype(np.float32)
  idx=raw["binding_indices"][first[used]].copy();weights=raw["weights"][first[used]].copy();orig=np.arange(len(f))
  bc=int(max(idx[weights>0]))+1
  for j in np.unique(raw["faces"]):
   k=mapping[iv[j]];assert np.array_equal(canon(raw["binding_indices"][j],raw["weights"][j],bc),canon(idx[k],weights[k],bc))
  ancestry=[{int(j)} for j in first[used]];reference=raw["vertices6"][:,:3]
  for op in row["operations"]:
   if "compact_vertex" in op:
    k=op["compact_vertex"];v[k,:3]=(v[k,:3].astype(float)+np.asarray(op["actual_increment_m"],float)).astype(np.float32)
    v[:,3:]=normals(v[:,:3].astype(float),f).astype(np.float32);continue
   remove=op["removed_vertex_before_compaction"];keep=op["retained_vertex_before_compaction"]
   if "component_local_owner_report" in op:
    topo=analyze_topology(v[:,:3].astype(float).tolist(),f.tolist())
    faces=np.asarray(next(c for c in topo["face_components"] if np.any(f[c]==keep)),int)
    vertices=np.unique(f[faces]);local=np.searchsorted(vertices,f[faces])
    nv,nf,no,check=collapse_midpoint_edge(v[vertices],local,orig[faces],remove_vertex=int(np.searchsorted(vertices,remove)),keep_vertex=int(np.searchsorted(vertices,keep)),max_endpoint_displacement_m=.00025,max_abs_volume_delta_m3=1e-10)
    assert check==op["component_local_owner_report"]
    newpoint=nv[check["retained_vertex_after_compaction"],:3]
   else:
    nv,nf,no,check=collapse_midpoint_edge(v,f,orig,remove_vertex=remove,keep_vertex=keep,max_endpoint_displacement_m=.00025,max_abs_volume_delta_m3=1e-10)
    assert check==op;newpoint=nv[check["retained_vertex_after_compaction"],:3]
   replaced=f.copy();replaced[replaced==remove]=keep
   valid=(replaced[:,0]!=replaced[:,1])&(replaced[:,1]!=replaced[:,2])&(replaced[:,2]!=replaced[:,0])
   survived=np.unique(replaced[valid]);mapping=np.full(len(v),-1);mapping[survived]=np.arange(len(survived));k=int(mapping[keep])
   mean=(canon(idx[keep],weights[keep],bc)+canon(idx[remove],weights[remove],bc))/2
   ii=np.flatnonzero(mean>0);assert len(ii)<=4
   ni=idx[survived].copy();nw=weights[survived].copy();ni[k]=np.uint32(4294967295);nw[k]=0;ni[k,:len(ii)]=ii;nw[k,:len(ii)]=mean[ii].astype(np.float32)
   na=[ancestry[int(j)] for j in survived];na[k]=ancestry[keep]|ancestry[remove]
   v=v[survived].copy();v[k,:3]=newpoint;f=mapping[replaced[valid]];v[:,3:]=normals(v[:,:3].astype(float),f).astype(np.float32);orig=orig[valid];idx,weights,ancestry=ni,nw,na
  z=np.load(npz)
  for k,value in [("vertices6",v),("faces",f),("binding_indices",idx),("weights",weights),("face_origins",orig)]:assert np.array_equal(z[k],value),(sid,k)
  maximum=max(float(np.linalg.norm(v[i,:3].astype(float)-reference[list(a)].astype(float),axis=1).max()) for i,a in enumerate(ancestry));assert maximum<=.00025
  pure=set(np.flatnonzero(raw["weights"].max(1)>=.999999))
  changed=set().union(*(a for i,a in enumerate(ancestry) if any(not np.array_equal(v[i,:3],reference[j]) for j in a)))
  assert not pure&changed
  bounds[sid]={"source_reconstruction_matches_candidate":True,"maximum_original_ancestry_displacement_m":maximum,"pure_attachment_proxy_changed":False}
  replacements.append((sid,npz,rp))
assert sorted(x[0] for x in replacements)==[55,56,57,58,115,116,147,148]
payload=O/"assets"/T.name;composition=pc.compose(T,payload.parent,replacements,reference_surface_rows=tuple(sorted(x[0] for x in replacements)))
receipt=O/"resting-anatomy-receipt.json";pc.bind_anatomy_receipt(B/"composed-anatomy/resting-anatomy-receipt.json",payload,receipt)
(O/"composition-result.json").write_text(json.dumps(composition,indent=2,sort_keys=True)+"\n")
(O/"source-resolution-bounds.json").write_text(json.dumps(bounds,indent=2,sort_keys=True)+"\n")
base=json.loads((P/"baseline/run-declaration.json").read_text());argsv=base["argv"][base["argv"].index("human-resting")+1:]
for flag,value in [("--anatomy-receipt",str(receipt)),("--output",str(O/"baseline/native-run")),("--seconds","16.0")]:argsv[argsv.index(flag)+1]=value
argsv+=["--lab","/Users/n/numi-lab-resting-window-vector-trace-1271","--build","/Users/n/numi-lab-resting-window-vector-trace-build-1271-001"]
parser=argparse.ArgumentParser();rr.add_arguments(parser);args=parser.parse_args(argsv);native,assets=rr.command(args)
env={}
for item in base["argv"][2:base["argv"].index("human-resting")-1]:
 key,value=item.split("=",1);env[key]=value
env["NUMI_HUMAN_ROOT"]=str(SRC.parent);env["PYTHONPATH"]=str(SRC)
env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"]="0,4767,5023,5599,6207,6815,7423,8000"
assert all(n in (0,8000) or (n+1)%32==0 for n in map(int,env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"].split(",")))
# Preserve baseline011's diagnostic window exactly; it does not activate within16s.
env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"]=str(args.output/"common-field-failure.json")
env.update(DYLD_LIBRARY_PATH=str(args.build/"lib")+":"+str(args.build/"matter"),DYLD_PRINT_LIBRARIES="1",NUMI_HUMAN_RESTING_INSPECTION_TOUR="1",NUMI_HUMAN_RESTING_INSPECTION_PERIOD_SECONDS=str(args.inspection_period_seconds))
argv=["/usr/bin/env","-i"]+[k+"="+v for k,v in sorted(env.items())]+["/Users/n/numi-human-prep-venv-20261005/bin/python3.13","-m","numilab_human.resting_run"]+argsv
launch=O/"launch_arm.py";launch.write_bytes((A/"ecu-apl-native-composition-005/launch_arm.py").read_bytes())
pins={**assets,**{str(p):sha(p) for p in [Path(__file__),Path(pc.__file__),Path(rr.__file__),launch,O/"source-resolution-bounds.json",*proofpaths]}}
for _,npz,rp in replacements:pins[str(npz)]=sha(npz);pins[str(rp)]=sha(rp)
decl={"schema":"numi.human.native-smoke.run-declaration.v1","seconds":16.0,"accepted_steps":8000,"capture_steps":[0,4767,5023,5599,6207,6815,7423,8000],"immutable_assets":pins,"argv":argv,"launch_adapter":{"path":str(launch),"sha256":sha(launch)},"owner_cli_preview":{"native_argv":native,"asset_sha256":assets,"recorded_invocation_environment":rr.invocation_environment(env)},"qualification":"Eight passive muscle repairs integrated into existing resting coupled human. Diagnostic settings matched to baseline011. Short anatomy verification only, not five-minute or whole-body qualification."}
(O/"baseline").mkdir();dp=O/"baseline/run-declaration.json";dp.write_text(json.dumps(decl,indent=2,sort_keys=True)+"\n")
(O/"launch-guard.json").write_text(json.dumps({"launcher_sha256":sha(launch),"arms":{"baseline":{"run_declaration_sha256":sha(dp),"native_output":str(args.output)}}},indent=2,sort_keys=True)+"\n")
print(json.dumps({"output":str(O),"payload_sha256":sha(payload),"pins":len(pins),"bounds":bounds},indent=2))

