from pathlib import Path
import sys, json, hashlib, importlib.util, time, os
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
A=R/"anatomy-completion-1276"
ROOT=A/"stable-141-positive-union-lift-001"
OUT=ROOT/"local-reference-001"/"result-001"
OUT.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-touching-loop-arrangement-1290/src")
from numilab_human import cardiac_cavity_intersections as ci, cardiac_cavity_geometry as cg, common_atlas_skin_clearance as ca
H=A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
sp=importlib.util.spec_from_file_location("positive_forward_141",H)
h=importlib.util.module_from_spec(sp); sp.loader.exec_module(h)
T=A/"forty-two-surface-native-composition-001/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
M=T.with_suffix(".manifest.json")
C=ROOT/"stable-141-reference-union-row-patch.npz"
POSES=[]
pair=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
specs=[
 ("current42","baseline",[0,4767,5023,5599,6207,6815,7423,8000],A/"forty-two-surface-native-composition-001/baseline/native-run/accepted-geometry"),
 ("legacy24-early","baseline",[0,4767,5023,5599,6207,6815,7423,8000],A/"twenty-eight-surface-native-composition-001/baseline/native-run/accepted-geometry"),
 ("legacy24-baseline-late","baseline",list(h.STEPS),pair/"baseline/native-run/accepted-geometry"),
 ("legacy24-intervention-late","intervention",list(h.STEPS),pair/"intervention/native-run/accepted-geometry"),
]
for group,arm,steps,base in specs:
 for step in steps:
  pack=base/f"step-{step}.mrvpack"
  rec=base/f"step-{step}.receipt.json"
  assert pack.is_file() and rec.is_file(),f"missing capture {group}/{step}: {pack}"
  rc=json.loads(rec.read_text())
  ph=hashlib.sha256(pack.read_bytes()).hexdigest()
  assert (rc.get("pack_file_sha256") or rc.get("accepted_pack_file_sha256"))==ph,f"capture pin mismatch {group}/{step}"
  prs=rc.get("accepted_body_poses") or rc.get("accepted_registered_body_poses")
  posemap={int(x["body_index"]):(np.asarray(x["position_m"],np.float32),np.asarray(x["quaternion_xyzw"],np.float32)) for x in prs}
  POSES.append({"group":group,"arm":arm,"step":step,"pack":pack,"receipt":rec,"posemap":posemap,"pack_sha":ph,"receipt_sha":hashlib.sha256(rec.read_bytes()).hexdigest(),"accepted_pose_count":len(prs)})
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def req(x,msg):
 if not x: raise RuntimeError(msg)
req(sha(Path(ci.__file__))=="90c7a7fb0ce4383397f97519dd5fe163201d86a0c97e18e3a9eb3fa9858cd561","predicate pin changed")
req(len(POSES)==32,"expected the named 32-pose audit set")
z=np.load(C,allow_pickle=False)
p0=np.ascontiguousarray(z["vertices6"][:,:3],dtype="<f4")
faces=np.ascontiguousarray(z["faces"],dtype="<i8")
orig=np.asarray(z["face_origins"],dtype="<i8")
local=np.asarray(z["binding_indices"],dtype="<u4")
weights=np.ascontiguousarray(z["weights"],dtype="<f4")
t=h.load_tissue(T); row=h.row_data(t,141)
req(p0.shape==(361,3) and faces.shape==(714,3),"unexpected stable141 union row layout")
req(np.all(local[weights>0]<row["bc"]) and np.all(local[weights<=0]==np.uint32(0xffffffff)),"binding map lane layout changed")
required={int(t["bindings"][row["fb"]+int(i)]["core"]) for i in np.unique(local[weights>0])}
for item in POSES: req(required.issubset(item["posemap"]),f"pose lacks active row141 cores: {item['group']}/{item['step']}")
pins={str(Path(__file__)):sha(Path(__file__)),str(H):sha(H),str(T):sha(T),str(M):sha(M),str(C):sha(C),str(Path(ci.__file__)):sha(ci.__file__),str(Path(cg.__file__)):sha(cg.__file__),str(Path(ca.__file__)):sha(ca.__file__)}
for item in POSES:
 pins[str(item["pack"])]=item["pack_sha"];pins[str(item["receipt"])]=item["receipt_sha"]
def exact_table(points):
 rec,deg=h.exact_rows(points,faces,ci)
 if len(deg): return {"count":None,"triangle_pairs":[],"degenerate_face_rows":[int(x) for x in deg]}
 d=ci._audit_pair(rec,rec,same_surface=True)
 return {"count":int(d["count"]),"triangle_pairs":sorted([list(map(int,x)) for x in d["triangle_pairs"]]),"degenerate_face_rows":[]}
def table_sha(table): return ca._baseline_self_pair_table_sha256(table,len(faces))
def fhash(x): return hashlib.sha256(np.ascontiguousarray(x,dtype="<f4").tobytes()).hexdigest()
source_base={"count":0,"triangle_pairs":[],"degenerate_face_rows":[]}
src_rec,src_deg=h.exact_rows(p0,faces,ci)
req(not src_deg and ci._audit_pair(src_rec,src_rec,same_surface=True)["count"]==0,"union candidate source no longer self-clear")
source_top=cg.analyze_topology(p0.astype(float).tolist(),faces.tolist())
req(source_top.get("closed_oriented_manifold_candidate"),"union candidate source topology not closed")
worlds=[]; tables=[]; pose_checks=[]
for i,item in enumerate(POSES):
 world=np.ascontiguousarray(h.forward(p0,local,weights,row,t,item["posemap"]),dtype="<f4")
 tab=exact_table(world)
 req(tab["count"] is not None,f"baseline pose degenerate {item['group']}/{item['step']}")
 worlds.append(world);tables.append(tab)
 pose_checks.append({"index":i,"group":item["group"],"arm":item["arm"],"step":item["step"],"baseline_world_sha256":fhash(world),"baseline_self_count":tab["count"],"baseline_pairs":tab["triangle_pairs"],"degenerate_face_rows":tab["degenerate_face_rows"],"pack_sha256":item["pack_sha"],"receipt_sha256":item["receipt_sha"]})
report={"schema":"stable141-bounded-pose-self-repair.v1","scope":"Offline position-only candidate from positive-winding union/lift. Only current stable141 row changes; maps, weights, face indices and original face ancestry are fixed. Source movement is bounded to 0.5 mm from this union seed. Every trial must keep source exact-self-clear, closed, nondegenerate and area-preserving, and all 32 named accepted pose contexts must have no self-pair regression. Target gate is deferred unless every named pose is self-clear. This is not native admission.","candidate_seed_path":str(C),"candidate_seed_sha256":sha(C),"stable_id":141,"label":"right extensor indicis","source_self_count":0,"source_closed_oriented":bool(source_top.get("closed_oriented_manifold_candidate")),"source_face_count":len(faces),"source_vertex_count":len(p0),"pose_checks":pose_checks,"input_pins":pins,"proposals":[],"selected":None,"target_gate_performed":False,"complete":False,"inputs_unchanged":False}
def save():
 tmp=OUT/"report.json.tmp"
 with tmp.open("w") as f: json.dump(report,f,indent=2,sort_keys=True); f.write("\n"); f.flush(); os.fsync(f.fileno())
 tmp.replace(OUT/"report.json")
def emit(kind,**kw):
 item={"event":kind,"elapsed_seconds":time.monotonic()-start,**kw}
 with (OUT/"progress.jsonl").open("a") as f: f.write(json.dumps(item,sort_keys=True,separators=(",",":"))+"\n")
 print(json.dumps(item,sort_keys=True),flush=True)
def incremental(baseworld,candworld,basetab):
 return ca.audit_incremental_skin_self_intersections(baseline_world_positions=baseworld,candidate_world_positions=candworld,baseline_faces=faces,candidate_faces=faces,baseline_self_audit=basetab,expected_baseline_world_f32_sha256=fhash(baseworld),expected_face_index_sha256=ca._face_index_sha256(faces),expected_baseline_self_pair_table_sha256=table_sha(basetab))
def jacobian(vertex,posemap):
 J=np.zeros((3,3),dtype=np.float64)
 for slot in range(4):
  ww=float(weights[vertex,slot])
  if ww<=0: continue
  b=t["bindings"][row["fb"]+int(local[vertex,slot])]
  value=b["value"]; bq=posemap[int(b["core"])][1]
  for k in range(3): J[:,k]+=ww*h.rotate32(bq,h.rotate32(value[3:7],np.eye(3,dtype=np.float32)[k]))*float(value[7])
 return J
def unit(x):
 n=float(np.linalg.norm(x))
 return x/n if n>1e-15 else None
def area_data(x):
 cr=np.cross(x[faces[:,1]].astype(np.float64)-x[faces[:,0]],x[faces[:,2]].astype(np.float64)-x[faces[:,0]])
 return np.linalg.norm(cr,axis=1),float(np.einsum("ij,ij->i",x[faces[:,0]].astype(np.float64),np.cross(x[faces[:,1]].astype(np.float64),x[faces[:,2]].astype(np.float64))).sum()/6)
base_area,base_vol=area_data(p0)
p=p0.copy(); current_worlds=list(worlds); current_tables=list(tables)
neighbor=[set() for _ in range(len(p))]
for tri in faces:
 ids=list(map(int,tri))
 for v in ids: neighbor[v].update(x for x in ids if x!=v)
locked=set(map(int,np.flatnonzero(np.max(weights,axis=1)>=0.999999)))
start=time.monotonic(); save()
for iteration in range(3):
 counts=[int(x["count"]) for x in current_tables]
 if sum(counts)==0:
  report["selected"]={"candidate_path":None,"max_delta_from_union_m":float(np.linalg.norm(p.astype(float)-p0.astype(float),axis=1).max())}
  break
 focus=max(range(len(POSES)),key=lambda i:current_tables[i]["count"])
 if current_tables[focus]["count"]==0: break
 focus_pairs=current_tables[focus]["triangle_pairs"]; pose=POSES[focus]; world=current_worlds[focus]
 proposals=[];seen=set()
 for fa,fb in focus_pairs:
  wa=world[faces[fa]].astype(np.float64);wb=world[faces[fb]].astype(np.float64)
  caa=wa.mean(axis=0);cbb=wb.mean(axis=0);ax=unit(caa-cbb)
  pair_axes=[]
  if ax is not None: pair_axes.append(("centroid_separation",ax))
  for fname,tri in (("face_a_normal",wa),("face_b_normal",wb)):
   n=unit(np.cross(tri[1]-tri[0],tri[2]-tri[0]))
   if n is not None:
    if ax is not None and float(np.dot(n,ax))<0: n=-n
    if not any(abs(float(np.dot(n,old)))>0.999 for _,old in pair_axes): pair_axes.append((fname,n))
  for side,fi in (("a",int(fa)),("b",int(fb))):
   tri_vertices=list(map(int,faces[fi])); movable=[v for v in tri_vertices if v not in locked]
   if not movable: continue
   groups=[("vertex",(v,),{v:1.0}) for v in movable]
   groups.append(("face",tuple(movable),{v:1.0 for v in movable}))
   ring=set(v for x in movable for v in neighbor[x])-set(movable)-locked
   if ring: groups.append(("one_ring_taper",tuple(movable+sorted(ring)),{**{v:1.0 for v in movable},**{v:0.5 for v in ring}}))
   for gname,group,factors in groups:
    for aname,axis in pair_axes:
     wanted=axis if side=="a" else -axis
     dirs={};valid=True
     for v in group:
      J=jacobian(v,pose["posemap"])
      try: d=np.linalg.lstsq(J,wanted,rcond=1e-8)[0]
      except np.linalg.LinAlgError: valid=False;break
      jd=J@d
      if np.linalg.norm(jd)<1e-8: valid=False;break
      dirs[v]=d/np.linalg.norm(jd)*float(factors[v])
     key=(tuple(group),tuple(np.round(wanted,5)),gname)
     if valid and key not in seen: proposals.append((gname,group,dirs,{"pair":[int(fa),int(fb)],"side":side,"axis":aname,"axis_world":wanted.tolist()}));seen.add(key)
 trial_count=0;best=None;trial_records=[]
 for gname,group,dirs,meta in proposals:
  for amount in (0.00005,0.0001,0.00025,0.0005):
   if trial_count>=120: break
   trial_count+=1
   q=p.astype(np.float64).copy()
   for v,d in dirs.items(): q[v]+=d*amount
   delta=q-p.astype(np.float64);lengths=np.linalg.norm(delta,axis=1)
   if lengths.max(initial=0)>0.0005001: continue
   cum=np.linalg.norm(q-p0.astype(np.float64),axis=1)
   if cum.max(initial=0)>0.0005001: continue
   q=np.ascontiguousarray(q.astype("<f4"));moved=np.flatnonzero(np.any(q!=p,axis=1))
   if not len(moved): continue
   ar,_=area_data(q); base_ar,_=area_data(p);ratio=ar/np.maximum(base_ar,1e-30)
   if not np.isfinite(ratio).all() or ratio.min()<0.2: continue
   _,vol=area_data(q)
   if vol*base_vol<=0 or abs(vol-base_vol)>max(abs(base_vol)*0.01,1e-15): continue
   srcres=incremental(p,q,source_base)
   if int(srcres["count"])!=0: continue
   before_counts=[int(x["count"]) for x in current_tables]
   after_tables=[];after_worlds=[];records=[];valid=True
   for i,item in enumerate(POSES):
    newworld=np.ascontiguousarray(h.forward(q,local,weights,row,t,item["posemap"]),dtype="<f4")
    res=incremental(current_worlds[i],newworld,current_tables[i]);cnt=int(res["count"])
    if cnt>before_counts[i]: valid=False;break
    warea,_=area_data(newworld);oldarea,_=area_data(current_worlds[i])
    if np.any(warea/np.maximum(oldarea,1e-30)<0.2): valid=False;break
    tab={"count":cnt,"triangle_pairs":sorted([list(map(int,x)) for x in res["triangle_pairs"]]),"degenerate_face_rows":[]}
    after_tables.append(tab);after_worlds.append(newworld)
    records.append({"group":item["group"],"arm":item["arm"],"step":item["step"],"count":cnt,"pairs":tab["triangle_pairs"]})
   if not valid: continue
   oldsum=sum(before_counts);newsum=sum(x["count"] for x in after_tables)
   if newsum>=oldsum: continue
   rec={"iteration":iteration,"trial_index":trial_count,"group":gname,"support_vertices":list(map(int,group)),"direction":meta,"amount_m":amount,"moved_vertices":moved.tolist(),"max_step_m":float(lengths.max()),"max_total_delta_from_union_m":float(cum.max()),"source_min_area_ratio":float(ratio.min()),"source_signed_volume_m3":vol,"baseline_counts":before_counts,"candidate_counts":[int(x["count"]) for x in after_tables],"baseline_total":oldsum,"candidate_total":newsum,"pose_results":records,"exact_incremental_all32_contexts":True}
   trial_records.append(rec);score=(newsum,max(x["count"] for x in after_tables),float(cum.max()))
   if best is None or score<best[0]: best=(score,q,after_tables,after_worlds,rec)
   if newsum==0: break
  if trial_count>=120 or (best and best[0][0]==0): break
 report["proposals"].append({"iteration":iteration,"focus_pose":{"index":focus,"group":pose["group"],"step":pose["step"]},"baseline_counts":counts,"focus_pair_count":len(focus_pairs),"proposal_count":len(proposals),"evaluated_trial_count":trial_count,"improving_trials":trial_records,"selected":None if best is None else best[4]})
 if best is None:
  emit("no_monotone_candidate",iteration=iteration,baseline_counts=counts,proposals=len(proposals),evaluated=trial_count);save();break
 _,p,current_tables,current_worlds,chosen=best
 patch=OUT/f"stable-141-position-correction-iteration-{iteration}.npz"
 v6=np.column_stack((p,h.vertex_normals(p,faces))).astype("<f4")
 np.savez(patch,vertices6=v6,faces=faces,weights=weights,binding_indices=local,face_origins=orig)
 chosen["candidate_path"]=str(patch);chosen["candidate_sha256"]=sha(patch)
 report["proposals"][-1]["selected"]=chosen
 report["latest_unadmitted_candidate"]={"path":str(patch),"sha256":sha(patch),"max_delta_from_union_m":float(np.linalg.norm(p.astype(float)-p0.astype(float),axis=1).max()),"pose_counts":[int(x["count"]) for x in current_tables]}
 emit("accepted_partial_geometry_step",iteration=iteration,old_total=chosen["baseline_total"],new_total=chosen["candidate_total"],per_pose_counts=[int(x["count"]) for x in current_tables],candidate_path=str(patch),candidate_sha256=sha(patch));save()
 if chosen["candidate_total"]==0:
  report["selected"]={"candidate_path":str(patch),"candidate_sha256":sha(patch),"max_delta_from_union_m":float(np.linalg.norm(p.astype(float)-p0.astype(float),axis=1).max()),"all32_self_clear":True}
  break
report["final_pose_counts"]=[int(x["count"]) for x in current_tables]
report["all32_self_clear"]=all(x["count"]==0 for x in current_tables)
report["target_gate_performed"]=bool(report["all32_self_clear"])
if report["all32_self_clear"]: report["note"]="Self gate passed, but external target scan remains to be run before admission."
report["complete"]=True;report["elapsed_seconds"]=time.monotonic()-start
report["inputs_unchanged"]=all(Path(k).is_file() and sha(k)==v for k,v in pins.items())
save();emit("complete",inputs_unchanged=report["inputs_unchanged"],all32_self_clear=report["all32_self_clear"],final_counts=report["final_pose_counts"],selected=report["selected"] is not None,elapsed_seconds=report["elapsed_seconds"])

