#!/usr/bin/env python3
from __future__ import annotations
import argparse,csv,hashlib,importlib.util,json,sys,time
from pathlib import Path
import numpy as np

A=Path('/Users/numi/numi-human-retained-delivery-20261009/anatomy-completion-1276')
C=A/'forearm054-native-diagnostic-009-refined085'
OLD=A/'forearm-shared-field-native-diagnostic-008'
P7=A/'forearm054-native-diagnostic-007-candidate060'
RUN=C/'baseline/native-run'; OLD_RUN=OLD/'baseline/native-run'
T=C/'assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue'
OLD_T=OLD/'assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue'
CAND=Path('/Users/numi/numi-human-fds132-m6-1350/attempt-085-interface-refinement-2mm-001/result-001/candidate.pkl')
FIELD=Path('/Users/numi/numi-human-fds132-m6-1350/attempt-088-registered-route-field-refined-2mm-001/result-001/route-anchor-reference-field-001.npz')
H=A/'neck-back-retained-pose-audit-002/forward_all_positive_weights.py'
PUB=Path('/Users/numi/numi-human-left-pq-publication-1344/src')
STEPS=[3807,0,4767,5023,5599,6207,7423,8000]
TARGETS=(132,134)

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(4*1024*1024),b''): h.update(b)
 return h.hexdigest()
def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def jdefault(x):
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,Path):return str(x)
 raise TypeError(type(x).__name__)
def parity(tri):
 inv=sum(int(tri[i]>tri[j]) for i in range(3) for j in range(i+1,3))
 return -1 if inv%2 else 1
def volume_signs(xyz,faces,components):
 out=[]
 x=np.asarray(xyz,dtype=np.float64)
 for comp in components:
  fc=faces[np.asarray(comp,dtype=np.int64)]
  used=np.unique(fc)
  tri=x[fc]-x[used].mean(axis=0,dtype=np.float64)
  out.append(float(np.einsum('ij,ij->i',tri[:,0],np.cross(tri[:,1],tri[:,2])).sum()/6.))
 return out
def sign(v):
 return ['positive' if x>0 else 'negative' if x<0 else 'zero' for x in v]
def build_union(surfaces,gids,coords):
 occ={};oriented_faces=[]
 index_by_sid={sid:{g:i for i,g in enumerate(gids[sid])} for sid in TARGETS}
 for sid in TARGETS:
  for fi,face in enumerate(np.asarray(surfaces[sid]['faces'],dtype=np.int64)):
   trip=tuple(int(gids[sid][int(v)]) for v in face);key=tuple(sorted(trip))
   occ.setdefault(key,[]).append((sid,fi,trip))
   oriented_faces.append((sid,fi,trip,key))
 shared=[];remove=set();errors=[]
 for key,items in occ.items():
  if len(items)==1:continue
  if len(items)==2 and {items[0][0],items[1][0]}==set(TARGETS):
   if parity(items[0][2])==-parity(items[1][2]):
    shared.append(key);remove.add((items[0][0],items[0][1]));remove.add((items[1][0],items[1][1]))
   else:errors.append({'global_face_ids':list(key),'reason':'shared_orientation_not_opposite','occurrences':[[a,b,list(c)] for a,b,c in items]})
  else:errors.append({'global_face_ids':list(key),'reason':'duplicate_or_unpaired_face','occurrences':[[a,b,list(c)] for a,b,c in items]})
 remain=[x for x in oriented_faces if (x[0],x[1]) not in remove]
 used=sorted({g for _,_,trip,_ in remain for g in trip})
 ix={g:i for i,g in enumerate(used)};xyz=[]
 for gid in used:
  choices=[]
  for sid in TARGETS:
   ri=index_by_sid[sid].get(gid)
   if ri is not None:choices.append(np.asarray(coords[sid][ri],dtype='<f4'))
  if not choices:
   errors.append({'global_vertex_id':gid,'reason':'coordinate_missing'});xyz.append(np.zeros(3,dtype='<f4'));continue
  first=choices[0]
  if any(q.tobytes()!=first.tobytes() for q in choices[1:]):
   errors.append({'global_vertex_id':gid,'reason':'shared_coordinates_not_bitwise_equal'})
  xyz.append(first)
 faces=np.asarray([[ix[g] for g in trip] for _,_,trip,_ in remain],dtype=np.int64)
 face_sources=[(sid,fi) for sid,fi,_,_ in remain]
 return np.asarray(xyz,dtype='<f4'),faces,face_sources,{'shared_face_pairs':len(shared),'removed_face_count':len(remove),'remaining_face_count':len(faces),'remaining_vertex_count':len(used),'interface_errors':errors,'shared_vertex_count':len(set(gids[132])&set(gids[134]))}
def summarize_topology(t):
 return {k:t.get(k) for k in ('closed_oriented_manifold_candidate','vertex_count','face_count','edge_count','face_component_count','boundary_edge_count','boundary_loop_count','euler_characteristic')}
def exact_audit(h,xyz,faces,ci):
 rec,dg=h.exact_rows(np.asarray(xyz,dtype='<f4'),np.asarray(faces,dtype=np.int64),ci)
 if rec is None or dg:return None,dg,[]
 a=ci._audit_pair(rec,rec,same_surface=True)
 return int(a['count']),dg,a.get('triangle_pairs',[])
def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--max-rss-gib',type=float,default=2.5)
 args=ap.parse_args()
 try:
  import resource
  lim=int(args.max_rss_gib*1024**3);resource.setrlimit(resource.RLIMIT_AS,(lim,lim))
 except Exception:pass
 out=C/'native-audit-003';out.mkdir(exist_ok=False);rp=out/'report.json'
 report={'schema':'numi.human.forearm-shared-route-field-native-009-refined085-audit.v1',
  'scope':'Experimental native diagnostic for refined085 children 132/134. Exact child and joined-union self/topology checks are performed on native accepted captures, beginning with step 3807. Each capture is compared to native008 at the same step for the 866 non-target surfaces, all accepted body poses, and physiology. This report does not admit anatomy or qualify all25 poses.',
  'status':'running','complete':False,'checks':{},'captures':{},'failures':[],'pins':{}}
 def save():rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=jdefault)+'\n')
 def check(name,ok,**fields):
  report['checks'][name]={'passed':bool(ok),**fields}
  if not ok:report['failures'].append(name)
  save()
 sys.path.insert(0,str(PUB))
 from numilab_human import cardiac_cavity_intersections as ci,common_atlas_skin_clearance as ca,passive_attachment_composition as pc
 from numilab_human.cardiac_cavity_geometry import analyze_topology
 h=module('forearm054_009_audit_forward',H)
 prep=json.loads((C/'preparation.json').read_text());decl=json.loads((C/'baseline/run-declaration.json').read_text())
 ex=json.loads((C/'baseline/execution.json').read_text());inv=json.loads((RUN/'invocation.json').read_text());meta=json.loads((RUN/'run-metadata.json').read_text())
 # The root execution receipt already records the full 86-input check; independently rehash
 # the candidate, field, target payload, extension and declarations used by this audit.
 prep_pins={C/'baseline/run-declaration.json':prep.get('run_declaration_sha256'),
  T:prep.get('child_payload_sha256'),C/'assets/shared-field-carriers.nhtissue':prep.get('carrier_payload_sha256'),
  C/'passive-tissue-parent-bindings.json':prep.get('parent_extension_sha256'),
  C/'carrier-roundtrip-report.json':prep.get('carrier_roundtrip_report_sha256'),
  CAND:prep.get('candidate_sha256'),FIELD:prep.get('route_field_sha256'),
  Path(prep.get('source_ancestry_path','')):prep.get('source_ancestry_sha256'),
  Path(prep.get('registered_rest_preflight_path','')):prep.get('registered_rest_preflight_sha256')}
 pin_bad=[]
 for p,expected in prep_pins.items():
  observed=sha(p) if p.is_file() else None
  if expected is not None and observed!=expected:pin_bad.append({'path':str(p),'expected':expected,'observed':observed})
 check('prepared_inputs_pinned_and_not_admitted',not pin_bad and prep.get('anatomical_admission_claimed') is False and prep.get('status')=='prepared_experimental_not_admitted',
  schema=prep.get('schema'),admission_claimed=prep.get('anatomical_admission_claimed'),preparation_status=prep.get('status'),rehash_count=len(prep_pins),pin_mismatches=pin_bad,root_verified_immutable_input_count=prep.get('immutable_input_count'))
 check('native_run_completed_as_declared',ex.get('returncode')==0 and ex.get('timed_out') is False and meta.get('exit_code')==0,
  returncode=ex.get('returncode'),timed_out=ex.get('timed_out'),wall_seconds=ex.get('wall_seconds'),native_exit_code=meta.get('exit_code'),accepted_steps=meta.get('accepted_steps'),simulation_time_s=meta.get('simulation_time_s'))
 check('invocation_and_source_unchanged',inv.get('argv')==decl.get('owner_cli_preview',{}).get('native_argv') and inv.get('environment')==decl.get('owner_cli_preview',{}).get('recorded_invocation_environment') and ex.get('native_argv_matches_prepared_cli_preview') is True and ex.get('native_environment_matches_prepared_cli_preview') is True and not ex.get('changed_inputs') and not meta.get('source_files_changed_during_run'),
  argv_match=ex.get('native_argv_matches_prepared_cli_preview'),environment_match=ex.get('native_environment_matches_prepared_cli_preview'),changed_input_count=len(ex.get('changed_inputs',[])),source_files_changed=meta.get('source_files_changed_during_run'))
 with np.load(FIELD,allow_pickle=False) as z:
  field={k:z[k].copy() for k in z.files}
 src={};gids={};faces={};rest={};weights={}
 geometry_match=True;source_details={}
 for sid in TARGETS:
  g=field[f'stable{sid}_global_vertex_ids'];f=field[f'stable{sid}_faces'];x=field[f'stable{sid}_rest_positions_m'];w=field[f'stable{sid}_core_weights']
  src[sid]={'global_vertex_ids':g,'faces':f,'vertices_float32_m':x,'core_weights_float64':w}
  g=np.asarray(g,dtype=np.uint64);f=np.asarray(f,dtype=np.int64);x=np.asarray(x,dtype='<f4');w=np.asarray(w,dtype='<f8')
  geometry_match &= g.ndim==1 and f.ndim==2 and f.shape[1]==3 and x.shape==(len(g),3) and w.shape[0]==len(g) and len(set(map(int,g)))==len(g)
  gids[sid]=list(map(int,g));faces[sid]=f;rest[sid]=x;weights[sid]=w
  source_details[str(sid)]={'vertices':len(g),'faces':len(f),'unique_global_ids':len(set(gids[sid])),'weight_lanes':int(w.shape[1]),'field_arrays_present':True}
 check('candidate085_routefield088_arrays_well_formed',geometry_match and sha(CAND)==prep.get('candidate_sha256') and sha(FIELD)==prep.get('route_field_sha256'),
  candidate_sha256=sha(CAND),route_field_sha256=sha(FIELD),rows=source_details,refinement_target_edge_mm=2)
 old_tissue=pc._read_nhtiss4(OLD_T);new_tissue=pc._read_nhtiss4(T)
 oldrec={int(r[6]):r for r in old_tissue['records']};newrec={int(r[6]):r for r in new_tissue['records']}
 raw_geometry_ok=True;raw_geometry={}
 for sid in TARGETS:
  r=pc._row_slices(new_tissue,newrec[sid]);xyz=np.frombuffer(r['vertex_bytes'],dtype='<f4').reshape((-1,14))[:,:3];rf=np.asarray(r['local_faces'],dtype=np.int64)
  ok=xyz.shape==rest[sid].shape and np.array_equal(xyz,rest[sid]) and np.array_equal(rf,faces[sid])
  raw_geometry_ok &= ok
  raw_geometry[str(sid)]={'nhtiss_vertices':len(xyz),'candidate_vertices':len(rest[sid]),'nhtiss_faces':len(rf),'candidate_faces':len(faces[sid]),'xyz_f32_exact':xyz.shape==rest[sid].shape and np.array_equal(xyz,rest[sid]),'faces_exact':np.array_equal(rf,faces[sid])}
 check('refined_candidate_geometry_matches_child_payload',raw_geometry_ok,rows=raw_geometry,child_payload_sha256=sha(T))
 other_rows_bad=[]
 for sid,r in oldrec.items():
  if sid in TARGETS:continue
  if sid not in newrec or not pc._row_local_equal(pc._row_slices(old_tissue,r),pc._row_slices(new_tissue,newrec[sid])):
   other_rows_bad.append(sid)
 check('non_target_nhtiss_source_rows_exact_to_008',not other_rows_bad,matched_count=len(oldrec)-len(TARGETS)-len(other_rows_bad),expected=len(oldrec)-len(TARGETS),mismatched_stable_ids=other_rows_bad[:30])
 shared=sorted(set(gids[132])&set(gids[134]))
 gix={sid:{g:i for i,g in enumerate(gids[sid])} for sid in TARGETS}
 seam_ref_exact=True;weight_ref_exact=True
 for gid in shared:
  i=gix[132][gid];j=gix[134][gid]
  seam_ref_exact &= rest[132][i].tobytes()==rest[134][j].tobytes()
  weight_ref_exact &= weights[132][i].tobytes()==weights[134][j].tobytes()
 check('shared_refined_interface_id_and_carrier_weights_canonical',len(shared)==4588 and seam_ref_exact and weight_ref_exact,
  shared_global_vertex_count=len(shared),expected_shared_global_vertex_count=4588,rest_coordinates_bitwise_equal=bool(seam_ref_exact),binary64_core_weights_bitwise_equal=bool(weight_ref_exact))
 # Candidate-derived union is the winding/topology reference; negative cavity components stay negative.
 union_rest,union_faces,union_sources,union_meta=build_union(src,gids,rest)
 union_rest_top=analyze_topology(union_rest.astype(float).tolist(),union_faces.tolist())
 union_rest_vol=volume_signs(union_rest,union_faces,union_rest_top.get('face_components',[]))
 child_rest_top={};child_rest_vol={}
 for sid in TARGETS:
  tt=analyze_topology(rest[sid].astype(float).tolist(),faces[sid].tolist())
  child_rest_top[sid]=tt;child_rest_vol[sid]=volume_signs(rest[sid],faces[sid],tt.get('face_components',[]))
 expected_union_ok=(not union_meta['interface_errors'] and union_meta['shared_face_pairs']==7010 and union_meta['removed_face_count']==14020 and union_meta['remaining_face_count']==40624 and union_meta['remaining_vertex_count']==20208 and union_rest_top.get('closed_oriented_manifold_candidate') is True and len(union_rest_top.get('face_components',[]))==12 and 'zero' not in sign(union_rest_vol))
 check('refined085_source_union_definition_and_topology',expected_union_ok,
  construction={k:v for k,v in union_meta.items() if k!='interface_errors'},interface_error_count=len(union_meta['interface_errors']),topology=summarize_topology(union_rest_top),component_signs=sign(union_rest_vol),component_signed_volumes_m3=union_rest_vol)
 # Compare accepted physiology directly to native008 at identical capture grid.
 def readcsv(p):
  with p.open(newline='') as f:return list(csv.DictReader(f))
 trace=readcsv(RUN/'resting-coupled.csv');old_trace=readcsv(OLD_RUN/'resting-coupled.csv')
 physiology_equal=trace==old_trace
 check('physiology_trace_exact_008_same_grid',physiology_equal,row_count=len(trace),native008_row_count=len(old_trace),last_step=int(float(trace[-1]['step'])) if trace else None,last_time_s=float(trace[-1]['time_s']) if trace else None)
 request_keys,*_=ca._load_target_inventory(h.INV)
 request_keys=set(request_keys)|{(51005,s) for s in (151,152,159,160,161,162,163,164)}
 expected_inventory=request_keys|{(51007,1)}
 target_keys={(51005,132),(51005,134)}
 available=[]
 for step in STEPS:
  p=RUN/'accepted-geometry'/f'step-{step}.mrvpack';r=p.with_suffix('.receipt.json')
  if p.is_file() and r.is_file():available.append(step)
 check('all_native_grid_captures_present',set(available)==set(STEPS),available_steps=sorted(available),requested_steps=sorted(STEPS))
 for step in STEPS:
  t0=time.monotonic();pack=RUN/'accepted-geometry'/f'step-{step}.mrvpack';rcpt=pack.with_suffix('.receipt.json')
  oldpack=OLD_RUN/'accepted-geometry'/f'step-{step}.mrvpack';oldrcpt=oldpack.with_suffix('.receipt.json')
  if not pack.is_file() or not rcpt.is_file() or not oldpack.is_file() or not oldrcpt.is_file():
   report['captures'][str(step)]={'failed':'capture_or_samegrid_comparator_missing'};check(f'capture_{step}_available',False);continue
  info=json.loads(rcpt.read_text());oldinfo=json.loads(oldrcpt.read_text())
  pos,surfs,_=ca._pack_surfaces(pack,request_keys);oldpos,oldsurfs,_=ca._pack_surfaces(oldpack,request_keys)
  inventory_ok=set(surfs)==expected_inventory and len(surfs)==868
  old_inventory_ok=set(oldsurfs)==expected_inventory and len(oldsurfs)==868
  pose_list=info.get('accepted_body_poses',[]);old_pose_list=oldinfo.get('accepted_body_poses',[])
  pose_ok=len(pose_list)==157 and pose_list==old_pose_list
  other_bad=[]
  for key in set(surfs)-target_keys:
   if key not in oldsurfs:other_bad.append([*key,'missing_008']);continue
   fa=np.asarray(surfs[key]['faces'],dtype=np.int64);fb=np.asarray(oldsurfs[key]['faces'],dtype=np.int64)
   if fa.shape!=fb.shape or not np.array_equal(pos[fa],oldpos[fb]):other_bad.append([*key,'geometry_diff'])
  other_ok=len(set(surfs)-target_keys)==866 and old_inventory_ok and not other_bad
  valid_receipt=info.get('physical_endpoint')=='accepted' and info.get('pack_file_sha256')==sha(pack)
  row_world={};row_results={}
  for sid in TARGETS:
   key=(51005,sid);native_faces=np.asarray(surfs[key]['faces'],dtype=np.int64);local=faces[sid]
   delta=native_faces-local
   layout_ok=native_faces.shape==local.shape and delta.size>0 and bool(np.all(delta==delta.flat[0]))
   if layout_ok:
    start=int(delta.flat[0]);world=pos[start:start+len(gids[sid])].astype('<f4',copy=True);row_world[sid]=world
    topo=analyze_topology(world.astype(float).tolist(),local.tolist())
    selfcount,dg,pairs=exact_audit(h,world,local,ci)
    vols=volume_signs(world,local,topo.get('face_components',[]))
    rest_signs=sign(child_rest_vol[sid]);pose_signs=sign(vols)
    winding_ok=pose_signs==rest_signs and 'zero' not in pose_signs
    expected_components=len(child_rest_top[sid].get('face_components',[]))
    topology_ok=topo.get('closed_oriented_manifold_candidate') is True and len(topo.get('face_components',[]))==expected_components
    passed=topology_ok and selfcount==0 and len(dg)==0 and winding_ok
    row_results[str(sid)]={'vertex_count':len(world),'face_count':len(local),'face_layout_matches_candidate':True,'closed_oriented_manifold':topology_ok,
     'topology':summarize_topology(topo),'component_signed_volumes_m3':vols,'source_component_signs':rest_signs,'component_signs':pose_signs,'winding_matches_source':winding_ok,
     'degenerate_face_count':len(dg),'degenerate_face_ids':[int(x) for x in dg[:20]],'exact_self_pair_count':selfcount,'exact_self_pairs':[list(map(int,x)) for x in pairs[:20]],'geometry_pass':passed}
   else:row_results[str(sid)]={'face_layout_matches_candidate':False,'geometry_pass':False,'reason':'native faces are not candidate faces plus constant offset'}
  seam_count=0;seam_ok=False;max_gap=None
  if set(row_world)==set(TARGETS):
   a=row_world[132][[gix[132][g] for g in shared]];b=row_world[134][[gix[134][g] for g in shared]]
   seam_count=int(np.count_nonzero(np.all(a==b,axis=1)))
   gaps=np.linalg.norm(a.astype(np.float64)-b.astype(np.float64),axis=1)*1e6;max_gap=float(gaps.max()) if len(gaps) else None
   seam_ok=seam_count==len(shared)
  native_union_ok=False;union_details={}
  if set(row_world)==set(TARGETS):
   ux,uf,usrc,umeta=build_union(src,gids,row_world)
   utop=analyze_topology(ux.astype(float).tolist(),uf.tolist())
   use_self,udg,upairs=exact_audit(h,ux,uf,ci)
   uvol=volume_signs(ux,uf,utop.get('face_components',[]));usigns=sign(uvol)
   winding=usigns==sign(union_rest_vol) and 'zero' not in usigns
   topology_ok=utop.get('closed_oriented_manifold_candidate') is True and len(utop.get('face_components',[]))==12 and utop.get('vertex_count')==20208 and utop.get('face_count')==40624
   pairs_detail=[]
   for pair in upairs[:20]:
    q=[]
    for fi in pair:
     if 0<=int(fi)<len(usrc):q.append({'union_face':int(fi),'source_surface':int(usrc[int(fi)][0]),'source_face':int(usrc[int(fi)][1])})
    pairs_detail.append(q)
   native_union_ok=(not umeta['interface_errors'] and umeta['shared_face_pairs']==7010 and umeta['removed_face_count']==14020 and umeta['remaining_face_count']==40624 and umeta['remaining_vertex_count']==20208 and seam_ok and len(udg)==0 and use_self==0 and topology_ok and winding)
   union_details={'construction':{k:v for k,v in umeta.items() if k!='interface_errors'},'interface_error_count':len(umeta['interface_errors']),
    'topology':summarize_topology(utop),'component_signed_volumes_m3':uvol,'component_signs':usigns,'source_component_signs':sign(union_rest_vol),'winding_matches_source':winding,
    'degenerate_face_count':len(udg),'degenerate_face_ids':[int(x) for x in udg[:20]],'exact_self_pair_count':use_self,'exact_self_pairs':pairs_detail,'union_pass':native_union_ok}
  else:union_details={'union_pass':False,'reason':'missing one or both native target rows'}
  entry={'pack_sha256':sha(pack),'receipt_sha256':sha(rcpt),'capture_receipt_valid':valid_receipt,
   'native_inventory_count':len(surfs),'inventory_868_exact':inventory_ok,'samegrid_008_inventory_868_exact':old_inventory_ok,
   'accepted_body_pose_count':len(pose_list),'accepted_body_poses_exact_008':pose_ok,'unchanged_surface_count':866-len(other_bad),'unchanged_surfaces_exact_008':other_ok,'unchanged_surface_mismatches':other_bad[:30],
   'physiology_trace_exact_008':physiology_equal,'shared_seam_vertex_count':len(shared),'shared_seam_bitwise_equal_count':seam_count,'shared_seam_max_gap_um':max_gap,'shared_seam_pass':seam_ok,
   'children':row_results,'joined_union':union_details,'audit_wall_seconds':time.monotonic()-t0}
  report['captures'][str(step)]=entry
  local_pass=all(x.get('geometry_pass') is True for x in row_results.values())
  check(f'capture_{step}_children_and_union_vs008',valid_receipt and inventory_ok and pose_ok and other_ok and physiology_equal and seam_ok and local_pass and native_union_ok,
    capture_step=step,capture_receipt_valid=valid_receipt,inventory_868_exact=inventory_ok,poses_157_equal_008=pose_ok,unchanged_866_equal_008=other_ok,physiology_equal_008=physiology_equal,
    seam_equal=seam_ok,children={k:{q:v for q,v in d.items() if q in ('geometry_pass','exact_self_pair_count','degenerate_face_count','closed_oriented_manifold','component_signs','source_component_signs')} for k,d in row_results.items()},joined_union={k:v for k,v in union_details.items() if k in ('union_pass','exact_self_pair_count','degenerate_face_count','component_signs','source_component_signs','topology')},audit_wall_seconds=entry['audit_wall_seconds'])
  print(json.dumps({'step':step,'seconds':entry['audit_wall_seconds'],'children':{k:{q:v for q,v in d.items() if q in ('geometry_pass','exact_self_pair_count','degenerate_face_count')} for k,d in row_results.items()},'union':{k:v for k,v in union_details.items() if k in ('union_pass','exact_self_pair_count','degenerate_face_count','component_signs')},'failed_check_count':len(report['failures'])}),flush=True)
 report['available_capture_steps']=sorted(available)
 report['native_execution']={'execution_json':str(C/'baseline/execution.json'),'execution_sha256':sha(C/'baseline/execution.json'),'run_metadata_sha256':sha(RUN/'run-metadata.json'),'native_log_sha256':sha(RUN/'native.log'),'returncode':ex.get('returncode'),'wall_seconds':ex.get('wall_seconds'),'native_exit_code':meta.get('exit_code'),'accepted_steps':meta.get('accepted_steps'),'simulation_time_s':meta.get('simulation_time_s'),'native_argv_matches_prepared':ex.get('native_argv_matches_prepared_cli_preview'),'native_environment_matches_prepared':ex.get('native_environment_matches_prepared_cli_preview')}
 report['pins']={str(p):sha(p) for p in [C/'preparation.json',C/'baseline/run-declaration.json',C/'baseline/execution.json',T,C/'assets/shared-field-carriers.nhtissue',C/'passive-tissue-parent-bindings.json',C/'resting-anatomy-receipt.json',C/'carrier-roundtrip-report.json',C/'source-ancestry-proof.json',C/'rest-registration-preflight.json',CAND,FIELD,OLD/'preparation.json',OLD/'baseline/run-declaration.json',OLD_RUN/'resting-coupled.csv',RUN/'resting-coupled.csv'] if p.is_file()}
 report['complete']=len(report['captures'])==len(STEPS)
 report['status']='experimental_native009_refined085_full_grid_clear_not_admitted' if report['complete'] and not report['failures'] else ('experimental_native009_refined085_full_grid_failed' if report['complete'] else 'native009_audit_incomplete')
 save()
 print(json.dumps({'report':str(rp),'status':report['status'],'failed_checks':report['failures'],'available_steps':sorted(map(int,report['captures']))},indent=2),flush=True)
if __name__=='__main__':main()

