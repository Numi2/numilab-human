#!/usr/bin/env python3
import gc, hashlib, json, math, os, pickle, resource, signal, struct, subprocess, sys, threading, time
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path
import numpy as np

os.environ.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1")
ROOT=Path("/Users/n/numi-human-fds132-m6-1350")
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276")
R=Path("/Users/n/numi-human-retained-delivery-20261009")
OUT=ROOT/"attempt-088-registered-route-field-refined-2mm-001"
OUT.mkdir(parents=True, exist_ok=False)
RES=OUT/"result-001"; RES.mkdir()
C=ROOT/"attempt-085-interface-refinement-2mm-001/result-001/candidate.pkl"
CR=C.parent/"report.json"
CK=CR
MAP=ROOT/"attempt-061-step0-capture-remesh-diagnostic/candidate060-adapted-source-parent-map-v2.pkl"
MAPR=ROOT/"attempt-061-step0-capture-remesh-diagnostic/candidate060-adapted-source-parent-map-report-v2.json"
ROUTE=ROOT/"attempt-050/arrangement-001/diagnostic-061/fds-fdp-source-routes-061.json"
ROUTE_SCRIPT=ROOT/"attempt-050/arrangement-001/diagnostic-061/trace_fds_fdp_source_routes_061.py"
ROUTE_CORE=ROOT/"attempt-050/arrangement-001/diagnostic-060/core-name-provenance-060.json"
T=A/"temporalis164-native-m6-002/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
T0=A/"left-fds-native-m6-001/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
TISS_MAN=T.with_suffix(".manifest.json")
H=A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
RIG=Path("/Users/n/numi-human-resting-build-20261005/resting-scene-20261005/Build/skin-source-fit-recovery-20261004/myosim-fullbody-core-reference.nhrigid")
ARCH=Path("/Users/n/numi-human-retained-delivery-20261009/skin-source-binding-1202/source-inputs/myosim/myo_sim-33c89c2b.tar.gz")
NATIVE=A/"forearm054-native-diagnostic-007-candidate060"
NATIVE_UNION=NATIVE/"native-union-audit-002/report.json"
CURRENT_CAP=NATIVE/"baseline/native-run/accepted-geometry"
PAIR=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
OLD_CAP=PAIR/"baseline/native-run/accepted-geometry"
CI=Path("/Users/n/numi-human-anatomy-completion-1276/src/numilab_human/cardiac_cavity_intersections.py")
START=time.monotonic()
RSS_LIMIT_KIB=int(2.5*1024*1024)
def watchdog():
    while True:
        try:
            rss=int(subprocess.check_output(["ps","-o","rss=","-p",str(os.getpid())],text=True).strip() or "0")
            if rss>RSS_LIMIT_KIB:
                print(json.dumps({"fatal":"RSS watchdog exceeded 2.5 GiB","rss_kib":rss}),flush=True)
                os.kill(os.getpid(),signal.SIGTERM)
        except Exception:
            pass
        time.sleep(2)
threading.Thread(target=watchdog,daemon=True).start()
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(8*1024*1024),b""): h.update(b)
    return h.hexdigest()
def req(x,m):
    if not x: raise RuntimeError(m)
def save_json(p,obj):
    q=Path(str(p)+".tmp")
    q.write_text(json.dumps(obj,sort_keys=True,indent=2,default=lambda z:z.item() if isinstance(z,np.generic) else str(z))+"\n")
    q.replace(p)
def loadmod(n,p):
    import importlib.util
    s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);sys.modules[n]=m;s.loader.exec_module(m);return m
def F32(x): return np.float32(x)
def cross32(a,b):
    f=np.float32
    return np.asarray([f(f(a[1]*b[2])-f(a[2]*b[1])),f(f(a[2]*b[0])-f(a[0]*b[2])),f(f(a[0]*b[1])-f(a[1]*b[0]))],dtype=np.float32)
def rotate_cxx(q,p):
    q=np.asarray(q,dtype=np.float32);p=np.asarray(p,dtype=np.float32);a=q[:3]
    cr=cross32(a,p);tw=np.asarray([F32(F32(2)*v) for v in cr],dtype=np.float32)
    corr=np.asarray([F32(F32(F32(q[3]*tw[0])+F32(a[1]*tw[2]))-F32(a[2]*tw[1])),
                     F32(F32(F32(q[3]*tw[1])+F32(a[2]*tw[0]))-F32(a[0]*tw[2])),
                     F32(F32(F32(q[3]*tw[2])+F32(a[0]*tw[1]))-F32(a[1]*tw[0]))],dtype=np.float32)
    return np.asarray([F32(p[i]+corr[i]) for i in range(3)],dtype=np.float32)
def rotate_metal(q,p):
    q=np.asarray(q,dtype=np.float32);p=np.asarray(p,dtype=np.float32);a=q[:3]
    cr=cross32(a,p)
    inner=np.asarray([F32(cr[i]+F32(q[3]*p[i])) for i in range(3)],dtype=np.float32)
    out=cross32(a,inner)
    return np.asarray([F32(p[i]+F32(F32(2)*out[i])) for i in range(3)],dtype=np.float32)
def rotate_double(q,v):
    x,y,z,w=[float(a) for a in q];vx,vy,vz=[float(a) for a in v]
    cx=y*vz-z*vy;cy=z*vx-x*vz;cz=x*vy-y*vx
    return np.asarray([vx+2.0*(w*cx+y*cz-z*cy),
                       vy+2.0*(w*cy+z*cx-x*cz),
                       vz+2.0*(w*cz+x*cy-y*cx)],dtype=np.float64)
def fma32(w,x,a):
    return np.asarray([F32(float(w)*float(x[k])+float(a[k])) for k in range(3)],dtype=np.float32)
def parse_nhrigid(path,archive):
    raw=Path(path).read_bytes()
    magic,pabi,eabi,source_count,body_count,joint_count,nq,nv,root,virtual,reserved,srcsha=struct.unpack_from("<8s10I32s",raw,0)
    req(magic==b"NHRIGID2" and pabi==1 and nq==nv+1,"NHRIGID header invalid")
    req(srcsha.hex()==sha(archive),"NHRIGID embedded source archive mismatch")
    body_off=224;joint_off=body_off+160*body_count;dof_off=joint_off+144*joint_count
    q_off=dof_off+64*nv
    q=np.frombuffer(raw,dtype="<f4",count=nq,offset=q_off).copy()
    v_off=q_off+4*nq;map_off=v_off+4*nv
    source_to_core=np.frombuffer(raw,dtype="<u4",count=source_count,offset=map_off).copy()
    pose_off=map_off+4*source_count;poses={}
    for si,core in enumerate(source_to_core):
        x,y,z,qx,qy,qz,qw=struct.unpack_from("<7f",raw,pose_off+28*si)
        poses[int(core)]=(np.asarray([x,y,z],dtype=np.float32),np.asarray([qx,qy,qz,qw],dtype=np.float32))
    req(len(poses)==source_count and pose_off+28*source_count==len(raw),"NHRIGID body-pose table layout mismatch")
    return {"poses":poses,"q":q,"source_count":source_count,"engine_body_count":body_count,"joint_count":joint_count,"nq":nq,"nv":nv,"header_sha":srcsha.hex()}
def field_for_points(points,control_xyz,control_core,core_ids,power=2.0):
    points=np.asarray(points,dtype=np.float64)
    controls=np.asarray(control_xyz,dtype=np.float64)
    out=np.zeros((len(points),len(core_ids)),dtype=np.float64)
    cidx={int(k):i for i,k in enumerate(core_ids)}
    core_idx=np.asarray([cidx[int(k)] for k in control_core],dtype=np.int64)
    # One global spatial Shepard kernel is applied at each query coordinate; route controls are deduplicated before this call.
    for i,p in enumerate(points):
        d2=np.sum((controls-p[None,:])**2,axis=1)
        zero=np.flatnonzero(d2==0.0)
        if len(zero):
            nw=np.zeros(len(controls),dtype=np.float64);nw[zero]=1.0/len(zero)
        else:
            mind=float(np.min(d2))
            raw=np.power(mind/d2,0.5*float(power))
            den=math.fsum(float(x) for x in raw)
            if not math.isfinite(den) or den<=0: raise RuntimeError("Shepard normalization is invalid")
            nw=raw/den
        cw=np.zeros(len(core_ids),dtype=np.float64)
        for j,w in enumerate(nw): cw[core_idx[j]]+=float(w)
        # Normalize in stable core order and close the partition of unity exactly in binary64.
        total=math.fsum(float(x) for x in cw)
        cw/=total
        if len(cw)>1:
            cw[-1]=1.0-sum(float(x) for x in cw[:-1])
        if np.any(cw<0) or abs(sum(float(x) for x in cw)-1.0)>1e-12:
            raise RuntimeError("aggregated core field is not a positive partition of unity")
        out[i]=cw
    return out
def unit_field_tests(control_xyz,control_core,core_ids):
    ids=sorted(set(int(x) for x in control_core))
    w=field_for_points(np.asarray(control_xyz[:1]),np.asarray(control_xyz[:1]),np.asarray(control_core[:1]),[int(control_core[0])])
    req(w.shape==(1,1) and abs(w[0,0]-1.0)<1e-15,"unique exact-anchor interpolation unit failed")
    # A synthetic, deliberate exact coordinate collision is handled by equal shares among distinct authored controls.
    pts=np.asarray([[0.,0.,0.],[0.,0.,0.]])
    cores=np.asarray([111,222],dtype=np.int64)
    w2=field_for_points(np.asarray([[0.,0.,0.]]),pts,cores,[111,222])
    req(np.array_equal(w2,np.asarray([[0.5,0.5]],dtype=np.float64)),"exact-anchor collision unit failed")
    q=np.asarray([[0.01,0.02,0.03]],dtype=np.float64)
    w3=field_for_points(q,np.asarray([[0.,0.,0.],[0.,0.1,0.]]),np.asarray([111,222]),[111,222])
    req(np.all(w3>0) and abs(sum(w3[0])-1.0)<1e-12,"strict-positive nonanchor field unit failed")
    return {"unique_exact_anchor":"pass","coincident_control_collision":"equal positive shares across coincident controls; pass","nonanchor_positive_partition":"pass"}
def audit_mesh(points,faces,ci,tag):
    pts=[tuple(F.from_float(float(np.float32(x))) for x in p) for p in points]
    deg=[]
    for i,tri in enumerate(faces):
        a,b,c=(pts[int(j)] for j in tri)
        if not any(ci._cross(ci._sub(b,a),ci._sub(c,a))):deg.append(int(i))
    if deg:
        return {"degenerate_count":len(deg),"degenerate_indices":deg[:64],"self_count":None,"self_pairs":[],"predicate_complete":False}
    rec=ci._records(pts,np.asarray(faces,dtype=np.int64).tolist())
    a=ci._audit_pair(rec,rec,same_surface=True)
    return {"degenerate_count":0,"degenerate_indices":[],"self_count":int(a["count"]),
            "self_pairs":[list(map(int,x)) for x in a["triangle_pairs"][:256]],
            "aabb_candidate_pairs":int(a.get("aabb_candidate_pairs",0)),"predicate_complete":True}
def audit_pair_plane_metrics(points,faces,pairs):
    # Two-sided triangle-to-opposite-plane crossing measure, explicitly not solid penetration depth.
    vals=[];spans=[]
    fpoints=np.asarray(points,dtype=np.float64)
    for ia,ib in pairs:
        a=np.asarray(faces[int(ia)],dtype=np.int64);b=np.asarray(faces[int(ib)],dtype=np.int64)
        ta=fpoints[a];tb=fpoints[b]
        na=np.cross(ta[1]-ta[0],ta[2]-ta[0]);nb=np.cross(tb[1]-tb[0],tb[2]-tb[0])
        la=float(np.linalg.norm(na));lb=float(np.linalg.norm(nb))
        if la==0 or lb==0:continue
        da=(tb-ta[0])@na/la;db=(ta-tb[0])@nb/lb
        xa=max(0.0,min(float(np.max(da)),-float(np.min(da))))
        xb=max(0.0,min(float(np.max(db)),-float(np.min(db))))
        vals.append(max(xa,xb)*1e6)
    if vals:
        v=np.asarray(vals); stats={"count":len(vals),"median_um":float(np.median(v)),"p95_um":float(np.quantile(v,.95)),"max_um":float(np.max(v))}
    else: stats={"count":0,"median_um":0.0,"p95_um":0.0,"max_um":0.0}
    return {"two_sided_triangle_plane_crossing_um":stats,"definition":"For each triangle relative to the other triangle plane, max(0,min(max(signed distances),-min(signed distances))); pair value is max of both directions. Not solid penetration depth."}
def join_union(gids,faces,points_by_sid):
    byface=defaultdict(list)
    for sid in (132,134):
        for fi,face in enumerate(faces[sid]):
            tri=tuple(int(gids[sid][int(v)]) for v in face)
            byface[tuple(sorted(tri))].append((sid,tri,fi))
    uf=[];bad=[];cancelled=0
    for key,items in byface.items():
        if len(items)==1:
            uf.append(items[0][1])
        elif len(items)==2 and items[0][0]!=items[1][0]:
            a,b=items[0][1],items[1][1]
            opposed=any(a==tuple(reversed(b[k:]+b[:k])) for k in range(3))
            if opposed:cancelled+=1
            else:bad.append({"stable_ids":[items[0][0],items[1][0]],"face_indices":[items[0][2],items[1][2]],"reason":"shared face winding not opposite"})
        else:
            bad.append({"triangle_global_ids":list(key),"multiplicity":len(items)})
    ug=sorted({v for tri in uf for v in tri});ui={g:i for i,g in enumerate(ug)}
    ufaces=np.asarray([[ui[g] for g in tri] for tri in uf],dtype=np.int64)
    return ug,ufaces,{"cancelled_opposite_shared_faces":cancelled,"winding_or_duplicate_errors":bad,"faces":len(ufaces)}
def quat_angle(q1,q2):
    a=np.asarray(q1,dtype=np.float64);b=np.asarray(q2,dtype=np.float64)
    c=abs(float(np.dot(a,b)))/(float(np.linalg.norm(a))*float(np.linalg.norm(b)))
    return 2.0*math.acos(min(1.0,max(-1.0,c)))
def load_pose(pack_base,step,source_label,expected_native_audit=None):
    pack=pack_base/f"step-{step}.mrvpack";receipt=pack_base/f"step-{step}.receipt.json"
    req(pack.is_file() and receipt.is_file(),f"missing accepted pose {source_label}/{step}")
    r=json.loads(receipt.read_text())
    req(int(r.get("accepted_step",-1))==step and r.get("physical_endpoint")=="accepted","pose is not an accepted endpoint")
    ph=sha(pack);req(r.get("pack_file_sha256")==ph,"accepted receipt pack hash mismatch")
    poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype=np.float32),np.asarray(x["quaternion_xyzw"],dtype=np.float32)) for x in r["accepted_registered_body_poses"]}
    req(len(poses)==86,"unexpected accepted registered pose inventory")
    if expected_native_audit is not None:
        cap=expected_native_audit["captures"][str(step)]
        req(cap["pack_sha256"]==ph,"native reference audit pack hash mismatch")
    return {"label":source_label,"step":step,"pack":str(pack),"pack_sha256":ph,"receipt":str(receipt),
            "receipt_sha256":sha(receipt),"body_state_sha256":r.get("accepted_body_state_sha256"),
            "pose_count":len(poses),"poses":poses}
def f32sum_points(points,weights,core_ids,default_poses,capture_poses,mode="fma"):
    # Source points stay in atlas metres; actual NHTISS registration maps each to body-local coordinates.
    out=np.zeros((len(points),3),dtype=np.float32)
    max_binding_norm_error=0.0
    for j,core in enumerate(core_ids):
        b=CANON[int(core)]
        local=np.asarray(b[:3]+np.float32(b[7])*rotate_cxx_batch(b[3:7],points),dtype=np.float32)
        cp,cq=capture_poses[int(core)]
        transformed=np.asarray([np.asarray([F32(cp[k]+x[k]) for k in range(3)],dtype=np.float32)
                                for x in rotate_metal_batch(cq,local)],dtype=np.float32)
        w32=weights[:,j].astype(np.float32)
        max_binding_norm_error=max(max_binding_norm_error,float(np.max(np.linalg.norm(local.astype(np.float64),axis=1))))
        if mode=="fma":
            for k in range(3):
                out[:,k]=np.asarray([F32(float(w32[i])*float(transformed[i,k])+float(out[i,k])) for i in range(len(points))],dtype=np.float32)
        else:
            out=np.asarray(out+np.asarray(w32[:,None]*transformed,dtype=np.float32),dtype=np.float32)
    return out
def rotate_cxx_batch(q,p):
    f=np.float32;q=np.asarray(q,dtype=np.float32);p=np.asarray(p,dtype=np.float32);a=q[:3]
    cr=np.stack((f(f(a[1]*p[:,2])-f(a[2]*p[:,1])),f(f(a[2]*p[:,0])-f(a[0]*p[:,2])),f(f(a[0]*p[:,1])-f(a[1]*p[:,0]))),axis=1).astype(np.float32)
    tw=np.asarray(f(f(2)*cr),dtype=np.float32)
    co=np.stack((f(f(f(q[3]*tw[:,0])+f(a[1]*tw[:,2]))-f(a[2]*tw[:,1])),f(f(f(q[3]*tw[:,1])+f(a[2]*tw[:,0]))-f(a[0]*tw[:,2])),f(f(f(q[3]*tw[:,2])+f(a[0]*tw[:,1]))-f(a[1]*tw[:,0]))),axis=1).astype(np.float32)
    return np.asarray(p+co,dtype=np.float32)
def rotate_metal_batch(q,p):
    f=np.float32;q=np.asarray(q,dtype=np.float32);p=np.asarray(p,dtype=np.float32);a=q[:3]
    cr=np.stack((f(f(a[1]*p[:,2])-f(a[2]*p[:,1])),f(f(a[2]*p[:,0])-f(a[0]*p[:,2])),f(f(a[0]*p[:,1])-f(a[1]*p[:,0]))),axis=1).astype(np.float32)
    inner=np.asarray(cr+f(q[3]*p),dtype=np.float32)
    out=np.stack((f(f(a[1]*inner[:,2])-f(a[2]*inner[:,1])),f(f(a[2]*inner[:,0])-f(a[0]*inner[:,2])),f(f(a[0]*inner[:,1])-f(a[1]*inner[:,0]))),axis=1).astype(np.float32)
    return np.asarray(p+f(f(2)*out),dtype=np.float32)
def point_summary(p,reference):
    d=np.linalg.norm(p.astype(np.float64)-reference.astype(np.float64),axis=1)*1e6
    im=int(np.argmax(d));return {"count":len(d),"max_um":float(d[im]),"rms_um":float(np.sqrt(np.mean(d*d))),"p95_um":float(np.quantile(d,.95)),"max_vertex":im,"max_delta_um":((p[im].astype(np.float64)-reference[im].astype(np.float64))*1e6).tolist()}
def main():
    global CANON, GQUERY
    req(not (RES/"report.json").exists(),"result output already exists")
    sys.path.insert(0,str(CI.parent.parent))
    from numilab_human import cardiac_cavity_intersections as ci
    h=loadmod("route_anchor_forward_helper_070",H)
    for p in (C,CR,CK,MAP,MAPR,ROUTE,ROUTE_SCRIPT,ROUTE_CORE,T,T0,TISS_MAN,RIG,ARCH,NATIVE_UNION,CI,H):
        req(Path(p).is_file(),f"missing input {p}")
    cand=pickle.loads(C.read_bytes());mp=cand
    candidate_sha=sha(C);check=json.loads(CR.read_text())
    req(check.get("status")=="completed_bounded_source_geometry_refinement" and check.get("candidate_sha256")==candidate_sha,"085 source refinement report/candidate hash mismatch")
    req(check["source_rest_exact_self_audits"]["union"].get("predicate_complete") and check["source_rest_exact_self_audits"]["union"].get("self_count")==0 and check["source_rest_exact_self_audits"]["union"].get("degenerate_count")==0,"085 exact union source audit is not passing")
    req(cand.get("input_candidate_sha256")=="7d2a1593548c50f1d9f57cb23fa42e2b51eb7aca2a5a6f2e93a83cfb855eddb9" and cand.get("input_source_parent_map_sha256")=="bd3753a02890269914e0caa181bf2da0e978124bf8f736fc017bf5263b715d78","085 original geometry/ancestry source pins changed")
    native_audit=json.loads(NATIVE_UNION.read_text())
    req(native_audit["status"]=="native_union_audit_failed","007 native failure reference changed")
    route_doc=json.loads(ROUTE.read_text())
    req(route_doc.get("schema")=="numi.human.fds-fdp-source-route-provenance-061.v1","route extraction schema mismatch")
    muscles=[m for m in route_doc["matching_muscles"] if str(m.get("actuator_name","")).endswith("_l")]
    expected_muscles={"FDS2_l","FDS3_l","FDS4_l","FDS5_l","FDP2_l","FDP3_l","FDP4_l","FDP5_l"}
    req({m["actuator_name"] for m in muscles}==expected_muscles,"left FDS/FDP source route inventory mismatch")
    occurrences=[]
    for m in muscles:
        for node in m["route_nodes"]:
            occurrences.append((m["actuator_name"],node))
    dedup={}
    memberships=defaultdict(list)
    for muscle,node in occurrences:
        key=(int(node["source_id"]),str(node["kind"]),int(node["core_body_index"]))
        ident={k:node[k] for k in ("source_id","name","kind","source_body_id","source_body_name","core_body_index","position_body_m","position_world_m")}
        if key in dedup:
            req(dedup[key]["identity"]==ident,"duplicate MyoSim control ID has conflicting source identity or coordinate")
        else:dedup[key]={"identity":ident,"muscles":[]}
        dedup[key]["muscles"].append(muscle);memberships[key].append(muscle)
    controls=[dedup[k]["identity"] for k in sorted(dedup)]
    core_ids=sorted({int(x["core_body_index"]) for x in controls})
    body_names={}
    for x in controls:
        c=int(x["core_body_index"]);n=str(x["source_body_name"])
        req(c not in body_names or body_names[c]==n,"core body maps to multiple route source names")
        body_names[c]=n
    req(len(controls)==74 and len(occurrences)==81 and len(core_ids)==21,"expected unique route control/body inventory mismatch")
    rigid=parse_nhrigid(RIG,ARCH);default_poses=rigid["poses"]
    req(all(c in default_poses for c in core_ids),"NHRIGID default pose missing route core")
    REG=ROOT/"registration-source-b1b410ad.json"
    req(sha(REG)=="b1b410ad6d4ac8c0c95fd0c3e10f655b24c890d5767a5c377cf78e28ef598f8e","authoring registration identity changed")
    GQUERY=np.asarray(json.loads(REG.read_text())["coordinate_system"]["global_source_mm_to_myosim_world_m"],dtype=float)[:3].copy()
    GQUERY[:,:3]*=1000.0
    data=h.load_tissue(T)
    CANON={}
    for sid in (132,134):
        rec=next(r for r in data["records"] if int(r[6])==sid)
        for item in data["bindings"][int(rec[0]):int(rec[0])+int(rec[1])]:
            core=int(item["core"]);val=np.asarray(item["value"],np.float32)
            if core in CANON:req(np.array_equal(CANON[core],val),"conflicting canonical bindings")
            else:CANON[core]=val.copy()
    req(set(core_ids)<=set(CANON),"shared field core absent in source bindings")
    registration_deltas={}
    for core in core_ids:
        b=CANON[core];dp,dq=default_poses[core]
        R=np.stack([rotate_double(dq,rotate_double(b[3:7],x)*float(b[7])) for x in np.eye(3)],axis=1)
        tr=dp.astype(float)+rotate_double(dq,b[:3])
        g=np.column_stack((R,tr))
        registration_deltas[str(core)]=float(np.max(np.abs(g-GQUERY)))
    req(max(registration_deltas.values())<1e-6,"compiled source bindings disagree with authoring registration")
    save_json(RES/"registration-frame-proof.json",{"authoring_registration_path":str(REG),"sha256":sha(REG),
        "source_m_to_registered_world_m":GQUERY.tolist(),"compiled_body_mapping_max_abs_errors":registration_deltas,
        "runtime_bindings":"Existing byte-preserved NHTISS registrations; no inverse-pose-only reconstruction",
        "prior_diagnostics":"073/076/082 used incorrect identity registration for atlas coordinates; superseded, not anatomical evidence."})

    anchor_registration=[]
    for x in controls:
        c=int(x["core_body_index"]);dp,dq=default_poses[c]
        calc=dp.astype(np.float64)+rotate_double(dq,x["position_body_m"])
        auth=np.asarray(x["position_world_m"],dtype=np.float64)
        anchor_registration.append(float(np.linalg.norm(calc-auth))*1e6)
    anchor_reg={"count":len(anchor_registration),"max_world_reconstruction_um":max(anchor_registration),"rms_world_reconstruction_um":float(np.sqrt(np.mean(np.square(anchor_registration)))),"p95_world_reconstruction_um":float(np.quantile(anchor_registration,.95))}
    surf=mp["surfaces"]
    gids={};faces={};rest_exact={};rest_f32={}
    for sid in (132,134):
        item=surf[sid];gids[sid]=list(map(int,item["global_vertex_ids"]));faces[sid]=np.asarray(item["faces"],dtype=np.int64)
        rest_exact[sid]=[tuple(q if isinstance(q,F) else F(int(q[0]),int(q[1])) for q in xyz) for xyz in item["vertices_exact_m"]]
        rest_f32[sid]=np.asarray(item["vertices_float32_m"],dtype=np.float32)
        recomputed=np.asarray([[F32(float(q)) for q in xyz] for xyz in rest_exact[sid]],dtype=np.float32)
        req(np.array_equal(rest_f32[sid],recomputed),f"085 exact/Float32 vertex tables disagree {sid}")
        req(len(gids[sid])==len(rest_f32[sid]) and len(rest_f32[sid])==len(faces[sid])*0+len(gids[sid]),f"candidate surface vertex alignment mismatch {sid}")
    row_index={s:{g:i for i,g in enumerate(gids[s])} for s in (132,134)}
    common=set(gids[132])&set(gids[134])
    mism=[]
    for g in common:
        i=row_index[132][g];j=row_index[134][g]
        if rest_exact[132][i]!=rest_exact[134][j] or not np.array_equal(rest_f32[132][i],rest_f32[134][j]):mism.append(g)
    req(not mism,"candidate060 source geometry has nonidentical shared point references")
    pts_all=np.concatenate([rest_f32[132],rest_f32[134]],axis=0)
    ctrl_xyz=np.asarray([x["position_world_m"] for x in controls],dtype=np.float64)
    ctrl_core=np.asarray([int(x["core_body_index"]) for x in controls],dtype=np.int64)
    field_tests=unit_field_tests(ctrl_xyz,ctrl_core,core_ids)
    weights={}
    for sid in (132,134):
        weights[sid]=field_for_points(rest_f32[sid].astype(np.float64)@GQUERY[:,:3].T+GQUERY[:,3],ctrl_xyz,ctrl_core,core_ids,power=2.0)
        req(np.isfinite(weights[sid]).all() and np.all(weights[sid]>=0),"route field has nonfinite/negative core weights")
        positive=np.count_nonzero(weights[sid]>0,axis=1)
        req(np.all(positive==len(core_ids)),"nonanchor source vertex lost a positive route core")
        req(float(np.min(weights[sid]))>0 and float(np.min(weights[sid].astype(np.float32)))>0,"route field coefficient underflows Float32")
    if len(common):
        for g in common:
            i=row_index[132][g];j=row_index[134][g]
            req(np.array_equal(weights[132][i],weights[134][j]),"shared seam route field weights are not bit-identical")
    np.savez_compressed(RES/"route-anchor-reference-field-001.npz",
        core_body_indices=np.asarray(core_ids,dtype="<u4"),
        stable132_global_vertex_ids=np.asarray(gids[132],dtype="<u8"),
        stable132_rest_positions_m=rest_f32[132].astype("<f4"),
        stable132_faces=faces[132].astype("<u4"),
        stable132_core_weights=weights[132].astype("<f8"),
        stable134_global_vertex_ids=np.asarray(gids[134],dtype="<u8"),
        stable134_rest_positions_m=rest_f32[134].astype("<f4"),
        stable134_faces=faces[134].astype("<u4"),
        stable134_core_weights=weights[134].astype("<f8"))
    npz=RES/"route-anchor-reference-field-001.npz"
    ug,ufaces,union_static=join_union(gids,faces,rest_f32)
    ug_index={g:i for i,g in enumerate(ug)}
    inputs=[Path(__file__),REG,RES/"registration-frame-proof.json",C,CR,CK,MAP,MAPR,ROUTE,ROUTE_SCRIPT,ROUTE_CORE,T,T0,TISS_MAN,RIG,ARCH,NATIVE_UNION,CI,H]
    pins={str(p):sha(p) for p in inputs}
    npz_sha=sha(npz)
    # Authoritative registered-rest reproduction and two diagnostic accepted poses.
    rest_pose=f32sum_points(np.concatenate([rest_f32[132],rest_f32[134]]),
        np.concatenate([weights[132],weights[134]]),core_ids,default_poses,default_poses,"fma")
    refconcat=(np.concatenate([rest_f32[132],rest_f32[134]]).astype(float)@GQUERY[:,:3].T+GQUERY[:,3]).astype(np.float32)
    rest_metric=point_summary(rest_pose,refconcat)
    contexts=[
        load_pose(CURRENT_CAP,0,"native007-current",native_audit),
        load_pose(OLD_CAP,151999,"P011-baseline",None),
    ]
    # Prevent repeated seam query differences from contaminating the union; field weights/pose outputs are keyed by exact global vertex ID.
    pose_results=[]
    for ctx in contexts:
        for core in core_ids:req(core in ctx["poses"],f"pose lacks route core {core}")
        # One computation per unique global vertex gives identical owner/recipient seam bytes by construction.
        gpoints={};gweights={}
        for sid in (132,134):
            for i,g in enumerate(gids[sid]):
                if g in gpoints:
                    req(np.array_equal(gpoints[g],rest_f32[sid][i]) and np.array_equal(gweights[g],weights[sid][i]),"global shared point/field changed across rows")
                else:
                    gpoints[g]=rest_f32[sid][i];gweights[g]=weights[sid][i]
        allg=sorted(gpoints)
        gx=np.asarray([gpoints[g] for g in allg],dtype=np.float32)
        gw=np.asarray([gweights[g] for g in allg],dtype=np.float64)
        posed=f32sum_points(gx,gw,core_ids,default_poses,ctx["poses"],"fma")
        gpos={g:posed[i] for i,g in enumerate(allg)}
        output={s:np.asarray([gpos[g] for g in gids[s]],dtype=np.float32) for s in (132,134)}
        row_audits={str(s):audit_mesh(output[s],faces[s],ci,f"stable-{s}") for s in (132,134)}
        ugposed=np.asarray([gpos[g] for g in ug],dtype=np.float32)
        union_audit=audit_mesh(ugposed,ufaces,ci,"union")
        union_pairs=union_audit.get("self_pairs",[])
        # Audit exact current child face-geometry against native 007 baseline pair inventory for requested current poses.
        result={"source_label":ctx["label"],"step":ctx["step"],"accepted_pack_path":ctx["pack"],"accepted_pack_sha256":ctx["pack_sha256"],
            "accepted_receipt_path":ctx["receipt"],"accepted_receipt_sha256":ctx["receipt_sha256"],"accepted_body_state_sha256":ctx["body_state_sha256"],
            "accepted_pose_count":ctx["pose_count"],"stable_rows":row_audits,"woven_union":union_audit,
            "shared_seam":{"global_shared_vertex_count":len(common),"exact_input_identity_mismatches":len(mism),
                "max_pose_gap_um":float(max((np.linalg.norm(output[132][row_index[132][g]].astype(np.float64)-output[134][row_index[134][g]].astype(np.float64)) for g in common),default=0)*1e6),
                "bit_identical_pose_vertices":sum(np.array_equal(output[132][row_index[132][g]],output[134][row_index[134][g]]) for g in common)},
            "candidate060_native_reference":{"path":str(NATIVE_UNION),"sha256":sha(NATIVE_UNION),
                "union_exact_self_pairs":native_audit["captures"].get(str(ctx["step"]),{}).get("exact_self_pair_count") if ctx["label"]=="native007-current" else None},
            "native_like_arithmetic":{"binding_pose_transform":"existing NHTISS source registration bindings; C++-style binding quaternion rotation followed by Metal-style captured pose rotation",
                "influence_weight":"float32 conversion of binary64 normalized aggregated core coefficient",
                "accumulation":"one Float32 fused multiply-add per influence and coordinate; actual route-field native capture not run",
                "CPU model only":True},
            "plane_crossing_metric":audit_pair_plane_metrics(ugposed,ufaces,union_pairs),
            "elapsed_seconds":time.monotonic()-START}
        outpath=RES/f"pose-{ctx['label']}-{ctx['step']}.json";save_json(outpath,result)
        pose_results.append(result)
        print(json.dumps({"event":"pose_complete","source":ctx["label"],"step":ctx["step"],
            "rows":{s:{k:row_audits[s].get(k) for k in ("degenerate_count","self_count","predicate_complete")} for s in row_audits},
            "union_self_pairs":union_audit.get("self_count"),"union_degenerate":union_audit.get("degenerate_count"),
            "shared_seam_bit_exact":result["shared_seam"]["bit_identical_pose_vertices"],"elapsed_seconds":result["elapsed_seconds"]},sort_keys=True),flush=True)
        del posed,output,ugposed;gc.collect()
    # Compact field statistics and route ancestry details.
    field_stats={}
    for sid in (132,134):
        pcount=np.count_nonzero(weights[sid]>0,axis=1)
        field_stats[str(sid)]={"vertex_count":len(weights[sid]),"face_count":len(faces[sid]),
            "positive_core_support":{"min":int(pcount.min()),"median":float(np.median(pcount)),"max":int(pcount.max())},
            "minimum_positive_core_weight":float(np.min(weights[sid])),"minimum_float32_positive_weight":float(np.min(weights[sid].astype(np.float32))),
            "per_core_mean_weight":{str(core):float(np.mean(weights[sid][:,j])) for j,core in enumerate(core_ids)},
            "per_core_minmax_weight":{str(core):[float(np.min(weights[sid][:,j])),float(np.max(weights[sid][:,j]))] for j,core in enumerate(core_ids)}}
    route_records=[{"source_id":int(x["source_id"]),"name":x["name"],"kind":x["kind"],"source_body_id":int(x["source_body_id"]),
        "source_body_name":x["source_body_name"],"core_body_index":int(x["core_body_index"]),
        "position_body_m":x["position_body_m"],"position_world_m":x["position_world_m"],
        "routes":sorted(dedup[(int(x["source_id"]),str(x["kind"]),int(x["core_body_index"]))]["muscles"])} for x in controls]
    report={"schema":"numi.human.left-fds132-fdp134-refined-route-anchor-field-pose-pilot-088.v1",
        "status":"completed_cpu_refined_route_anchor_field_pose_pilot","scope":"Bounded CPU-only source-defined route-anchor reference-field pilot on exact candidate085 2 mm conforming interface refinement. The geometry is an exact bisection refinement of candidate060. The 74 deduplicated left FDS2–5/FDP2–5 authored MyoSim route sites/wrap controls define one shared spatial field over stable132/134. These are force-path controls, not validated passive surface attachment landmarks. No captured-pose fitting, source mutation, native launch, or GPU use.",
        "candidate":{"path":str(C),"sha256":candidate_sha,"source_geometry_report_path":str(CR),"source_geometry_report_sha256":sha(CR),
            "candidate_adapted_map_path":str(MAP),"candidate_adapted_map_sha256":sha(MAP),"conforming_refinement_candidate_path":str(C),"conforming_refinement_report_path":str(CR),"conforming_refinement_report_sha256":sha(CR),"source_face_rows":{str(s):{"vertices":len(gids[s]),"faces":len(faces[s])} for s in (132,134)},
            "static_union":{"shared_global_vertices":len(common),**union_static},"native007_reference_path":str(NATIVE_UNION),"native007_reference_sha256":sha(NATIVE_UNION)},
        "route_controls":{"report_path":str(ROUTE),"report_sha256":sha(ROUTE),"extractor_path":str(ROUTE_SCRIPT),"extractor_sha256":sha(ROUTE_SCRIPT),
            "route_names":sorted(expected_muscles),"route_occurrences":len(occurrences),"unique_controls":len(controls),
            "dedup_key":"compiled source_id + node kind + NHRIGID core index, requiring repeated occurrences to carry identical source IDs, names, core bodies, and body/world coordinates",
            "duplicate_occurrences_removed":len(occurrences)-len(controls),"unique_core_bodies":len(core_ids),
            "core_body_names":{str(k):v for k,v in body_names.items()},"anchor_world_registration_vs_NHRIGID_pose":anchor_reg,
            "controls":route_records,"source_interpretation":route_doc["interpretation"]},
        "field":{"family":"continuous interpolatory inverse-square Shepard field on deduplicated authored route controls",
            "formula":"At nonanchor x, each unique route control a has raw weight (d_min(x)^2 / ||x-a||^2), equivalent after normalization to 1/||x-a||^2. Normalize across all controls, then sum control weights by NHRIGID core body. At exact-anchor coordinates, assign equal mass among controls at that same coordinate and zero to the others.",
            "power":2.0,"distance_softening_m":0.0,"anchor_collision_rule":"equal share among all deduplicated controls at the exact coincident coordinate; subsequently aggregate by core body",
            "parameter_sensitivity":{"declared_alternative_powers":[1.0,1.5,3.0],"tested_in_this_pilot":False,"reason":"Primary requested inverse-square field first; no pose-optimized or selected-capture parameter fitting."},
            "normalization":"All 74 node weights normalized in binary64; aggregate to the 21 route-bearing cores; stable core order; final coefficient closes partition of unity; no nearest-k pruning.",
            "unit_tests":field_tests,"weight_artifact_path":str(npz),"weight_artifact_sha256":npz_sha,"per_surface":field_stats,
            "shared_seam_weights_bit_identical":True},
        "registered_rest_reproduction":{"reference_pose":"NHRIGID true serialized defaultQ",
            "reconstructed_field_vertices":len(rest_pose),"max_error_from_candidate_Float32_rest_um":rest_metric["max_um"],
            "rms_error_um":rest_metric["rms_um"],"p95_error_um":rest_metric["p95_um"],
            "gate_value_from_parent_loader":"2 µm rest-world reproduction; compare this provisional route-carrier reference to the child row registration gate before native composition.",
            "interpretation":"Source-rest transform reproduction only. It does not imply a current captured-pose match or anatomy qualification."},
        "pose_audits":pose_results,"candidate060_prior_native_reference":{"path":str(NATIVE_UNION),"sha256":sha(NATIVE_UNION),
            "captured_native_union_self_pair_counts":{str(k):v["exact_self_pair_count"] for k,v in native_audit["captures"].items()}},
        "runtime_emulation":{"body_lane_transform":"NHRIGID binary32 default pose inverse converted to source-carrier binding; C++-style binary32 binding rotation; Metal-style binary32 accepted body pose rotation",
            "sum":"Float32 FMA for each positive coefficient × transformed source-carrier point",
            "limitations":"CPU arithmetic emulation; no route-field native candidate emitted or executed; does not establish exact shader parity or accepted-body loader validation."},
        "qualification":{"cpu_only":True,"gpu_used":False,"native_candidate_emitted":False,"source_mutated":False,
            "admitted":False,"all_three_selected_pose_self_and_union_clear":all(all(x["woven_union"].get("self_count")==0 and x["woven_union"].get("degenerate_count")==0 and all(y.get("self_count")==0 and y.get("degenerate_count")==0 for y in x["stable_rows"].values()) for x in pose_results)),
            "candidate_admission":"Not claimed. CPU source-defined field on refined geometry is a targeted pose diagnostic; native loader/graphics execution and all-pose qualification remain pending."},
        "environment":{"python":sys.version,"numpy":np.__version__,"cpu_workers":1,"rss_watchdog_kib":RSS_LIMIT_KIB},
        "input_hashes":pins,"input_hashes_stable_at_completion":all(sha(Path(p))==v for p,v in pins.items()),
        "elapsed_seconds":time.monotonic()-START}
    rp=RES/"report.json";save_json(rp,report)
    print(json.dumps({"event":"report_complete","status":report["status"],"report":str(rp),"report_sha256":sha(rp),
        "field_npz_sha256":npz_sha,"anchor_reg_max_um":anchor_reg["max_world_reconstruction_um"],
        "rest_max_um":rest_metric["max_um"],"pose_union_pairs":{str(x["step"]):x["woven_union"].get("self_count") for x in pose_results},
        "stable_inputs":report["input_hashes_stable_at_completion"],"elapsed_seconds":report["elapsed_seconds"]},sort_keys=True),flush=True)
if __name__=="__main__":
    main()

