from pathlib import Path
import sys,json,hashlib,argparse,numpy as np,subprocess,shutil
R=Path("/Users/n/numi-human-retained-delivery-20261009");A=R/"anatomy-completion-1276"
O=A/"masseters-native-composition-004";O.mkdir(exist_ok=False)
SRC=Path("/Users/n/numi-human-local-clearance-preservation-1280/src");sys.path.insert(0,str(SRC))
from numilab_human import passive_attachment_composition as pc,resting_run as rr
B=A/"right-scm-native-composition-001";SK=A/"skin-candidate-30-pose-preparation-001/result-005"
Z=R/"head-muscle-coverage-1291/alternate-head-source-inventory-001/z-anatomy-range/head-bone-triangle-registration-001";D=Z/"masseter-harmonic-patch-001";AP=D/"append-to-right-scm-parent-002"
P=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011";sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
RP=D/"audit-current-right-scm-861-001/report.json";C=AP/"assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue";arp=AP/"append-preparation-report.json"
assert sha(C)=="f94c6d06f32564ca44cef54f9fe2b3fa232b7246eb636e75bca00e4cb85e3101"
assert sha(RP)=="54f43d54bc020a5289abff974307855410cba6f381da2e7159a86d9a132d8cdc"
r=json.loads(RP.read_text());ar=json.loads(arp.read_text())
assert r["complete"] and r["inputs_unchanged"] and r["all_eight_pose_self_clear"] and r["all_eight_pose_target_crossings_zero"]
assert ar["complete"] and ar["inputs_unchanged"] and ar["parent_rows_and_bindings_byte_exact"] and ar["appended_stable_ids"]==[159,160]
oldreg=Z/"registration-and-interface-report-003.json";recheck=Z/"corrected-helper-recheck-001/registration-and-interface-report-003.json"
old=json.loads(oldreg.read_text());new=json.loads(recheck.read_text());assert new["inputs"]["all_inputs_unchanged"]
assert all(old[k]==new[k] for k in old if k!="inputs")
inputpins={**ar["input_sha256_before"],**r["input_sha256"],**new["inputs"]["sha256"]}
for path,digest in inputpins.items():assert sha(path)==digest,(path,sha(path),digest)
(O/"assets").symlink_to(AP/"assets",target_is_directory=True)
payload=C;receipt=AP/"resting-anatomy-receipt.json";(O/receipt.name).symlink_to(receipt);bound=json.loads(receipt.read_text())
assert bound["mass_geometry_accounting"]==json.loads((B/"resting-anatomy-receipt.json").read_text())["mass_geometry_accounting"]
composition=ar["composition_proof"];(O/"composition-result.json").write_text(json.dumps(composition,indent=2,sort_keys=True)+"\n")
bounds={str(row["stable_id"]):row for row in ar["rows"]};(O/"source-resolution-bounds.json").write_text(json.dumps(bounds,indent=2,sort_keys=True)+"\n")
proofpaths=[RP,arp,oldreg,recheck,B/"native-verification-001/report.json"];union_inputs=list(map(Path,inputpins));replacements=[]
base=json.loads((P/"baseline/run-declaration.json").read_text());argsv=base["argv"][base["argv"].index("human-resting")+1:]
for flag,value in [("--body-scene",str(SK/"resting-supine-scene.manifest.json")),("--anatomy-receipt",str(receipt)),("--output",str(O/"baseline/native-run")),("--seconds","16.0")]:argsv[argsv.index(flag)+1]=value
argsv+=["--lab","/Users/n/numi-lab-passive-single-binding-1328","--build","/Users/n/numi-lab-passive-single-binding-build-1328"]
parser=argparse.ArgumentParser();rr.add_arguments(parser);args=parser.parse_args(argsv);native,assets=rr.command(args)
env={}
for item in base["argv"][2:base["argv"].index("human-resting")-1]:
 key,value=item.split("=",1);env[key]=value
env["NUMI_HUMAN_ROOT"]=str(SRC.parent);env["PYTHONPATH"]=str(SRC)
env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"]="0,4767,5023,5599,6207,6815,7423,8000"
assert all(n in (0,8000) or (n+1)%32==0 for n in map(int,env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"].split(",")))
# Baseline011's Q observer is inactive throughout its first16s.
# A window beyond this short run is rejected; disable the observer and omit bounds.
env["NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT"]="0"
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_FIRST_STEP",None)
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_LAST_STEP",None)
env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"]=str(args.output/"common-field-failure.json")
env.update(DYLD_LIBRARY_PATH=str(args.build/"lib")+":"+str(args.build/"matter"),DYLD_PRINT_LIBRARIES="1",NUMI_HUMAN_RESTING_INSPECTION_TOUR="1",NUMI_HUMAN_RESTING_INSPECTION_PERIOD_SECONDS=str(args.inspection_period_seconds))
argv=["/usr/bin/env","-i"]+[k+"="+v for k,v in sorted(env.items())]+["/Users/n/numi-human-prep-venv-20261005/bin/python3.13","-m","numilab_human.resting_run"]+argsv
launch=O/"launch_arm.py";launch.write_text((A/"ecu-apl-native-composition-005/launch_arm.py").read_text().replace("6000 * 1024 * 1024", "4000 * 1024 * 1024"))
pins={**assets,**{str(p):sha(p) for p in [Path(__file__),Path(pc.__file__),Path(rr.__file__),launch,O/"source-resolution-bounds.json",*proofpaths,*union_inputs]}}
for _,npz,rp in replacements:pins[str(npz)]=sha(npz);pins[str(rp)]=sha(rp)
decl={"schema":"numi.human.native-smoke.run-declaration.v1","seconds":16.0,"accepted_steps":8000,"capture_steps":[0,4767,5023,5599,6207,6815,7423,8000],"immutable_assets":pins,"argv":argv,"launch_adapter":{"path":str(launch),"sha256":sha(launch)},"owner_cli_preview":{"native_argv":native,"asset_sha256":assets,"recorded_invocation_environment":rr.invocation_environment(env)},"qualification":"Existing native151-row scene plus passive registered superficial masseters159/160. Source and eight currentSCM poses self-clear with zero crossings against861 targets and opposite masseter. Correct closest-point head registration independently reproduced. No jaw mechanics, measured individual, full-body or five-minute qualification claimed. Native verification pending; performance deferred."}
(O/"baseline").mkdir();dp=O/"baseline/run-declaration.json";dp.write_text(json.dumps(decl,indent=2,sort_keys=True)+"\n")
(O/"launch-guard.json").write_text(json.dumps({"launcher_sha256":sha(launch),"arms":{"baseline":{"run_declaration_sha256":sha(dp),"native_output":str(args.output)}}},indent=2,sort_keys=True)+"\n")
print(json.dumps({"output":str(O),"payload_sha256":sha(payload),"pins":len(pins),"rows":list(bounds)},indent=2))

