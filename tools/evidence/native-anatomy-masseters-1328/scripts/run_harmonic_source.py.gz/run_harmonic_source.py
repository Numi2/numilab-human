from pathlib import Path
import hashlib,json,sys,time
import numpy as np
from scipy.sparse import lil_matrix
from scipy.sparse.linalg import spsolve
R=Path("/Users/n/numi-human-retained-delivery-20261009/head-muscle-coverage-1291/alternate-head-source-inventory-001/z-anatomy-range")
BASE=R/"head-bone-triangle-registration-001";OUT=BASE/"masseter-harmonic-patch-001"
NPZ=R/"head-main-meshes.npz";META=R/"head-main-meshes.json.meta";AUDIT=R/"head-source-self-audit-001/report.json"
OWNER=Path("/Users/n/numi-human-touching-loop-arrangement-1290");sys.path.insert(0,str(OWNER/"src"))
from numilab_human import cardiac_cavity_intersections as pred,cardiac_cavity_geometry as cg
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def rec(v,f):return pred._records([pred.float32_point_lattice_key(p) for p in np.asarray(v,dtype="<f4")],np.asarray(f,dtype=np.int64).tolist())
def harmonic(v,f,seeds,radius):
 n=len(v);adj=[set() for _ in range(n)]
 for tri in f:
  a,b,c=map(int,tri);adj[a].update((b,c));adj[b].update((a,c));adj[c].update((a,b))
 dist=np.full(n,999,dtype=np.int32);front=list(map(int,seeds))
 for i in front:dist[i]=0
 for level in range(radius):
  nxt=[]
  for i in front:
   for j in adj[i]:
    if dist[j]>level+1:dist[j]=level+1;nxt.append(j)
  front=nxt
 free=np.flatnonzero(dist<radius);boundary=np.flatnonzero(dist==radius)
 if not len(free) or not len(boundary):raise RuntimeError("invalid local patch")
 local=np.full(n,-1,dtype=np.int64);local[free]=np.arange(len(free));L=lil_matrix((len(free),len(free)));rhs=np.zeros((len(free),3))
 for i in free:
  ii=local[i];L[ii,ii]=len(adj[i])
  for j in adj[i]:
   jj=local[j]
   if jj>=0:L[ii,jj]-=1
   else:rhs[ii]+=v[j].astype(float)
 sol=np.column_stack([spsolve(L.tocsr(),rhs[:,k]) for k in range(3)])
 target=v.astype(float).copy();target[free]=sol
 return target,free,boundary
def vol(v,f):
 t=np.asarray(v,dtype=np.float64)[np.asarray(f,dtype=np.int64)]
 return float(np.einsum("ij,ij->i",t[:,0],np.cross(t[:,1],t[:,2])).sum()/6.0)
def area(v,f):
 t=np.asarray(v,dtype=np.float64)[np.asarray(f,dtype=np.int64)]
 return .5*np.linalg.norm(np.cross(t[:,1]-t[:,0],t[:,2]-t[:,0]),axis=1)
t0=time.monotonic();pins={str(p):sha(p) for p in [Path(__file__),NPZ,META,AUDIT,OWNER/"src/numilab_human/cardiac_cavity_intersections.py",OWNER/"src/numilab_human/cardiac_cavity_geometry.py"]}
meta=json.loads(META.read_text());z=np.load(NPZ,allow_pickle=False);src={};rows=[]
for obj in meta["objects"]:
 name=obj["object_name"]
 if name not in ("Superficial part of masseter.l","Superficial part of masseter.r"):continue
 v=np.asarray(z[obj["prefix"]+"_world_vertices_f64"],dtype="<f4");f=np.asarray(z[obj["prefix"]+"_triangles_i32"],dtype=np.int64)
 base=pred._audit_pair(rec(v,f),rec(v,f),same_surface=True)
 if base["triangle_pairs"]!=[[1358,1369],[1358,1377]]:raise RuntimeError("source witness drift")
 src[name]=(v,f,int(base["count"]))
seedfaces=np.asarray([1358,1369,1377],dtype=np.int64)
trial_cache={};all_trials=[];selected=None
for radius in (1,2):
 harmonics={}
 for name,(v,f,_) in src.items():harmonics[name]=harmonic(v,f,np.unique(f[seedfaces].reshape(-1)),radius)
 for alpha in (.25,.5,1.0):
  trial_rows=[];data={};all_ok=True
  for name,(v,f,basecount) in src.items():
   target,free,boundary=harmonics[name];c=np.asarray(v.astype(float)+alpha*(target-v.astype(float)),dtype="<f4")
   d=np.linalg.norm(c.astype(float)-v.astype(float),axis=1);a0=area(v,f);a1=area(c,f);vol0=vol(v,f);vol1=vol(c,f)
   tri0=v[f].astype(float);tri1=c[f].astype(float);n0=np.cross(tri0[:,1]-tri0[:,0],tri0[:,2]-tri0[:,0]);n1=np.cross(tri1[:,1]-tri1[:,0],tri1[:,2]-tri1[:,0]);cos=np.einsum("ij,ij->i",n0,n1)/(np.linalg.norm(n0,axis=1)*np.linalg.norm(n1,axis=1))
   ex=pred._audit_pair(rec(c,f),rec(c,f),same_surface=True);top=cg.analyze_topology(c.tolist(),f.tolist())
   valid=bool(np.isfinite(c).all() and a1.min()>1e-15 and vol0*vol1>0 and top["closed_oriented_manifold_candidate"] and d.max()<=.001)
   row={"object_name":name,"radius_rings":radius,"alpha":alpha,"free_vertices":int(len(free)),"boundary_vertices":int(len(boundary)),"max_displacement_m":float(d.max()),"self_count":int(ex["count"]),"self_pairs":ex["triangle_pairs"][:12],"min_area_ratio":float((a1/a0).min()),"reversed_face_count":int(np.count_nonzero(cos<=0)),"min_normal_cosine":float(cos.min()),"volume_before_m3":vol0,"volume_after_m3":vol1,"relative_volume_change":abs(vol1-vol0)/abs(vol0),"closed_oriented":bool(top["closed_oriented_manifold_candidate"]),"valid":valid}
   trial_rows.append(row);data[name]=(c,f)
   if not valid or ex["count"]!=0:all_ok=False
  entry={"radius_rings":radius,"alpha":alpha,"rows":trial_rows,"source_gate":all_ok};all_trials.append(entry);trial_cache[(radius,alpha)]=data
  print(json.dumps({"trial":len(all_trials),"radius":radius,"alpha":alpha,"self_counts":[r["self_count"] for r in trial_rows],"max_displacement_mm":max(r["max_displacement_m"]*1000 for r in trial_rows),"source_gate":all_ok},sort_keys=True),flush=True)
  if all_ok:selected=(radius,alpha,data);break
 if selected:break
if selected is None:
 # Retain the least-displaced bounded trial for diagnostics, never as a passed candidate.
 best=min(all_trials,key=lambda t:max(r["max_displacement_m"] for r in t["rows"]))
 selected=(best["radius_rings"],best["alpha"],trial_cache[(best["radius_rings"],best["alpha"])])
out_npz=OUT/"bilateral-superficial-masseter-harmonic-source-trial.npz";payload={}
for name,(v,f) in selected[2].items():
 k=name.replace(" ","_");payload[k+"__vertices_f32"]=v;payload[k+"__faces_i32"]=f.astype("<i4");payload[k+"__face_origins_i32"]=np.arange(len(f),dtype="<i4")
np.savez_compressed(out_npz,**payload);candidate_sha=sha(out_npz)
after={str(p):sha(p) for p in [Path(__file__),NPZ,META,AUDIT,OWNER/"src/numilab_human/cardiac_cavity_intersections.py",OWNER/"src/numilab_human/cardiac_cavity_geometry.py"]}
if pins!=after:raise RuntimeError("input changed during harmonic patch probe")
rep={"schema":"numi.zanatomy-superficial-masseter-harmonic-patch-source-probe.v1","status":"source_geometry_clear" if all(t["source_gate"] for t in all_trials) else "no_source_clear_candidate","complete":True,"native_admission":False,"inputs_unchanged":pins==after,"input_sha256":pins,"source_baselines":[{"name":n,"vertices":len(v),"faces":len(f),"self_count":c} for n,(v,f,c) in src.items()],"trials":all_trials,"selected_trial":{"radius_rings":selected[0],"alpha":selected[1],"passed_source_gate":bool(any(t["source_gate"] and t["radius_rings"]==selected[0] and t["alpha"]==selected[1] for t in all_trials))},"candidate_npz":{"path":str(out_npz),"sha256":candidate_sha,"bytes":out_npz.stat().st_size},"limits":"Source-only bounded harmonic fit; no pose or target scans unless source gate passes. Marker meshes are unchanged; no certified attachment-footprint claim.","elapsed_seconds":time.monotonic()-t0}
rp=OUT/"source-report.json";rp.write_text(json.dumps(rep,sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":rep["status"],"report":str(rp),"report_sha256":sha(rp),"candidate":str(out_npz),"candidate_sha256":candidate_sha,"inputs_unchanged":pins==after,"elapsed_seconds":rep["elapsed_seconds"]},sort_keys=True),flush=True)

