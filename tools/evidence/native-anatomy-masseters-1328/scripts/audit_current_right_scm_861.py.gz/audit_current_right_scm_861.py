from pathlib import Path
import hashlib,json,sys,time,struct,mmap,importlib.util
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
ROOT=R/"head-muscle-coverage-1291/alternate-head-source-inventory-001/z-anatomy-range"
BASE=ROOT/"head-bone-triangle-registration-001"
OUT=BASE/"masseter-harmonic-patch-001"
CAND=OUT/"bilateral-superficial-masseter-harmonic-source-trial.npz"
SOURCE_REPORT=OUT/"source-report.json";SOURCE_RUNNER=OUT/"run_harmonic_source.py"
NPZ=ROOT/"head-main-meshes.npz";META=ROOT/"head-main-meshes.json.meta";REG=BASE/"registration-and-interface-report-003.json"
CAPTURE_DIR=R/"anatomy-completion-1276/right-scm-native-composition-001/baseline/native-run/accepted-geometry"
STEPS=(0,4767,5023,5599,6207,6815,7423,8000)
CAPTURES=[CAPTURE_DIR/f"step-{step}.mrvpack" for step in STEPS];RECEIPTS=[CAPTURE_DIR/f"step-{step}.receipt.json" for step in STEPS]
APPEND=OUT/"append-to-right-scm-parent-002"
CHILD=APPEND/"assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
CHILD_MANIFEST=CHILD.with_suffix(".manifest.json")
CHILD_RECEIPT=APPEND/"resting-anatomy-receipt.json"
APPEND_REPORT=APPEND/"append-preparation-report.json"
PARENT=R/"anatomy-completion-1276/right-scm-native-composition-001/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
PARENT_RECEIPT=R/"anatomy-completion-1276/right-scm-native-composition-001/resting-anatomy-receipt.json"
H=R/"anatomy-completion-1276/neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
COMPOSER=Path("/Users/n/numi-human-anatomy-publication-1308")
sys.path.insert(0,str(COMPOSER/"src"))
from numilab_human import passive_attachment_composition as pac
_hspec=importlib.util.spec_from_file_location("masseter_abi5_forward",H)
h=importlib.util.module_from_spec(_hspec);_hspec.loader.exec_module(h)
OWNER=Path("/Users/n/numi-human-touching-loop-arrangement-1290");sys.path.insert(0,str(OWNER/"src"))
from numilab_human import cardiac_cavity_intersections as pred
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_geometry as cg
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def rec(v,f):return pred._records([pred.float32_point_lattice_key(p) for p in np.asarray(v,dtype="<f4")],np.asarray(f,dtype=np.int64).tolist())
def target_keys_from_pack(path):
 with path.open("rb") as stream:m=mmap.mmap(stream.fileno(),0,access=mmap.ACCESS_READ)
 h=ca._PACK_HEADER.unpack_from(m,0);directory={}
 for i in range(h[2]):
  item=ca._PACK_DIRECTORY.unpack_from(m,ca._PACK_HEADER.size+i*ca._PACK_DIRECTORY.size);directory[item[0]]=item
 primitive=directory[4];keys=set()
 for i in range(primitive[4]):
  off=primitive[2]+i*64;sem,sid,body,_=struct.unpack_from("<4I",m,off+16)
  if sem not in (51004,51007,51999):keys.add((int(sem),int(sid)))
 m.close();return keys
def body23(path,step):
 rc=json.loads(path.read_text())
 if rc.get("accepted_step")!=step or rc.get("physical_endpoint")!="accepted":raise RuntimeError(f"receipt identity mismatch {step}")
 rows=rc.get("accepted_body_poses")
 if not isinstance(rows,list) or len(rows)!=157:raise RuntimeError(f"expected157 body poses {step}")
 poses={int(r["body_index"]):(np.asarray(r["position_m"],dtype="<f4"),np.asarray(r["quaternion_xyzw"],dtype="<f4")) for r in rows}
 if len(poses)!=157 or 23 not in poses:raise RuntimeError(f"body23 absent {step}")
 p,q=poses[23];return ca._rotation(q),p.astype(np.float64),len(poses),poses
def external_hits(v,f,packed,targets):
 first=rec(v,f);lo=v.min(0);hi=v.max(0);hits=[];disjoint=0;points=packed.astype("<f4")
 for key,s in targets.items():
  tf=np.asarray(s["faces"],dtype=np.int64);tri=points[tf]
  take=np.flatnonzero(np.all(tri.max(1)>=lo,axis=1)&np.all(tri.min(1)<=hi,axis=1))
  if not len(take):disjoint+=1;continue
  sub=tf[take];ids=np.unique(sub.reshape(-1));second=rec(points[ids],np.searchsorted(ids,sub))
  result=pred._audit_pair(first,second,same_surface=False)
  if result["count"]:hits.append({"semantic":int(key[0]),"stable_id":int(key[1]),"count":int(result["count"]),"witness_pairs":result["triangle_pairs"][:12]})
 return hits,disjoint
t0=time.monotonic()
sr=json.loads(SOURCE_REPORT.read_text())
if sr.get("status")!="source_geometry_clear" or not sr.get("selected_trial",{}).get("passed_source_gate"):raise RuntimeError("source proof is not a passing exact source gate")
if sr["candidate_npz"]["sha256"]!=sha(CAND):raise RuntimeError("source candidate hash differs from source report")
input_paths=[Path(__file__),CAND,SOURCE_REPORT,SOURCE_RUNNER,NPZ,META,REG,*CAPTURES,*RECEIPTS,
 OWNER/"src/numilab_human/cardiac_cavity_intersections.py",
 OWNER/"src/numilab_human/cardiac_cavity_geometry.py",
 OWNER/"src/numilab_human/common_atlas_skin_clearance.py",
 APPEND_REPORT,CHILD,CHILD_MANIFEST,CHILD_RECEIPT,PARENT,PARENT.with_suffix(".manifest.json"),PARENT_RECEIPT,
 COMPOSER/"src/numilab_human/passive_attachment_composition.py",H]
pins={str(p):sha(p) for p in input_paths}
registration=json.loads(REG.read_text())["source_registration"]
mat=np.asarray(registration["head_refined_source_to_bodyparts_matrix"],dtype=np.float64)
hb=registration["head_binding"];br=np.asarray(hb["rotation_matrix"],dtype=np.float64);bt=np.asarray(hb["translation_m"],dtype=np.float64);bs=float(hb["scale"])
z=np.load(CAND,allow_pickle=False)
child_data=pac._read_nhtiss4(CHILD)
child_tissue=h.load_tissue(CHILD)
parent_tissue=h.load_tissue(PARENT)
parent_hrow=h.row_data(parent_tissue,151)
child_manifest=json.loads(CHILD_MANIFEST.read_text())
registration=json.loads(REG.read_text())["source_registration"]
mat=np.asarray(registration["head_refined_source_to_bodyparts_matrix"],dtype=np.float64)
hb=registration["head_binding"];br=np.asarray(hb["rotation_matrix"],dtype=np.float64);bt=np.asarray(hb["translation_m"],dtype=np.float64);bs=float(hb["scale"])
names=("Superficial part of masseter.l","Superficial part of masseter.r")
stable_for_name={"Superficial part of masseter.r":159,"Superficial part of masseter.l":160}
meta=json.loads(META.read_text());objects={o["object_name"]:o for o in meta["objects"]}
original=np.load(NPZ,allow_pickle=False)
parent_data=pac._read_nhtiss4(PARENT)
parent_row151=next(r for r in parent_data["records"] if int(r[6])==151)
parent151=pac._row_slices(parent_data,parent_row151)
parent_head_bindings=[parent151["binding_bytes"][i*36:(i+1)*36] for i in range(parent151["binding_count"])
                      if struct.unpack_from("<I",parent151["binding_bytes"],i*36)[0]==23]
if len(parent_head_bindings)!=1:raise RuntimeError("current row151 does not have one core-23 binding")
parent_head_binding=parent_head_bindings[0]
candidate={};source_rows=[]
for name in names:
 sid=stable_for_name[name]
 rows=[r for r in child_data["records"] if int(r[6])==sid]
 if len(rows)!=1:raise RuntimeError(f"appended child lacks exactly one row {sid}")
 local=pac._row_slices(child_data,rows[0]);arr=pac._biceps_row_arrays(local)
 hrow=h.row_data(child_tissue,sid)
 if local["layer"]!=1 or local["vertex_count"]!=702 or local["index_count"]!=4212 or local["binding_count"]!=1:
  raise RuntimeError(f"unexpected appended ABI row shape for {sid}")
 if local["binding_bytes"]!=parent_head_binding:raise RuntimeError(f"row {sid} head binding differs from current row151")
 if not (np.array_equal(hrow["positions"],arr["vertices6"][:,:3]) and np.array_equal(hrow["faces"],arr["faces"]) and np.array_equal(hrow["local"],arr["binding_indices"]) and np.array_equal(hrow["weights"],arr["weights"])):raise RuntimeError(f"h.row_data differs from composer-decoded row {sid}")
 if not (np.all(arr["binding_indices"][:,0]==0) and np.all(arr["binding_indices"][:,1:]==0xFFFFFFFF)
         and np.all(arr["weights"][:,0]==1) and np.all(arr["weights"][:,1:]==0)):
  raise RuntimeError(f"row {sid} support weights/sentinels differ")
 key=name.replace(" ","_")
 z_vertices=np.asarray(z[key+"__vertices_f32"],dtype="<f4")
 faces=np.asarray(z[key+"__faces_i32"],dtype=np.int64)
 origins=np.asarray(z[key+"__face_origins_i32"],dtype=np.int64)
 source_faces=np.asarray(original[objects[name]["prefix"]+"_triangles_i32"],dtype=np.int64)
 if not np.array_equal(origins,np.arange(len(faces))) or not np.array_equal(faces,source_faces):
  raise RuntimeError(f"source face stream or ancestry changed for {name}")
 bp_expected=np.asarray(z_vertices.astype(np.float64)@mat[:3,:3].T+mat[:3,3],dtype="<f4")
 bp_payload=np.asarray(arr["vertices6"][:,:3],dtype="<f4")
 if bp_expected.tobytes()!=bp_payload.tobytes():raise RuntimeError(f"row {sid} stored positions differ from registered source candidate")
 if not np.isfinite(arr["vertices6"]).all():raise RuntimeError(f"row {sid} has nonfinite vertex/normal fields")
 normals=arr["vertices6"][:,3:].astype(np.float64)
 if np.max(np.abs(np.linalg.norm(normals,axis=1)-1.0))>2e-6:raise RuntimeError(f"row {sid} normals are not unit length")
 v=bp_payload;canonical=bt+bs*(v.astype(np.float64)@br.T)
 candidate[name]={"stable_id":sid,"source_vertices":z_vertices,"bodyparts_vertices":v,"faces":faces,
                  "face_origins":origins,"canonical":canonical,"payload_row":local,"h_row":hrow}
 for space,vertices in (("source",z_vertices),("registered_bodyparts",v),("head_local",np.asarray(canonical,dtype="<f4"))):
  exact=pred._audit_pair(rec(vertices,faces),rec(vertices,faces),same_surface=True)
  top=cg.analyze_topology(vertices.tolist(),faces.tolist())
  source_rows.append({"stable_id":sid,"object_name":name,"space":space,"self_count":int(exact["count"]),
      "self_pairs":exact["triangle_pairs"][:12],"closed_oriented":bool(top.get("closed_oriented_manifold_candidate")),
      "vertex_count":len(vertices),"face_count":len(faces)})
base_keys=target_keys_from_pack(CAPTURES[0]);expected=set(base_keys)|{(51007,1)}|{(51004,i) for i in range(1,186)}
if (51005,151) not in base_keys:raise RuntimeError("current right-SCM stable151 target is absent from the target inventory")
if len(expected)!=861:raise RuntimeError(f"expected861 target keys, got{len(expected)}")
pose_rows=[];external_rows=[];bilateral_rows=[];parent151_replay_rows=[];all_pose_self=True;all_external=True
for step,packpath,receipt in zip(STEPS,CAPTURES,RECEIPTS):
 rot,trans,body_count,posemap=body23(receipt,step)
 packed,targets,stats=ca._pack_surfaces(packpath,base_keys)
 if set(targets)!=expected:raise RuntimeError(f"target keyset mismatch: got{len(targets)} expected{len(expected)} at{step}")
 if (51005,151) not in targets:raise RuntimeError(f"stable151 SCM is missing from the pose target map at{step}")
 world={}
 for name,c in candidate.items():
  v=np.asarray(c["canonical"]@rot.T+trans,dtype="<f4")
  world[name]=v
  h_world=np.asarray(h.forward(c["h_row"]["positions"],c["h_row"]["local"],c["h_row"]["weights"],c["h_row"],child_tissue,posemap),dtype="<f4")
  forward_error=float(np.linalg.norm(h_world.astype(np.float64)-v.astype(np.float64),axis=1).max(initial=0.0))
  if forward_error>2e-6:raise RuntimeError(f"h.forward disagrees with registered-payload replay at {step}/{name}: {forward_error}")
  v=h_world;world[name]=v
  exact=pred._audit_pair(rec(v,c["faces"]),rec(v,c["faces"]),same_surface=True)
  top=cg.analyze_topology(v.tolist(),c["faces"].tolist())
  pose_rows.append({"step":step,"object_name":name,"stable_id":c["stable_id"],"body_pose_count":body_count,"abi5_forward_max_delta_from_registered_matrix_m":forward_error,"self_pair_count":int(exact["count"]),"self_pairs":exact["triangle_pairs"][:12],"closed_oriented":bool(top.get("closed_oriented_manifold_candidate"))})
  if exact["count"] or not top.get("closed_oriented_manifold_candidate"):all_pose_self=False
 scene151_faces=np.asarray(targets[(51005,151)]["faces"],dtype=np.int64)
 scene151_offset=scene151_faces-parent_hrow["faces"]
 if scene151_faces.shape!=parent_hrow["faces"].shape or not np.all(scene151_offset==scene151_offset.flat[0]):raise RuntimeError(f"native stable151 face stream does not map to parent ABI5 row at {step}")
 scene151_world=packed[int(scene151_offset.flat[0]):int(scene151_offset.flat[0])+parent_hrow["vc"]]
 scene151_prediction=np.asarray(h.forward(parent_hrow["positions"],parent_hrow["local"],parent_hrow["weights"],parent_hrow,parent_tissue,posemap),dtype="<f4")
 parent151_replay_error=float(np.linalg.norm(scene151_world.astype(np.float64)-scene151_prediction.astype(np.float64),axis=1).max(initial=0.0))
 if parent151_replay_error>1e-6:raise RuntimeError(f"current parent row151 h.forward replay error {parent151_replay_error}m at {step}")
 parent151_replay_rows.append({"step":step,"stable_id":151,"captured_vertex_count":len(scene151_world),"max_world_position_error_m":parent151_replay_error})
 for name,c in candidate.items():
  hits,disjoint=external_hits(world[name],c["faces"],packed,targets)
  count=sum(h["count"] for h in hits)
  external_rows.append({"step":step,"object_name":name,"target_count":len(targets),"aabb_disjoint_target_count":disjoint,"external_pair_count":count,"targets":hits})
  if count:all_external=False
 l=candidate[names[0]];r=candidate[names[1]]
 cross=pred._audit_pair(rec(world[names[0]],l["faces"]),rec(world[names[1]],r["faces"]),same_surface=False)
 bilateral_rows.append({"step":step,"pair_count":int(cross["count"]),"pairs":cross["triangle_pairs"][:12]})
 if cross["count"]:all_external=False
 del packed,targets,stats
# source bilateral exact check
cross=pred._audit_pair(rec(candidate[names[0]]["source_vertices"],candidate[names[0]]["faces"]),rec(candidate[names[1]]["source_vertices"],candidate[names[1]]["faces"]),same_surface=False)
bilateral_rows.insert(0,{"step":"source","pair_count":int(cross["count"]),"pairs":cross["triangle_pairs"][:12]})
if cross["count"]:all_external=False
after={str(p):sha(p) for p in input_paths}
if pins!=after:raise RuntimeError("input changed during accepted-pose/full-target audit")
report={"schema":"numi.zanatomy-superficial-masseter-current-right-scm-861-target-audit.v1","status":"offline_all_gates_clear_unadmitted" if all(x["self_count"]==0 and x["closed_oriented"] for x in source_rows) and all_pose_self and all_external else "offline_candidate_rejected_by_pose_or_target_gates","complete":True,"native_admission":False,"inputs_unchanged":pins==after,"input_sha256":pins,"source_rows":source_rows,"pose_self_audits":pose_rows,"current_parent_151_forward_replay":parent151_replay_rows,"all_eight_pose_self_clear":all_pose_self,"external_audits":external_rows,"all_eight_pose_target_crossings_zero":all_external,"bilateral_audits":bilateral_rows,"target_inventory":{"count":len(expected),"keys":[list(k) for k in sorted(expected)],"capture_steps":list(STEPS),"bed_excluded":True,"current_right_scm_stable_151_included":True,"current_right_scm_target_key":[51005,151]},"capture_pose_source":"authoritative accepted_body_poses[body_index=23] from eight physical_endpoint=accepted right-SCM parent receipts; pose fitting was not used. Candidate and parent rows were decoded with retained ABI5 h.row_data and forwarded with h.forward; row151 replayed against captured packed vertices within 1e-6m.","registration":{"raw_Z_to_BodyParts_matrix":registration["head_refined_source_to_bodyparts_matrix"],"head_binding":hb},"candidate_npz":{"path":str(CAND),"sha256":sha(CAND)},"appended_payload":{"path":str(CHILD),"sha256":sha(CHILD)},"appended_manifest":{"path":str(CHILD_MANIFEST),"sha256":sha(CHILD_MANIFEST)},"bound_receipt":{"path":str(CHILD_RECEIPT),"sha256":sha(CHILD_RECEIPT)},"append_report":{"path":str(APPEND_REPORT),"sha256":sha(APPEND_REPORT)},"current_parent_payload":{"path":str(PARENT),"sha256":sha(PARENT)},"interpretation":"This is an offline inferred source correction with unchanged topology/face ancestry and one-hot head binding. The full external exact-predicate screen includes all current bones, skin and other body surfaces and excludes only the bed. Any nonzero rows remain unresolved; no geometry is admitted to runtime here.","elapsed_seconds":time.monotonic()-t0}
AUDIT_OUT=OUT/"audit-current-right-scm-861-001"
AUDIT_OUT.mkdir(parents=True,exist_ok=False)
path=AUDIT_OUT/"report.json";path.write_text(json.dumps(report,sort_keys=True,indent=2)+"\n")
print(json.dumps({"status":report["status"],"source":[(x["object_name"],x["self_count"],x["closed_oriented"]) for x in source_rows],"all_eight_pose_self_clear":all_pose_self,"all_external_clear":all_external,"target_count":len(expected),"audit":str(path),"audit_sha256":sha(path),"inputs_unchanged":pins==after,"elapsed_seconds":report["elapsed_seconds"]},sort_keys=True),flush=True)

