from pathlib import Path
import sys,pickle,json,importlib.util,hashlib,time
from collections import defaultdict
B=Path('/Users/n/numi-human-back-m6-1349');D=Path('/Users/n/numi-human-fds132-m6-1350/attempt-060-paired-cut-sliver-contraction-001');O=D/'exact-check-001';O.mkdir(exist_ok=False)
sys.path.insert(0,'/Users/n/numi-human-exact-normalization-m6-1348/src')
from numilab_human import cardiac_cavity_intersections as ci
S=B/'attempt-337-registered-edge-contact-arrangement-001/cardiac_partition_certificate_rational_multicomponent.py';sp=importlib.util.spec_from_file_location('numilab_human.cert342',S);c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
P=D/'candidate.pkl';d=pickle.loads(P.read_bytes());regions={n:[tuple(z['vertices'][i] for i in f) for f in z['faces']] for n,z in d['regions'].items()}
def parity(t):
 ss=sorted(t);p=[ss.index(x) for x in t];return (-1)**sum(p[i]>p[j] for i in range(3) for j in range(i+1,3))
byface=defaultdict(list)
for name,ts in regions.items():
 for i,t in enumerate(ts):byface[tuple(sorted(t))].append((name,i,t,parity(t)))
union=[];interface=[];invalid=[]
for k,rs in byface.items():
 if len(rs)==1:union.append(rs[0][2])
 elif len(rs)==2 and rs[0][0]!=rs[1][0] and rs[0][3]==-rs[1][3]:interface.append(k)
 else:invalid.append([(n,i) for n,i,t,p in rs])
out=dict(candidate_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),complete=False,duplicate_orientation_failures=invalid,shared_interface_triangles=len(interface),checks={})
start=time.monotonic()
for name,tris in {**regions,'union':union}.items():
 try:top=c._topology(tris);err=None
 except Exception as e:top=None;err=str(e)
 vertices,faces=c._mesh(tris);rec=ci._records(vertices,faces);au=ci._audit_pair(rec,rec,same_surface=True)
 out['checks'][name]=dict(topology=top,topology_error=err,self_count=au['count'],self_pairs=au['triangle_pairs'])
 (O/'report.json').write_text(json.dumps(out,indent=2,default=str)+'\n')
 print(json.dumps(dict(name=name,topology=top,error=err,self_count=au['count'])),flush=True)
out.update(complete=True,elapsed_seconds=time.monotonic()-start);(O/'report.json').write_text(json.dumps(out,indent=2,default=str)+'\n')

