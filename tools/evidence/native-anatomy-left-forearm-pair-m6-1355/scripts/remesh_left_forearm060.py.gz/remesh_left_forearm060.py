from pathlib import Path
import json,pickle,hashlib,sys,importlib.util,time
from collections import defaultdict,Counter
from fractions import Fraction as F
import numpy as np
B=Path('/Users/n/numi-human-back-m6-1349');W=Path('/Users/n/numi-human-fds132-m6-1350')
O=W/'attempt-060-paired-cut-sliver-contraction-001';O.mkdir(exist_ok=False)
sys.path.insert(0,'/Users/n/numi-human-exact-normalization-m6-1348/src')
from numilab_human import cardiac_cavity_intersections as ci
S=B/'attempt-337-registered-edge-contact-arrangement-001/cardiac_partition_certificate_rational_multicomponent.py';sp=importlib.util.spec_from_file_location('numilab_human.certforearm057',S);c=importlib.util.module_from_spec(sp);sp.loader.exec_module(c)
A=W/'attempt-050/arrangement-001/result-001/source-parent-refs-054/source-parent-refs-and-shared-interface.json';src=json.loads(A.read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
localpoints={name:[tuple(F(*x) for x in v['exact_xyz_m']) for v in z['vertices']] for name,z in src['rows'].items()}
points=sorted({p for pp in localpoints.values() for p in pp});index={p:i for i,p in enumerate(points)}
faces={name:[tuple(index[localpoints[name][int(i)]] for i in tri) for tri in z['faces']] for name,z in src['rows'].items()}
original={k:list(v) for k,v in faces.items()};np_points=np.asarray(points,float)
regions={n:[tuple(points[i] for i in f) for f in fs] for n,fs in faces.items()}
face_rows={n:z['face_parent_refs'] for n,z in src['rows'].items()}
original_raw=set()
for name,descriptor in src['source_ids'].items():
 z=np.load(descriptor['candidate_path'])
 assert sha(descriptor['candidate_path'])==descriptor['candidate_sha256']
 original_raw.update(tuple(F(float(x)) for x in p) for p in z['vertices6'][:,:3])
patch={i for i,p in enumerate(points) if p not in original_raw}
baseline_topology={n:c._topology(tris) for n,tris in regions.items()}
origin=np.arange(len(points));members={i:{i} for i in range(len(points))}
removed=defaultdict(list);accepted=[];rejected=[];start=time.monotonic()
def mesh_edges(fs):
 e=defaultdict(list);vf=defaultdict(set)
 for fi,f in enumerate(fs):
  if f is None:continue
  for v in f:vf[v].add(fi)
  for a,b in zip(f,f[1:]+f[:1]):e[tuple(sorted((a,b)))].append(fi)
 return e,vf
def normal(f):return ci._cross(ci._sub(points[f[1]],points[f[0]]),ci._sub(points[f[2]],points[f[0]]))
def union_faces():
 by=defaultdict(list)
 for name,fs in faces.items():
  for f in fs:
   if f is not None:by[tuple(sorted(f))].append((name,f))
 union=[]
 for rows in by.values():
  if len(rows)==1:union.append(rows[0][1])
  else:
   assert len(rows)==2 and rows[0][0]!=rows[1][0]
   a,b=rows[0][1],rows[1][1]
   assert any(a==tuple(reversed(b[k:]+b[:k])) for k in range(3))
 return union
def contraction(u,v):
 # Keep the simpler existing exact endpoint, preferring the midline; never invent a support map.
 key=lambda i:(points[i][0]!=0,sum(x.numerator.bit_length()+x.denominator.bit_length() for x in points[i]),i)
 keep,drop=sorted((u,v),key=key)
 merged=members[keep]|members[drop]
 disp=max(float(np.linalg.norm(np_points[j]-np_points[keep])) for j in merged)
 if disp>1e-5:return None,'cumulative_displacement'
 changes={}
 # A collapse may not identify a free material vertex with an interface vertex.
 labels={i:{name for name,fs in faces.items() if any(f is not None and i in f for f in fs)} for i in (u,v)}
 if labels[u]!=labels[v]:return None,'material_vertex_stratum'
 guard_faces={**faces,'_union':union_faces()}
 for name,fs in guard_faces.items():
  ed,vf=mesh_edges(fs)
  if drop not in vf:continue
  if keep in vf and tuple(sorted((keep,drop))) not in ed:return None,'nonedge_identification:'+name
  if keep in vf:
   ef=ed[tuple(sorted((keep,drop)))]
   if len(ef)!=2:return None,'edge_incidence:'+name
   nk={w for f in vf[keep] for w in fs[f]}-{keep,drop}
   nd={w for f in vf[drop] for w in fs[f]}-{keep,drop}
   opp={w for fi in ef for w in fs[fi]}-{keep,drop}
   if nk&nd !=opp:return None,'link_condition:'+name
  change={}
  for fi in vf[drop]:
   old=fs[fi];new=tuple(keep if x==drop else x for x in old)
   if len(set(new))<3:change[fi]=None;continue
   nn=normal(new);on=normal(old)
   if not any(nn):return None,'collinear:'+name
   if sum(x*y for x,y in zip(nn,on))<=0:return None,'normal_inversion:'+name
   change[fi]=new
  occupied={tuple(sorted(f)) for fi,f in enumerate(fs) if f is not None and fi not in change}
  for f in change.values():
   if f is None:continue
   keyf=tuple(sorted(f))
   if keyf in occupied:return None,'duplicate_face:'+name
   occupied.add(keyf)
  if name!='_union':changes[name]=change
 return (keep,drop,merged,disp,changes),None
# Only short edges in submicrometre-altitude faces meeting new intersection vertices are candidates.
# The global displacement cap is 10 um; measured native invalid triangle11496 spans0.924um.
tested=set()
while True:
 ed=set()
 for fs in faces.values():
  active=np.asarray([f for f in fs if f is not None],int)
  tri=np_points[active];lengths=np.linalg.norm(tri[:,[1,2,0]]-tri[:,[0,1,2]],axis=2)
  altitude=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/lengths.max(axis=1)
  for f,ll,alt in zip(active,lengths,altitude):
   if alt>1e-6:continue
   for j in range(3):
    a,b=sorted((int(f[j]),int(f[(j+1)%3])))
    if ll[j]<=1e-5 and (members[a]|members[b])&patch:ed.add((a,b))
 short=sorted((float(np.linalg.norm(np_points[a]-np_points[b])),a,b) for a,b in ed if (a,b) not in tested)
 if not short:break
 length,u,v=short[0];tested.add((u,v));result,error=contraction(u,v)
 if error:rejected.append(dict(edge=[u,v],length_m=length,reason=error));continue
 keep,drop,merged,disp,changes=result
 for name,ch in changes.items():
  for fi,f in ch.items():
   if f is None:removed[name].append(fi)
   faces[name][fi]=f
 origin[list(members[drop])]=keep;members[keep]=merged;members[drop]=set()
 accepted.append(dict(keep=keep,drop=drop,length_m=length,max_original_vertex_displacement_m=disp,changed_faces={n:sorted(ch) for n,ch in changes.items()}))
print(json.dumps(dict(accepted=len(accepted),rejected=len(rejected))),flush=True)
out={};metrics={}
for name,fs in faces.items():
 kept=[i for i,f in enumerate(fs) if f is not None];triangles=[tuple(points[i] for i in fs[fi]) for fi in kept]
 try:top=c._topology(triangles);err=None
 except Exception as e:top=None;err=str(e)
 before=c._moment_vector(regions[name])[0];after=c._moment_vector(triangles)[0]
 out[name]=dict(original_local_to_global=[index[p] for p in localpoints[name]],vertices=points,faces=[fs[i] for i in kept],original_face_indices=kept,arrangement_row_ancestry=[face_rows[name][i] for i in kept],removed_original_face_indices=removed[name])
 metrics[name]=dict(before_faces=len(original[name]),after_faces=len(kept),topology=top,topology_error=err,before_signed_volume_m3=float(before),after_signed_volume_m3=float(after),relative_signed_volume_change=float((after-before)/before),exact_signed_volume_change=str(after-before))
payload=dict(regions=out,original_to_retained_vertex=origin.tolist(),contractions=accepted,source_arrangement=str(A),source_sha256=sha(A),inferred_geometry=True,scope='Paired submicrometre-altitude cut-sliver contraction with edges up to10um at new exact-intersection vertices of left132/134. Existing raw-source-only edges excluded. Ancestry retained as provenance, not a claim of exact source-face coplanarity after contraction.')
p=O/'candidate.pkl';p.write_bytes(pickle.dumps(payload,protocol=5))
report=dict(union_link_and_material_stratum_guard=True,baseline_topology=baseline_topology,failed_native_triangle11496_removed=11496 in removed['132'],complete=True,admitted=False,source_pins={str(x):sha(x) for x in [Path(__file__),A,S]},candidate_path=str(p),candidate_sha256=sha(p),edge_threshold_m=1e-5,minimum_altitude_threshold_m=1e-6,cumulative_displacement_bound_m=1e-5,max_actual_displacement_m=max((r['max_original_vertex_displacement_m'] for r in accepted),default=0),accepted_contractions=accepted,rejected_contractions=rejected,regions=metrics,elapsed_seconds=time.monotonic()-start,qualification='Construction only. Exact self/interface tests and source-map/pose checks pending. Original054 native006 presentation failed at7.614s. This inferred remesh is not admitted.')
(O/'report.json').write_text(json.dumps(report,indent=2,default=str)+'\n')
print(json.dumps({k:report[k] for k in ('candidate_sha256','max_actual_displacement_m','regions','elapsed_seconds')},default=str),flush=True)

