#!/usr/bin/env python3
from __future__ import annotations
import hashlib, importlib.util, json, signal, sys, time, traceback
from fractions import Fraction
from pathlib import Path
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
A=R/"anatomy-completion-1276"
ROOT=A/"scm-vessel-clearance-001"
OUT=ROOT/"run-064-scm-ijv-offset-difference-002"
RESULT=OUT/"result-001"
PATCH=A/"right-scm-local-reference-002/stable-151-alpha-0.3.npz"
TISS=R/"passive-neck-back-coverage-1281/candidate-005/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
FORWARD=A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
PACKDIR=A/"twenty-six-surface-native-composition-001/baseline/native-run/accepted-geometry"
PACK=PACKDIR/"step-0.mrvpack"
RECEIPT=PACKDIR/"step-0.receipt.json"
INV=Path("/Users/n/numi-human-resting-evidence-20261005/native-complete-skin-containment-audit-890/pair-summary-v3.csv")
OWNER=Path("/Users/n/numi-human-anatomy-publication-1308/src")
CA=OWNER/"numilab_human/common_atlas_skin_clearance.py"
CI=OWNER/"numilab_human/cardiac_cavity_intersections.py"
PART=OWNER/"numilab_human/cardiac_cavity_partition.py"
SCRIPT=Path(__file__).resolve()
if OUT.exists():
    raise SystemExit(f"refuse existing output path {OUT}")
OUT.mkdir(parents=True)
RESULT.mkdir()
def sha(p):
    h=hashlib.sha256()
    with Path(p).open("rb") as f:
        for b in iter(lambda:f.read(4*1024*1024),b""): h.update(b)
    return h.hexdigest()
def req(c,m):
    if not c: raise RuntimeError(m)
def alarm(_sig,_frame):
    raise TimeoutError("two-surface exact arrangement exceeded 150 seconds")
signal.signal(signal.SIGALRM,alarm)
started=time.monotonic()
BASE_ZERO_REPORT=ROOT/"run-062-scm-ijv-difference-001/result-001/report.json"
REPORT_PREFLIGHT=ROOT/"run-064-report-writer-preflight-001.json"
REPORT_PREFLIGHT_SCRIPT=ROOT/"run-064-report-writer-preflight-001.py"
pins={str(p):sha(p) for p in [PATCH,TISS,FORWARD,PACK,RECEIPT,INV,CA,CI,PART,BASE_ZERO_REPORT,REPORT_PREFLIGHT,REPORT_PREFLIGHT_SCRIPT]}
receipt=json.loads(RECEIPT.read_text())
req(receipt.get("accepted_step")==0 and receipt.get("physical_endpoint")=="accepted" and receipt.get("pack_file_sha256")==sha(PACK),"step0 receipt/pack mismatch")
sys.path.insert(0,str(OWNER))
from numilab_human import common_atlas_skin_clearance as ca, cardiac_cavity_intersections as ci, cardiac_cavity_partition as cp
spec=importlib.util.spec_from_file_location("scm_forward",FORWARD)
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
tissue=h.load_tissue(TISS)
row=h.row_data(tissue,151)
with np.load(PATCH,allow_pickle=False) as z:
    scm=np.asarray(z["vertices6"][:,:3],dtype="<f4")
    faces=np.asarray(z["faces"],dtype=np.int64)
    local=np.asarray(z["binding_indices"],dtype="<u4")
    weights=np.asarray(z["weights"],dtype="<f4")
row.update(positions=scm,faces=faces,local=local,weights=weights)
poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype=np.float32),np.asarray(x["quaternion_xyzw"],dtype=np.float32)) for x in receipt["accepted_body_poses"]}
req(len(poses)==157,"step0 capture must contain all 157 body poses")
legacy,*_=ca._load_target_inventory(INV); legacy=set(legacy)
xyz,surfs,_=ca._pack_surfaces(PACK,legacy)
vkey=(51011,468)
req(vkey in surfs,"IJV stable key absent from accepted pack")
vfaces=np.asarray(surfs[vkey]["faces"],dtype=np.int64)
vused=np.unique(vfaces.reshape(-1)); vmap=np.full(len(xyz),-1,dtype=np.int64); vmap[vused]=np.arange(len(vused),dtype=np.int64)
vessel=ca._prepare_closed_clearance_target(np.asarray(xyz[vused],dtype="<f4"),vmap[vfaces])
req(vessel["report"]["closed_connected_oriented"] and vessel["report"]["self_intersection_audit"]["count"]==0 and vessel["report"]["embedded_closed_target"],"accepted IJV is not an exact closed embedded target")
# Declared reference offset: expand the closed accepted IJV shell 0.10 mm
# along area-weighted vertex normals, then revalidate the packed-F32 shell.
# This is an inferred geometry search margin, not a measured tissue gap.
base_vessel_vertices=np.asarray(vessel["vertices"],dtype=np.float64)
base_vessel_faces=np.asarray(vessel["faces"],dtype=np.int64)
face_cross=np.cross(base_vessel_vertices[base_vessel_faces[:,1]]-base_vessel_vertices[base_vessel_faces[:,0]],
                    base_vessel_vertices[base_vessel_faces[:,2]]-base_vessel_vertices[base_vessel_faces[:,0]])
signed_volume_base=float(np.einsum("ij,ij->i",base_vessel_vertices[base_vessel_faces[:,0]],
                                   np.cross(base_vessel_vertices[base_vessel_faces[:,1]],base_vessel_vertices[base_vessel_faces[:,2]])).sum()/6.0)
req(abs(signed_volume_base)>0,"IJV signed volume is zero")
if signed_volume_base<0: face_cross=-face_cross
vertex_normals=np.zeros_like(base_vessel_vertices)
for corner in range(3): np.add.at(vertex_normals,base_vessel_faces[:,corner],face_cross)
norms=np.linalg.norm(vertex_normals,axis=1)
req(np.isfinite(norms).all() and np.all(norms>0),"IJV has an undefined vertex normal for the reference offset")
vertex_normals/=norms[:,None]
offset_m=0.0001
offset_vessel_vertices=np.asarray(base_vessel_vertices+offset_m*vertex_normals,dtype="<f4")
offset_displacements=np.linalg.norm(offset_vessel_vertices.astype(np.float64)-base_vessel_vertices,axis=1)
offset_vessel=ca._prepare_closed_clearance_target(offset_vessel_vertices,
                np.asarray(vessel["faces"],dtype=np.int64))
req(offset_vessel["report"]["closed_connected_oriented"] and
    offset_vessel["report"]["self_intersection_audit"]["count"]==0 and
    offset_vessel["report"]["embedded_closed_target"],
    "0.10 mm offset IJV shell failed closed embedded exact validation")

world=h.forward(scm,local,weights,row,tissue,poses).astype("<f4")
req(np.isfinite(world).all(),"nonfinite SCM forward")
def rational_vertices(points):
    return [tuple(Fraction.from_float(float(x)) for x in p) for p in np.asarray(points,dtype="<f4")]
sources={
    "SCM":{"vertices":rational_vertices(world),"triangles":faces.tolist(),"source_sha256":sha(PATCH)},
     "IJV":{"vertices":rational_vertices(offset_vessel["vertices"]),
            "triangles":np.asarray(offset_vessel["faces"],dtype=np.int64).tolist(),"source_sha256":sha(PACK)}
}
req(len(sources["SCM"]["vertices"])==len(world) and len(sources["IJV"]["vertices"])==len(vessel["vertices"]),"rationalization changed vertex count")
signal.alarm(240)
children,meta=cp.construct_arrangement(sources,source_names=("SCM","IJV"))
signal.alarm(0)

# Form the exact oriented boundary of SCM minus IJV: retain SCM exterior
# patches and reverse IJV patches that lie inside SCM.
selected=[]
ancestry=[]
for child in children:
    if child["source"]=="SCM" and child["other_location"]=="outside":
        selected.append(tuple(child["vertices"]))
        ancestry.append({"source":"SCM","source_face":int(child["source_face"]),"reversed":False})
    elif child["source"]=="IJV" and child["other_location"]=="inside":
        tri=tuple(child["vertices"])
        selected.append((tri[0],tri[2],tri[1]))
        ancestry.append({"source":"IJV","source_face":int(child["source_face"]),"reversed":True})
req(selected,"empty SCM-minus-IJV boundary")
mesh=cp.indexed_mesh(selected,convert=lambda x:x)
exact_vertices=mesh["vertices_m"]
faces_out=mesh["triangles"]
records=ci._records(exact_vertices,faces_out)
exact_self=ci._audit_pair(records,records,same_surface=True)
exact_topology=None
exact_topology_error=None
try:
    exact_topology=cp._validate_output_topology(records)
except Exception as e:
    exact_topology_error=f"{type(e).__name__}: {e}"
# Exact signed volume from rational triangle coordinates.
def dot(a,b): return sum(a[i]*b[i] for i in range(3))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def signed_mesh_volume(vertices,faces):
    value=Fraction(0)
    for f in faces:
        a,b,c=(vertices[i] for i in f)
        value += dot(a,cross(b,c))/6
    return value
vol=signed_mesh_volume(exact_vertices,faces_out)
scm_original_exact=rational_vertices(world)
scm_original_volume=signed_mesh_volume(scm_original_exact,faces.tolist())
zero_report=json.loads(BASE_ZERO_REPORT.read_text())
zero_vol=cp._decode_fraction(zero_report["output"]["signed_volume_m3"])
pure_onehot=((weights==1.0).sum(axis=1)==1) & ((weights==0.0).sum(axis=1)==weights.shape[1]-1)
pure_q0=[tuple(Fraction.from_float(float(x)) for x in p) for p in world[pure_onehot]]
exact_point_set=set(exact_vertices)
pure_retained=sum(p in exact_point_set for p in pure_q0)
# Test a true canonical Float32 export. If rational vertices collide after
# conversion, indexed_mesh rejects rather than silently welding them.
mesh32=cp.indexed_mesh(selected,convert=np.float32)
verts32=np.asarray(mesh32["vertices_m"],dtype="<f4")
faces32=mesh32["triangles"]
f32_exact=[tuple(Fraction.from_float(float(x)) for x in p) for p in verts32]
records32=ci._records(f32_exact,faces32)
f32_self=ci._audit_pair(records32,records32,same_surface=True)
f32_topology=None
f32_topology_error=None
try:
    f32_topology=cp._validate_output_topology(records32)
except Exception as e:
    f32_topology_error=f"{type(e).__name__}: {e}"
# The Boolean cap lies exactly on the original IJV shell; quantify this
# intentional zero-gap interface separately from any penetration claim.
vessel_exact_vertices=rational_vertices(vessel["vertices"])
vessel_records=ci._records(vessel_exact_vertices,np.asarray(vessel["faces"],dtype=np.int64).tolist())
contact=ci._audit_pair(records,vessel_records,same_surface=False)
mesh_json={"schema":"offline.scmtarget-scm-minus-ijv-rational-mesh.v1",
           "vertices_m":cp.encode_rational(exact_vertices),
           "triangles":faces_out,"face_ancestry":ancestry}
mesh_path=RESULT/"scm-minus-ijv.exact.json"
mesh_path.write_text(json.dumps(mesh_json,sort_keys=True,separators=(",",":"),allow_nan=False)+"\n")
signal.alarm(0)
status = "constructed_unadmitted" if exact_topology is not None and exact_self["count"] == 0 and f32_topology is not None and f32_self["count"] == 0 else "constructed_rejected"
body={
 "schema":"offline.scmtarget-scm-minus-ijv-diagnostic.v1",
 "status":status,
 "scope":"Exact q0 Boolean-difference boundary from SCM/IJV arrangement. This is a pose-space diagnostic, not source-space NHTISS output.",
 "input_pins":pins,"script_sha256":sha(SCRIPT),"accepted_step":0,
 "source_arrangement_report_sha256":sha(ROOT/"run-061-two-surface-arrangement-diagnostic-003/result-001/report.json"),
 "scm_world_f32_sha256":ca._float32_xyz_sha256(world),
 "arrangement":{"intersecting_pair_count":meta["source_intersecting_triangle_pair_count"],
                "intersection_segment_count":len(meta["intersection_segments_m"]),
                "subtriangle_count":meta["subtriangle_count"],
                "source_face_count":meta["source_face_count"]},
  "boolean_rule":"SCM children outside the expanded IJV plus reversed expanded-IJV children inside SCM",
 "inferred_offset":{"nominal_vertex_normal_offset_m":offset_m,
                    "min_packed_vertex_displacement_m":float(offset_displacements.min()),
                    "max_packed_vertex_displacement_m":float(offset_displacements.max()),
                    "expanded_ijv_validation":offset_vessel["report"],
                    "interpretation":"An exploratory 0.10 mm outward reference-shell offset; not an anatomical measurement."},
 "output":{"vertex_count":len(exact_vertices),"face_count":len(faces_out),
           "ancestry_counts":{"SCM":sum(x["source"]=="SCM" for x in ancestry),
                              "IJV_cap":sum(x["source"]=="IJV" for x in ancestry)},
            "signed_volume_m3":cp.encode_rational(vol),
           "signed_volume_change_vs_zero_gap_boolean_m3":cp.encode_rational(vol-zero_vol),
           "signed_volume_change_vs_unmodified_q0_scm_m3":cp.encode_rational(vol-scm_original_volume),
           "signed_volume_change_vs_zero_gap_boolean_fraction":float((vol-zero_vol)/zero_vol),
           "pure_onehot_binding_vertices":{"count":int(pure_onehot.sum()),
               "exact_q0_points_retained":int(pure_retained),
               "remaining_points_not_retained":int(pure_onehot.sum()-pure_retained),
               "certified_attachment_mask_available":False},
           "exact_self_intersection_count":exact_self["count"],
           "exact_topology":exact_topology,"exact_topology_error":exact_topology_error,
           "float32_self_intersection_count":f32_self["count"],
           "float32_topology":f32_topology,"float32_topology_error":f32_topology_error,
           "float32_vertex_sha256":ca._float32_xyz_sha256(verts32),
           "float32_face_sha256":ca._face_index_sha256(np.asarray(faces32,dtype=np.int64))},
 "ijv_interface":{"exact_pair_count":contact["count"],
                   "expanded_shell_interface_pairs":ci._audit_pair(records,ci._records(rational_vertices(offset_vessel["vertices"]),
                 np.asarray(offset_vessel["faces"],dtype=np.int64).tolist()),same_surface=False)["count"],
                  "interpretation":"The candidate is cut against the expanded shell. Pair intersection count against the original shell is measured independently; no minimum-distance claim is made."},
 "unadmitted_mesh_path":str(mesh_path),
 "limitations":[ "The cap is coincident with the expanded reference shell; its distance from the original IJV was only screened by exact pair intersection, not by a full closest-surface distance computation.",
                "Only accepted step 0 was evaluated; no other accepted pose was checked.",
                "The mesh is in posed world coordinates and has no source-space lifted positions or binding attributes.",
                "No full 859-target or skin audit was run.",
                "Even closed/self-clear output is not an anatomical admission or a change to the retained asset."],
 "elapsed_seconds":time.monotonic()-started
}

for p,digest in pins.items():
    req(sha(p)==digest,"input changed during diagnostic: "+p)
(RESULT/"report.json").write_text(json.dumps(cp.encode_rational(body),sort_keys=True,indent=2,allow_nan=False)+"\n")
print(json.dumps({"status":body["status"],"report":str(RESULT/"report.json"),"report_sha256":sha(RESULT/"report.json"),
                  "mesh":str(mesh_path),"mesh_sha256":sha(mesh_path),"script_sha256":sha(SCRIPT),
                  "source_pair_count":meta["source_intersecting_triangle_pair_count"],
                  "output_faces":len(faces_out),"exact_self":exact_self["count"],
                  "exact_topology":exact_topology,"f32_self":f32_self["count"],
                  "f32_topology":f32_topology,"ijv_interface_pairs":contact["count"],
                  "elapsed_seconds":body["elapsed_seconds"]},sort_keys=True),flush=True)

