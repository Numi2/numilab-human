from pathlib import Path
import sys,json,hashlib,argparse,numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009");A=R/"anatomy-completion-1276"
O=A/"right-scm-native-composition-001";O.mkdir(exist_ok=False)
SRC=Path("/Users/n/numi-human-local-clearance-preservation-1280/src");sys.path.insert(0,str(SRC))
from numilab_human import passive_attachment_composition as pc,resting_run as rr
from numilab_human.resting_anatomy_interface_patch import normals
B=A/"fifty-seven-surface-native-composition-001";SK=A/"skin-candidate-30-pose-preparation-001/result-005"
T=B/"assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue";S=A/"neck-back-append-preparation-002/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
P=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011";sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
RP=A/"scm-vessel-clearance-001/run-072-scm-ica-offset-source-lift-001/result-001/report.json";C=RP.parent/"unadmitted-scm-minus-ica-ijv-source-lift.npz"
assert sha(T)=="680b9340ea33781cbd29474767929d36beaee9f13a4278d7b6fa53bdb818e1ef"
assert sha(S)=="5e026b3acdaf74d0133346be28928bc2d8c48f3427e3cf904aa5ea33df96e4c7"
assert sha(C)=="ce1f5875fef87b5c2d4eea4238b29b4599ca28ff35bd44b3b3649a22698f36cf"
assert sha(RP)=="80240935f802a05b617dd1551dd40536adadc1154cb7efc6fcfd5a45c8132546"
r=json.loads(RP.read_text())
for path,digest in r["input_pins"].items():assert sha(path)==digest,(path,sha(path),digest)
assert r["source"]["self_pairs"]==0 and r["source"]["topology"]["closed_oriented_2_manifold"]
assert len(r["pose_checks"])==8
for c in r["pose_checks"]:
 assert c["self_pairs"]==0 and c["topology"]["closed_oriented_2_manifold"] and not c["unexpected_changed_target_keys"]
 assert all(c["key_targets"][k]["candidate"]==0 for k in ("51011:466","51011:468","51007:1","51005:152"))
 assert set(c["changed_target_surfaces"])=={"51011:466","51011:468"}
z=np.load(C);cp=O/"right-scm-row-patch.npz"
np.savez(cp,vertices6=np.column_stack((z["positions_m"],normals(z["positions_m"].astype(float),z["faces"]))).astype("<f4"),faces=z["faces"],binding_indices=z["binding_indices"],weights=z["weights"])
sourceproof=O/"source-reconstruction-proof.json";bounds={151:{"scope":"Passive source-derived right sternocleidomastoid reference reconstruction with inferred vessel clearance, not measured-person geometry or mechanical muscle material.","source_report":str(RP),"source_report_sha256":sha(RP),"source_candidate":str(C),"source_candidate_sha256":sha(C),"source":r["source"],"boolean_volume_and_offset":{k:v for k,v in r["boolean"].items() if k not in ("arrangement",)},"lift":r["lift"],"limitations":r["limitations"],"native_verification_pending":True}}
sourceproof.write_text(json.dumps(bounds,indent=2,sort_keys=True)+"\n")
app=O/"append-parent";appendproof=pc.append_passive_surfaces(T,S,app,stable_ids=(151,))
pc.bind_anatomy_receipt(B/"resting-anatomy-receipt.json",app/T.name,app/"resting-anatomy-receipt.json")
replacements=[(151,cp,sourceproof)];payload=O/"assets"/T.name
composition=pc.compose(app/T.name,payload.parent,replacements,reference_surface_rows=(151,))
receipt=O/"resting-anatomy-receipt.json";bound=pc.bind_anatomy_receipt(app/"resting-anatomy-receipt.json",payload,receipt)
old=json.loads((B/"resting-anatomy-receipt.json").read_text());assert bound["mass_geometry_accounting"]==old["mass_geometry_accounting"]
(O/"composition-result.json").write_text(json.dumps(composition,indent=2,sort_keys=True)+"\n")
(O/"source-resolution-bounds.json").write_text(json.dumps(bounds,indent=2,sort_keys=True)+"\n")
proofpaths=[RP,sourceproof,app/"report.json",B/"native-verification-001/report.json"];union_inputs=list(map(Path,r["input_pins"]))
base=json.loads((P/"baseline/run-declaration.json").read_text());argsv=base["argv"][base["argv"].index("human-resting")+1:]
for flag,value in [("--body-scene",str(SK/"resting-supine-scene.manifest.json")),("--anatomy-receipt",str(receipt)),("--output",str(O/"baseline/native-run")),("--seconds","16.0")]:argsv[argsv.index(flag)+1]=value
argsv+=["--lab","/Users/n/numi-lab-complete-body-capture-1276","--build","/Users/n/numi-lab-complete-body-capture-build-1276-001"]
parser=argparse.ArgumentParser();rr.add_arguments(parser);args=parser.parse_args(argsv);native,assets=rr.command(args)
env={}
for item in base["argv"][2:base["argv"].index("human-resting")-1]:
 key,value=item.split("=",1);env[key]=value
env["NUMI_HUMAN_ROOT"]=str(SRC.parent);env["PYTHONPATH"]=str(SRC)
env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"]="0,4767,5023,5599,6207,6815,7423,8000"
assert all(n in (0,8000) or (n+1)%32==0 for n in map(int,env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"].split(",")))
# Baseline011's Q observer is inactive throughout its first16s.
# A window beyond this short run is rejected; disable the observer and omit bounds.
env["NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT"]="0"
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_FIRST_STEP",None)
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_LAST_STEP",None)
env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"]=str(args.output/"common-field-failure.json")
env.update(DYLD_LIBRARY_PATH=str(args.build/"lib")+":"+str(args.build/"matter"),DYLD_PRINT_LIBRARIES="1",NUMI_HUMAN_RESTING_INSPECTION_TOUR="1",NUMI_HUMAN_RESTING_INSPECTION_PERIOD_SECONDS=str(args.inspection_period_seconds))
argv=["/usr/bin/env","-i"]+[k+"="+v for k,v in sorted(env.items())]+["/Users/n/numi-human-prep-venv-20261005/bin/python3.13","-m","numilab_human.resting_run"]+argsv
launch=O/"launch_arm.py";launch.write_text((A/"ecu-apl-native-composition-005/launch_arm.py").read_text().replace("6000 * 1024 * 1024", "4000 * 1024 * 1024"))
pins={**assets,**{str(p):sha(p) for p in [Path(__file__),Path(pc.__file__),Path(rr.__file__),launch,O/"source-resolution-bounds.json",*proofpaths,*union_inputs]}}
for _,npz,rp in replacements:pins[str(npz)]=sha(npz);pins[str(rp)]=sha(rp)
decl={"schema":"numi.human.native-smoke.run-declaration.v1","seconds":16.0,"accepted_steps":8000,"capture_steps":[0,4767,5023,5599,6207,6815,7423,8000],"immutable_assets":pins,"argv":argv,"launch_adapter":{"path":str(launch),"sha256":sha(launch)},"owner_cli_preview":{"native_argv":native,"asset_sha256":assets,"recorded_invocation_environment":rr.invocation_environment(env)},"qualification":"Existing57 repaired surfaces and corrected skin plus passive right sternocleidomastoid151. Source and8 retained current57 poses self-clear; ICA/IJV/skin/oppositeSCM clear, all other target pair identities preserved. Inferred reference reconstruction; mass and physical routes unchanged. Native verification pending. Not whole-body or five-minute qualification; performance deferred."}
(O/"baseline").mkdir();dp=O/"baseline/run-declaration.json";dp.write_text(json.dumps(decl,indent=2,sort_keys=True)+"\n")
(O/"launch-guard.json").write_text(json.dumps({"launcher_sha256":sha(launch),"arms":{"baseline":{"run_declaration_sha256":sha(dp),"native_output":str(args.output)}}},indent=2,sort_keys=True)+"\n")
print(json.dumps({"output":str(O),"payload_sha256":sha(payload),"pins":len(pins),"bounds":bounds},indent=2))

