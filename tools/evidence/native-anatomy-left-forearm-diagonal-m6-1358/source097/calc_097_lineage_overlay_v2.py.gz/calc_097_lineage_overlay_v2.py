import pickle,hashlib,json
from pathlib import Path
from fractions import Fraction as F
root=Path('/Users/n/numi-human-fds132-m6-1350')
p097=root/'attempt-097-minimal-late-witness-diagonal-screen-001/candidate-source-preserving-flip.pkl'
p085=root/'attempt-085-interface-refinement-2mm-001/result-001/candidate.pkl'
p060=root/'attempt-060-paired-cut-sliver-contraction-001/candidate.pkl'
out=root/'attempt-100-pq130-shared-route-field-screen-001/097-lineage-overlay-001.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=pickle.loads(p097.read_bytes());b=pickle.loads(p085.read_bytes());c=pickle.loads(p060.read_bytes())
s=a['surfaces'][132];old=c['regions']['132']
newidx=(5111,5112);oldrowids=(5819,5820)
oldidx={}
for i,ref in enumerate(old['arrangement_row_ancestry']):
 row=int(ref.get('row_local_face_index',-1))
 if row in oldrowids:
  if row in oldidx:raise RuntimeError('non-unique old row-local ancestry')
  oldidx[row]=i
assert set(oldidx)==set(oldrowids),oldidx
def pt(x):return tuple(v if isinstance(v,F) else F(int(v[0]),int(v[1])) for v in x)
def orient(p,q,r):return (q[0]-p[0])*(r[1]-p[1])-(q[1]-p[1])*(r[0]-p[0])
def area2(poly):
 if len(poly)<3:return F(0)
 return abs(sum((poly[i][0]*poly[(i+1)%len(poly)][1]-poly[(i+1)%len(poly)][0]*poly[i][1] for i in range(len(poly))),F(0)))
def clip(subject,clipper,sgn):
 poly=list(subject)
 for i in range(3):
  A=clipper[i];B=clipper[(i+1)%3]
  if not poly:break
  out=[];P=poly[-1];dp=sgn*orient(A,B,P)
  for Q in poly:
   dq=sgn*orient(A,B,Q);pin=dp>=0;qin=dq>=0
   if qin:
    if not pin:
     t=dp/(dp-dq);out.append((P[0]+t*(Q[0]-P[0]),P[1]+t*(Q[1]-P[1])))
    out.append(Q)
   elif pin:
    t=dp/(dp-dq);out.append((P[0]+t*(Q[0]-P[0]),P[1]+t*(Q[1]-P[1])))
   P=Q;dp=dq
  poly=out
 return poly
def fmt(x):return {'numerator':str(x.numerator),'denominator':str(x.denominator),'decimal':float(x)}
oldtris={row:[pt(old['vertices'][int(v)]) for v in old['faces'][idx]] for row,idx in oldidx.items()}
oldgids={row:[int(old['original_local_to_global'][int(v)]) for v in old['faces'][idx]] for row,idx in oldidx.items()}
u=oldtris[5819]
normal=((u[1][1]-u[0][1])*(u[2][2]-u[0][2])-(u[1][2]-u[0][2])*(u[2][1]-u[0][1]),
 (u[1][2]-u[0][2])*(u[2][0]-u[0][0])-(u[1][0]-u[0][0])*(u[2][2]-u[0][2]),
 (u[1][0]-u[0][0])*(u[2][1]-u[0][1])-(u[1][1]-u[0][1])*(u[2][0]-u[0][0]))
axis=max(range(3),key=lambda k:abs(normal[k]));axes=[k for k in range(3) if k!=axis]
def proj(p):return (p[axes[0]],p[axes[1]])
coplanar=lambda p:sum(normal[k]*(p[k]-u[0][k]) for k in range(3))==0
assert all(coplanar(p) for tri in oldtris.values() for p in tri)
changed=[i for i,(x,y) in enumerate(zip(s['faces'],b['surfaces'][132]['faces'])) if tuple(x)!=tuple(y)]
assert changed==list(newidx),(changed,newidx)
newtris={i:[pt(s['vertices_exact_m'][int(v)]) for v in s['faces'][i]] for i in newidx}
assert all(coplanar(p) for tri in newtris.values() for p in tri)
face_entries=[];pool={row:F(0) for row in oldrowids};ntotal=F(0)
for ni,tri3 in newtris.items():
 tri=[proj(p) for p in tri3];na=area2(tri);assert na>0;ntotal+=na;ov={}
 for row,oldtri3 in oldtris.items():
  cl=[proj(p) for p in oldtri3];sgn=1 if orient(*cl)>0 else -1;ar=area2(clip(tri,cl,sgn));ov[row]=ar;pool[row]+=ar
 assert all(v>0 for v in ov.values()),ov
 assert sum(ov.values(),F(0))==na,(ni,ov,na)
 face_entries.append({'new_candidate097_row_local_face_index':ni,'new_face_global_vertex_ids':[int(s['global_vertex_ids'][int(v)]) for v in s['faces'][ni]],
  'retained_scalar_parent_row_local_face_index':int(s['parent_060_face_indices'][ni]),'old060_overlay_projected_double_area_m2_by_row_local_parent':{str(k):fmt(v) for k,v in ov.items()},
  'new_triangle_projected_double_area_m2':fmt(na),'area_fraction_by_old060_row_local_parent':{str(k):fmt(v/na) for k,v in ov.items()},
  'positive_overlap_with_both_old_faces':True,'area_partition_exact':sum(ov.values(),F(0))==na})
assert sum(pool.values(),F(0))==ntotal
def edge_boundary(triangles):
 edges={}
 for tri in triangles:
  for i in range(3):
   e=tuple(sorted((tri[i],tri[(i+1)%3])))
   edges[e]=edges.get(e,0)+1
 return {e for e,n in edges.items() if n==1}
oldcoordtris=[[pt(old['vertices'][int(v)]) for v in old['faces'][oldidx[row]]] for row in oldrowids]
newcoordtris=list(newtris.values())
old_boundary=edge_boundary(oldcoordtris);new_boundary=edge_boundary(newcoordtris)
assert old_boundary==new_boundary
global_by_coord={pt(p):int(g) for p,g in zip(s['vertices_exact_m'],s['global_vertex_ids'])}
def edge_global_ids(edge):
 return sorted(global_by_coord[p] for p in edge)
old_diagonal=tuple(set(oldcoordtris[0])&set(oldcoordtris[1]))
new_diagonal=tuple(set(newcoordtris[0])&set(newcoordtris[1]))
assert len(old_diagonal)==len(new_diagonal)==2
report={'schema':'numi.human.forearm097-diagonal-flip-exact-pooled-lineage-100.v3','scope':'Exact Fraction overlay audit only; no geometry changed. The flipped stable132 triangles are overlaid against the two old060 faces selected by their row-local ancestry IDs 5819 and 5820. The old060 candidate array indices are reported separately because they are 5805 and 5806.',
 'inputs':{str(p097):sha(p097),str(p085):sha(p085),str(p060):sha(p060)},'candidate_rows':{'stable_id':132,'changed_row_local_faces_vs_085':changed,'changed_face_count':len(changed)},
 'overlay':{'old_candidate060_row_local_face_indices':list(oldrowids),'old_candidate060_candidate_array_indices':{str(k):int(v) for k,v in oldidx.items()},
  'old060_global_vertex_ids_by_row_local_face':{str(k):edge_global_ids(tuple(pt(old['vertices'][int(v)]) for v in old['faces'][oldidx[k]])) for k in oldrowids},
  'old060_source_ancestry_by_row_local_face':{str(k):old['arrangement_row_ancestry'][oldidx[k]] for k in oldrowids},
  'all_four_old_and_new_triangles_exactly_coplanar':True,'projection_dropped_axis':axis,'new_face_overlays':face_entries,
  'pooled_projected_double_area_m2':fmt(ntotal),'pooled_area_fraction_by_old060_row_local_face':{str(k):fmt(pool[k]/ntotal) for k in oldrowids},
  'pooled_partition_exact':sum(pool.values(),F(0))==ntotal and all(v>0 for v in pool.values()),
  'quad_boundary_exact_coordinate_edges_unchanged':True,'old_internal_diagonal_global_ids':edge_global_ids(old_diagonal),'new_internal_diagonal_global_ids':edge_global_ids(new_diagonal),
  'interpretation':'Each new triangle overlaps both old060 triangles by positive exact area; their per-face fractions are recorded. Correct ancestry is the pooled pair [5819,5820]. Retained scalar parent IDs are historical labels after this flip, not an exclusive single-triangle support claim.'}}
out.write_text(json.dumps(report,sort_keys=True,indent=2)+'\n')
print(json.dumps({'path':str(out),'sha256':sha(out),'old060_array_indices':oldidx,'pooled':report['overlay']['pooled_area_fraction_by_old060_row_local_face'],'per_new_face':[x['area_fraction_by_old060_row_local_parent'] for x in face_entries]},sort_keys=True))
