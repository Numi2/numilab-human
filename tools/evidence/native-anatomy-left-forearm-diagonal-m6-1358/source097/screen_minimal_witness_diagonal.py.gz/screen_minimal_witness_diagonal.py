from __future__ import annotations
import ast, copy, gc, hashlib, json, math, os, struct, sys, time, importlib.util, pickle, resource
from collections import defaultdict
from fractions import Fraction
from pathlib import Path
os.environ.update(OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1")
import numpy as np

ROOT=Path("/Users/numi")
A=ROOT/"numi-human-retained-delivery-20261009/anatomy-completion-1276"
FD=ROOT/"numi-human-fds132-m6-1350"
OUT=FD/"attempt-097-minimal-late-witness-diagonal-screen-001"
OUT.mkdir(exist_ok=True)
CAND=FD/"attempt-085-interface-refinement-2mm-001/result-001/candidate.pkl"
FIELD=FD/"attempt-088-registered-route-field-refined-2mm-001/result-001/route-anchor-reference-field-001.npz"
OLD092=FD/"attempt-092-late-witness-arithmetic-001/report.json"
CORR093=FD/"attempt-093-unit-correction-001/corrected-unit-receipt.json"
RAW={132:FD/"attempt-049/result-001/stable-132-candidate049-current-pq-retained-root-union-candidate.npz",
     134:A/"stable-134-pose-repair-001/local-reference-search-001/stable-134-unadmitted-local-reference.npz"}
TISS=A/"temporalis164-native-m6-002/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
RIG=ROOT/"numi-human-resting-build-20261005/resting-scene-20261005/Build/skin-source-fit-recovery-20261004/myosim-fullbody-core-reference.nhrigid"
ARCH=ROOT/"numi-human-retained-delivery-20261009/skin-source-binding-1202/source-inputs/myosim/myo_sim-33c89c2b.tar.gz"
REG=FD/"registration-source-b1b410ad.json"
H= A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
FWD088=FD/"attempt-088-registered-route-field-refined-2mm-001.py"
PUB=ROOT/"numi-human-left-pq-publication-1344/src"
CI=ROOT/"numi-human-anatomy-completion-1276/src/numilab_human/cardiac_cavity_intersections.py"
PACK_HELPER=PUB/"numilab_human/common_atlas_skin_clearance.py"
NATIVE=A/"forearm054-native-diagnostic-009-refined085"
NATIVE_RUN=NATIVE/"baseline/native-run"
NATIVE_AUDIT=NATIVE/"native-audit-003/report.json"
P011=ROOT/"numi-human-retained-delivery-20261009/skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011/baseline/native-run/accepted-geometry"
P011_STEP=151999
STEPS=[0,3807,4767,5023,5599,6207,7423,8000]
TARGETS=(132,134)
ALTS_092=[(132,5112),(134,3723),(134,3724),(134,3741)]
VARIANT_OPS={
 "flip132_5111_5112":{132:{"faces":[5111,5112],"edge_gids":[5490,5492]}},
}
PROGRESS=OUT/"progress.jsonl"
START=time.monotonic()
sys.path.insert(0,str(PUB));sys.path.insert(0,str(CI.parent.parent))
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_intersections as ci
spec=importlib.util.spec_from_file_location("pilot_flip_helpers",A/"forearm-shared-field-native-compensated-011/conditioning-repair-001/prepare_conditioned_candidate.py")
pm=importlib.util.module_from_spec(spec);sys.modules[spec.name]=pm;spec.loader.exec_module(pm)
hmod=importlib.util.spec_from_file_location("forward_all_positive_helpers",H)
h=importlib.util.module_from_spec(hmod);sys.modules[hmod.name]=h;hmod.loader.exec_module(h)

def sha(p):
 q=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""):q.update(b)
 return q.hexdigest()
def progress(event,**kw):
 x={"event":event,"elapsed_s":time.monotonic()-START,**kw}
 with PROGRESS.open("a") as f:f.write(json.dumps(x,sort_keys=True)+"\n")
 print(json.dumps(x,sort_keys=True),flush=True)
def tri_altitudes_um(x,tri):
 p=np.asarray(x,dtype=np.float64)[np.asarray(tri,dtype=np.int64)]
 lens=np.asarray([np.linalg.norm(p[(i+1)%3]-p[(i+2)%3]) for i in range(3)])
 area2=float(np.linalg.norm(np.cross(p[1]-p[0],p[2]-p[0])))
 if np.any(lens==0):return np.zeros(3)
 return area2/lens*1e6
def vec_area(x,tri):
 p=np.asarray(x,dtype=np.float64)[np.asarray(tri,dtype=np.int64)]
 return np.cross(p[1]-p[0],p[2]-p[0])
def facekey(gids,tri):return tuple(sorted(int(gids[int(i)]) for i in tri))
def parentkey(ref):
 return (int(ref["parent_stable_id"]),int(ref["parent_candidate_face_index"]),int(ref["parent_original_source_face_index"]))
def normal_cosines(x,oldfaces,newfaces):
 oldn=[vec_area(x,t) for t in oldfaces]
 ref=oldn[0]+oldn[1];rn=float(np.linalg.norm(ref))
 if rn==0:return []
 out=[]
 for tri in newfaces:
  n=vec_area(x,tri);nn=float(np.linalg.norm(n))
  if nn==0:return [-1.0]
  out.append(float((n/nn)@(ref/rn)))
 return out
def source_parent_altitude_min_um(sid,face_index):
 z=np.load(RAW[sid],allow_pickle=False)
 xyz=np.asarray(z["vertices6"][:,:3],dtype=np.float64)
 f=np.asarray(z["faces"][face_index],dtype=np.int64);p=xyz[f]
 l=np.asarray([np.linalg.norm(p[(i+1)%3]-p[(i+2)%3]) for i in range(3)])
 a=float(np.linalg.norm(np.cross(p[1]-p[0],p[2]-p[0])))
 z.close()
 return float(np.min(a/l*1e6))
def plane_residual_um(points,plane_tri):
 p=np.asarray(points,dtype=np.float64);q=np.asarray(plane_tri,dtype=np.float64)
 n=np.cross(q[1]-q[0],q[2]-q[0]);ln=float(np.linalg.norm(n))
 if ln==0:return None
 return float(np.max(np.abs((p-q[0])@(n/ln)))*1e6)
def local_patch_delta(x,oldfaces,newfaces):
 ids=sorted({int(v) for t in oldfaces for v in t})
 p=np.asarray(x,dtype=np.float64)[ids]
 origin=p.mean(axis=0)
 def vol(ts):
  q=np.asarray(x,dtype=np.float64)[np.asarray(ts,dtype=np.int64)]-origin
  return float(np.einsum("ij,ij->i",q[:,0],np.cross(q[:,1],q[:,2])).sum()/6)
 oldarea=math.fsum(float(np.linalg.norm(vec_area(x,t)))/2 for t in oldfaces)
 newarea=math.fsum(float(np.linalg.norm(vec_area(x,t)))/2 for t in newfaces)
 return {"old_area_m2":oldarea,"new_area_m2":newarea,"relative_area_change":abs(newarea-oldarea)/max(oldarea,1e-300),
         "oriented_patch_volume_before_m3":vol(oldfaces),"oriented_patch_volume_after_m3":vol(newfaces),
         "oriented_patch_volume_delta_m3":vol(newfaces)-vol(oldfaces),
         "oriented_patch_volume_delta_um3":(vol(newfaces)-vol(oldfaces))*1e18}
def build_union(rows,gids,coords):
 occ=defaultdict(list)
 for sid in TARGETS:
  f=np.asarray(rows[sid],dtype=np.int64)
  g=np.asarray(gids[sid],dtype=np.uint64)
  for fi,t in enumerate(f):
   tr=tuple(int(g[int(v)]) for v in t)
   occ[tuple(sorted(tr))].append((sid,fi,tr))
 outfaces=[];sources=[];shared=set();errors=[]
 for key,items in occ.items():
  if len(items)==1:
   outfaces.append(items[0][2]);sources.append((items[0][0],items[0][1]))
  elif len(items)==2 and items[0][0]!=items[1][0]:
   a,b=items[0][2],items[1][2]
   opp=all((a[i],a[(i+1)%3]) in {(b[(j+1)%3],b[j]) for j in range(3)} for i in range(3))
   if opp:shared.add(key)
   else:errors.append({"key":list(key),"reason":"shared_winding_not_opposite"})
  else:errors.append({"key":list(key),"occurrences":[[x[0],x[1]] for x in items],"reason":"duplicate_face"})
 if errors:raise RuntimeError("shared interface invalid: "+str(errors[:3]))
 used=sorted({v for t in outfaces for v in t})
 ix={g:i for i,g in enumerate(used)}
 xyz_by_gid={}
 for sid in TARGETS:
  for gid,p in zip(gids[sid],coords[sid]):
   gid=int(gid);pp=np.asarray(p,dtype=np.float32)
   if gid in xyz_by_gid:
    if xyz_by_gid[gid].tobytes()!=pp.tobytes():raise RuntimeError(f"shared native point differs gid {gid}")
   else:xyz_by_gid[gid]=pp.copy()
 xyz=np.asarray([xyz_by_gid[g] for g in used],dtype="<f4")
 faces=np.asarray([[ix[g] for g in t] for t in outfaces],dtype=np.int64)
 return used,xyz,faces,sources,{"cancelled_shared_face_count":len(shared),"face_count":len(faces),"vertex_count":len(used),"shared_faces":shared}
def exact_local_union_screen(rows,gids,coords,changed_by_sid):
 used,xyz,ufaces,sources,meta=build_union(rows,gids,coords)
 changed_set={(sid,int(fi)) for sid,rowsi in changed_by_sid.items() for fi in rowsi}
 new_index=[i for i,src in enumerate(sources) if src in changed_set]
 if len(new_index)!=sum(len(v) for v in changed_by_sid.values()):
  raise RuntimeError(f"changed faces missing/unshared mismatch: {new_index}")
 base_index=[i for i in range(len(ufaces)) if i not in set(new_index)]
 lattice=[ci.float32_point_lattice_key(tuple(float(a) for a in p)) for p in xyz]
 nf=ufaces[np.asarray(new_index,dtype=np.int64)]
 bf=ufaces[np.asarray(base_index,dtype=np.int64)]
 # Fail on any newly degenerate source/native triangle before predicate assembly.
 def degenerate_count(faces):
  n=0
  for t in faces:
   a,b,c=(lattice[int(i)] for i in t)
   if not any(ci._cross(ci._sub(b,a),ci._sub(c,a))):n+=1
  return n
 newdeg=degenerate_count(nf)
 if newdeg:return {"passed":False,"reason":"new_degenerate_faces","new_degenerate_count":newdeg,"meta":{k:v for k,v in meta.items() if k!="shared_faces"}}
 brec=ci._records(lattice,bf.tolist())
 bmap=[(r[0],r[1],r[2],base_index[j],r[4]) for j,r in enumerate(brec)]
 nrec0=ci._records(lattice,nf.tolist())
 nmap=[(r[0],r[1],r[2],len(ufaces)+j,r[4]) for j,r in enumerate(nrec0)]
 cross=ci._audit_pair(bmap,nmap,same_surface=True)
 within=ci._audit_pair(nmap,nmap,same_surface=True)
 return {"passed":cross["count"]==0 and within["count"]==0,"new_degenerate_count":0,
  "new_vs_unchanged_pair_count":cross["count"],"new_vs_unchanged_pairs":cross["triangle_pairs"][:20],
  "new_vs_new_pair_count":within["count"],"new_vs_new_pairs":within["triangle_pairs"][:20],
  "new_face_source":[list(sources[i]) for i in new_index],
  "meta":{k:v for k,v in meta.items() if k!="shared_faces"}}
def cpu_pose_from_receipt(p):
 r=json.loads(Path(p).read_text())
 return {int(x["body_index"]):(np.asarray(x["position_m"],dtype=np.float32),np.asarray(x["quaternion_xyzw"],dtype=np.float32)) for x in r["accepted_registered_body_poses"]}
def normalize_capture(step):
 pack=NATIVE_RUN/"accepted-geometry"/f"step-{step}.mrvpack"
 receipt=pack.with_suffix(".receipt.json")
 r=json.loads(receipt.read_text())
 if r.get("pack_file_sha256")!=sha(pack):raise RuntimeError(f"current native pack pin mismatch {step}")
 pos,surfs,_=ca._pack_surfaces(pack,{(51005,132),(51005,134)})
 coords={}
 candidate_faces={}
 for sid in TARGETS:
  b=BASE["surfaces"][sid];local=np.asarray(b["faces"],dtype=np.int64)
  nativef=np.asarray(surfs[(51005,sid)]["faces"],dtype=np.int64)
  d=nativef-local
  if nativef.shape!=local.shape or d.size==0 or not np.all(d==d.flat[0]):raise RuntimeError(f"native face order/layout differs stable{sid} step{step}")
  start=int(d.flat[0]);coords[sid]=np.asarray(pos[start:start+len(b["global_vertex_ids"])],dtype="<f4").copy()
 del pos,surfs;gc.collect()
 return coords,{"step":step,"pack":str(pack),"pack_sha256":r["pack_file_sha256"],"receipt_sha256":sha(receipt)}
def transform_late_cpu():
 # Independently reproduce the same 092 ordinary binary32 route-field arithmetic; this is a CPU pose screen only.
 tree=ast.parse(FWD088.read_text())
 names={"sha","req","F32","parse_nhrigid","rotate_cxx_batch","rotate_metal_batch","f32sum_points"}
 ns={"np":np,"math":math,"struct":struct,"hashlib":hashlib,"Path":Path,"Fraction":Fraction}
 nodes=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names]
 exec(compile(ast.Module(body=nodes,type_ignores=[]),str(FWD088),"exec"),ns)
 rigid=ns["parse_nhrigid"](RIG,ARCH);default=rigid["poses"]
 source=h.load_tissue(TISS);canon={}
 for sid in TARGETS:
  rec=next(r for r in source["records"] if int(r[6])==sid)
  for item in source["bindings"][int(rec[0]):int(rec[0])+int(rec[1])]:
   core=int(item["core"]);val=np.asarray(item["value"],dtype=np.float32)
   if core in canon and not np.array_equal(canon[core],val):raise RuntimeError(f"canonical binding differs for core {core}")
   canon.setdefault(core,val.copy())
 ns["CANON"]=canon
 field=np.load(FIELD,allow_pickle=False)
 cores=np.asarray(field["core_body_indices"],dtype=np.uint32)
 pose=cpu_pose_from_receipt(P011/f"step-{P011_STEP}.receipt.json")
 rows={}
 for sid in TARGETS:
  points=np.asarray(field[f"stable{sid}_rest_positions_m"],dtype=np.float32)
  weights=np.asarray(field[f"stable{sid}_core_weights"],dtype=np.float64)
  rows[sid]=ns["f32sum_points"](points,weights,cores,default,pose,"fma")
 field.close()
 return rows,{"source":"P011 baseline step151999 accepted registered body-pose receipt","arithmetic":"CPU reproduction of 088 float32 binding transforms + per-core FMA route-field accumulation; matches the 092 three pair intersection counts, not a native capture"}
def intersection_nonshared(coords,gids,facesA,facesB,fa,fb):
 ta=facesA[int(fa)];tb=facesB[int(fb)]
 pa=tuple(ci.float32_point_lattice_key(tuple(float(a) for a in coords[132][int(i)])) for i in ta)
 pb=tuple(ci.float32_point_lattice_key(tuple(float(a) for a in coords[134][int(i)])) for i in tb)
 pts=ci.triangle_intersection_points(pa,pb)
 ga=set(int(gids[132][int(i)]) for i in ta);gb=set(int(gids[134][int(i)]) for i in tb)
 common_g=ga&gb;common=set()
 for g in common_g:
  ia=GIX[132][g];common.add(ci.float32_point_lattice_key(tuple(float(a) for a in coords[132][ia])))
 non=[p for p in pts if not ci._allowed_shared_point(p,common)]
 return {"intersection_point_count":len(pts),"nonshared_intersection_point_count":len(non),
         "nonshared_intersection_points":[[int(v) for v in q] for q in non]}
def prepare_ops(base):
 rows=base["surfaces"]; gids={sid:list(map(int,rows[sid]["global_vertex_ids"])) for sid in TARGETS}
 variant_ops={}
 metrics={}
 shared0=pm.shared_face_set(rows)
 for name,defs in VARIANT_OPS.items():
  fc={sid:np.asarray(rows[sid]["faces"],dtype=np.int64).copy() for sid in TARGETS}
  opdetails={}
  changed={}
  for sid,spec0 in defs.items():
   fis=list(map(int,spec0["faces"]));edge=tuple(GIX[sid][int(x)] for x in spec0["edge_gids"])
   ref=rows[sid]["parent_054_face_refs"][fis[0]]
   if parentkey(ref)!=parentkey(rows[sid]["parent_054_face_refs"][fis[1]]):raise RuntimeError(f"{name} mixes source parent faces")
   new=pm.oriented_flip(fc[sid],edge,tuple(fis))
   if new is None:raise RuntimeError(f"{name} edge has inconsistent source winding")
   oldkeys=[facekey(gids[sid],fc[sid][i]) for i in fis]
   if any(k in shared0 for k in oldkeys):raise RuntimeError(f"{name} touches exact shared source interface face")
   otherids=134 if sid==132 else 132
   otherkeys={facekey(gids[otherids],t) for t in fc[otherids]}
   samekeys={facekey(gids[sid],t) for i,t in enumerate(fc[sid]) if i not in fis}
   newkeys=[facekey(gids[sid],t) for t in new]
   if len(set(newkeys))!=2 or any(k in shared0 or k in otherkeys or k in samekeys for k in newkeys):raise RuntimeError(f"{name} introduces a shared/duplicate face")
   x=np.asarray(rows[sid]["vertices_float32_m"],dtype=np.float64)
   oldfaces=fc[sid][fis]
   oldalt=[tri_altitudes_um(x,t).tolist() for t in oldfaces]
   newalt=[tri_altitudes_um(x,t).tolist() for t in new]
   qverts=sorted({int(v) for t in oldfaces for v in t})
   qpoints=x[qverts]
   parentface=int(ref["parent_candidate_face_index"])
   rawnp=np.load(RAW[sid],allow_pickle=False)
   rawx=np.asarray(rawnp["vertices6"][:,:3],dtype=np.float64)
   rawface=np.asarray(rawnp["faces"][parentface],dtype=np.int64)
   rawtri=rawx[rawface];rawnp.close()
   opdetails[str(sid)]={"old_face_indices":fis,"edge_global_vertex_ids":sorted(map(int,spec0["edge_gids"])),
    "old_face_global_ids":[[gids[sid][int(v)] for v in t] for t in oldfaces],
    "new_face_global_ids":[[gids[sid][int(v)] for v in t] for t in new],
    "source_parent_identity":list(parentkey(ref)),"source_parent_reference_records":copy.deepcopy([rows[sid]["parent_054_face_refs"][i] for i in fis]),
    "source_parent_raw_triangle_min_altitude_um":source_parent_altitude_min_um(sid,parentface),
    "old_pair_face_min_altitudes_um":[float(np.min(a)) for a in oldalt],
    "new_pair_face_min_altitudes_um":[float(np.min(a)) for a in newalt],
    "new_min_altitude_um":float(min(np.min(a) for a in newalt)),
    "candidate_quad_nonplanarity_um":plane_residual_um(qpoints,x[oldfaces[0]]),
    "raw_source_parent_plane_residual_um":plane_residual_um(qpoints,rawtri),
    "source_vertex_max_displacement_um":0.0,
    "local_area_volume":local_patch_delta(x,oldfaces,new),
    "rest_orientation_cosines":normal_cosines(x,oldfaces,new),
    "shared_interface_unchanged_by_operation":True,
    "oldfaces_are_two_face_interior_edge":True,
    "same_parent_face_for_entire_two_face_patch":True}
   if opdetails[str(sid)]["new_min_altitude_um"]<=1.0:raise RuntimeError(f"{name} new face below 1um rest floor")
   if min(opdetails[str(sid)]["rest_orientation_cosines"])<=0:raise RuntimeError(f"{name} flips rest winding")
   for i,t in zip(fis,new):fc[sid][i]=t
   changed[sid]=fis
  candidate=copy.deepcopy(base)
  for sid in TARGETS:
   candidate["surfaces"][sid]["faces"]=fc[sid].copy()
   candidate["surfaces"][sid]["faces_global"]=[tuple(gids[sid][int(v)] for v in t) for t in fc[sid]]
  shared1=pm.shared_face_set(candidate["surfaces"])
  if shared1!=shared0:raise RuntimeError(f"{name} changed exact shared face set")
  variant_ops[name]={"faces":fc,"changed":changed,"shared_face_count":len(shared1),"operation_details":opdetails,"candidate":candidate}
  metrics[name]={"operation_details":opdetails,"exact_shared_interface_face_count_before_after":[len(shared0),len(shared1)],"shared_face_set_identical":True,
                "changed_face_count":sum(len(v) for v in changed.values()),"changed_by_sid":{str(s):list(v) for s,v in changed.items()}}
 return variant_ops,metrics,shared0

# Input ownership and hash verification.
REQUIRED=[CAND,FIELD,OLD092,CORR093,*RAW.values(),TISS,RIG,ARCH,REG,FWD088,CI,PACK_HELPER,H,
 NATIVE/"preparation.json",NATIVE/"baseline/run-declaration.json",NATIVE/"baseline/execution.json",
 NATIVE/"native-audit-003/report.json",P011/f"step-{P011_STEP}.mrvpack",P011/f"step-{P011_STEP}.receipt.json"]
missing=[str(p) for p in REQUIRED if not p.is_file()]
if missing:raise RuntimeError("missing pinned inputs "+str(missing))
PINS={str(p):sha(p) for p in REQUIRED}
# Read source candidate and prepare source-preserving same-parent diagonals.
BASE=pickle.load(CAND.open("rb"))
GIDS={sid:np.asarray(BASE["surfaces"][sid]["global_vertex_ids"],dtype=np.uint64) for sid in TARGETS}
GIX={sid:{int(g):i for i,g in enumerate(GIDS[sid])} for sid in TARGETS}
OPS,OP_METRICS,SHARED0=prepare_ops(BASE)
progress("source_flip_candidates_ready",variants=list(OPS),shared_face_count=len(SHARED0))
# Load field arrays and assert exact candidate point identity.
with np.load(FIELD,allow_pickle=False) as z:
 CORE_IDS=z["core_body_indices"].copy()
 REST={sid:z[f"stable{sid}_rest_positions_m"].copy() for sid in TARGETS}
 WEIGHTS={sid:z[f"stable{sid}_core_weights"].copy() for sid in TARGETS}
 for sid in TARGETS:
  if not np.array_equal(GIDS[sid],z[f"stable{sid}_global_vertex_ids"]) or not np.array_equal(REST[sid],BASE["surfaces"][sid]["vertices_float32_m"]):
   raise RuntimeError(f"route field order/positions differ from candidate row {sid}")
# P011 CPU witness validation and candidate local union checks.
P011CPU,CPU_NOTE=transform_late_cpu()
for sid in TARGETS:
 if P011CPU[sid].shape!=REST[sid].shape:raise RuntimeError(f"P011 CPU row size differs {sid}")
oldw=json.loads(OLD092.read_text())
witness_union_pairs=[(132,5112,134,3723),(132,5112,134,3724),(132,5112,134,3741)]
baseline_late=[]
for sa,fa,sb,fb in witness_union_pairs:
 q=intersection_nonshared(P011CPU,GIDS,BASE["surfaces"][132]["faces"],BASE["surfaces"][134]["faces"] ,fa,fb)
 baseline_late.append({"row_face_pair":[sa,fa,sb,fb],**q})
if [x["nonshared_intersection_point_count"] for x in baseline_late]!=[1,2,1]:
 raise RuntimeError("independent P011 CPU screen failed to reproduce 092 nonshared witness counts")
progress("p011_cpu_witness_reproduced",nonshared_counts=[x["nonshared_intersection_point_count"] for x in baseline_late])
# Capture accepted actual 009 coordinates for all eight current poses.
CURRENT={}
CAPTURE_PINS={}
for step in STEPS:
 coords,pin=normalize_capture(step);CURRENT[step]=coords;CAPTURE_PINS[str(step)]=pin
 progress("native_capture_loaded",step=step,pack_sha256=pin["pack_sha256"])
# Each variant: exact source support audit, all8 actual current native poses, and P011 diagnostic.
variant_reports={}
for name,v in OPS.items():
 rows={sid:v["faces"][sid] for sid in TARGETS}
 changed=v["changed"]
 # Candidate source/default rest pose.
 rest_local=exact_local_union_screen(rows,GIDS,REST,changed)
 # actual native current8 accepted body surfaces.
 current_rows=[]
 for step in STEPS:
  ar=exact_local_union_screen(rows,GIDS,CURRENT[step],changed)
  postmins={}
  cos={}
  for sid,fis in changed.items():
   oldf=np.asarray(BASE["surfaces"][sid]["faces"],dtype=np.int64)
   newf=rows[sid]
   x=CURRENT[step][sid]
   op=v["operation_details"][str(sid)]
   oldfaces=oldf[np.asarray(fis,dtype=np.int64)]
   newfaces=newf[np.asarray(fis,dtype=np.int64)]
   postmins[str(sid)]=float(min(np.min(tri_altitudes_um(x,t)) for t in newfaces))
   cos[str(sid)]=normal_cosines(x,oldfaces,newfaces)
  current_rows.append({"step":step,"local_union_exact_screen":ar,"new_triangle_min_altitude_um":postmins,"normal_cosines_vs_old_patch":cos})
  progress("candidate_variant_current_pose",variant=name,step=step,pass_local_union=ar["passed"],new_altitude_um=postmins)
 # P011 current CPU native-like route field pose, all candidate interactions on changed union triangles.
 late=exact_local_union_screen(rows,GIDS,P011CPU,changed)
 changed_pairs={(sid,int(fi)) for sid,fs in changed.items() for fi in fs}
 residual=[]
 for q in baseline_late:
  a=(q["row_face_pair"][0],q["row_face_pair"][1]);b=(q["row_face_pair"][2],q["row_face_pair"][3])
  if a not in changed_pairs and b not in changed_pairs:
   residual.append({"pair":q["row_face_pair"],"baseline_nonshared_intersections":q["nonshared_intersection_point_count"],"persists_unmodified":True})
 pose_min={}
 pose_cos={}
 for sid,fis in changed.items():
  oldf=np.asarray(BASE["surfaces"][sid]["faces"],dtype=np.int64)
  newf=rows[sid];x=P011CPU[sid];oldfaces=oldf[np.asarray(fis,dtype=np.int64)];newfaces=newf[np.asarray(fis,dtype=np.int64)]
  pose_min[str(sid)]=float(min(np.min(tri_altitudes_um(x,t)) for t in newfaces))
  pose_cos[str(sid)]=normal_cosines(x,oldfaces,newfaces)
 passes=current_rows and all(p["local_union_exact_screen"]["passed"] for p in current_rows) and rest_local["passed"] and late["passed"] and not residual and all(m>1.0 for p in current_rows for m in p["new_triangle_min_altitude_um"].values()) and all(m>1.0 for m in pose_min.values()) and all(min(c)>0 for c in pose_cos.values())
 variant_reports[name]={"operations":v["operation_details"],"source_rest_local_union_exact_screen":rest_local,
  "current_009_actual_native_captures":current_rows,"p011_step151999_cpu_pose_screen":{**late,"known_092_witness_baseline":[{"pair":x["row_face_pair"],"baseline_nonshared_intersection_count":x["nonshared_intersection_point_count"]} for x in baseline_late],
    "remaining_unmodified_known_witness_pairs":residual,"new_triangle_min_altitude_um":pose_min,"normal_cosines_vs_old_patch":pose_cos,"cpu_note":CPU_NOTE},
  "passes_bounded_pose_screen":bool(passes)}
 progress("candidate_variant_complete",variant=name,passes=bool(passes),p011_new_pairs=late.get("new_vs_unchanged_pair_count"),p011_unmodified_witnesses=len(residual))
# Decide whether to stage the least-edit candidate that clears every required local screen.
passing=[n for n,r in variant_reports.items() if r["passes_bounded_pose_screen"]]
chosen=min(passing,key=lambda n:(variant_reports[n]["operations"].get("changed_face_count",999),n)) if passing else None
# Record exact triangle fixture to prevent a metre/micrometre labeling regression.
fixture=np.asarray([[0.,0.,0.],[1e-3,0.,0.],[0.,1e-3,0.]],dtype=np.float64)
fmin=float(min(np.linalg.norm(np.cross(fixture[1]-fixture[0],fixture[2]-fixture[0]))/
                    np.linalg.norm(fixture[(i+1)%3]-fixture[(i+2)%3])*1e6 for i in range(3)))
if not math.isclose(fmin,1000.0/math.sqrt(2.0),rel_tol=0,abs_tol=1e-12):raise RuntimeError("unit sanity fixture failed")
outputs={}
if chosen:
 q=OPS[chosen]["candidate"]
 # Preserve old exact checks as explicitly historical, then attach operation/pose-screen provenance.
 for k in ("source_rest_exact_self_audits","source_rest_union_cancellation","source_self_inheritance","topology","input_topology"):
  if k in q:q["conditioning_historical_"+k]=q.pop(k)
 q["conditioning"]={"schema":"numi.forearm085.source-preserving-adaptive-flip.v1","status":"experimental_not_admitted",
  "input_candidate_sha256":PINS[str(CAND)],"input_field_sha256":PINS[str(FIELD)],
  "operations":OP_METRICS,"selected_variant":chosen,"pose_screen_report_path":str(OUT/"report.json"),
  "method":"same-parent interior edge 2-to-2 retriangulation; vertices and source bindings unchanged; no pose-fitted geometry",
  "numerical_floor":{"world_float32_ulp_order_um":0.12,"postflip_triangle_min_altitude_floor_um":1.0,"interpretation":"conditioning screen only, not an intersection tolerance"},
  "qualification":{"exact_source_changed_triangle_audit":variant_reports[chosen]["source_rest_local_union_exact_screen"],
   "current_009_native_capture_local_union_checks":variant_reports[chosen]["current_009_actual_native_captures"],
   "p011_cpu_pose_screen":variant_reports[chosen]["p011_step151999_cpu_pose_screen"],
   "fresh_native_run_required":True,"all25_pose_qualification":False,"admitted":False}}
 cp=OUT/"candidate-source-preserving-flip.pkl";cp.write_bytes(pickle.dumps(q,protocol=pickle.HIGHEST_PROTOCOL))
 with np.load(FIELD,allow_pickle=False) as z: fields={k:z[k].copy() for k in z.files}
 for sid in TARGETS:fields[f"stable{sid}_faces"]=np.asarray(q["surfaces"][sid]["faces"],dtype="<u4")
 fp=OUT/"route-anchor-reference-field-flipped.npz";np.savez_compressed(fp,**fields)
 outputs={"candidate_path":str(cp),"candidate_sha256":sha(cp),"field_path":str(fp),"field_sha256":sha(fp)}
# All failures retained in report regardless of selection.
report={"schema":"numi.human.forearm085-late-witness-source-preserving-flip-screen.v1",
 "status":"completed_cpu_pose_screen","scope":"Two same-source-parent local edge flips screened against the source mesh, all eight actual accepted native009 capture geometries, and the old P011-baseline step151999 using the existing 088 F32 route-field arithmetic. No GPU launch or admission.",
 "input_pins":PINS,"current_native_capture_pins":CAPTURE_PINS,
 "corrected_092_units_receipt_sha256":PINS[str(CORR093)],
 "unit_conventions":{"input_coordinates":"metres","reported_altitude":"micrometres","metres_to_micrometres":1e6,
  "sanity_fixture":{"right_isosceles_legs_mm":1,"minimum_altitude_um":fmin,"expected_um":"1000/sqrt(2)","passed":True}},
 "source_operations":OP_METRICS,"p011_baseline_original_witness_pairs":baseline_late,
 "p011_baseline_reproduced_092_counts":True,"p011_cpu_method":CPU_NOTE,
 "candidate_variants":variant_reports,"chosen_variant":chosen,"outputs":outputs,
 "qualification":{"gpu":False,"fresh_native":False,"all25_pose_qualification":False,"admitted":False,
  "source_preserving_operation_only":True,"old092_late_crossings_cleared_in_cpu_screen":bool(chosen),
  "claim_native_or_allpose_clearance":False,"note":"A passing offline screen only provides a candidate for an independently prepared ordinary-runtime native check."},
 "environment":{"python":sys.version,"numpy":np.__version__,"cpu_workers":1,"maxrss":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
 "elapsed_seconds":time.monotonic()-START}
rp=OUT/"report.json";rp.write_text(json.dumps(report,indent=2,sort_keys=True,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
print(json.dumps({"report":str(rp),"report_sha256":sha(rp),"chosen_variant":chosen,"variants":{k:v["passes_bounded_pose_screen"] for k,v in variant_reports.items()},"outputs":outputs},indent=2))
