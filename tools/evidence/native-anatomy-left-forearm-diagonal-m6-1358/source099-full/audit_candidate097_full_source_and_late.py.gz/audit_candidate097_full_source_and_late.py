from __future__ import annotations
import ast,copy,gc,hashlib,json,math,os,pickle,resource,sys,time,struct
from collections import defaultdict
from pathlib import Path
from fractions import Fraction
import numpy as np

os.environ.update(OMP_NUM_THREADS="1",OPENBLAS_NUM_THREADS="1",VECLIB_MAXIMUM_THREADS="1")
START=time.monotonic()
ROOT=Path("/Users/numi")
FD=ROOT/"numi-human-fds132-m6-1350"
A=ROOT/"numi-human-retained-delivery-20261009/anatomy-completion-1276"
OUT=FD/"attempt-099-candidate097-full-source-and-late-audit-001"
OUT.mkdir(exist_ok=True)
CAND=FD/"attempt-097-minimal-late-witness-diagonal-screen-001/candidate-source-preserving-flip.pkl"
BASE_CAND=FD/"attempt-085-interface-refinement-2mm-001/result-001/candidate.pkl"
FIELD=FD/"attempt-088-registered-route-field-refined-2mm-001/result-001/route-anchor-reference-field-001.npz"
TISS=A/"temporalis164-native-m6-002/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
RIG=ROOT/"numi-human-resting-build-20261005/resting-scene-20261005/Build/skin-source-fit-recovery-20261004/myosim-fullbody-core-reference.nhrigid"
ARCH=ROOT/"numi-human-retained-delivery-20261009/skin-source-binding-1202/source-inputs/myosim/myo_sim-33c89c2b.tar.gz"
REG=FD/"registration-source-b1b410ad.json"
FWD=FD/"attempt-088-registered-route-field-refined-2mm-001.py"
H=A/"neck-back-retained-pose-audit-002/forward_all_positive_weights.py"
CI=ROOT/"numi-human-anatomy-completion-1276/src/numilab_human/cardiac_cavity_intersections.py"
sys.path.insert(0,str(CI.parent.parent))
from numilab_human import cardiac_cavity_intersections as ci

def sha(p):
 q=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""):q.update(b)
 return q.hexdigest()
def log(e,**kw):
 with (OUT/"progress.jsonl").open("a") as f:f.write(json.dumps({"event":e,"elapsed_s":time.monotonic()-START,**kw},sort_keys=True)+"\n")
def topology(faces,nverts,xyz):
 edge=defaultdict(list)
 for fi,t in enumerate(np.asarray(faces,dtype=np.int64)):
  for u,v in ((int(t[0]),int(t[1])),(int(t[1]),int(t[2])),(int(t[2]),int(t[0]))):
   k=(min(u,v),max(u,v));edge[k].append((fi,1 if u<v else -1))
 badcounts=[(k,len(v)) for k,v in edge.items() if len(v)!=2]
 badwind=[k for k,v in edge.items() if len(v)==2 and v[0][1]==v[1][1]]
 adj=[[] for _ in range(len(faces))]
 for k,v in edge.items():
  if len(v)==2:adj[v[0][0]].append(v[1][0]);adj[v[1][0]].append(v[0][0])
 seen=set();comps=[]
 for i in range(len(faces)):
  if i in seen:continue
  stack=[i];seen.add(i);cc=[]
  while stack:
   j=stack.pop();cc.append(j)
   for n in adj[j]:
    if n not in seen:seen.add(n);stack.append(n)
  comps.append(cc)
 vols=[]
 x=np.asarray(xyz,dtype=np.float64);f=np.asarray(faces,dtype=np.int64)
 for cc in comps:
  vids=sorted({int(v) for fi in cc for v in f[fi]});origin=x[vids].mean(axis=0)
  q=x[f[np.asarray(cc,dtype=np.int64)]]-origin
  vol=float(np.einsum("ij,ij->i",q[:,0],np.cross(q[:,1],q[:,2])).sum()/6)
  vols.append({"face_count":len(cc),"vertex_count":len(vids),"signed_volume_m3":vol,"sign":"positive" if vol>0 else "negative" if vol<0 else "zero"})
 return {"closed":not badcounts,"consistently_oriented":not badwind,"face_count":len(faces),"vertex_count":int(nverts),"edge_count":len(edge),
         "face_components":len(comps),"bad_edge_incidence_count":len(badcounts),"bad_edge_winding_count":len(badwind),
         "bad_edge_incidence_examples":[[list(k),n] for k,n in badcounts[:10]],"bad_edge_winding_examples":[list(k) for k in badwind[:10]],
         "component_signed_volumes":vols}
def union_mesh(candidate):
 rows=candidate["surfaces"]; target=(132,134);occ=defaultdict(list)
 for sid in target:
  s=rows[sid];faces=np.asarray(s["faces"],dtype=np.int64);gids=np.asarray(s["global_vertex_ids"],dtype=np.uint64)
  for fi,t in enumerate(faces):
   gt=tuple(int(gids[int(v)]) for v in t)
   occ[tuple(sorted(gt))].append((sid,fi,gt))
 faces=[];sources=[];shared=[];bad=[]
 for k,items in occ.items():
  if len(items)==1:faces.append(items[0][2]);sources.append((items[0][0],items[0][1]))
  elif len(items)==2 and items[0][0]!=items[1][0]:
   a,b=items[0][2],items[1][2]
   opposite=all((a[i],a[(i+1)%3]) in {(b[(j+1)%3],b[j]) for j in range(3)} for i in range(3))
   if opposite:shared.append(k)
   else:bad.append({"key":list(k),"sources":[list(x[:2]) for x in items],"reason":"same-direction shared interface"})
  else:bad.append({"key":list(k),"sources":[list(x[:2]) for x in items],"reason":"duplicate or nonmanifold face"})
 used=sorted({v for t in faces for v in t});ix={g:i for i,g in enumerate(used)}
 xyzby={}
 for sid in target:
  s=rows[sid]
  for gid,p in zip(s["global_vertex_ids"],s["vertices_float32_m"]):
   g=int(gid);pp=np.asarray(p,dtype="<f4")
   if g in xyzby and xyzby[g].tobytes()!=pp.tobytes():bad.append({"gid":g,"reason":"shared position bitwise mismatch"})
   xyzby[g]=pp.copy()
 xyz=np.asarray([xyzby[g] for g in used],dtype="<f4")
 ff=np.asarray([[ix[int(g)] for g in t] for t in faces],dtype=np.int64)
 return {"vertices":xyz,"faces":ff,"sources":sources,"gids":used,"shared":shared,"errors":bad}
def lattice(points):
 return [ci.float32_point_lattice_key(tuple(float(a) for a in p)) for p in np.asarray(points,dtype=np.float32)]
def audit_mesh(name,faces,points):
 pts=lattice(points);f=np.asarray(faces,dtype=np.int64);records=ci._records(pts,f.tolist())
 res=ci._audit_pair(records,records,same_surface=True)
 del records;gc.collect()
 return {"name":name,"face_count":len(f),"exact_float32_self_pair_count":int(res["count"]),
         "exact_float32_self_pairs":[list(map(int,p)) for p in res["triangle_pairs"][:30]],
         "degenerate_count":0,"passed":int(res["count"])==0}
def exact_sub_volume(delta,xyz):
 # Return exact oriented volume delta, using Fraction-valued exact coordinates.
 def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
 def dot(a,b):return sum((a[k]*b[k] for k in range(3)),Fraction(0))
 return delta

C=pickle.load(CAND.open("rb"));B=pickle.load(BASE_CAND.open("rb"))
PINS={str(p):sha(p) for p in (CAND,BASE_CAND,FIELD,TISS,RIG,ARCH,REG,FWD,H,CI)}
# Check only two face rows changed; all exact and Float32 positions, bindings, ancestry are byte/value-identical.
change={}
identity={}
for sid in (132,134):
 c=C["surfaces"][sid];b=B["surfaces"][sid]
 changed=np.flatnonzero(np.any(np.asarray(c["faces"])!=np.asarray(b["faces"]),axis=1)) if np.asarray(c["faces"]).shape==np.asarray(b["faces"]).shape else []
 identity[str(sid)]={"vertex_count":len(c["global_vertex_ids"]),"face_count":len(c["faces"]),
   "vertices_exact_equal":c["vertices_exact_m"]==b["vertices_exact_m"],
   "vertices_float32_equal":np.array_equal(c["vertices_float32_m"],b["vertices_float32_m"]),
   "global_ids_equal":list(map(int,c["global_vertex_ids"]))==list(map(int,b["global_vertex_ids"])),
   "parent_refs_equal":c["parent_054_face_refs"]==b["parent_054_face_refs"],
   "changed_face_indices":list(map(int,changed))}
 if not identity[str(sid)]["vertices_exact_equal"] or not identity[str(sid)]["vertices_float32_equal"] or not identity[str(sid)]["global_ids_equal"] or not identity[str(sid)]["parent_refs_equal"]:
  raise RuntimeError(f"non-face payload changed row{sid}")
log("candidate_identity_checked",rows=identity)
source={}
for ckind,cand in (("candidate097",C),):
 rows=cand["surfaces"]
 results={}
 for sid in (132,134):
  s=rows[sid];faces=np.asarray(s["faces"],dtype=np.int64);xyz=s["vertices_float32_m"]
  top=topology(faces,len(xyz),xyz)
  res=audit_mesh(f"source_{ckind}_row{sid}",faces,xyz)
  results[str(sid)]={"topology":top,"exact_self":res}
  log("source_child_audit_complete",candidate=ckind,sid=sid,topology=top["closed"],oriented=top["consistently_oriented"],self_pairs=res["exact_float32_self_pair_count"],components=top["face_components"])
  del res;gc.collect()
 u=union_mesh(cand)
 if u["errors"]:raise RuntimeError(f"union assembly errors {ckind}: {u['errors'][:3]}")
 utop=topology(u["faces"],len(u["vertices"]),u["vertices"])
 uaudit=audit_mesh(f"source_{ckind}_joined_union",u["faces"],u["vertices"])
 results["union"]={"cancelled_opposite_shared_faces":len(u["shared"]),"face_sources":len(u["sources"]),"topology":utop,"exact_self":uaudit}
 log("source_union_audit_complete",candidate=ckind,shared=len(u["shared"]),faces=len(u["faces"]),vertices=len(u["vertices"]),closed=utop["closed"],oriented=utop["consistently_oriented"],self_pairs=uaudit["exact_float32_self_pair_count"],components=utop["face_components"])
 source[ckind]=results
 del u;gc.collect()
# Same exact rational parent-plane and oriented-volume proof, computed from candidate exact coordinates.
s=C["surfaces"][132];changed=identity["132"]["changed_face_indices"]
old=np.asarray(B["surfaces"][132]["faces"],dtype=np.int64)[np.asarray(changed,dtype=np.int64)]
new=np.asarray(C["surfaces"][132]["faces"],dtype=np.int64)[np.asarray(changed,dtype=np.int64)]
gids=[int(x) for x in s["global_vertex_ids"]];patchids=sorted({int(v) for tri in old for v in tri})
exactxyz=s["vertices_exact_m"]
ref=s["parent_054_face_refs"][int(changed[0])]
rawpath=FD/"attempt-049/result-001/stable-132-candidate049-current-pq-retained-root-union-candidate.npz"
with np.load(rawpath,allow_pickle=False) as z:
 rf=int(ref["parent_candidate_face_index"]);rawtri=np.asarray(z["vertices6"][:,:3])[np.asarray(z["faces"][rf],dtype=np.int64)]
 from fractions import Fraction as F
 p0,p1,p2=[[F.from_float(float(v)) for v in row] for row in rawtri]
 def sub(a,b):return tuple(a[k]-b[k] for k in range(3))
 def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
 def dot(a,b):return sum((a[k]*b[k] for k in range(3)),F(0))
 pn=cross(sub(p1,p0),sub(p2,p0));expoints=[tuple(exactxyz[i]) for i in patchids]
 plane_num=[dot(sub(q,p0),pn) for q in expoints]
 def surfvol(fs):
  val=F(0)
  for tri in fs:
   p=[tuple(exactxyz[int(i)]) for i in tri]
   val+=dot(p[0],cross(p[1],p[2]))/6
  return val
 exact_delta=surfvol(new)-surfvol(old)
 exact_support={"source_parent":{k:ref[k] for k in ("parent_stable_id","parent_candidate_face_index","parent_original_source_face_index")},
  "patch_global_vertex_ids":[gids[i] for i in patchids],"vertices_on_raw_source_parent_plane_exactly":all(v==0 for v in plane_num),
  "raw_parent_plane_signed_tripleproducts":[[int(v.numerator),int(v.denominator)] for v in plane_num],
  "source_parent_plane_max_distance_um":0.0 if all(v==0 for v in plane_num) else None,
  "exact_oriented_patch_volume_delta_m3":[int(exact_delta.numerator),int(exact_delta.denominator)],
  "exact_oriented_patch_volume_delta_is_zero":exact_delta==0,
  "exact_vertices_identical_before_after":True,
  "source_support_claim":"Exact rational parent-plane membership plus same four vertices and a convex planar quadrilateral; old and new diagonals triangulate the same patch."}
# 092 P011 baseline step151999, same 088 original route-field accumulation; then full, not local-star, child and union exact audits.
tree=ast.parse(FWD.read_text());names={"sha","req","F32","parse_nhrigid","rotate_cxx_batch","rotate_metal_batch","f32sum_points"}
ns={"np":np,"math":math,"struct":struct,"hashlib":hashlib,"Path":Path,"Fraction":Fraction}
nodes=[n for n in tree.body if isinstance(n,(ast.Import,ast.ImportFrom)) or isinstance(n,ast.FunctionDef) and n.name in names]
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(FWD),"exec"),ns)
hm=__import__("importlib.util").util.spec_from_file_location("forward_helpers_098",H);h=__import__("importlib.util").util.module_from_spec(hm);sys.modules[hm.name]=h;hm.loader.exec_module(h)
rigid=ns["parse_nhrigid"](RIG,ARCH);default=rigid["poses"];tissue=h.load_tissue(TISS)
canon={}
for sid in (132,134):
 rec=next(r for r in tissue["records"] if int(r[6])==sid)
 for item in tissue["bindings"][int(rec[0]):int(rec[0])+int(rec[1])]:
  core=int(item["core"]);val=np.asarray(item["value"],dtype=np.float32)
  if core in canon and not np.array_equal(canon[core],val):raise RuntimeError(f"canonical binding differs core{core}")
  canon.setdefault(core,val.copy())
ns["CANON"]=canon
with np.load(FIELD,allow_pickle=False) as z:
 cores=z["core_body_indices"].copy()
 points={sid:z[f"stable{sid}_rest_positions_m"].copy() for sid in (132,134)}
 weights={sid:z[f"stable{sid}_core_weights"].copy() for sid in (132,134)}
rc=Path("/Users/numi/numi-human-retained-delivery-20261009/skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011/baseline/native-run/accepted-geometry/step-151999.receipt.json")
pose_rc=json.loads(rc.read_text());pose={int(x["body_index"]):(np.asarray(x["position_m"],dtype=np.float32),np.asarray(x["quaternion_xyzw"],dtype=np.float32)) for x in pose_rc["accepted_registered_body_poses"]}
late={sid:ns["f32sum_points"](points[sid],weights[sid],cores,default,pose,"fma") for sid in (132,134)}
late_rows=C["surfaces"];late_union=union_mesh(C)
if late_union["errors"]:raise RuntimeError("P011 union assembly failed")
late_coords={};lookup={}
for sid in (132,134):
 ss=late_rows[sid];ll={int(g):i for i,g in enumerate(ss["global_vertex_ids"])}
 lookup[sid]=ll
for sid in (132,134):
 for gid,i in lookup[sid].items():
  late_coords.setdefault(gid,np.asarray(late[sid][i],dtype="<f4").copy())
late_xyz=np.asarray([late_coords[g] for g in late_union["gids"]],dtype="<f4")
late_full={"rows":{}}
for sid in (132,134):
 s=late_rows[sid]
 tr=audit_mesh(f"P011151999_row{sid}",np.asarray(s["faces"],dtype=np.int64),late[sid])
 late_full["rows"][str(sid)]=tr
 log("P011_child_audit_complete",sid=sid,self_pairs=tr["exact_float32_self_pair_count"])
tu=topology(late_union["faces"],len(late_xyz),late_xyz)
ua=audit_mesh("P011151999_joined_union",late_union["faces"],late_xyz)
late_full["union"]={"topology":tu,"exact_self":ua,"cancelled_opposite_shared_faces":len(late_union["shared"])}
late_full["baseline_092_target_witnesses"]={"original":"(132,5112) with (134,3723),(134,3724),(134,3741)","screen":"full exact union; all pairs preserved with candidate face provenance","known_baseline_counts":[1,2,1]}
log("P011_union_audit_complete",pairs=ua["exact_float32_self_pair_count"],faces=len(late_union["faces"]),components=tu["face_components"])
report={"schema":"numi.human.forearm085-candidate097-full-source-and-late-audit.v1","status":"completed",
 "scope":"Full exact Float32-lattice child and joined-union self/topology audit for candidate097 source geometry, plus full P011 baseline step151999 CPU ordinary-path F32 route-field child/union audit. Candidate identity against base085 is exact except row132 faces5111/5112. Base085 full audit is durably recorded in prior 098 progress.jsonl. CPU-only, no native run, no all25 qualification.",
 "pins":{**PINS,str(CAND):sha(CAND),str(BASE_CAND):sha(BASE_CAND),str(FD/"attempt-098-full-source-and-late-audit-001/progress.jsonl"):sha(FD/"attempt-098-full-source-and-late-audit-001/progress.jsonl"),str(FD/"attempt-093-unit-correction-001/corrected-unit-receipt.json"):sha(FD/"attempt-093-unit-correction-001/corrected-unit-receipt.json")},
 "candidate_face_only_identity":identity,"exact_rational_source_support_proof":exact_support,"source_full_audits":source,
 "p011_step151999_full_cpu_ordinary_path_audit":{"pose_receipt_path":str(rc),"pose_receipt_sha256":sha(rc),
  "arithmetic":"same 088 F32 binding transforms and per-core FMA route field accumulation used to reproduce 092 witnesses; CPU pose reproduction, not native capture",
  "full_children_and_union":late_full},
 "qualification":{"gpu":False,"native":False,"all25":False,"admitted":False,"ordinary_path_p011_late":bool(ua["exact_float32_self_pair_count"]==0 and all(x["exact_float32_self_pair_count"]==0 for x in late_full["rows"].values())),
  "claim":"candidate source/CPU P011 gates only; root fresh native check required"},
 "environment":{"python":sys.version,"numpy":np.__version__,"cpu_workers":1,"maxrss_platform_units":resource.getrusage(resource.RUSAGE_SELF).ru_maxrss},
 "elapsed_seconds":time.monotonic()-START}
out=OUT/"report.json";out.write_text(json.dumps(report,indent=2,sort_keys=True,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))+"\n")
print(json.dumps({"report":str(out),"sha256":sha(out),"source":{k:{r:v.get("exact_self",{}).get("exact_float32_self_pair_count",v.get("exact_self",{}).get("exact_float32_self_pair_count")) for r,v in q.items()} for k,q in source.items()},
 "p011":{"union_pairs":ua["exact_float32_self_pair_count"],"child_pairs":{k:v["exact_float32_self_pair_count"] for k,v in late_full["rows"].items()},"topology":tu},"exact_support":exact_support,"elapsed_s":report["elapsed_seconds"]},indent=2))
