from pathlib import Path
import gzip,hashlib,json,shutil
A=Path('/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276')
C=A/'forearm-shared-field-native-012-diagonal097'
FW=Path('/Users/n/numi-human-fds132-m6-1350')
PUB=Path('/Users/n/numi-human-left-pq-publication-1344')
E=PUB/'tools/evidence/native-anatomy-left-forearm-diagonal-m6-1358'
R=C/'baseline/native-run'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 audit=json.loads((C/'native-audit-001/report.json').read_text())
 assert audit['complete'] and not audit['failures']
 assert len(audit['captures'])==8
 ex=json.loads((C/'baseline/execution.json').read_text())
 assert ex['returncode']==0 and not ex['changed_inputs']
 compact=json.loads((C/'compact-state-observations.json').read_text())
 assert compact['accepted_step_grid']['last']==8000 and compact['last_state']['time_s']>15.999
 prep=json.loads((C/'preparation.json').read_text());decl=json.loads((C/'baseline/run-declaration.json').read_text())
 assert len(decl['immutable_assets'])==89 and all(sha(p)==d for p,d in decl['immutable_assets'].items())
 E.mkdir(exist_ok=False)
 retained=[]
 def cp(src,rel,compress=False):
  src=Path(src);dst=E/rel;dst.parent.mkdir(parents=True,exist_ok=True)
  raw=src.read_bytes();dst.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
  retained.append({'source_path':str(src),'source_sha256':sha(src),'archived_path':str(dst.relative_to(E)),'archived_sha256':sha(dst),'gzip':compress})
 cp(A/'forearm012-publication-readme.md','README.md')
 for name in ['compact-state-observations.json','preparation.json','source-ancestry-proof.json','source-097-change-proof.json','carrier-roundtrip-report.json','rest-registration-preflight.json','launch-command.txt','launch-guard.json','launch_arm.py']:
  cp(C/name,name)
 for name in ['run-declaration.json','execution.json']:
  cp(C/'baseline'/name,'execution/'+name)
 for name in ['invocation.json','run-metadata.json']:
  cp(R/name,'native/'+name)
 for name in ['resting-coupled.csv','resting-surface-audit.csv']:
  cp(R/name,'native/'+name+'.gz',True)
 cp(C/'native-audit-001/report.json','native-audit/report.json')
 cp(FW/'attempt-100-pq130-shared-route-field-screen-001/097-lineage-overlay-001.json','source097/097-lineage-overlay-001.json')
 assert sha(FW/'attempt-100-pq130-shared-route-field-screen-001/calc_097_lineage_overlay_v2.py')=='d36d64ff430f57019576067972c4d16d73e9fe1f1179e32f71fe0ad5a77044f0'
 cp(FW/'attempt-100-pq130-shared-route-field-screen-001/calc_097_lineage_overlay_v2.py','source097/calc_097_lineage_overlay_v2.py.gz',True)
 cp(C/'verify_forearm_shared_field_native_012.py','scripts/verify_forearm_shared_field_native_012.py.gz',True)
 cp(A/'prepare_forearm_shared_field_native_012_diagonal097.py','scripts/prepare_forearm_shared_field_native_012_diagonal097.py.gz',True)
 cp(Path(__file__),'scripts/publish_forearm_native012_evidence_1358.py.gz',True)
 for folder,name in [('attempt-097-minimal-late-witness-diagonal-screen-001','screen_minimal_witness_diagonal.py'),('attempt-099-candidate097-full-source-and-late-audit-001','audit_candidate097_full_source_and_late.py')]:
  label='source097' if '097-minimal' in folder else 'source099-full'
  cp(FW/folder/'report.json',label+'/report.json')
  cp(FW/folder/name,label+'/'+name+'.gz',True)
 cp(R/'native-viewer.mov','viewer/native-viewer.mov')
 cp(C/'inspection-frames-001/extraction.json','viewer/extraction.json')
 cp(C/'inspection-frames-001/end.png','viewer/end.png')
 old=PUB/'tools/evidence/native-anatomy-left-forearm-refined-m6-1357'
 cp(old/'anatomy-source-attribution.json','anatomy-source-attribution.json')
 cp(A/'forearm054-native-diagnostic-009-refined085/external-union-census-001/report.json','surrounding-anatomy-native009/report.json')
 cp(A/'audit_forearm009_external_union_001.py','surrounding-anatomy-native009/audit_forearm009_external_union_001.py.gz',True)
 cp(C/'external-union-census-001/report.json','surrounding-anatomy-native012/report.json')
 cp(C/'external-union-census-001/comparison-native009.json','surrounding-anatomy-native012/comparison-native009.json')
 cp(A/'audit_forearm012_external_union_001.py','surrounding-anatomy-native012/audit_forearm012_external_union_001.py.gz',True)
 external=dict(decl['immutable_assets'])
 external.update(json.loads((FW/'attempt-100-pq130-shared-route-field-screen-001/097-lineage-overlay-001.json').read_text())['inputs'])
 external.update(audit['pins'])
 for p in [R/'native.log',C/'resting-anatomy-receipt.json',FW/'attempt-097-minimal-late-witness-diagonal-screen-001/candidate-source-preserving-flip.pkl',FW/'attempt-097-minimal-late-witness-diagonal-screen-001/route-anchor-reference-field-flipped.npz']:
  external[str(p)]=sha(p)
 for step in audit['available_capture_steps']:
  p=R/'accepted-geometry'/f'step-{step}.mrvpack'
  external[str(p)]=sha(p);external[str(p.with_suffix('.receipt.json'))]=sha(p.with_suffix('.receipt.json'))
 assert all(sha(p)==d for p,d in external.items())
 (E/'retained-external-files.json').write_text(json.dumps(external,indent=2,sort_keys=True)+'\n')
 summary={'status':'bounded_native012_and_cpu_late097_pass_not_complete_human','execution_host':'numi','device':decl['hardware'],'accepted_steps':8000,'simulation_clock_source':'native resting-coupled.csv accepted endpoint, pinned in compact-state-observations.json','simulation_seconds':compact['last_state']['time_s'],'launcher_wall_seconds':ex['wall_seconds'],'realtime_factor':compact['last_state']['time_s']/ex['wall_seconds'],'native_capture_count':8,'all_target_coordinates_bitwise_equal_native009':all(all(c['coordinate_array_bitwise_equal_native009'] for c in row['children'].values()) for row in audit['captures'].values()),'all_866_other_surfaces_and_157_poses_and_1000_physiology_rows_exact_native009':True,'exact_source_change':'One same-parent edge flip in left132 faces5111/5112; exact source coordinates, patch coverage, signed volume, bindings, laterality, shared interface unchanged.','source097_report_metric_correction':'The unstable local-plane Float32 metric in097 is not a source-plane deviation. Exact source coplanarity and zero rational signed-volume difference are established by099 and source-097-change-proof.','derived_face_lineage':'New faces5111 and5112 each draw from both old060 row-local faces5819/5820. Retained scalar060 ancestry is historical, not exclusive; exact pooled lineage overlay is authoritative.','qualification_limits':['Native run16s only; old late151999 proof uses CPU reproduction of ordinary shader arithmetic, not a fresh long native run.','Other forearm interfaces remain unclassified: previous native009 canceledunion census has4007 raw pairs atstep8000, including1177 with leftPQ130.','Rightforearm and six-part back remain under repair; no final anatomical admission or final five-minute baseline/intervention qualification.','Performance remains about0.15x; no new optimization claim.']}
 assert summary['all_target_coordinates_bitwise_equal_native009']
 (E/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
 (E/'retained-files.json').write_text(json.dumps(retained,indent=2,sort_keys=True)+'\n')
 (E/'viewer/visual-inspection.json').write_text(json.dumps({'frame':'end.png','observed':'Whole supine adult visible on existing flat support. Native HUD accepted16.00s,3breaths,19beats,lung2.77L,airflow0.64L/s,PaO2102.73mmHg,PaCO238.92mmHg,SaO297.41%,tidal528.92mL,stroke70.05mL,blood5.15L,meanCO5.02L/min.','boundary':'Root visually inspected the unmodified decoded frame. This does not establish tissue intersection clearance.'},indent=2)+'\n')
 print(json.dumps({'evidence':str(E),'files':len(retained),'external_pins':len(external),'summary':summary},indent=2))
if __name__=='__main__':main()
