from __future__ import annotations
import ast, hashlib, importlib.util, json, signal, sys, time, traceback
from pathlib import Path
import numpy as np

R=Path("/Users/n/numi-human-retained-delivery-20261009")
ROOT=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001"
OUT=ROOT/"attempt-048"
TISS=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
MAN=TISS.with_suffix(".manifest.json")
PAIR=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
INV=Path("/Users/n/numi-human-resting-evidence-20261005/native-complete-skin-containment-audit-890/pair-summary-v3.csv")
ATTEMPT010=ROOT/"attempt-010/run_gluteus_union_010.py"
PARENT_SMALL=ROOT/"attempt-019/solve_terminal_self_pairs_019.py"
PARENT_AUDIT=ROOT/"attempt-047/result.json"
FORWARD=R/"signed-winding-self-union-1273/subscap-pilot-001/full-attribute-lift-007/run_offline_attribute_lift_pose_audit_007.py"
OWNER=Path("/Users/n/numi-human-local-clearance-preservation-1277/src")
SIGNED=Path("/Users/n/numi-human-signed-winding-1273/src")
STEPS=(47519,151999,152607,153215,153823,154431,155000)
ARMS=("baseline","intervention")
TARGET_KEY=(51004,2)
TARGET_BODY=131
SOURCE_ROW=29
MAX_ADDED_L2_MM=1.0
LOCAL_SUPPORT_FACE_HOPS=2
sys.path[:0]=[str(OWNER),str(SIGNED)]
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_intersections as ci

PINS={
 str(TISS):"6579d06d358bfcf51f964feb57425fe568c467fd361930bce46d376ec8aedaa4",
 str(MAN):"80d775bef6b8a4108e159fb7882a84b2fb8dce5b492059cd8c7cf3644a137467",
 str(INV):"a43484aa8d65b207cc498bb470097ec5f06ef2bb9872837bde9f197e19e815e3",
 str(ATTEMPT010):"3343c53df203e43d30d778b2f6178295ce250c1519326db55e97c5118e44fcd4",
 str(PARENT_SMALL):"f903fd518bbad959cb6de4c0cf9ba4f6816667f7451613265ec8ad172e16d02e",
 str(PARENT_AUDIT):"68b5e8848f691594234d553753808bee80ebbcbbb11b958bfa4edc45d27b89f4",
 str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"):"6af6d36091228465a76f12764c6c82c6ad844f704ffcbea81f7545e57f467a03",
 str(ROOT/"attempt-019/stable-29-unadmitted-local-offset-candidate.npz"):"828f05a830d50ee699ba6f23731351ff380e469e88f3d0365bdcc1384c50debd",
 str(ROOT/"attempt-019/result.json"):"079a5af99e3aa6523b1508101c50998432b15d40905c9d415f0d796c7251c355",
 str(ROOT/"attempt-047/result.json"):"4d566946c4caf9ec2c596ecebac6cd48d0611556de76294f620b1169e224721d",
 str(ROOT/"attempt-034/solve_local_femur_clearance_034.py"):"ddfaa29f30f906f8f762526a3b6cfafb3e5daedae1baf7fe0c2fe5e3cb46f929",
 str(ROOT/"attempt-046/result.json"):"2b36e753ffa37a50cfd0f41679a32a69e6a8befec9a78af5b58def9205490c3f",
 str(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz"):"1dbe9157946714f592d1f3e97759a5abf507fd36b6f570bdf7eec5a0315fc45d",
 str(ROOT/"attempt-035/audit_gluteus_femur_clearance_035.py"):"79a7507f83e40011c726a2bf40d5614e49dae38d630deb76dfdb3c6f57852264",
 str(ROOT/"attempt-035/result.json"):"37a04fd381af636b75956957ed5e328e8ee3fa372eedf9da04ed965a61a974c9",
 str(ROOT/"attempt-036/solve_local_femur_clearance_036.py"):"013e8395e3d94a12ff389455ecc054a8798ab94848df32ac6070e9b9f2b5016e",
 str(ROOT/"attempt-036/failure.json"):"b561834b54e9f8ae64ad7efcba719b06124da35a03f07f9dc5ee57c0f1161057",
 str(OWNER/"numilab_human/cardiac_cavity_geometry.py"):"f6e98744dad9e23cd3b505efc02e7faa618fccce81d2ee08b07f948ef182fb72",
 str(OWNER/"numilab_human/cardiac_cavity_intersections.py"):"423180082e32d002375b612aad36f307ed439af07c04d655e6a8bedc87a338bd",
 str(OWNER/"numilab_human/common_atlas_skin_clearance.py"):"fd152a157cd698094592e64cb746a81a32fc29381a6e6ffc4d5524400041f6b5",
 str(ROOT/"attempt-037/solve_local_femur_clearance_037.py"):"34e7e8bc7a17407598101a62e81ea09f546cc2833a1958141df825c0f2a42d67",
 str(ROOT/"attempt-037/failure.json"):"896ad0e6ca474926405332a225bb6b198a7e06204afcb43249ce2320ea12372e",
 str(Path("/Users/n/numi-human-local-clearance-preservation-1277/tests/test_common_atlas_skin_self_separation_proposal.py")):"465ae67ca0b49c7ba6a77fee8876d463245e915a492f9b3893579aa6129aa9fe",
 str(ROOT/"attempt-039/solve_local_femur_clearance_039.py"):"aed4c6e777914fa671ff2e5eae8bf16c2d1312cba7a79ed29863db4dcd6e6bec",
 str(ROOT/"attempt-039/failure.json"):"39002a312ca55e83146e8d674cf60ae5336e4c5c7b11ee0f9f808b25f039e5c4",
 str(ROOT/"attempt-040/solve_local_femur_clearance_040.py"):"c5f9821845a7720f1fd88d1dbb67340ee7c9573e7a185d240a9ab68d38532935",
 str(ROOT/"attempt-040/failure.json"):"acd21e60f58b2f62d517bfe9bde754bb9ad34368dbb65545231925c9fde9cb5a",
 str(ROOT/"attempt-041/diagnose_local_qp_conflict_041.py"):"a675752abb146185c8368f22385a8bd89978b933ad2e65290822469ea8b17960",
 str(ROOT/"attempt-041/feasibility-isolation.json"):"274a9e1f293b55d6400a06ec55dff91c4051be2accdc5a0315d0e2ba54d3c28f",
 str(ROOT/"attempt-041/progress.jsonl"):"71817c00b4e9d35a3d6d86830dd94cb3d13f2b4219af87c4ef959fc3b270ec58",
 str(ROOT/"attempt-042/solve_local_femur_clearance_042.py"):"76fb1bf99cd404973d7680c0be112366f032a2312f97e64aebe759d40b2ba8c8",
 str(ROOT/"attempt-042/failure.json"):"827a467977117b8c8c233c5f7988085b6f14a75064dde13e8a526d5a34431dc7",
 str(ROOT/"attempt-043/solve_local_femur_clearance_043.py"):"d6be837e7f67509daf5e2bda90b1757ecfa466fe4d299b9dc163c0369b718e16",
 str(ROOT/"attempt-044/solve_local_femur_clearance_044.py"):"c3a9a21548fd86617e712b0856b88cb19eae96631456256f0d1c7bca223ad0e4",
 str(ROOT/"attempt-044/failure.json"):"cc10a971b3ee19ea83e465fbab21ea71bcbdb35c5bf5e1ac09bd4823988a8c93",
 str(ROOT/"attempt-045/solve_local_femur_clearance_045.py"):"a0334e09d4f327c150c8c73953601288b37ce8390f25246099e7f0194f57ee5c",
 str(ROOT/"attempt-045/failure.json"):"89ef85fae6f53a49fc04b6bb477ba31f5f5c23973832cbc7b43c44cfe2734f74",
 str(ROOT/"attempt-046/solve_local_femur_clearance_046.py"):"073dc2277e2c79fc04612c6fa74c8afde62c0c9f8400b19d2652b02055a66298",
 str(ROOT/"attempt-046/result.json"):"26e9358752ad6de60a8975805378a504c97dd1b49a376ec0af75e647a47668a8",
 str(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz"):"65a91686a35d50c0c4b0afd06de6eb803d077d77c633fc59e138c0ab91d6e740",
 str(ROOT/"attempt-047/audit_gluteus_clearance_047.py"):"4839c892254eff2cddbc27603ffda1d4c8b4ad4bf398472fa88ad359cb23cbb3",
 str(FORWARD):"e78fe261b2f625de51378c34d238b6716ac38bf2eb667824d669cdd2bda6ad47",
}
START=time.monotonic()

def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""): h.update(b)
 return h.hexdigest()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def emit(event,**kw):
 row={"event":event,"elapsed_s":time.monotonic()-START,**kw}
 with (OUT/"progress.jsonl").open("a") as f: f.write(json.dumps(row,sort_keys=True,separators=(",",":"))+"\n")
 print(json.dumps(row,sort_keys=True),flush=True)
def load_forward():
 tree=ast.parse(FORWARD.read_text()); ns={"np":np,"Path":Path,"struct":__import__("struct")}
 wanted={"need","load_tissue","row_data","f32","cross32","rotate32","forward"}
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name in wanted:
   exec(compile(ast.Module(body=[node],type_ignores=[]),str(FORWARD),"exec"),ns)
 return ns
def exact_tri_intersects(a,b):
 aa=tuple(ci.float32_point_lattice_key(tuple(float(v) for v in p)) for p in np.asarray(a,dtype="<f4"))
 bb=tuple(ci.float32_point_lattice_key(tuple(float(v) for v in p)) for p in np.asarray(b,dtype="<f4"))
 return bool(ci.triangle_intersection_points(aa,bb))
def exact_self(points,faces):
 p=np.asarray(points,dtype="<f4"); f=np.asarray(faces,dtype=np.int64)
 uq,inv=np.unique(p,axis=0,return_inverse=True); qf=inv[f]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in row)) for row in uq]
 deg=[]
 for i,t in enumerate(qf):
  n=ci._cross(ci._sub(lattice[int(t[1])],lattice[int(t[0])]),ci._sub(lattice[int(t[2])],lattice[int(t[0])]))
  if not any(n): deg.append(int(i))
 if deg:return {"count":None,"pairs":None,"degenerate_faces":deg}
 rec=ci._records(lattice,qf.tolist())
 result=ci._audit_pair(rec,rec,same_surface=True)
 return {"count":int(result["count"]),"pairs":result["triangle_pairs"],"degenerate_faces":[]}
def load_pose(receipt,step):
 d=json.loads(receipt.read_text())
 require(d.get("accepted_step")==step and d.get("physical_endpoint")=="accepted",f"unaccepted endpoint {receipt}")
 pack=receipt.with_name(receipt.name.replace(".receipt.json",".mrvpack"))
 require(d.get("pack_file_sha256")==sha(pack),f"receipt does not bind pack {pack}")
 poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype="<f4"),np.asarray(x["quaternion_xyzw"],dtype="<f4")) for x in d["accepted_registered_body_poses"]}
 return poses,pack
def oriented_cyclic(t):
 t=tuple(map(int,t))
 return min(t, t[1:]+t[:1], t[2:]+t[:2])
def quat_rotation(q):
 x,y,z,w=map(float,np.asarray(q,dtype=np.float32))
 return np.asarray([[1.0-2.0*(y*y+z*z),2.0*(x*y-w*z),2.0*(x*z+y*w)],
                    [2.0*(x*y+z*w),1.0-2.0*(x*x+z*z),2.0*(y*z-x*w)],
                    [2.0*(x*z-y*w),2.0*(y*z+x*w),1.0-2.0*(x*x+y*y)]],dtype=np.float64)
def pose_jacobians(points,local,weights,row,tissue,poses):
 out=np.zeros((len(points),3,3),dtype=np.float64)
 for vi in range(len(points)):
  for slot in range(4):
   w=np.float32(weights[vi,slot])
   if w<=np.float32(2e-6): continue
   li=int(local[vi,slot])
   require(li<row["bc"],"active candidate route index outside binding table")
   bind=tissue["bindings"][row["fb"]+li]
   core=int(bind["core"]); val=bind["value"]
   require(core in poses,f"missing pose for body {core}")
   body_rot=quat_rotation(poses[core][1]); local_rot=quat_rotation(val[3:7]); scale=float(np.float32(val[7]))
   out[vi]+=float(w)*body_rot@(scale*local_rot)
 return out
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 require(not (OUT/"result.json").exists() and not (OUT/"progress.jsonl").exists(),"attempt043 outputs already exist")
 prior_audit=json.loads((ROOT/"attempt-046/result.json").read_text())
 require(prior_audit.get("inputs_unchanged") is True and prior_audit.get("status")=="unadmitted_local_source_candidate_tracked_pairs_clear","attempt046 starting candidate not locally clear")
 target_pairs_by_pose={}
 for check in prior_audit["target_identity"]["baseline_clear_current_candidate_intersects_checks"]:
  key=(check["arm"],int(check["step"]))
  require(key[0] in ARMS and key[1] in STEPS,f"unexpected attempt046 tracked pose {key}")
  target_pairs_by_pose.setdefault(key,[]).append((int(check["source_face"]),int(check["femur_face"])))
 target_pairs_by_pose={k:sorted(set(v)) for k,v in target_pairs_by_pose.items()}
 require(len(target_pairs_by_pose)==14 and sum(map(len,target_pairs_by_pose.values()))==54,"attempt046 baseline pair inventory changed")
 new_report=json.loads(PARENT_AUDIT.read_text())
 require(new_report.get("inputs_unchanged") is True and new_report.get("status")=="unadmitted_candidate_failed_one_or_more_16pose_gates","attempt047 audit not closed as expected")
 new_pairs_by_pose={}
 for failure in new_report["external_gate_failures"]:
  if int(failure["stable_id"])!=SOURCE_ROW: continue
  key=(failure["arm"],int(failure["step"]))
  require(key[0] in ARMS and key[1]==155000,f"unexpected new-pair pose {key}")
  vals=[]
  for x in failure["added_pairs"]:
   sem,tid,sf,tf=map(int,x)
   require((sem,tid)==TARGET_KEY,"new pair does not target pinned external interface")
   vals.append((sf,tf))
  require(vals,"empty added-pair failure row")
  new_pairs_by_pose[key]=sorted(set(vals))
  target_pairs_by_pose[key]=sorted(set(target_pairs_by_pose[key])|set(vals))
 require(set(new_pairs_by_pose)=={(arm,155000) for arm in ARMS},f"unexpected new-pair pose rows {new_pairs_by_pose}")
 all_pairs=sorted({x for vals in target_pairs_by_pose.values() for x in vals})
 require(all_pairs==[(262,427),(336,437),(344,436),(461,404),(461,406),(461,408),(463,434),(865,1097)],f"unexpected combined tracked pair set {all_pairs}")
 before_paths=[Path(p) for p in PINS]
 for arm in ARMS:
  before_paths += [PAIR/arm/"run-declaration.json",PAIR/arm/"execution.json",PAIR/arm/"native-run/run-metadata.json"]
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   before_paths += [rp,rp.with_name(rp.name.replace(".receipt.json",".mrvpack"))]
 pins_before={str(p):sha(p) for p in [Path(__file__),*before_paths]}
 for p,expected in PINS.items(): require(pins_before[p]==expected,f"pinned input changed: {p}")
 for arm in ARMS:
  ex=json.loads((PAIR/arm/"execution.json").read_text())
  meta=json.loads((PAIR/arm/"native-run/run-metadata.json").read_text())
  require(ex.get("returncode")==0 and ex.get("changed_inputs")=={} and ex.get("native_argv_matches_prepared_cli_preview") is True and ex.get("native_environment_matches_prepared_cli_preview") is True,f"{arm} pair arm not closed")
  require(meta.get("exit_code")==0 and meta.get("source_files_changed_during_run")==[],f"{arm} native metadata failed")
 emit("pinned_inputs_verified",files=len(pins_before),pose_pair_rows=sum(map(len,target_pairs_by_pose.values())),unique_pairs=all_pairs)
 # The two row patches retain identical topology and weights; only source xyz/normals differ.
 union_npz=np.load(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz",allow_pickle=False)
 small_npz=np.load(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz",allow_pickle=False)
 union=np.ascontiguousarray(union_npz["vertices6"][:,:3],dtype="<f4")
 small=np.ascontiguousarray(small_npz["vertices6"][:,:3],dtype="<f4")
 faces=np.asarray(union_npz["faces"],dtype=np.int64)
 local=np.asarray(union_npz["binding_indices"],dtype="<u4")
 weights=np.asarray(union_npz["weights"],dtype="<f4")
 require(faces.shape==(2372,3) and union.shape==small.shape==(1190,3),"source row shape changed")
 require(np.array_equal(faces,small_npz["faces"]),"source faces changed between raw union and small self-clear candidate")
 require(np.array_equal(local,small_npz["binding_indices"]) and np.array_equal(weights,small_npz["weights"]),"source maps changed between raw union and candidate")
 face_motion={}
 for sf in sorted({x[0] for x in all_pairs}):
  tri=faces[sf]
  require(oriented_cyclic(tri)==oriented_cyclic(small_npz["faces"][sf]),f"source face {sf} is not cyclically identical")
  require(np.array_equal(local[tri],small_npz["binding_indices"][tri]) and np.array_equal(weights[tri],small_npz["weights"][tri]),f"source face {sf} binding map changed")
  delta=np.linalg.norm(small[tri].astype(np.float64)-union[tri].astype(np.float64),axis=1)*1000.0
  face_motion[str(sf)]={"oriented_cyclic_connectivity_same":True,"weights_and_binding_indices_same":True,"vertex_ids":tri.tolist(),"vertex_displacement_mm":delta.tolist(),"max_vertex_displacement_mm":float(delta.max())}
 require(max(x["max_vertex_displacement_mm"] for x in face_motion.values())>0.0,"all affected rows are unchanged; likely metadata-only pair artifact")
 # Load exact shared owner forwarding and source row bindings.
 fwd=load_forward(); tissue=fwd["load_tissue"](TISS); row=fwd["row_data"](tissue,SOURCE_ROW); forward=fwd["forward"]
 # Pure-route anchors are inherited exactly from the self-clear candidate report.
 small_report=json.loads((ROOT/"attempt-046/result.json").read_text())
 anchors=np.asarray(small_report["local_patch"]["preserved_anchor_vertex_ids"],dtype=np.int64)
 require(len(anchors)>0 and np.array_equal(union[anchors],small[anchors]),"small self-clear start moved preserved pure-route anchors")
 # Build only the five oriented local femur triangles used by the exact changed-pair report.
 target_face_ids=sorted({tf for _,tf in all_pairs})
 target_face_row={tf:i for i,tf in enumerate(target_face_ids)}
 samples=[]
 baseline_pair_checks=[]
 for arm in ARMS:
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   poses,pack=load_pose(rp,step)
   pack_positions,surfaces,_=ca._pack_surfaces(pack,{TARGET_KEY})
   require(TARGET_KEY in surfaces and int(surfaces[TARGET_KEY]["body"])==TARGET_BODY,f"wrong target identity in {arm}/{step}")
   target_faces=np.asarray(surfaces[TARGET_KEY]["faces"],dtype=np.int64)
   require(target_faces.ndim==2 and target_faces.shape[1]==3 and min(target_face_ids)>=0 and max(target_face_ids)<len(target_faces),"femur face row outside target")
   selected=target_faces[target_face_ids]
   target_vertex_mesh_ids=np.unique(selected.reshape(-1))
   target_vertex_local=np.searchsorted(target_vertex_mesh_ids,selected)
   combined_faces=np.concatenate([faces, target_vertex_local.astype(np.int64)+len(union)],axis=0)
   appended_target_ids=np.arange(len(union),len(union)+len(target_vertex_mesh_ids),dtype=np.int64)
   target_xyz=np.ascontiguousarray(pack_positions[target_vertex_mesh_ids],dtype="<f4")
   world_union=forward(union,local,weights,row,tissue,poses)
   world_small=forward(small,local,weights,row,tissue,poses)
   baseline_world=np.concatenate([world_union,target_xyz],axis=0).astype("<f4")
   rejected_world=np.concatenate([world_small,target_xyz],axis=0).astype("<f4")
   jac=np.zeros((len(baseline_world),3,3),dtype=np.float64)
   jac[:len(union)]=pose_jacobians(small,local,weights,row,tissue,poses)
   pose_pairs=[]
   preservation_pairs=[]
   old_pairs=[p for p in target_pairs_by_pose[(arm,step)] if p not in new_pairs_by_pose.get((arm,step),[])]
   for sf,tf in old_pairs:
    source_tri=faces[sf]
    target_tri=pack_positions[target_faces[tf]]
    base_hit=exact_tri_intersects(world_union[source_tri],target_tri)
    current_hit=exact_tri_intersects(world_small[source_tri],target_tri)
    require(not base_hit and not current_hit,f"prior pair lost exact-clear state at {arm}/{step} pair {sf}/{tf}: union={base_hit},current={current_hit}")
    combined_target_face=len(faces)+target_face_row[tf]
    require(sf<combined_target_face,"preserved pair face-row ordering must be canonical lower-first")
    preservation_pairs.append((sf,combined_target_face))
    baseline_pair_checks.append({"arm":arm,"step":step,"source_face":sf,"femur_face":tf,"pair_kind":"preserve","baseline_clear":True,"current_clear":True})
   for sf,tf in new_pairs_by_pose.get((arm,step),[]):
    source_tri=faces[sf]
    target_tri=pack_positions[target_faces[tf]]
    base_hit=exact_tri_intersects(world_union[source_tri],target_tri)
    rejected_hit=exact_tri_intersects(world_small[source_tri],target_tri)
    require(not base_hit and rejected_hit,f"pair is not an exact raw-union-clear to current-candidate-hit transition at {arm}/{step} pair {sf}/{tf}: base={base_hit},current={rejected_hit}")
    combined_target_face=len(faces)+target_face_row[tf]
    require(sf<combined_target_face,"pair face-row ordering must be canonical lower-first")
    pose_pairs.append((sf,combined_target_face))
    baseline_pair_checks.append({"arm":arm,"step":step,"source_face":sf,"femur_face":tf,"pair_kind":"resolve","baseline_clear":True,"candidate_intersects":True})
   pose_pairs=np.asarray(sorted(set(pose_pairs)),dtype=np.int64).reshape(-1,2)
   preservation_pairs=np.asarray(sorted(set(preservation_pairs)),dtype=np.int64).reshape(-1,2)
   require(len(pose_pairs)==len(new_pairs_by_pose.get((arm,step),[])),"new-pair local SAT row mapping lost duplicate or pair")
   require(len(preservation_pairs)==len(old_pairs),"prior50 preservation row mapping lost duplicate or pair")
   if len(pose_pairs) or len(preservation_pairs):
    samples.append({"arm":arm,"step":step,
                    "vertex_ids":np.arange(len(baseline_world),dtype=np.int64),
                    "baseline_world_positions":baseline_world,
                    "rejected_world_positions":rejected_world,
                    "jacobians":jac,
                    "self_pair_rows":pose_pairs,
                    "clearance_preservation_pair_rows":preservation_pairs,"_accepted_poses":poses})
   emit("exact_local_pair_precheck",arm=arm,step=step,pairs=len(pose_pairs),target_faces=target_face_ids)
 # Combined local geometric table is the gluteus source mesh plus five actual oriented femur triangles.
 fixed_target=np.arange(len(union),len(union)+len(target_vertex_mesh_ids),dtype=np.int64)
 combined_source=np.concatenate([small,np.zeros((len(target_vertex_mesh_ids),3),dtype="<f4")],axis=0)
 prior_source_faces=sorted({sf for vals in target_pairs_by_pose.values() for sf,tf in vals if (sf,tf) not in {p for v in new_pairs_by_pose.values() for p in v}})
 prior_constraint_vertices=np.unique(faces[np.asarray(prior_source_faces,dtype=np.int64)].reshape(-1)).astype(np.int64)
 new_source_faces=sorted({sf for vals in new_pairs_by_pose.values() for sf,_ in vals})
 new_face_vertices=np.unique(faces[np.asarray(new_source_faces,dtype=np.int64)].reshape(-1)).astype(np.int64)
 seed=new_face_vertices
 require(len(seed)>0,"new target faces have no movable source vertices after preserving prior pair geometry")
 neighbors={int(v):set() for v in range(len(union))}
 for tri in faces:
  tv=list(map(int,tri))
  for v in tv: neighbors[v].update(tv)
 movable_set=set(map(int,seed))
 frontier=set(map(int,seed))
 for _ in range(LOCAL_SUPPORT_FACE_HOPS):
  next_frontier=set()
  for v in frontier: next_frontier.update(neighbors[int(v)])
  frontier=next_frontier-movable_set
  movable_set.update(frontier)
 fixed_support=anchors
 movable=np.asarray(sorted(movable_set-set(map(int,fixed_support))),dtype=np.int64)
 require(np.all(np.isin(seed,movable)),"new-pair seeds overlap fixed route anchors")
 require(len(movable)<=256,f"two-ring local patch exceeds owner bound: {len(movable)}")
 allfaces=np.concatenate([faces,combined_faces[len(faces):]],axis=0)
 local_pair_pose_rows=sum(map(len,new_pairs_by_pose.values()))
 prior_pair_pose_rows=sum(map(len,target_pairs_by_pose.values()))-local_pair_pose_rows
 # Keep every prior-clear and new-transition pair identity, but constrain only
 # rows that are exact intersections in the current candidate at each stage.
 fixed_target = np.arange(len(union), len(union) + len(target_vertex_mesh_ids), dtype=np.int64)
 combined_source = np.concatenate([small, np.zeros((len(target_vertex_mesh_ids), 3), dtype="<f4")], axis=0)
 prior_source_faces = sorted({sf for vals in target_pairs_by_pose.values() for sf,tf in vals if (sf,tf) not in {p for v in new_pairs_by_pose.values() for p in v}})
 prior_constraint_vertices = np.unique(faces[np.asarray(prior_source_faces, dtype=np.int64)].reshape(-1)).astype(np.int64)
 new_source_faces = sorted({sf for vals in new_pairs_by_pose.values() for sf, _ in vals})
 seed = np.unique(faces[np.asarray(sorted({sf for sf, _ in all_pairs}), dtype=np.int64)].reshape(-1)).astype(np.int64)
 require(len(seed) > 0, "tracked source pair set has no movable source vertices")
 neighbors = {int(v): set() for v in range(len(union))}
 for tri in faces:
  tv = list(map(int, tri))
  for v in tv:
   neighbors[v].update(tv)
 movable_set = set(map(int, seed))
 frontier = set(map(int, seed))
 for _ in range(LOCAL_SUPPORT_FACE_HOPS):
  next_frontier = set()
  for v in frontier:
   next_frontier.update(neighbors[int(v)])
  frontier = next_frontier - movable_set
  movable_set.update(frontier)
 fixed_support = anchors
 movable = np.asarray(sorted(movable_set - set(map(int, fixed_support))), dtype=np.int64)
 require(np.all(np.isin(seed, movable)), "tracked-pair seeds overlap fixed route anchors")
 require(len(movable) <= 256, f"two-ring local patch exceeds owner bound: {len(movable)}")
 allfaces = np.concatenate([faces, combined_faces[len(faces):]], axis=0)
 pose_contexts = {(sample["arm"], int(sample["step"])): sample for sample in samples}
 require(len(pose_contexts) == 14, f"expected 14 distinct arm/pose contexts, got {len(pose_contexts)}")
 pair_rows_by_context = {key: sorted(set(target_pairs_by_pose[key])) for key in pose_contexts}
 expected_initial_hits = {(key, pair) for key, vals in new_pairs_by_pose.items() for pair in vals}
 local_pair_pose_rows = sum(map(len, new_pairs_by_pose.values()))
 prior_pair_pose_rows = sum(map(len, target_pairs_by_pose.values())) - local_pair_pose_rows
 emit("active_set_setup", pair_pose_rows=sum(map(len, pair_rows_by_context.values())),
      initially_expected_hit_rows=len(expected_initial_hits), unique_pairs=all_pairs,
      seed_vertices=seed.tolist(), movable_vertices=len(movable), pure_route_anchors=len(anchors),
      prior_pair_source_faces=prior_source_faces, target_vertices=len(fixed_target),
      target_face_rows=target_face_ids, cumulative_l2_cap_mm=1.0)

 def exact_pair_hits(candidate_source):
  hit_rows = []
  current_world_by_pose = {}
  for key, sample in pose_contexts.items():
   poses = sample["_accepted_poses"]
   source_world = forward(candidate_source, local, weights, row, tissue, poses)
   target_xyz = sample["baseline_world_positions"][len(union):]
   world = np.concatenate([source_world, target_xyz], axis=0).astype("<f4")
   current_world_by_pose[key] = world
   for sf, tf in pair_rows_by_context[key]:
    target_face = len(faces) + target_face_row[tf]
    hit = exact_tri_intersects(world[allfaces[int(sf)]], world[allfaces[target_face]])
    if hit:
     hit_rows.append({"arm": key[0], "step": key[1],
                      "source_face": int(sf), "femur_face": int(tf)})
  return hit_rows, current_world_by_pose

 def candidate_axes(sample, pair, current_world):
  sf, tf = pair
  face_b = len(faces) + target_face_row[tf]
  tri_a = sample["baseline_world_positions"][faces[sf]]
  tri_b = sample["baseline_world_positions"][allfaces[face_b]]
  now_a = current_world[faces[sf]]
  now_b = current_world[allfaces[face_b]]
  def sat_axes(a, b):
   ea = np.roll(a, -1, axis=0) - a
   eb = np.roll(b, -1, axis=0) - b
   na = np.cross(ea[0], ea[1])
   nb = np.cross(eb[0], eb[1])
   return [na, nb, *[np.cross(x, y) for x in ea for y in eb],
           *[np.cross(x, na) for x in ea], *[np.cross(x, nb) for x in eb]]
  raw_axes = sat_axes(tri_a, tri_b) + sat_axes(now_a, now_b)
  raw_axes += [tri_b.mean(axis=0) - tri_a.mean(axis=0),
               now_b.mean(axis=0) - now_a.mean(axis=0)]
  raw_axes += [b - a for a in tri_a for b in tri_b]
  raw_axes += [b - a for a in now_a for b in now_b]
  scored = []
  seen = []
  for raw in raw_axes:
   axis = np.asarray(raw, dtype=np.float64)
   norm = float(np.linalg.norm(axis))
   if not np.isfinite(norm) or norm <= 1.0e-14:
    continue
   axis = axis / norm
   if any(abs(float(np.dot(axis, prior))) >= 1.0 - 1.0e-10 for prior in seen):
    continue
   seen.append(axis)
   a0, b0 = tri_a @ axis, tri_b @ axis
   gap_ab = float(np.min(b0) - np.max(a0))
   gap_ba = float(np.min(a0) - np.max(b0))
   if gap_ab >= gap_ba:
    baseline_gap = gap_ab
    current_gap = float(np.min(now_b @ axis) - np.max(now_a @ axis))
   else:
    baseline_gap = gap_ba
    current_gap = float(np.min(now_a @ axis) - np.max(now_b @ axis))
   if baseline_gap <= 1.0e-12:
    continue
   required = baseline_gap - current_gap
   if not np.isfinite(required) or required <= 0:
    continue
   scored.append((required, -baseline_gap, axis))
  scored.sort(key=lambda item: (item[0], item[1], tuple(float(x) for x in item[2])))
  return scored[:3]

 def current_delta_limits(candidate):
  delta = (candidate.astype(np.float64) - union.astype(np.float64)) * 1000.0
  l2 = np.linalg.norm(delta, axis=1)
  return float(l2.max(initial=0.0)), float(np.abs(delta).max(initial=0.0))

 current = small.copy()
 stage_rows = []
 initial_hits, current_world_by_pose = exact_pair_hits(current)
 initial_hit_ids = {((x["arm"], x["step"]), (x["source_face"], x["femur_face"])) for x in initial_hits}
 require(initial_hit_ids == expected_initial_hits,
         f"starting exact pair set differs from retained transition report: expected={sorted(expected_initial_hits)}, actual={sorted(initial_hit_ids)}")
 current_hits = initial_hits
 maximum_increment_l2_mm = 0.0
 seen_states = {hashlib.sha256(current.tobytes()).hexdigest()}
 for stage in range(1, 13):
  if not current_hits:
   break
  active_groups = sorted({(int(x["source_face"]), int(x["femur_face"])) for x in current_hits})
  group = active_groups[0]
  active_rows = [x for x in current_hits
                 if (int(x["source_face"]), int(x["femur_face"])) == group]
  emit("active_pair_solve_start", stage=stage, pair=list(group), active_pose_rows=active_rows,
       all_tracked_intersections_before=len(current_hits))
  pose_data = []
  for hit in active_rows:
   key = (hit["arm"], int(hit["step"]))
   sample = pose_contexts[key]
   pose_data.append((key, sample, current_world_by_pose[key],
                     candidate_axes(sample, group, current_world_by_pose[key])))
  require(all(options for _, _, _, options in pose_data),
          f"no positive accepted-baseline separator remains for active pair {group}")
  import itertools
  option_products = []
  for selected in itertools.product(*[entry[3] for entry in pose_data]):
   option_products.append((sum(item[0] for item in selected), selected))
  option_products.sort(key=lambda x: x[0])
  accepted_trial = None
  trial_receipts = []
  for option_index, (_, selected_axes) in enumerate(option_products[:6]):
   dynamic_samples = []
   axis_receipts = []
   for (key, sample, rejected_world, _), axis_item in zip(pose_data, selected_axes):
    sf, tf = group
    face_b = len(faces) + target_face_row[tf]
    dynamic_samples.append({
     "vertex_ids": sample["vertex_ids"],
     "baseline_world_positions": sample["baseline_world_positions"],
     "rejected_world_positions": rejected_world,
     "jacobians": sample["jacobians"],
     "self_pair_rows": np.asarray([[sf, face_b]], dtype=np.int64),
     "clearance_preservation_pair_rows": np.empty((0, 2), dtype=np.int64),
     "self_pair_axis_overrides": [{"face_pair": [sf, face_b],
                                   "axis_world": axis_item[2].tolist()}],
    })
    axis_receipts.append({"arm": key[0], "step": key[1],
                          "baseline_gap_deficit_m": float(axis_item[0]),
                          "baseline_gap_m": float(-axis_item[1]),
                          "axis_world": axis_item[2].tolist()})
   try:
    proposal_trial = ca._propose_local_self_separation_increment(
     source_positions_m=np.concatenate([current, np.zeros((len(target_vertex_mesh_ids), 3), dtype="<f4")], axis=0),
     faces=allfaces, movable_vertex_ids=movable, self_patch_seed_vertex_ids=seed,
     required_target_seed_vertex_ids=np.asarray([], dtype=np.int64),
     active_target_face_vertex_ids=fixed_target, fixed_support_vertex_ids=fixed_support,
     preserved_anchor_vertex_ids=anchors, pose_samples=dynamic_samples)
    trial_source = np.asarray(proposal_trial["proposal_source_positions_m_f32"][:len(union)], dtype="<f4")
    if trial_source.tobytes() == current.tobytes():
     trial_receipts.append({"axis_combination": option_index, "status": "no_source_change",
                            "axis_choices": axis_receipts})
     continue
    if trial_source[anchors].tobytes() != small[anchors].tobytes():
     trial_receipts.append({"axis_combination": option_index, "status": "anchor_changed",
                            "axis_choices": axis_receipts})
     continue
    outside = np.setdiff1d(np.arange(len(union), dtype=np.int64), movable, assume_unique=True)
    if trial_source[outside].tobytes() != small[outside].tobytes():
     trial_receipts.append({"axis_combination": option_index, "status": "outside_support_changed",
                            "axis_choices": axis_receipts})
     continue
    max_cumulative_l2, max_cumulative_component = current_delta_limits(trial_source)
    if max_cumulative_l2 > 1.0 + 1.0e-7:
     trial_receipts.append({"axis_combination": option_index, "status": "cumulative_l2_bound_exceeded",
                            "max_cumulative_l2_mm": max_cumulative_l2,
                            "axis_choices": axis_receipts})
     continue
    self_trial = exact_self(trial_source, faces)
    if self_trial["degenerate_faces"] or self_trial["count"] != 0:
     trial_receipts.append({"axis_combination": option_index, "status": "source_self_or_degenerate",
                            "source_self_count": self_trial["count"],
                            "degenerate_faces": self_trial["degenerate_faces"],
                            "axis_choices": axis_receipts})
     continue
    trial_hits, trial_world_by_pose = exact_pair_hits(trial_source)
    active_steps = {(x["arm"], x["step"]) for x in active_rows}
    active_remaining = [x for x in trial_hits
                        if (int(x["source_face"]), int(x["femur_face"])) == group
                        and (x["arm"], x["step"]) in active_steps]
    if active_remaining:
     trial_receipts.append({"axis_combination": option_index, "status": "active_pair_still_intersects",
                            "active_remaining": active_remaining,
                            "remaining_tracked_intersections": len(trial_hits),
                            "axis_choices": axis_receipts})
     continue
    accepted_trial = (trial_source, trial_hits, trial_world_by_pose,
                      proposal_trial, max_cumulative_l2, max_cumulative_component, self_trial)
    trial_receipts.append({"axis_combination": option_index, "status": "accepted_exact_active_clear",
                           "remaining_tracked_intersections": len(trial_hits),
                           "max_cumulative_l2_mm": max_cumulative_l2,
                           "max_cumulative_component_mm": max_cumulative_component,
                           "axis_choices": axis_receipts})
    break
   except Exception as exc:
    trial_receipts.append({"axis_combination": option_index, "status": "solver_or_exact_reject",
                           "error_type": type(exc).__name__, "error": str(exc),
                           "axis_choices": axis_receipts})
  if accepted_trial is None:
   stage_rows.append({"stage": stage, "active_pair": list(group), "active_rows": active_rows,
                      "status": "all_axis_choices_rejected", "axis_trials": trial_receipts})
   emit("active_pair_solve_failed", stage=stage, pair=list(group),
        axis_trials=len(trial_receipts), reasons=[x["status"] for x in trial_receipts])
   break
  previous = current
  current, current_hits, current_world_by_pose, proposal_trial, cumulative_l2, cumulative_component, self_trial = accepted_trial
  stage_inc = float(np.linalg.norm((current.astype(np.float64)-previous.astype(np.float64))*1000.0,
                                   axis=1).max(initial=0.0))
  maximum_increment_l2_mm = max(maximum_increment_l2_mm, stage_inc)
  state_sha = hashlib.sha256(current.tobytes()).hexdigest()
  require(state_sha not in seen_states, "active-set source state repeated; refusing a cycle")
  seen_states.add(state_sha)
  stage_row = {"stage": stage, "active_pair": list(group), "active_rows": active_rows,
               "status": "accepted_exact_active_clear", "axis_trials": trial_receipts,
               "remaining_tracked_intersections": len(current_hits),
               "max_increment_l2_mm": stage_inc, "max_cumulative_l2_mm": cumulative_l2,
               "max_cumulative_component_mm": cumulative_component,
               "source_self_count": self_trial["count"], "state_f32_sha256": state_sha}
  stage_rows.append(stage_row)
  emit("active_pair_solve_accepted", **stage_row)
  np.save(OUT / f"stage-{stage:02d}-unadmitted-source.npy", current.astype("<f4"), allow_pickle=False)
 final_hits, current_world_by_pose = exact_pair_hits(current)
 proposed = np.ascontiguousarray(current, dtype="<f4")
 extra = (proposed.astype(np.float64) - small.astype(np.float64)) * 1000.0
 cum = (proposed.astype(np.float64) - union.astype(np.float64)) * 1000.0
 max_extra_l2 = float(np.linalg.norm(extra, axis=1).max(initial=0))
 max_cum_l2 = float(np.linalg.norm(cum, axis=1).max(initial=0))
 require(proposed[anchors].tobytes() == small[anchors].tobytes(), "source solve moved a preserved pure-route anchor")
 outside = np.setdiff1d(np.arange(len(union), dtype=np.int64), movable, assume_unique=True)
 require(proposed[outside].tobytes() == small[outside].tobytes(), "source solve changed vertices outside its two-ring support")
 source_gate = exact_self(proposed, faces)
 require(source_gate["degenerate_faces"] == [] and source_gate["count"] == 0,
         f"final source self/degenerate failures: {source_gate}")
 exact_after = []
 for sample in samples:
  arm, step = sample["arm"], int(sample["step"])
  world_all = current_world_by_pose[(arm, step)]
  for sf, tf in pair_rows_by_context[(arm, step)]:
   face_b = len(faces) + target_face_row[tf]
   hit = exact_tri_intersects(world_all[allfaces[sf]], world_all[allfaces[face_b]])
   exact_after.append({"arm":arm,"step":step,"source_face":int(sf),"femur_face":int(tf),
                       "intersects_after_actual_forward":bool(hit)})
 require(len(exact_after) == sum(map(len, target_pairs_by_pose.values())),
         "missing exact recheck row after active-set solve")
 proposal = {"status":"bounded_sequential_active_set",
             "constraint_rows_by_pose":[{"stage":x["stage"],"active_pair":x["active_pair"],
                                         "axis_trials":x.get("axis_trials",[])} for x in stage_rows],
             "pair_pose_receipts":[{"stage":x["stage"],"active_pair":x["active_pair"],
                                    "active_rows":x["active_rows"],
                                    "remaining_tracked_intersections":x.get("remaining_tracked_intersections"),
                                    "status":x["status"]} for x in stage_rows],
             "float32_max_vertex_l2_increment_mm":maximum_increment_l2_mm,
             "active_set_stages":stage_rows}
 emit("source_and_local_forward_postcheck",source_self_pairs=source_gate["count"],source_degenerate_faces=0,
      max_increment_l2_mm=max_extra_l2,max_cumulative_from_union_l2_mm=max_cum_l2,
      local_remaining_pairs=sum(x["intersects_after_actual_forward"] for x in exact_after),
      stage_count=len(stage_rows))
 # Import the same geometry utility used by the parent attempt for normals, no asset edits.
 spec=importlib.util.spec_from_file_location("gluteus_attempt010",ATTEMPT010)
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
 from numilab_human.cardiac_cavity_geometry import analyze_topology
 m.analyze_topology=analyze_topology
 topology=m.analyze_topology(proposed.astype(float).tolist(),faces.tolist())
 require(topology["closed_oriented_manifold_candidate"],"source correction broke closed oriented topology")
 old_top=m.analyze_topology(small.astype(float).tolist(),faces.tolist())
 def signed_vols(top,xyz):
  out=[]
  for comp in top["face_components"]:
   vals=[]
   for k in comp:
    a,b,c=(np.asarray(xyz[int(j)],dtype=np.float64) for j in faces[int(k)])
    vals.append(float(np.dot(a,np.cross(b,c)))/6.0)
   out.append(float(sum(vals)))
  return out
 old_vol=signed_vols(old_top,small); new_vol=signed_vols(topology,proposed)
 require(len(old_vol)==len(new_vol) and all(a*b>0 for a,b in zip(old_vol,new_vol)),"source component orientation changed")
 outnpz=OUT/"stable-29-unadmitted-femur-clearance-candidate.npz"
 out_vertices6=np.concatenate([proposed,m.vertex_normals(proposed,faces)],axis=1).astype("<f4")
 np.savez(outnpz,vertices6=out_vertices6,binding_indices=local,weights=weights,faces=faces.astype("<u4"))
 pins_after={str(p):sha(p) for p in [Path(__file__),*before_paths]}
 require(pins_before==pins_after,"an input changed during local source solve")
 report={
  "schema":"numi.human.gluteus-maximus-local-femur-clearance-048.v1",
  "status":("unadmitted_local_source_candidate_tracked_pairs_clear" if not final_hits else "unadmitted_local_source_candidate_tracked_pairs_remaining"),
  "scope":"Stable row29 gluteus maximus only. Existing local source-position/Jacobian SAT QP combines the prior50 exact-clearance preservation rows and four newly migrated intersecting pair-pose rows against the same raw-union reference gaps. Open femur is an oriented local target patch; no global inside/outside or bone-volume claim.",
  "inputs_before":pins_before,"inputs_after":pins_after,"inputs_unchanged":pins_before==pins_after,
  "candidate_start":{"path":str(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz"),"sha256":PINS[str(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz")],"prior_source_motion_bound_mm":small_report["solver"]["source_max_from_raw_union_l2_mm"]},
  "raw_union_reference":{"path":str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"),"sha256":PINS[str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz")],"role":"local pair-clearance reference only; original source union is not an admitted whole-body baseline"},
  "target_identity":{"inventory_key":list(TARGET_KEY),"body_index":TARGET_BODY,"actual_oriented_femur_face_rows":target_face_ids,"full16_pose_audit_expected":True,"new_pair_pose_rows":local_pair_pose_rows,"prior50_clearance_preservation_pair_pose_rows":prior_pair_pose_rows,"unique_source_femur_pairs":[list(x) for x in all_pairs],"baseline_clear_current_candidate_intersects_checks":baseline_pair_checks},
  "triangle_identity_check":{"source_faces":face_motion,"cyclic_oriented_face_identity_used":True,"binding_indices_and_weights_identical":True},
  "local_patch":{"source_seed_vertex_ids":seed.tolist(),"new_source_face_ids":new_source_faces,"movable_vertex_ids":movable.tolist(),"preserved_anchor_vertex_ids":anchors.tolist(),"fixed_prior_pair_source_face_ids":prior_source_faces,"fixed_prior_pair_source_vertex_ids":prior_constraint_vertices.tolist(),"prior50_clearance_protection":"all prior rows are exact-checked after every update; only rows that actually intersect at that stage enter the next local QP; final all16 audit remains required","fixed_femur_target_vertex_ids":fixed_target.tolist(),"movable_vertex_count":len(movable),"support_geodesic_face_hops":LOCAL_SUPPORT_FACE_HOPS,"femur_target_vertex_count":len(fixed_target),"qp_max_increment_l2_bound_mm":MAX_ADDED_L2_MM},
  "solver":{"status":proposal["status"],"active_set_stages":stage_rows,"constraint_rows_by_pose":proposal["constraint_rows_by_pose"],"pair_pose_receipts":proposal["pair_pose_receipts"],"max_source_increment_l2_mm":proposal["float32_max_vertex_l2_increment_mm"],"source_max_from_raw_union_l2_mm":max_cum_l2,"component_orientation_preserved":True,"source_exact_self":source_gate,"local_exact_actual_forward_pair_recheck":exact_after,"local_exact_actual_forward_remaining_count":sum(x["intersects_after_actual_forward"] for x in exact_after),"full_16_pose_859_target_gate":"not run by this proposal step"},
  "candidate":{"path":str(outnpz),"sha256":sha(outnpz),"source_faces_unchanged":True,"binding_indices_unchanged":True,"weights_unchanged":True,"preserved_anchors_bitwise":True,"outside_two_ring_support_bitwise":True,"topology_closed_oriented":True,"source_area_ratio_vs_start":float(m.area(proposed,faces)/m.area(small,faces)),"component_signed_volumes_start_m3":old_vol,"component_signed_volumes_candidate_m3":new_vol},
  "limitations":["The active-set helper constrains only exact currently intersecting tracked pair-pose rows, then re-forwards and checks every retained tracked row after each accepted update. It covers the prior 50-preservation plus four initial transition rows, not all 859 targets.","This is an inferred reference-geometry proposal, not a measured anatomy update or native candidate pass.","A subsequent exact all16-pose source self/topology and all859-target changed-face audit is mandatory; no composition or admission is performed."],
  "wall_seconds":time.monotonic()-START
 }
 out=OUT/"result.json"; out.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":report["status"],"candidate":str(outnpz),"candidate_sha256":report["candidate"]["sha256"],"report":str(out),"report_sha256":sha(out),"local_remaining":report["solver"]["local_exact_actual_forward_remaining_count"],"wall_seconds":report["wall_seconds"]},sort_keys=True),flush=True)

if __name__=="__main__":
 try:
  signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError("attempt046 exceeded 1200 s")))
  signal.alarm(1200); main()
 except Exception as exc:
  OUT.mkdir(parents=True,exist_ok=True)
  failure={"schema":"numi.human.gluteus-maximus-local-femur-clearance-046.failure.v1","status":"failed_or_rejected_local_candidate","error_type":type(exc).__name__,"error":str(exc),"traceback":traceback.format_exc(),"pinned_hashes_at_failure":{p:sha(p) for p in PINS if Path(p).is_file()},"wall_seconds":time.monotonic()-START}
  fp=OUT/"failure.json";fp.write_text(json.dumps(failure,indent=2,sort_keys=True)+"\n")
  print(json.dumps({"status":failure["status"],"failure":str(fp),"sha256":sha(fp),"error":str(exc)},sort_keys=True),flush=True)
  raise
 finally:
  signal.alarm(0)

