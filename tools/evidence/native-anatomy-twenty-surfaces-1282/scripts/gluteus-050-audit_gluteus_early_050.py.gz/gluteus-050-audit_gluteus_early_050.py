from __future__ import annotations
import hashlib, importlib.util, json, signal, sys, time, traceback
from pathlib import Path
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
ROOT=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001"
OUT=ROOT/"attempt-050"
TISS=R/"anatomy-completion-1276/seventeen-surface-native-composition-002/assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
CURRENT_TISS=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
CURRENT_MAN=CURRENT_TISS.with_suffix(".manifest.json")
MAN=TISS.with_suffix(".manifest.json")
PAIR=R/"anatomy-completion-1276/seventeen-surface-native-composition-002"
BASELINE_CAND={29:ROOT/"attempt-010/stable-29-reference-union-row-patch.npz",30:ROOT/"attempt-010/stable-30-reference-union-row-patch.npz"}
CANDIDATE={29:ROOT/"attempt-048/stable-29-unadmitted-femur-clearance-candidate.npz",30:ROOT/"attempt-019/stable-30-unadmitted-local-offset-candidate.npz"}
CANDIDATE_REPORT=ROOT/"attempt-019/result.json"
CANDIDATE_PROPOSAL_REPORT=ROOT/"attempt-048/result.json"
INV=Path("/Users/n/numi-human-resting-evidence-20261005/native-complete-skin-containment-audit-890/pair-summary-v3.csv")
FORWARD=R/"signed-winding-self-union-1273/subscap-pilot-001/full-attribute-lift-007/run_offline_attribute_lift_pose_audit_007.py"
ATTEMPT010=ROOT/"attempt-010/run_gluteus_union_010.py"
ATTEMPT019=ROOT/"attempt-019/solve_terminal_self_pairs_019.py"
ATTEMPT034=ROOT/"attempt-034/solve_local_femur_clearance_034.py"
OWNER=Path("/Users/n/numi-human-self-separation-partial-resume-1267/src")
SIGNED=Path("/Users/n/numi-human-signed-winding-1273/src")
STEPS=[0,4767,5023,5599,6207,6815,7423,8000]
ARMS=["baseline"]
PINS={
 str(TISS):"925aa14b0faf4e0d31e3290ef867f949b7752eac00802e5ba7694cfe31c762c4",
 str(MAN):"665285d2098bf9df9b3426385c7d5e54b0a3426e57e434e79e67b647988f6821",
 str(INV):"a43484aa8d65b207cc498bb470097ec5f06ef2bb9872837bde9f197e19e815e3",
 str(CURRENT_TISS):"6579d06d358bfcf51f964feb57425fe568c467fd361930bce46d376ec8aedaa4",
 str(CURRENT_MAN):"80d775bef6b8a4108e159fb7882a84b2fb8dce5b492059cd8c7cf3644a137467",
 str(OWNER/"numilab_human/cardiac_cavity_geometry.py"):"f6e98744dad9e23cd3b505efc02e7faa618fccce81d2ee08b07f948ef182fb72",
 str(OWNER/"numilab_human/cardiac_cavity_intersections.py"):"423180082e32d002375b612aad36f307ed439af07c04d655e6a8bedc87a338bd",
 str(OWNER/"numilab_human/common_atlas_skin_clearance.py"):"151ba8925910ae164bdf9a41417ca2cc5c63b07c3b05eb09496d20c4771c5e9b",
 FORWARD:"e78fe261b2f625de51378c34d238b6716ac38bf2eb667824d669cdd2bda6ad47",
 ATTEMPT010:"3343c53df203e43d30d778b2f6178295ce250c1519326db55e97c5118e44fcd4",
 str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"):"6af6d36091228465a76f12764c6c82c6ad844f704ffcbea81f7545e57f467a03",
 str(ROOT/"attempt-010/stable-30-reference-union-row-patch.npz"):"46886a95bff1922f66709df0af8d87011c88d143144aa2bdcf75f6b87c082894",
 str(ROOT/"attempt-046/solve_local_femur_clearance_046.py"):"073dc2277e2c79fc04612c6fa74c8afde62c0c9f8400b19d2652b02055a66298",
 str(ROOT/"attempt-046/stable-29-unadmitted-femur-clearance-candidate.npz"):"65a91686a35d50c0c4b0afd06de6eb803d077d77c633fc59e138c0ab91d6e740",
 str(ROOT/"attempt-046/result.json"):"26e9358752ad6de60a8975805378a504c97dd1b49a376ec0af75e647a47668a8",
 str(ROOT/"attempt-047/audit_gluteus_clearance_047.py"):"4839c892254eff2cddbc27603ffda1d4c8b4ad4bf398472fa88ad359cb23cbb3",
 str(ROOT/"attempt-047/result.json"):"4d566946c4caf9ec2c596ecebac6cd48d0611556de76294f620b1169e224721d",
 str(ROOT/"attempt-048/solve_local_femur_clearance_048.py"):"fc28f3e03e81ba6f975932ee6961577871608e27ee5146a437d4c5e7fad56474",
 str(ROOT/"attempt-048/stable-29-unadmitted-femur-clearance-candidate.npz"):"835ee62f40dbbad0a0b30833583fac07825787dc603c39007d46f11776dc6790",
 str(ROOT/"attempt-048/result.json"):"5f6ecc89ad329982395214fd61073c4ad96af27237d9ea16fe5031863f3ac5f7",
 str(ROOT/"attempt-034/stable-29-unadmitted-femur-clearance-candidate.npz"):"1dbe9157946714f592d1f3e97759a5abf507fd36b6f570bdf7eec5a0315fc45d",
 str(ROOT/"attempt-034/result.json"):"2b36e753ffa37a50cfd0f41679a32a69e6a8befec9a78af5b58def9205490c3f",
 ATTEMPT034:"ddfaa29f30f906f8f762526a3b6cfafb3e5daedae1baf7fe0c2fe5e3cb46f929",
 str(ROOT/"attempt-019/stable-30-unadmitted-local-offset-candidate.npz"):"9a87f13548e5d6b62ce8bd19829b0c433b9203ebfa8fdbf8f66ca065445eca3d",
 str(CANDIDATE_REPORT):"079a5af99e3aa6523b1508101c50998432b15d40905c9d415f0d796c7251c355",
 ATTEMPT019:"f903fd518bbad959cb6de4c0cf9ba4f6816667f7451613265ec8ad172e16d02e",
 str(ROOT/"attempt-003/stable-29-exact-union.json"):"9cc5521c0c4b04c165beb3747c953fe7d541eba61e0299cb1527c451fccfe31c",
 str(ROOT/"attempt-003/stable-30-exact-union.json"):"aee6990edc4011dc70848cd23876901c69a1813cdfb4ba1468f20d41b80281fd",
 str(ROOT/"attempt-003/union-execution-003.json"):"802cee9e44d996b5ca94adc7458ab223e9b0188c98c346fee2595354fedba769",
}
sys.path[:0]=[str(OWNER),str(SIGNED)]
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_intersections as ci
from numilab_human.cardiac_cavity_geometry import analyze_topology
START=time.monotonic()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""): h.update(b)
 return h.hexdigest()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def progress(event,**kw):
 row={"event":event,"elapsed_s":time.monotonic()-START,**kw}
 with (OUT/"progress.jsonl").open("a") as f: f.write(json.dumps(row,sort_keys=True,separators=(",",": "))+"\n")
 print(json.dumps(row,sort_keys=True),flush=True)
def pose_map(receipt_path,step):
 d=json.loads(receipt_path.read_text())
 require(d.get("accepted_step")==step and d.get("physical_endpoint")=="accepted",f"unaccepted pose receipt {receipt_path}")
 pack=receipt_path.with_name(receipt_path.name.replace(".receipt.json",".mrvpack"))
 require(d.get("pack_file_sha256")==sha(pack),f"pose receipt does not bind pack {pack}")
 pose_rows=d.get("accepted_body_poses")
 require(isinstance(pose_rows,list) and len(pose_rows)==157,"early capture must expose all157 accepted body poses")
 poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype="<f4"),np.asarray(x["quaternion_xyzw"],dtype="<f4")) for x in pose_rows}
 require(len(poses)==157,"early accepted body pose IDs are not unique")
 return poses,pack
def load_forward():
 tree=__import__("ast").parse(FORWARD.read_text()); ns={"np":np,"Path":Path,"struct":__import__("struct")}
 wanted={"need","load_tissue","row_data","f32","cross32","rotate32","forward"}
 for node in tree.body:
  if isinstance(node,__import__("ast").FunctionDef) and node.name in wanted:
   exec(compile(__import__("ast").Module(body=[node],type_ignores=[]),str(FORWARD),"exec"),ns)
 return ns
def exact_audit(points,faces):
 p=np.asarray(points,dtype="<f4"); f=np.asarray(faces,dtype=np.int64)
 if not np.isfinite(p).all(): return {"count":None,"pairs":None,"degenerate_faces":[-1]},None
 uq,inv=np.unique(p,axis=0,return_inverse=True); qf=inv[f]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in row)) for row in uq]
 deg=[]
 for i,t in enumerate(qf):
  n=ci._cross(ci._sub(lattice[int(t[1])],lattice[int(t[0])]),ci._sub(lattice[int(t[2])],lattice[int(t[0])]))
  if not any(n): deg.append(int(i))
 if deg:return {"count":None,"pairs":None,"degenerate_faces":deg},None
 rec=ci._records(lattice,qf.tolist())
 a=ci._audit_pair(rec,rec,same_surface=True)
 return {"count":int(a["count"]),"pairs":a["triangle_pairs"],"degenerate_faces":[]},rec
def mutual_audit(a,fa,b,fb):
 aa,ra=exact_audit(a,fa); bb,rb=exact_audit(b,fb)
 if ra is None or rb is None:return {"count":None,"pairs":None}
 q=ci._audit_pair(ra,rb,same_surface=False)
 return {"count":int(q["count"]),"pairs":q["triangle_pairs"]}
def changed_records(points,faces,face_ids):
 p=np.asarray(points,dtype="<f4"); f=np.asarray(faces,dtype=np.int64)[face_ids]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in row)) for row in p]
 local=ci._records(lattice,f.tolist())
 return [rec[:3]+(int(face_ids[int(rec[3])]),rec[4]) for rec in local]
def pairs_by_target(per_surface):
 out={}
 for key,rec in per_surface.items():
  out[key]={tuple(map(int,p)) for p in rec["triangle_pairs"]}
 return out
def diff_pairs(before,after):
 added=[]; removed=[]
 for key in sorted(set(before)|set(after)):
  b=before.get(key,set()); a=after.get(key,set())
  added.extend((key,*x) for x in sorted(a-b))
  removed.extend((key,*x) for x in sorted(b-a))
 return added,removed
def signed_volumes(topology,points,faces):
 vals=[]
 for comp in topology["face_components"]:
  terms=[]
  for k in comp:
   a,b,c=(np.asarray(points[int(j)],dtype=np.float64) for j in faces[int(k)])
   terms.append(float(np.dot(a,np.cross(b,c)))/6.0)
  vals.append(float(sum(terms)))
 return vals
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 require(not (OUT/"result.json").exists() and not (OUT/"progress.jsonl").exists(),"attempt050 outputs already exist")
 input_paths={Path(p) for p in PINS}
 input_paths.update({Path(__file__),CANDIDATE_REPORT,INV})
 union_paths=[ROOT/f"attempt-003/stable-{sid}-exact-union.json" for sid in (29,30)]
 input_paths.update(union_paths)
 for arm in ARMS:
  for name in ["run-declaration.json","execution.json","native-run/run-metadata.json"]:
   input_paths.add(PAIR/arm/name)
  decl=json.loads((PAIR/arm/"run-declaration.json").read_text())
  exe=json.loads((PAIR/arm/"execution.json").read_text())
  meta=json.loads((PAIR/arm/"native-run/run-metadata.json").read_text())
  asset_pins=meta.get("asset_sha256",{})
  require(asset_pins.get(str(TISS))==PINS[str(TISS)] and asset_pins.get(str(MAN))==PINS[str(MAN)],"early native run did not bind its exact assembled TISS and manifest")
  require(exe.get("returncode")==0 and exe.get("changed_inputs")=={} and exe.get("native_argv_matches_prepared_cli_preview") is True and exe.get("native_environment_matches_prepared_cli_preview") is True,f"{arm} execution not closed/matched")
  require(meta.get("exit_code")==0 and meta.get("source_files_changed_during_run")==[],f"{arm} native metadata not successful/unchanged")
  require(sorted(map(int,decl["capture_steps"]))==STEPS,f"{arm} declaration capture steps differ")
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   pk=PAIR/arm/f"native-run/accepted-geometry/step-{step}.mrvpack"
   input_paths.update([rp,pk])
   require(rp.is_file() and pk.is_file(),f"missing accepted pose {arm}/{step}")
 before={str(p):sha(p) for p in sorted(input_paths)}
 for p,expected in PINS.items():require(before[str(p)]==expected,f"pinned input hash changed: {p}")
 candidate_report=json.loads(CANDIDATE_REPORT.read_text())
 require(candidate_report.get("immutable_inputs_unchanged") is True,f"attempt019 starting candidate did not close immutable")
 candidate_proposal_report=json.loads(CANDIDATE_PROPOSAL_REPORT.read_text())
 require(candidate_proposal_report.get("inputs_unchanged") is True and candidate_proposal_report.get("status")=="unadmitted_local_source_candidate_tracked_pairs_clear", "attempt034 local source proposal did not close its source gates")
 zbase={}; zcand={}; faces={}; local={}; weights={}; changed_vertices={}; changed_faces={}; candidate_motion={}
 anchors={}
 for sid in (29,30):
  b=np.load(BASELINE_CAND[sid],allow_pickle=False)
  c=np.load(CANDIDATE[sid],allow_pickle=False)
  zbase[sid]=np.asarray(b["vertices6"][:,:3],dtype="<f4")
  zcand[sid]=np.asarray(c["vertices6"][:,:3],dtype="<f4")
  faces[sid]=np.asarray(b["faces"],dtype=np.int64)
  require(np.array_equal(faces[sid],c["faces"]),f"candidate {sid} changed face connectivity")
  require(np.array_equal(b["binding_indices"],c["binding_indices"]) and np.array_equal(b["weights"],c["weights"]),f"candidate {sid} changed bindings/weights")
  local[sid]=np.asarray(b["binding_indices"],dtype="<u4"); weights[sid]=np.asarray(b["weights"],dtype="<f4")
  require(zbase[sid].shape==(1190,3) and faces[sid].shape==(2372,3),f"candidate {sid} geometry shape changed")
  changed_vertices[sid]=np.flatnonzero(np.any(zbase[sid]!=zcand[sid],axis=1))
  report_row=candidate_report["local_solver_and_exact_results"][str(sid)]
  candidate_motion[sid]=float(np.linalg.norm(zcand[sid].astype(np.float64)-zbase[sid].astype(np.float64),axis=1).max(initial=0.0))
  if sid==29:
   anchors[sid]=np.asarray(candidate_proposal_report["local_patch"]["preserved_anchor_vertex_ids"],dtype=np.int64)
   require(candidate_proposal_report["candidate"]["sha256"]==sha(CANDIDATE[sid]),"attempt034 candidate report does not bind stable29 payload")
   require(len(changed_vertices[sid])>0,"stable29 candidate has no changed vertices")
  else:
   anchors[sid]=np.asarray(report_row["pure_route_anchor_vertex_ids"],dtype=np.int64)
   require(len(changed_vertices[sid])==report_row["moved_vertex_count"]==22,f"row {sid} changed vertex count inconsistent")
  require(np.array_equal(zbase[sid][anchors[sid]],zcand[sid][anchors[sid]]),f"row {sid} moved preserved route anchors")
  changed_faces[sid]=np.flatnonzero(np.any(np.isin(faces[sid],changed_vertices[sid]),axis=1))
  require(len(changed_faces[sid])>0,f"row {sid} has no changed incident faces")
 target_keys,clearance_keys,expected_counts,pop=ca._load_target_inventory(INV)
 require(len(target_keys)==859 and len(clearance_keys)==842,f"target inventory changed")
 forward_ns=load_forward(); tissue=forward_ns["load_tissue"](TISS); forward=forward_ns["forward"]
 rows={sid:forward_ns["row_data"](tissue,sid) for sid in (29,30)}
 current_tissue=forward_ns["load_tissue"](CURRENT_TISS)
 current_rows={sid:forward_ns["row_data"](current_tissue,sid) for sid in (29,30)}
 row_identity={}
 for sid in (29,30):
  early,current=rows[sid],current_rows[sid]
  ok=(early["vertex_bytes"]==current["vertex_bytes"] and early["binding_bytes"]==current["binding_bytes"]
      and np.array_equal(early["faces"],current["faces"]) and np.array_equal(early["local"],current["local"])
      and np.array_equal(early["weights"],current["weights"]))
  require(ok,f"early composed source row {sid} differs from current source row")
  row_identity[str(sid)]={"exact_row_vertex_bytes":True,"exact_binding_bytes":True,"exact_faces":True,"exact_local_indices":True,"exact_weights":True,"vertex_count":early["vc"],"face_count":len(early["faces"]),"binding_count":early["bc"]}
 results=[]; total_added=0; total_removed=0; self_gate_failures=[]; mutual_gate_failures=[]; external_gate_failures=[]
 for arm in ARMS:
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   poses,pack=pose_map(rp,step)
   pack_positions,surfaces,pack_meta=ca._pack_surfaces(pack,target_keys|{(51005,29),(51005,30)})
   require(target_keys.issubset(surfaces),f"{arm}/{step} pack misses target surfaces")
   
   world_base={}; world_cand={}; self_base={}; self_cand={}; topology_rows={}
   for sid in (29,30):
    row=rows[sid]
    wb=forward(zbase[sid],local[sid],weights[sid],row,tissue,poses)
    wc=forward(zcand[sid],local[sid],weights[sid],row,tissue,poses)
    require(np.array_equal(wb[np.setdiff1d(np.arange(len(wb)),changed_vertices[sid])],wc[np.setdiff1d(np.arange(len(wc)),changed_vertices[sid])]),f"{arm}/{step}/{sid} unchanged source vertices changed world coordinates")
    ab,_=exact_audit(wb,faces[sid]); ac,_=exact_audit(wc,faces[sid])
    require(not ab["degenerate_faces"] and not ac["degenerate_faces"],f"{arm}/{step}/{sid} degenerate face")
    if ac["count"]!=0: self_gate_failures.append({"arm":arm,"step":step,"stable_id":sid,"pairs":ac["pairs"]})
    self_base[sid]=ab; self_cand[sid]=ac; world_base[sid]=wb; world_cand[sid]=wc
    top=analyze_topology(wc.astype(float).tolist(),faces[sid].tolist())
    src_top=analyze_topology(zcand[sid].astype(float).tolist(),faces[sid].tolist())
    require(top["closed_oriented_manifold_candidate"] and src_top["closed_oriented_manifold_candidate"],f"{arm}/{step}/{sid} candidate topology not closed/oriented")
    source_volumes=signed_volumes(src_top,zcand[sid],faces[sid])
    posed_volumes=signed_volumes(top,wc,faces[sid])
    orientation_ok=(len(source_volumes)==len(posed_volumes) and all(a*b>0 for a,b in zip(source_volumes,posed_volumes)))
    require(orientation_ok,f"{arm}/{step}/{sid} component signed-volume orientation changed")
    topology_rows[sid]={"candidate_components":len(top["face_components"]),"closed_oriented":top["closed_oriented_manifold_candidate"],"component_signed_volumes_m3":posed_volumes,"source_component_signed_volumes_m3":source_volumes,"component_orientation_preserved":orientation_ok}
   mutual_base=mutual_audit(world_base[29],faces[29],world_base[30],faces[30])
   mutual_cand=mutual_audit(world_cand[29],faces[29],world_cand[30],faces[30])
   require(mutual_base["pairs"] is not None and mutual_cand["pairs"] is not None,f"{arm}/{step} mutual exact audit degenerate")
   mutual_added,mutual_removed=diff_pairs({"all":{tuple(p) for p in mutual_base["pairs"]}},{"all":{tuple(p) for p in mutual_cand["pairs"]}})
   if mutual_added: mutual_gate_failures.append({"arm":arm,"step":step,"added_pairs":mutual_added})
   external_rows={}
   for sid in (29,30):
    # Exact target comparisons are limited to every face incident to a changed source vertex.
    old_records=changed_records(world_base[sid],faces[sid],changed_faces[sid])
    new_records=changed_records(world_cand[sid],faces[sid],changed_faces[sid])
    face_ids=changed_faces[sid]
    face_vertices=np.unique(faces[sid][face_ids])
    region_points=np.concatenate([world_base[sid][face_vertices],world_cand[sid][face_vertices]],axis=0)
    lo=region_points.min(axis=0); hi=region_points.max(axis=0)
    added=[]; removed=[]; old_total=0; new_total=0; target_scanned=0; interfaces=[]
    for key,target in sorted(surfaces.items()):
     if key==(51005,sid): continue
     target_scanned+=1
     tf=np.asarray(target["faces"],dtype=np.int64)
     tri=pack_positions[tf]
     select=np.flatnonzero(np.all(tri.max(axis=1)>=lo,axis=1)&np.all(tri.min(axis=1)<=hi,axis=1))
     if not len(select): continue
     selected_faces=tf[select]
     unique=np.unique(selected_faces)
     compact=np.searchsorted(unique,selected_faces)
     target_lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in p)) for p in pack_positions[unique]]
     target_records_local=ci._records(target_lattice,compact.tolist())
     target_records=[rec[:3]+(int(select[int(rec[3])]),rec[4]) for rec in target_records_local]
     before_audit=ci._audit_pair(old_records,target_records,same_surface=False)
     after_audit=ci._audit_pair(new_records,target_records,same_surface=False)
     before_pairs={tuple(map(int,p)) for p in before_audit["triangle_pairs"]}
     after_pairs={tuple(map(int,p)) for p in after_audit["triangle_pairs"]}
     old_total+=len(before_pairs); new_total+=len(after_pairs)
     add=sorted(after_pairs-before_pairs); rem=sorted(before_pairs-after_pairs)
     if add or rem:
      interfaces.append({"semantic":int(key[0]),"stable_id":int(key[1]),"body":int(target["body"]),
       "baseline_pairs":[list(x) for x in sorted(before_pairs)],"candidate_pairs":[list(x) for x in sorted(after_pairs)],
       "added_pairs":[list(x) for x in add],"removed_pairs":[list(x) for x in rem]})
     added.extend((int(key[0]),int(key[1]),x[0],x[1]) for x in add)
     removed.extend((int(key[0]),int(key[1]),x[0],x[1]) for x in rem)
    require(target_scanned==859,f"{arm}/{step}/{sid} external target coverage not859: {target_scanned}")
    if added: external_gate_failures.append({"arm":arm,"step":step,"stable_id":sid,"added_pairs":added})
    total_added+=len(added); total_removed+=len(removed)
    external_rows[str(sid)]={"changed_vertex_count":len(changed_vertices[sid]),"changed_face_count":len(face_ids),
      "target_surface_count":target_scanned,"changed_region_baseline_pair_count":old_total,
      "changed_region_candidate_pair_count":new_total,"added_pair_count":len(added),"removed_pair_count":len(removed),
      "interfaces_with_pair_changes":interfaces,"exact_external_target_coverage":True}
   row_result={"arm":arm,"accepted_step":step,"receipt_sha256":sha(rp),"pack_sha256":sha(pack),
     "self_pairs_before":{str(s):self_base[s]["count"] for s in (29,30)},"self_pairs_candidate":{str(s):self_cand[s]["count"] for s in (29,30)},
     "candidate_topology":topology_rows,"row29_30_mutual_before_count":mutual_base["count"],"row29_30_mutual_candidate_count":mutual_cand["count"],
     "row29_30_mutual_added_count":len(mutual_added),"row29_30_mutual_removed_count":len(mutual_removed),"row29_30_mutual_removed_pairs":mutual_removed,
     "external_changed_region":external_rows}
   results.append(row_result)
   progress("accepted_pose_audit_complete",arm=arm,step=step,self_pairs=row_result["self_pairs_candidate"],
      mutual_before=mutual_base["count"],mutual_after=mutual_cand["count"],
      external_added={sid:x["added_pair_count"] for sid,x in external_rows.items()},
      external_removed={sid:x["removed_pair_count"] for sid,x in external_rows.items()})
 after={str(p):sha(p) for p in sorted(input_paths)}
 require(before==after,"one or more source/owner/receipt/pack inputs changed during pose audit")
 report={"schema":"numi.human.gluteus-maximus-femur-clearance-early-eight-pose-audit-050.v1",
  "status":"unadmitted_candidate_passed_all_gates" if not self_gate_failures and not mutual_gate_failures and not external_gate_failures else "unadmitted_candidate_failed_one_or_more_16pose_gates",
  "scope":"Stable29/30 local source-position reference reconstruction only. Full exact self and topology checks at eight early accepted poses from the seventeen-surface composition002 baseline; complete changed-face external comparison against all859 target surfaces, plus bilateral mutual pair nonregression. Candidate rows are predicted using all157 accepted body poses; source row bytes/maps are cross-checked exactly against current TISS. Offline prediction, not native candidate composition or whole-body anatomy admission.",
  "source_semantics":"The local offsets are explicit inferred reference corrections, not measured tissue dimensions. Source-row lineage comes from current TISS; early native run used the separately pinned composition002 TISS whose row29/30 vertex, binding, face, local-index, and weight bytes match exactly. The source offsets remain unadmitted inferred geometry; all157 accepted body poses are used in the offline mapping.",
  "candidate_source_motion_max_vertex_l2_from_raw_union_mm":{str(s):candidate_motion[s] for s in (29,30)},
  "candidate_starting_019_source_motion_max_vertex_l2_mm":candidate_report["local_solver_and_exact_results"]["29"]["max_source_vertex_l2_motion_mm"],
  "attempt034_additional_source_increment_max_vertex_l2_mm":candidate_proposal_report["solver"]["max_source_increment_l2_mm"],
  "candidate_parent_result_sha256":sha(CANDIDATE_PROPOSAL_REPORT),
  "candidate_starting_self_clear_parent_result_sha256":"079a5af99e3aa6523b1508101c50998432b15d40905c9d415f0d796c7251c355",
  "starting_local_motion_bound_mm":0.25,"additional_local_vertex_l2_bound_mm":1.0,
  "candidate_npy_sha256":{str(s):sha(CANDIDATE[s]) for s in (29,30)},
  "target_inventory":{"path":str(INV),"sha256":sha(INV),"target_surface_count":len(target_keys),"clearance_surface_count":len(clearance_keys),"populations":pop},
  "unchanged_face_world_identity_checked":True,"preserved_anchor_vertices_bitwise":{str(s):anchors[s].tolist() for s in (29,30)},
  "source_owner_and_pose_pins_before":before,"source_owner_and_pose_pins_after":after,"inputs_unchanged":before==after,"exact_row_identity_to_current_source":row_identity,
  "all_pose_results":results,"external_changed_region_total_added_pairs":total_added,"external_changed_region_total_removed_pairs":total_removed,
  "self_gate_failures":self_gate_failures,"mutual_gate_failures":mutual_gate_failures,"external_gate_failures":external_gate_failures,
  "limitations":["Target checks compare only faces incident to changed source vertices, which is complete for new intersections caused by this candidate because all other source and forwarded face vertices are bit-identical to the baseline union candidate.","The inherited union baseline may have existing self or cross-surface pairs; only candidate self-zero and no-added bilateral/external pair identities are required here. Removed pair identities are reported.","These are CPU forward predictions from the existing row owner. Native current-build export and final composed-scene checks remain required; no whole-body qualification is implied."],
  "elapsed_s":time.monotonic()-START}
 out=OUT/"result.json"; out.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":report["status"],"report":str(out),"sha256":sha(out),"pose_count":len(results),"added_external":total_added,"removed_external":total_removed,"elapsed_s":report["elapsed_s"]},sort_keys=True),flush=True)
if __name__=="__main__":
 try:
  signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError("early 8-pose candidate audit exceeded 1800s")))
  signal.alarm(1800); main()
 except Exception as exc:
  OUT.mkdir(parents=True,exist_ok=True)
  failure={"schema":"numi.human.gluteus-maximus-local-offset-16pose-audit-028.failure.v1","status":"failed_or_blocked","error_type":type(exc).__name__,"error":str(exc),"traceback":traceback.format_exc(),"elapsed_s":time.monotonic()-START}
  fp=OUT/"failure.json"; fp.write_text(json.dumps(failure,indent=2,sort_keys=True)+"\n")
  print(json.dumps({"status":failure["status"],"failure":str(fp),"sha256":sha(fp),"error":str(exc)},sort_keys=True),flush=True)
  raise
 finally:
  signal.alarm(0)
