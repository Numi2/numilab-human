from __future__ import annotations
import ast, hashlib, importlib.util, json, signal, sys, time, traceback
from pathlib import Path
import numpy as np

R=Path("/Users/n/numi-human-retained-delivery-20261009")
ROOT=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001"
OUT=ROOT/"attempt-034"
TISS=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
MAN=TISS.with_suffix(".manifest.json")
PAIR=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
INV=Path("/Users/n/numi-human-resting-evidence-20261005/native-complete-skin-containment-audit-890/pair-summary-v3.csv")
ATTEMPT010=ROOT/"attempt-010/run_gluteus_union_010.py"
PARENT_SMALL=ROOT/"attempt-019/solve_terminal_self_pairs_019.py"
PARENT_AUDIT=ROOT/"attempt-028/audit_gluteus_local_offset_028.py"
FORWARD=R/"signed-winding-self-union-1273/subscap-pilot-001/full-attribute-lift-007/run_offline_attribute_lift_pose_audit_007.py"
OWNER=Path("/Users/n/numi-human-self-separation-partial-resume-1267/src")
SIGNED=Path("/Users/n/numi-human-signed-winding-1273/src")
STEPS=(151999,152607,153215,153823,154431,155000)
ARMS=("baseline","intervention")
TARGET_KEY=(51004,2)
TARGET_BODY=131
SOURCE_ROW=29
MAX_ADDED_L2_MM=1.0
sys.path[:0]=[str(OWNER),str(SIGNED)]
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_intersections as ci

PINS={
 str(TISS):"6579d06d358bfcf51f964feb57425fe568c467fd361930bce46d376ec8aedaa4",
 str(MAN):"80d775bef6b8a4108e159fb7882a84b2fb8dce5b492059cd8c7cf3644a137467",
 str(INV):"a43484aa8d65b207cc498bb470097ec5f06ef2bb9872837bde9f197e19e815e3",
 str(ATTEMPT010):"3343c53df203e43d30d778b2f6178295ce250c1519326db55e97c5118e44fcd4",
 str(PARENT_SMALL):"f903fd518bbad959cb6de4c0cf9ba4f6816667f7451613265ec8ad172e16d02e",
 str(PARENT_AUDIT):"68b5e8848f691594234d553753808bee80ebbcbbb11b958bfa4edc45d27b89f4",
 str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"):"6af6d36091228465a76f12764c6c82c6ad844f704ffcbea81f7545e57f467a03",
 str(ROOT/"attempt-019/stable-29-unadmitted-local-offset-candidate.npz"):"828f05a830d50ee699ba6f23731351ff380e469e88f3d0365bdcc1384c50debd",
 str(ROOT/"attempt-019/result.json"):"079a5af99e3aa6523b1508101c50998432b15d40905c9d415f0d796c7251c355",
 str(ROOT/"attempt-028/result.json"):"0dad1dbe35688ddfc9cd2a89a283869f27487bc35053bdabcd3140e99812a8db",
 str(OWNER/"numilab_human/cardiac_cavity_geometry.py"):"f6e98744dad9e23cd3b505efc02e7faa618fccce81d2ee08b07f948ef182fb72",
 str(OWNER/"numilab_human/cardiac_cavity_intersections.py"):"423180082e32d002375b612aad36f307ed439af07c04d655e6a8bedc87a338bd",
 str(OWNER/"numilab_human/common_atlas_skin_clearance.py"):"151ba8925910ae164bdf9a41417ca2cc5c63b07c3b05eb09496d20c4771c5e9b",
 str(FORWARD):"e78fe261b2f625de51378c34d238b6716ac38bf2eb667824d669cdd2bda6ad47",
}
START=time.monotonic()

def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""): h.update(b)
 return h.hexdigest()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def emit(event,**kw):
 row={"event":event,"elapsed_s":time.monotonic()-START,**kw}
 with (OUT/"progress.jsonl").open("a") as f: f.write(json.dumps(row,sort_keys=True,separators=(",",":"))+"\n")
 print(json.dumps(row,sort_keys=True),flush=True)
def load_forward():
 tree=ast.parse(FORWARD.read_text()); ns={"np":np,"Path":Path,"struct":__import__("struct")}
 wanted={"need","load_tissue","row_data","f32","cross32","rotate32","forward"}
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name in wanted:
   exec(compile(ast.Module(body=[node],type_ignores=[]),str(FORWARD),"exec"),ns)
 return ns
def exact_tri_intersects(a,b):
 aa=tuple(ci.float32_point_lattice_key(tuple(float(v) for v in p)) for p in np.asarray(a,dtype="<f4"))
 bb=tuple(ci.float32_point_lattice_key(tuple(float(v) for v in p)) for p in np.asarray(b,dtype="<f4"))
 return bool(ci.triangle_intersection_points(aa,bb))
def exact_self(points,faces):
 p=np.asarray(points,dtype="<f4"); f=np.asarray(faces,dtype=np.int64)
 uq,inv=np.unique(p,axis=0,return_inverse=True); qf=inv[f]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in row)) for row in uq]
 deg=[]
 for i,t in enumerate(qf):
  n=ci._cross(ci._sub(lattice[int(t[1])],lattice[int(t[0])]),ci._sub(lattice[int(t[2])],lattice[int(t[0])]))
  if not any(n): deg.append(int(i))
 if deg:return {"count":None,"pairs":None,"degenerate_faces":deg}
 rec=ci._records(lattice,qf.tolist())
 result=ci._audit_pair(rec,rec,same_surface=True)
 return {"count":int(result["count"]),"pairs":result["triangle_pairs"],"degenerate_faces":[]}
def load_pose(receipt,step):
 d=json.loads(receipt.read_text())
 require(d.get("accepted_step")==step and d.get("physical_endpoint")=="accepted",f"unaccepted endpoint {receipt}")
 pack=receipt.with_name(receipt.name.replace(".receipt.json",".mrvpack"))
 require(d.get("pack_file_sha256")==sha(pack),f"receipt does not bind pack {pack}")
 poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype="<f4"),np.asarray(x["quaternion_xyzw"],dtype="<f4")) for x in d["accepted_registered_body_poses"]}
 return poses,pack
def oriented_cyclic(t):
 t=tuple(map(int,t))
 return min(t, t[1:]+t[:1], t[2:]+t[:2])
def quat_rotation(q):
 x,y,z,w=map(float,np.asarray(q,dtype=np.float32))
 return np.asarray([[1.0-2.0*(y*y+z*z),2.0*(x*y-w*z),2.0*(x*z+y*w)],
                    [2.0*(x*y+z*w),1.0-2.0*(x*x+z*z),2.0*(y*z-x*w)],
                    [2.0*(x*z-y*w),2.0*(y*z+x*w),1.0-2.0*(x*x+y*y)]],dtype=np.float64)
def pose_jacobians(points,local,weights,row,tissue,poses):
 out=np.zeros((len(points),3,3),dtype=np.float64)
 for vi in range(len(points)):
  for slot in range(4):
   w=np.float32(weights[vi,slot])
   if w<=np.float32(2e-6): continue
   li=int(local[vi,slot])
   require(li<row["bc"],"active candidate route index outside binding table")
   bind=tissue["bindings"][row["fb"]+li]
   core=int(bind["core"]); val=bind["value"]
   require(core in poses,f"missing pose for body {core}")
   body_rot=quat_rotation(poses[core][1]); local_rot=quat_rotation(val[3:7]); scale=float(np.float32(val[7]))
   out[vi]+=float(w)*body_rot@(scale*local_rot)
 return out
def main():
 OUT.mkdir(parents=True,exist_ok=True)
 require(not (OUT/"result.json").exists() and not (OUT/"progress.jsonl").exists(),"attempt034 outputs already exist")
 parent=json.loads((ROOT/"attempt-028/result.json").read_text())
 require(parent.get("inputs_unchanged") is True and parent.get("status")=="unadmitted_candidate_failed_one_or_more_16pose_gates","attempt028 parent not closed as expected")
 target_pairs_by_pose={}
 for row in parent["external_gate_failures"]:
  if int(row["stable_id"])!=SOURCE_ROW: continue
  require(row.get("arm") in ARMS and int(row["step"]) in STEPS,"unexpected parent pair pose")
  vals=[]
  for x in row["added_pairs"]:
   sem,tid,sf,tf=map(int,x)
   require((sem,tid)==TARGET_KEY,"unexpected target interface in repair scope")
   vals.append((sf,tf))
  target_pairs_by_pose[(row["arm"],int(row["step"]))]=sorted(set(vals))
 require(len(target_pairs_by_pose)==12,"expected exact 12 pose-local changed-pair rows")
 all_pairs=sorted({x for vals in target_pairs_by_pose.values() for x in vals})
 require(all_pairs==[(336,437),(461,404),(461,406),(461,408),(463,434)],f"unexpected target pair set {all_pairs}")
 before_paths=[Path(p) for p in PINS]
 for arm in ARMS:
  before_paths += [PAIR/arm/"run-declaration.json",PAIR/arm/"execution.json",PAIR/arm/"native-run/run-metadata.json"]
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   before_paths += [rp,rp.with_name(rp.name.replace(".receipt.json",".mrvpack"))]
 pins_before={str(p):sha(p) for p in [Path(__file__),*before_paths]}
 for p,expected in PINS.items(): require(pins_before[p]==expected,f"pinned input changed: {p}")
 for arm in ARMS:
  ex=json.loads((PAIR/arm/"execution.json").read_text())
  meta=json.loads((PAIR/arm/"native-run/run-metadata.json").read_text())
  require(ex.get("returncode")==0 and ex.get("changed_inputs")=={} and ex.get("native_argv_matches_prepared_cli_preview") is True and ex.get("native_environment_matches_prepared_cli_preview") is True,f"{arm} pair arm not closed")
  require(meta.get("exit_code")==0 and meta.get("source_files_changed_during_run")==[],f"{arm} native metadata failed")
 emit("pinned_inputs_verified",files=len(pins_before),pose_pair_rows=sum(map(len,target_pairs_by_pose.values())),unique_pairs=all_pairs)
 # The two row patches retain identical topology and weights; only source xyz/normals differ.
 union_npz=np.load(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz",allow_pickle=False)
 small_npz=np.load(ROOT/"attempt-019/stable-29-unadmitted-local-offset-candidate.npz",allow_pickle=False)
 union=np.ascontiguousarray(union_npz["vertices6"][:,:3],dtype="<f4")
 small=np.ascontiguousarray(small_npz["vertices6"][:,:3],dtype="<f4")
 faces=np.asarray(union_npz["faces"],dtype=np.int64)
 local=np.asarray(union_npz["binding_indices"],dtype="<u4")
 weights=np.asarray(union_npz["weights"],dtype="<f4")
 require(faces.shape==(2372,3) and union.shape==small.shape==(1190,3),"source row shape changed")
 require(np.array_equal(faces,small_npz["faces"]),"source faces changed between raw union and small self-clear candidate")
 require(np.array_equal(local,small_npz["binding_indices"]) and np.array_equal(weights,small_npz["weights"]),"source maps changed between raw union and candidate")
 face_motion={}
 for sf in sorted({x[0] for x in all_pairs}):
  tri=faces[sf]
  require(oriented_cyclic(tri)==oriented_cyclic(small_npz["faces"][sf]),f"source face {sf} is not cyclically identical")
  require(np.array_equal(local[tri],small_npz["binding_indices"][tri]) and np.array_equal(weights[tri],small_npz["weights"][tri]),f"source face {sf} binding map changed")
  delta=np.linalg.norm(small[tri].astype(np.float64)-union[tri].astype(np.float64),axis=1)*1000.0
  face_motion[str(sf)]={"oriented_cyclic_connectivity_same":True,"weights_and_binding_indices_same":True,"vertex_ids":tri.tolist(),"vertex_displacement_mm":delta.tolist(),"max_vertex_displacement_mm":float(delta.max())}
 require(max(x["max_vertex_displacement_mm"] for x in face_motion.values())>0.0,"all affected rows are unchanged; likely metadata-only pair artifact")
 # Load exact shared owner forwarding and source row bindings.
 fwd=load_forward(); tissue=fwd["load_tissue"](TISS); row=fwd["row_data"](tissue,SOURCE_ROW); forward=fwd["forward"]
 # Pure-route anchors are inherited exactly from the self-clear candidate report.
 small_report=json.loads((ROOT/"attempt-019/result.json").read_text())
 anchors=np.asarray(small_report["local_solver_and_exact_results"][str(SOURCE_ROW)]["pure_route_anchor_vertex_ids"],dtype=np.int64)
 require(len(anchors)>0 and np.array_equal(union[anchors],small[anchors]),"small self-clear start moved preserved pure-route anchors")
 # Build only the five oriented local femur triangles used by the exact changed-pair report.
 target_face_ids=sorted({tf for _,tf in all_pairs})
 target_face_row={tf:i for i,tf in enumerate(target_face_ids)}
 samples=[]
 baseline_pair_checks=[]
 for arm in ARMS:
  for step in STEPS:
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   poses,pack=load_pose(rp,step)
   pack_positions,surfaces,_=ca._pack_surfaces(pack,{TARGET_KEY})
   require(TARGET_KEY in surfaces and int(surfaces[TARGET_KEY]["body"])==TARGET_BODY,f"wrong target identity in {arm}/{step}")
   target_faces=np.asarray(surfaces[TARGET_KEY]["faces"],dtype=np.int64)
   require(target_faces.ndim==2 and target_faces.shape[1]==3 and min(target_face_ids)>=0 and max(target_face_ids)<len(target_faces),"femur face row outside target")
   selected=target_faces[target_face_ids]
   target_vertex_mesh_ids=np.unique(selected.reshape(-1))
   target_vertex_local=np.searchsorted(target_vertex_mesh_ids,selected)
   combined_faces=np.concatenate([faces, target_vertex_local.astype(np.int64)+len(union)],axis=0)
   appended_target_ids=np.arange(len(union),len(union)+len(target_vertex_mesh_ids),dtype=np.int64)
   target_xyz=np.ascontiguousarray(pack_positions[target_vertex_mesh_ids],dtype="<f4")
   world_union=forward(union,local,weights,row,tissue,poses)
   world_small=forward(small,local,weights,row,tissue,poses)
   baseline_world=np.concatenate([world_union,target_xyz],axis=0).astype("<f4")
   rejected_world=np.concatenate([world_small,target_xyz],axis=0).astype("<f4")
   jac=np.zeros((len(baseline_world),3,3),dtype=np.float64)
   jac[:len(union)]=pose_jacobians(small,local,weights,row,tissue,poses)
   pose_pairs=[]
   for sf,tf in target_pairs_by_pose[(arm,step)]:
    source_tri=faces[sf]
    target_tri=pack_positions[target_faces[tf]]
    base_hit=exact_tri_intersects(world_union[source_tri],target_tri)
    rejected_hit=exact_tri_intersects(world_small[source_tri],target_tri)
    require(not base_hit and rejected_hit,f"pair is not an exact raw-union-clear to current-candidate-hit transition at {arm}/{step} pair {sf}/{tf}: base={base_hit},current={rejected_hit}")
    combined_target_face=len(faces)+target_face_row[tf]
    require(sf<combined_target_face,"pair face-row ordering must be canonical lower-first")
    pose_pairs.append((sf,combined_target_face))
    baseline_pair_checks.append({"arm":arm,"step":step,"source_face":sf,"femur_face":tf,"baseline_clear":True,"candidate_intersects":True})
   pose_pairs=np.asarray(sorted(set(pose_pairs)),dtype=np.int64)
   require(len(pose_pairs)==len(target_pairs_by_pose[(arm,step)]),"local SAT row mapping lost duplicate or pair")
   samples.append({"vertex_ids":np.arange(len(baseline_world),dtype=np.int64),
                   "baseline_world_positions":baseline_world,
                   "rejected_world_positions":rejected_world,
                   "jacobians":jac,
                   "self_pair_rows":pose_pairs})
   emit("exact_local_pair_precheck",arm=arm,step=step,pairs=len(pose_pairs),target_faces=target_face_ids)
 # Combined local geometric table is the gluteus source mesh plus five actual oriented femur triangles.
 fixed_target=np.arange(len(union),len(union)+len(target_vertex_mesh_ids),dtype=np.int64)
 combined_source=np.concatenate([small,np.zeros((len(target_vertex_mesh_ids),3),dtype="<f4")],axis=0)
 seed=np.unique(faces[np.asarray(sorted({sf for sf,_ in all_pairs}),dtype=np.int64)].reshape(-1)).astype(np.int64)
 neighbors={int(v):set() for v in range(len(union))}
 for tri in faces:
  tv=list(map(int,tri))
  for v in tv: neighbors[v].update(tv)
 movable_set=set(map(int,seed))
 for v in seed: movable_set.update(neighbors[int(v)])
 movable=np.asarray(sorted(movable_set-set(map(int,anchors))),dtype=np.int64)
 require(np.all(np.isin(seed,movable)),"self-clear seeds overlap fixed pure-route anchors")
 require(len(movable)<=256,f"one-ring local patch exceeds owner bound: {len(movable)}")
 allfaces=np.concatenate([faces,combined_faces[len(faces):]],axis=0)
 emit("local_qp_start",moved_pair_pose_rows=sum(map(len,target_pairs_by_pose.values())),unique_pairs=all_pairs,seed_vertices=seed.tolist(),movable_vertices=len(movable),pure_route_anchors=len(anchors),target_vertices=len(fixed_target),target_face_rows=target_face_ids)
 proposal=ca._propose_local_self_separation_increment(
     source_positions_m=combined_source,faces=allfaces,movable_vertex_ids=movable,
     self_patch_seed_vertex_ids=seed,required_target_seed_vertex_ids=np.asarray([],dtype=np.int64),
     active_target_face_vertex_ids=fixed_target,fixed_support_vertex_ids=anchors,preserved_anchor_vertex_ids=anchors,
     pose_samples=samples)
 proposed=np.asarray(proposal["proposal_source_positions_m_f32"][:len(union)],dtype="<f4")
 extra=(proposed.astype(np.float64)-small.astype(np.float64))*1000.0
 cum=(proposed.astype(np.float64)-union.astype(np.float64))*1000.0
 max_extra_l2=float(np.linalg.norm(extra,axis=1).max(initial=0))
 max_cum_l2=float(np.linalg.norm(cum,axis=1).max(initial=0))
 require(proposed[anchors].tobytes()==small[anchors].tobytes(),"source QP moved a preserved pure-route anchor")
 outside=np.setdiff1d(np.arange(len(union),dtype=np.int64),movable,assume_unique=True)
 require(proposed[outside].tobytes()==small[outside].tobytes(),"source QP changed vertices outside its one-ring support")
 source_gate=exact_self(proposed,faces)
 require(source_gate["degenerate_faces"]==[] and source_gate["count"]==0,f"repaired source has self/degenerate failures: {source_gate}")
 # Recheck every actually used local femur pair after actual nonlinear forward; do not treat linear SAT as admission.
 exact_after=[]
 for i,sample in enumerate(samples):
  arm=ARMS[i//len(STEPS)]; step=STEPS[i%len(STEPS)]
  poses,_=load_pose(PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json",step)
  target_xyz=sample["rejected_world_positions"][len(union):]
  world=forward(proposed,local,weights,row,tissue,poses)
  for sf,tf in target_pairs_by_pose[(arm,step)]:
   target_tri_row=target_face_row[tf]
   target_vertex_local=target_faces if False else None
   # Face rows are represented by the fixed appended vertices used in this sample.
   sample_face=sample["self_pair_rows"][list(map(tuple,sample["self_pair_rows"])).index((sf,len(faces)+target_face_row[tf]))]
   combined_tri=allfaces[int(sample_face[1])]
   tri_target=target_xyz[combined_tri-len(union)]
   hit=exact_tri_intersects(world[faces[sf]],tri_target)
   exact_after.append({"arm":arm,"step":step,"source_face":sf,"femur_face":tf,"intersects_after_actual_forward":hit})
 # Verify all pose windows and their required pairs were constrained; exact after is diagnostic before full16/859 gate.
 require(len(exact_after)==sum(map(len,target_pairs_by_pose.values())),"missing actual-forward local-pair postchecks")
 emit("source_and_local_forward_postcheck",source_self_pairs=source_gate["count"],source_degenerate_faces=0,max_increment_l2_mm=max_extra_l2,max_cumulative_from_union_l2_mm=max_cum_l2,local_remaining_pairs=sum(x["intersects_after_actual_forward"] for x in exact_after))
 # Import the same geometry utility used by the parent attempt for normals, no asset edits.
 spec=importlib.util.spec_from_file_location("gluteus_attempt010",ATTEMPT010)
 m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
 from numilab_human.cardiac_cavity_geometry import analyze_topology
 m.analyze_topology=analyze_topology
 topology=m.analyze_topology(proposed.astype(float).tolist(),faces.tolist())
 require(topology["closed_oriented_manifold_candidate"],"source correction broke closed oriented topology")
 old_top=m.analyze_topology(small.astype(float).tolist(),faces.tolist())
 def signed_vols(top,xyz):
  out=[]
  for comp in top["face_components"]:
   vals=[]
   for k in comp:
    a,b,c=(np.asarray(xyz[int(j)],dtype=np.float64) for j in faces[int(k)])
    vals.append(float(np.dot(a,np.cross(b,c)))/6.0)
   out.append(float(sum(vals)))
  return out
 old_vol=signed_vols(old_top,small); new_vol=signed_vols(topology,proposed)
 require(len(old_vol)==len(new_vol) and all(a*b>0 for a,b in zip(old_vol,new_vol)),"source component orientation changed")
 outnpz=OUT/"stable-29-unadmitted-femur-clearance-candidate.npz"
 out_vertices6=np.concatenate([proposed,m.vertex_normals(proposed,faces)],axis=1).astype("<f4")
 np.savez(outnpz,vertices6=out_vertices6,binding_indices=local,weights=weights,faces=faces.astype("<u4"))
 pins_after={str(p):sha(p) for p in [Path(__file__),*before_paths]}
 require(pins_before==pins_after,"an input changed during local source solve")
 report={
  "schema":"numi.human.gluteus-maximus-local-femur-clearance-032.v1",
  "status":"unadmitted_local_source_candidate_exact_source_gates_passed",
  "scope":"Stable row29 gluteus maximus only. Existing local source-position/Jacobian SAT QP constrains only exact new candidate-vs-femur pair rows. Open femur is used as an oriented local target patch; no global inside/outside or bone-volume claim.",
  "inputs_before":pins_before,"inputs_after":pins_after,"inputs_unchanged":pins_before==pins_after,
  "candidate_start":{"path":str(ROOT/"attempt-019/stable-29-unadmitted-local-offset-candidate.npz"),"sha256":PINS[str(ROOT/"attempt-019/stable-29-unadmitted-local-offset-candidate.npz")],"prior_source_motion_bound_mm":0.25},
  "raw_union_reference":{"path":str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"),"sha256":PINS[str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz")],"role":"local pair-clearance reference only; original source union is not an admitted whole-body baseline"},
  "target_identity":{"inventory_key":list(TARGET_KEY),"body_index":TARGET_BODY,"actual_oriented_femur_face_rows":target_face_ids,"pose_rows":12,"exact_target_pair_rows":sum(map(len,target_pairs_by_pose.values())),"unique_source_femur_pairs":[list(x) for x in all_pairs],"baseline_clear_current_candidate_intersects_checks":baseline_pair_checks},
  "triangle_identity_check":{"source_faces":face_motion,"cyclic_oriented_face_identity_used":True,"binding_indices_and_weights_identical":True},
  "local_patch":{"source_seed_vertex_ids":seed.tolist(),"movable_vertex_ids":movable.tolist(),"preserved_anchor_vertex_ids":anchors.tolist(),"fixed_femur_target_vertex_ids":fixed_target.tolist(),"movable_vertex_count":len(movable),"femur_target_vertex_count":len(fixed_target),"qp_max_increment_l2_bound_mm":MAX_ADDED_L2_MM},
  "solver":{"status":proposal["status"],"constraint_rows_by_pose":proposal["constraint_rows_by_pose"],"pair_pose_receipts":proposal["pair_pose_receipts"],"max_source_increment_l2_mm":proposal["float32_max_vertex_l2_increment_mm"],"source_max_from_raw_union_l2_mm":max_cum_l2,"component_orientation_preserved":True,"source_exact_self":source_gate,"local_exact_actual_forward_pair_recheck":exact_after,"local_exact_actual_forward_remaining_count":sum(x["intersects_after_actual_forward"] for x in exact_after),"full_16_pose_859_target_gate":"not run by this proposal step"},
  "candidate":{"path":str(outnpz),"sha256":sha(outnpz),"source_faces_unchanged":True,"binding_indices_unchanged":True,"weights_unchanged":True,"preserved_anchors_bitwise":True,"outside_one_ring_bitwise":True,"topology_closed_oriented":True,"source_area_ratio_vs_start":float(m.area(proposed,faces)/m.area(small,faces)),"component_signed_volumes_start_m3":old_vol,"component_signed_volumes_candidate_m3":new_vol},
  "limitations":["The helper preserves local SAT gaps measured in the exact raw-union predicted forward world for supplied pairs only; its own forward is linearized. The following actual-forward checks are limited to these pair rows.","This is an inferred reference-geometry proposal, not a measured anatomy update or native candidate pass.","A subsequent exact all16-pose source self/topology and all859-target changed-face audit is mandatory; no composition or admission is performed."],
  "wall_seconds":time.monotonic()-START
 }
 out=OUT/"result.json"; out.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":report["status"],"candidate":str(outnpz),"candidate_sha256":report["candidate"]["sha256"],"report":str(out),"report_sha256":sha(out),"local_remaining":report["solver"]["local_exact_actual_forward_remaining_count"],"wall_seconds":report["wall_seconds"]},sort_keys=True),flush=True)

if __name__=="__main__":
 try:
  signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError("attempt034 exceeded 900 s")))
  signal.alarm(900); main()
 except Exception as exc:
  OUT.mkdir(parents=True,exist_ok=True)
  failure={"schema":"numi.human.gluteus-maximus-local-femur-clearance-032.failure.v1","status":"failed_or_rejected_local_candidate","error_type":type(exc).__name__,"error":str(exc),"traceback":traceback.format_exc(),"pinned_hashes_at_failure":{p:sha(p) for p in PINS if Path(p).is_file()},"wall_seconds":time.monotonic()-START}
  fp=OUT/"failure.json";fp.write_text(json.dumps(failure,indent=2,sort_keys=True)+"\n")
  print(json.dumps({"status":failure["status"],"failure":str(fp),"sha256":sha(fp),"error":str(exc)},sort_keys=True),flush=True)
  raise
 finally:
  signal.alarm(0)

