from pathlib import Path
import sys,json,hashlib,importlib.util
import numpy as np
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");D=A.parent/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001";O=A/"gluteus-native-ready-001";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-positive-winding-1279/src")
from numilab_human import cardiac_cavity_intersections as ci
from numilab_human.cardiac_cavity_geometry import analyze_topology
from numilab_human.resting_anatomy_interface_patch import signed_volume
H=D/"attempt-010/run_gluteus_union_010.py";sp=importlib.util.spec_from_file_location("h",H);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [Path(__file__),H,h.TISS,h.MAN,Path(ci.__file__)]}
for a,expected,n in [(49,"0860a1a48801d82d07e1a0e0db9d978c24b4476a389a903818e003014ad23f9f",16),(50,"ccc71a82eb56ce2b3344be8a1d68ebf33a14387afdf643db04675a9b801e5246",8)]:
 p=D/f"attempt-{a:03d}/result.json";pins[str(p)]=sha(p);assert pins[str(p)]==expected
 r=json.loads(p.read_text());assert r["inputs_unchanged"] and r["status"]=="unadmitted_candidate_passed_all_gates"
 assert len(r["all_pose_results"])==n and r["external_changed_region_total_added_pairs"]==r["external_changed_region_total_removed_pairs"]==0
 assert not r["external_gate_failures"] and not r["self_gate_failures"] and not r["mutual_gate_failures"]
t=h.load_tissue(h.TISS);geometry={"manifest_rows":{int(x["stable_id"]):x for x in json.loads(h.MAN.read_text())["source"]["surfaces"]},"analyze_topology":analyze_topology}
h.OUT=O/"raw-union-replay";h.OUT.mkdir()
out={"scope":"Existing gluteal source union replay plus explicit bounded local reference offsets. Canonical maps, topology and pure-weight attachment proxies preserved; 16 late and 8 early exact audits passed, native admission still required.","pins":pins,"rows":[],"complete":False}
def save():(O/"report.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
for sid,attempt,file,expected,limit in [(29,48,"stable-29-unadmitted-femur-clearance-candidate.npz","835ee62f40dbbad0a0b30833583fac07825787dc603c39007d46f11776dc6790",.0003),(30,19,"stable-30-unadmitted-local-offset-candidate.npz","9a87f13548e5d6b62ce8bd19829b0c433b9203ebfa8fdbf8f66ca065445eca3d",.00025)]:
 p=D/f"attempt-{attempt:03d}"/file;rp=p.parent/"result.json";up=D/f"attempt-003/stable-{sid}-exact-union.json"
 for x in [p,rp,up]:pins[str(x)]=sha(x)
 assert sha(p)==expected
 z=np.load(p);row=h.row_data(t,sid);raw=h.make_candidate(sid,t,row,json.loads(up.read_text()),ci,geometry)
 for key,original in [("faces",raw["faces"]),("binding_indices",raw["local"]),("weights",raw["weights"])]:assert np.array_equal(z[key],original)
 delta=np.linalg.norm(z["vertices6"][:,:3].astype(float)-raw["positions"].astype(float),axis=1);assert delta.max()<=limit
 used=np.unique(row["faces"]);pure=used[row["weights"][used].max(1)>=.999999];missing=[]
 for j in pure:
  matches=np.flatnonzero(np.all(z["vertices6"][:,:3]==row["positions"][j],axis=1))
  if not any(np.array_equal(z["binding_indices"][i],row["local"][j]) and np.array_equal(z["weights"][i],row["weights"][j]) for i in matches):missing.append(int(j))
 assert not missing
 records,deg=h.exact_rows(z["vertices6"][:,:3],z["faces"],ci);audit=ci._audit_pair(records,records,same_surface=True);top=analyze_topology(z["vertices6"][:,:3].astype(float).tolist(),z["faces"].tolist())
 assert audit["count"]==0 and not deg and top["closed_oriented_manifold_candidate"]
 target=O/f"stable-{sid}-reference-row-patch.npz";np.savez(target,**{k:z[k] for k in z.files},face_origins=np.asarray(raw["parents"],int))
 rr={"stable_id":sid,"candidate_path":str(target),"candidate_sha256":sha(target),"source_patch_path":str(p),"source_patch_sha256":sha(p),"derivation_report_path":str(rp),"derivation_report_sha256":sha(rp),"exact_union_path":str(up),"exact_union_sha256":sha(up),"raw_union_attribute_replay":raw["report"],"maximum_reference_offset_from_raw_union_m":float(delta.max()),"changed_vertex_count":int(np.sum(delta>0)),"pure_attachment_proxy_count":len(pure),"changed_or_missing_pure_attachment_proxies":missing,"source_and_sampled_pose_self_clear":True,"source_self_count":audit["count"],"closed_oriented_manifold_candidate":True,"original_signed_surface_volume_m3":signed_volume(row["positions"].astype(float),row["faces"]),"candidate_signed_surface_volume_m3":signed_volume(z["vertices6"][:,:3].astype(float),z["faces"]),"native_admitted":False,"late_pose_count":16,"early_pose_count":8}
 out["rows"].append(rr);save();print(json.dumps({k:rr[k] for k in ["stable_id","candidate_sha256","maximum_reference_offset_from_raw_union_m","changed_vertex_count","pure_attachment_proxy_count"]}),flush=True)
out.update(complete=True,inputs_unchanged=all(sha(p)==v for p,v in pins.items()));save()
