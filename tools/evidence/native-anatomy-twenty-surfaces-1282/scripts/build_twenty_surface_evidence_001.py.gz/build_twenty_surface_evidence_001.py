from pathlib import Path
import json,hashlib,gzip,csv
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");N=A/"twenty-surface-native-composition-001"
repo=Path("/Users/n/numi-human-positive-winding-1279");O=A/"twenty-surface-publication-001"
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text())
checks=read(N/"native-verification-001/report.json");interfaces=read(N/"native-interface-verification-001/report.json");classified=read(N/"native-pronator-interface-classification-001/report.json")
assert checks["complete"] and checks["inputs_unchanged"] and checks["all_native_repaired_surface_checks_pass"] and checks["all_coupled_trace_rows_exact_baseline_prefix"]
assert interfaces["complete"] and interfaces["inputs_unchanged"] and len(interfaces["poses"])==8
for p in interfaces["poses"]:
 assert len(p["rows"])==20
 for r in p["rows"]:
  assert r["self_count"]==0 and r["external_targets_scanned"]==859
  assert r["new_triangle_pair_count"]==(4 if r["stable_id"]==128 else 0)
assert classified["complete"] and classified["inputs_unchanged"] and len(classified["poses"])==8
assert all(len(p["rows"])==1 and p["rows"][0]["intended_local_shared_insertion_classification_pass"] and p["rows"][0]["other_added_interface_pairs"]==0 for p in classified["poses"])
O.mkdir(exist_ok=False);inventory={}
def put(src,relative,compress=False):
 src=Path(src);dest=O/relative;dest.parent.mkdir(parents=True,exist_ok=True);raw=src.read_bytes();dest.write_bytes(gzip.compress(raw,mtime=0) if compress else raw)
 inventory[relative]={"bytes":dest.stat().st_size,"encoding":"gzip" if compress else "identity","retained_path":str(src),"retained_sha256":hashlib.sha256(raw).hexdigest(),"sha256":sha(dest)}
for f in ["launch_arm.py","launch-guard.json","composition-result.json","source-resolution-bounds.json"]:put(N/f,"native/"+f)
for f in ["run-declaration.json","execution-start.json","execution.json"]:put(N/"baseline"/f,"native/baseline/"+f)
for f in ["invocation.json","run-metadata.json","resting-coupled.csv"]:put(N/"baseline/native-run"/f,"native/baseline/native-run/"+f)
for f in ["frame-skin.png","frame-muscles.png","frame-skeleton.png","frame-organs.png","native-viewer.mov"]:put(N/"baseline/native-run"/f,"viewer/"+f)
put(A/"twenty-surface-movie-inspection-001.log","viewer/movie-inspection.log")
for name,src in [
 ("native-self-and-trace",N/"native-verification-001/report.json"),
 ("native-interfaces",N/"native-interface-verification-001/report.json"),
 ("native-shared-head-classification",N/"native-pronator-interface-classification-001/report.json"),
 ("heldout-shared-head-classification",A/"left-pronator-positive-late-classification-001/report.json"),
 ("early-shared-head-classification",A/"left-pronator-positive-early-classification-001/report.json"),
 ("heldout-pronator-interface-audit",A/"pronator-parent-positive-allpose-interface-audit-001/report.json"),
 ("early-pronator-interface-audit",A/"pronator-parent-positive-early-interface-audit-002/report.json")
]:put(src,"checks/"+name+".json")
put(A/"pronator-parent-positive-union-lift-001/report.json","derivation/parent-lift-report.json.gz",True)
put(A/"parent-positive-union-128-001/result.json","derivation/union-result.json")
put(A/"parent-positive-union-128-001/stable-128-exact-union.json","derivation/exact-union.json.gz",True)
put(A/"bounded-halfmm-source-resolution-001/stable-128-reference-resolution-row-patch.npz","derivation/collapsed-parent.npz")
r=next(x for x in read(A/"pronator-parent-positive-union-lift-001/report.json")["rows"] if x["stable_id"]==128)
put(Path(r["candidate_path"]),"patches/stable-128.npz")
for f in ["prepare_twenty_surface_native_001.py","verify_twenty_surface_native_001.py","verify_twenty_surface_native_interfaces_001.py","verify_twenty_native_left_pronator_positive_001.py","classify_left_pronator_positive_late_001.py","classify_left_pronator_positive_early_001.py","prepare_pronator_parent_positive_union_lift_001.py"]:
 put(A/f,"scripts/"+f+".gz",True)
put(Path(__file__),"scripts/"+Path(__file__).name+".gz",True)
G=A.parent/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001"
original_audit=read(A/"gluteus-original-source-allpose-interface-audit-001/report.json")
assert original_audit["complete"] and original_audit["inputs_unchanged"] and len(original_audit["poses"])==16
assert all(len(p["rows"])==2 and all(r["self_count"]==r["new_triangle_pair_count"]==0 and r["external_targets_scanned"]==859 and r["max_referenced_forward_error_m"]<1e-6 for r in p["rows"]) for p in original_audit["poses"])
put(A/"gluteus-original-source-allpose-interface-audit-001/report.json","checks/gluteus-original-source-late-interfaces.json")
put(A/"gluteus-native-ready-001/report.json","derivation/gluteus-replayed-reference.json.gz",True)
for sid in [29,30]:
 put(A/"gluteus-native-ready-001"/f"stable-{sid}-reference-row-patch.npz",f"patches/stable-{sid}.npz")
 put(G/"attempt-003"/f"stable-{sid}-exact-union.json",f"derivation/gluteus-{sid}-exact-union.json.gz",True)
for attempt in [19,34,46,48,49,50]:
 put(G/f"attempt-{attempt:03d}/result.json",f"derivation/gluteus-attempt-{attempt:03d}.json.gz",True)
 for script in sorted((G/f"attempt-{attempt:03d}").glob("*.py")):put(script,f"scripts/gluteus-{attempt:03d}-"+script.name+".gz",True)
put(G/"attempt-010/source-union-attribute-lift-terminal-audit-001.json","derivation/gluteus-original-attribute-lift.json.gz",True)
put(G/"attempt-010/run_gluteus_union_010.py","scripts/run_gluteus_union_010.py.gz",True)
for f in ["prepare_gluteus_native_rows_001.py","audit_gluteus_original_source_allpose_interfaces_001.py"]:put(A/f,"scripts/"+f+".gz",True)
put(G/"attempt-047/result.json","rejected/gluteus-047-terminal-crossing.json.gz",True)
runtime=read(N/"baseline/native-run/run-metadata.json");trace=list(csv.DictReader((N/"baseline/native-run/resting-coupled.csv").open()))
sim=float(trace[-1][next(iter(trace[-1]))]);wall=runtime["wall_seconds"]
maxdist=max(x["maximum_distance_to_original_shared_crossing_segments_m"] for p in classified["poses"] for x in p["rows"])
summary={"anatomy_complete":False,"five_minute_final_anatomy_qualification":False,"accepted_steps":8000,"simulated_seconds":sim,"owner_wall_seconds":wall,"real_time_factor":sim/wall,"stable_ids":[29,30,35,36,55,56,57,58,105,106,107,108,115,116,124,128,147,148,149,150],"candidate_tissue_sha256":sha(N/"assets/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"),"device":"SSH macmini, Apple M4 Pro, 24 GB, macOS26.6","source_revisions":{"Numi2/numilab-human":"48f20699315f1039df770a4289360ef9419646d3","Numi2/numi-lab":"3a1cfffaeba4502d946cc0d4aeb8860a0075da79","Numi2/numi-brain":"a1cf7218fae5d26f9aed9d845047fc6c472ad596"},"code_revision_equivalence":{"human_positive_winding":"3493b44bf325a3106fed0d0377a15a43be748180","lab_native_build":"015ff2ebd7756247bb511319c8ef21295ba37273"},"native_left_pronator_shared_crossing_distance_upper_bound_m":maxdist,"prior_derivation_evidence":"../native-anatomy-eighteen-surfaces-1281/README.md","left_pronator_union_preparation_cwd":str(A)}
(O/"summary.json").write_text(json.dumps(summary,indent=2,sort_keys=True)+"\n")
previous=repo/"tools/evidence/native-anatomy-seventeen-surfaces-1280/reproduce.py"
(O/"reproduce.py").write_text(previous.read_text().replace("seventeen-surface","twenty-surface"))
(O/"README.md").write_text('# Twenty repaired surfaces in the integrated native human\n\nBoth gluteus maximus surfaces (29/30) join the [previous eighteen repairs](../native-anatomy-eighteen-surfaces-1281/README.md). The native resting human still runs mechanically driven breathing, heart pumping, circulation and gas exchange through the existing Metal owners on the SSH Mac mini.\n\n**Whole-body anatomy and the final five-minute qualification remain incomplete.** Performance work is paused. This is a tested anatomy increment.\n\n## Reproduce\n\n    /usr/bin/python3 tools/evidence/native-anatomy-twenty-surfaces-1282/reproduce.py\n\nThe retained Mini runtime and assets are required. --prepare-only verifies bound inputs and prepares a fresh run. Exact command, source bytes, configuration, device and measured timing are retained. No new simulator or asset format is introduced.\n\n## Gluteal reconstruction\n\nThe existing exact nonzero-winding source union and canonical attribute lift were replayed from the original source for both sides. Bounded local offsets then repair the posed folds and avoid the adjacent femur. The right correction reaches 0.296457 mm from its raw union; the left reaches 0.248738 mm. These are explicitly inferred reference corrections, not measurements of one person.\n\nEach side retains its own physical route, body binding table and weights. Seven original pure-weight attachment vertex rows per side remain bitwise represented; this is a software proxy check, not a measured clinical footprint. The exact union changes tessellation, so a direct original-to-union vertexwise displacement bound is not claimed. Face ancestry travels in the existing optional face_origins patch array, with original union sidecars retained.\n\nThe legacy offline audits 049/050 compared local offsets to the raw union and mislabeled two metre-valued motion fields as millimetres. Those original files are preserved. The independently replayed composition report uses explicit metre fields, and a separate complete changed-region audit compares the final gluteal candidates directly to the original source, including union reconstruction and local offsets, over all sixteen late baseline/intervention poses.\n\n## Native verification\n\nEight actual native captures cover settling and a complete breathing cycle. All twenty repaired surfaces have zero exact self-intersections and pass closed oriented manifold checks. Nineteen add zero changed-region source-lineage crossings against all 859 surrounding structures. The left pronator retains only its four previously qualified shared-head insertion pairs, with native witnesses and the same explicit local bound. No blanket intersection exemption is used.\n\nAll 1,000 rows and 60 coupled physiology/mechanics columns exactly match the unchanged baseline011 prefix. The run accepts 8,000 steps, approximately 16 simulated seconds. The existing flat support plane, contact mechanics, forces, physical mass and physiological controllers remain unchanged.\n\nThe continuous native framebuffer recording, seven-layer inspection log and four inspection frames are retained. Framebuffer evidence does not assert separate remote desktop visibility. Measured timing includes this development run and is not a new performance qualification.\n\nRemaining source or posed defects, including the shoulder and lower-leg candidates still under repair, are excluded from this increment. The prior long physiological run does not qualify these new assets for the final five-minute requirement. BodyParts3D and MyoSim rights and mixed-source reference status remain bound in the asset receipts.\n\nExecuted scripts are losslessly gzip-compressed. retained-files.json verifies both encoded and decoded hashes.\n')
(O/"retained-files.json").write_text(json.dumps(inventory,indent=2,sort_keys=True)+"\n")
for rel,x in inventory.items():
 raw=(O/rel).read_bytes();assert hashlib.sha256(raw).hexdigest()==x["sha256"];decoded=gzip.decompress(raw) if x["encoding"]=="gzip" else raw;assert hashlib.sha256(decoded).hexdigest()==x["retained_sha256"]
print(json.dumps({"output":str(O),"retained_files":len(inventory),"summary":summary},indent=2))
