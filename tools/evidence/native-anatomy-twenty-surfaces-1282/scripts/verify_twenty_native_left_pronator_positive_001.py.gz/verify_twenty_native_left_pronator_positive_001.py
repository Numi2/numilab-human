from pathlib import Path
from fractions import Fraction
import sys,json,hashlib,importlib.util,time
import numpy as np
A=Path("/Users/n/numi-human-retained-delivery-20261009/anatomy-completion-1276");N=A/"twenty-surface-native-composition-001/baseline/native-run";O=N.parent.parent/"native-pronator-interface-classification-001";O.mkdir(exist_ok=False)
sys.path.insert(0,"/Users/n/numi-human-anatomy-completion-1276/src")
from numilab_human import cardiac_cavity_intersections as ci,common_atlas_skin_clearance as ca
H=A.parent/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001/attempt-010/run_gluteus_union_010.py"
sp=importlib.util.spec_from_file_location("h",H);h=importlib.util.module_from_spec(sp);sp.loader.exec_module(h)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pins={str(p):sha(p) for p in [Path(__file__),H,h.TISS,h.MAN,Path(ci.__file__),Path(ca.__file__)]}
rp=A/"pronator-parent-positive-union-lift-001/report.json";ap=N.parent.parent/"native-interface-verification-001/report.json"
for p in [rp,ap]:pins[str(p)]=sha(p)
r=json.loads(rp.read_text());audit=json.loads(ap.read_text());assert audit["complete"] and audit["inputs_unchanged"]
t=h.load_tissue(h.TISS);man=json.loads(h.MAN.read_text());members={x["stable_id"]:x for x in man["source"]["surfaces"]}
out={"scope":"Continuous upper bound: distance to one fixed old crossing segment is convex along a new straight segment, so the maximum endpoint distance bounds the whole new segment; minimizing this bound across old segments conservatively bounds distance to their union. Native candidate positions and original source forwarded through the same accepted body poses. Local diagnostic of reconstructed pronator-head crossing lineage near the existing shared distal insertion. Anatomical joining is supported by source identities/shared physical actuator and literature; a clinical footprint or blanket exemption is not implied.","references":["https://pmc.ncbi.nlm.nih.gov/articles/PMC5380802/","https://pmc.ncbi.nlm.nih.gov/articles/PMC5797209/"],"pins":pins,"poses":[],"complete":False}
def save():(O/"report.json").write_text(json.dumps(out,indent=2,sort_keys=True)+"\n")
def etri(p):return tuple(tuple(Fraction.from_float(float(c)) for c in v) for v in p)
def segments(a,b):
 points=ci.triangle_intersection_points(etri(a),etri(b))
 if not points:return []
 v=np.asarray([[float(c) for c in x] for x in points])
 if len(v)==1:return [(v[0],v[0])]
 i,j=np.unravel_index(np.argmax(np.linalg.norm(v[:,None]-v[None,:],axis=2)),(len(v),len(v)))
 return [(v[i],v[j])]
def distance(p,ss):
 aa=np.array([x[0] for x in ss]);bb=np.array([x[1] for x in ss]);v=bb-aa;den=np.sum(v*v,axis=1)
 u=np.divide(np.sum((p-aa)*v,axis=1),den,out=np.zeros_like(den),where=den>0);u=np.clip(u,0,1)
 return float(np.linalg.norm(p-(aa+u[:,None]*v),axis=1).min())
for pose in audit["poses"]:
 arm=pose["arm"];step=pose["step"];pack=N/"accepted-geometry"/f"step-{step}.mrvpack";receipt=pack.with_suffix(".receipt.json")
 for p in [pack,receipt]:pins[str(p)]=sha(p)
 rc=json.loads(receipt.read_text());poses={x["body_index"]:(np.asarray(x["position_m"],np.float32),np.asarray(x["quaternion_xyzw"],np.float32)) for x in rc["accepted_body_poses"]}
 positions,surfaces,_=ca._pack_surfaces(pack,{(51005,x) for x in [125,126,127,128]})
 pp={"arm":arm,"step":step,"rows":[]};out["poses"].append(pp)
 for ar in pose["rows"]:
  if ar["stable_id"] not in [128]:continue
  sid=ar["stable_id"];target=sid-2;row=h.row_data(t,sid);tr=h.row_data(t,target)
  assert members[sid]["matched_muscles"]==members[target]["matched_muscles"]
  added=[(x,pair) for x in ar["changed_star_interfaces"] for pair in x["added_lineage_pairs"]]
  assert all(x["semantic"]==51005 and x["stable_id"]==target for x,pair in added)
  source_faces=np.asarray(surfaces[(51005,sid)]["faces"],int);target_faces=np.asarray(surfaces[(51005,target)]["faces"],int)
  # Exact pair IDs are authored face IDs, not positions in sorted record arrays.
  bs=h.forward(row["positions"],row["local"],row["weights"],row,t,poses)[row["faces"]];ts=positions[target_faces]
  bv=bs.reshape(-1,3);bf=np.arange(len(bv)).reshape(-1,3)
  tv=ts.reshape(-1,3);tf=np.arange(len(tv)).reshape(-1,3)
  br,_=h.exact_rows(bv,bf,ci);tt,_=h.exact_rows(tv,tf,ci)
  before=ci._audit_pair(br,tt,same_surface=False)["triangle_pairs"]
  oldsegments=[s for i,j in before for s in segments(bs[i],ts[j])]
  assert oldsegments
  cr=next(x for x in r["rows"] if x["stable_id"]==sid);cp=Path(cr["candidate_path"]);pins[str(cp)]=sha(cp);z=np.load(cp)
  delta=source_faces-z["faces"];assert np.all(delta==delta.flat[0]);world=positions[int(delta.flat[0]):int(delta.flat[0])+len(z["vertices6"])]
  measured=[]
  for _,(orig,tid) in added:
   for cf in np.flatnonzero(z["face_origins"]==orig):
    for aa,bb in segments(world[z["faces"][cf]],ts[tid]):
     samples=[aa,(aa+bb)/2,bb]
     measured.append({"source_face":orig,"candidate_face":int(cf),"target_face":tid,"witness_segment_m":[aa.tolist(),bb.tolist()],"maximum_distance_to_original_shared_crossing_segments_m":min(max(distance(aa,[segment]),distance(bb,[segment])) for segment in oldsegments)})
  sourceids=[853,864];pv=row["positions"][row["faces"][sourceids]].reshape(-1,3);used=np.unique(row["faces"]);v=row["positions"][used]
  distal_extent_fraction=float((pv[:,2].max()-v[:,2].min())/(v[:,2].max()-v[:,2].min()))
  rr={"stable_id":sid,"shared_head_target_id":target,"source_member":members[sid]["member_id"],"target_member":members[target]["member_id"],"shared_actuator":members[sid]["matched_muscles"],"before_full_head_crossing_pairs":len(before),"added_lineage_pair_count":len(added),"added_witnesses":measured,"maximum_distance_to_original_shared_crossing_segments_m":max((x["maximum_distance_to_original_shared_crossing_segments_m"] for x in measured),default=0.0),"source_distal_extent_fraction":distal_extent_fraction,"minimum_radius_binding_weight_in_added_source_faces":float(min(sum(float(w) for i,w in zip(row["local"][j],row["weights"][j]) if i==2) for j in np.unique(row["faces"][sourceids]))),"other_added_interface_pairs":0}
  allowed={(853,268),(853,269),(853,293),(864,293)}
  assert {(x["source_face"],x["target_face"]) for x in measured}=={tuple(pair) for _,pair in added}, "every added pair requires an actual witness"
  assert {tuple(pair) for _,pair in added}<=allowed
  assert rr["maximum_distance_to_original_shared_crossing_segments_m"]<.0005
  assert rr["source_distal_extent_fraction"]<.1 and rr["minimum_radius_binding_weight_in_added_source_faces"]>.7
  rr["intended_local_shared_insertion_classification_pass"]=True
  pp["rows"].append(rr);save()
 print(json.dumps({"arm":arm,"step":step,"distances_mm":[x["maximum_distance_to_original_shared_crossing_segments_m"]*1000 for x in pp["rows"]]}),flush=True)
assert len(out["poses"])==8 and all(len(x["rows"])==1 for x in out["poses"])
out["complete"]=True;out["inputs_unchanged"]=all(sha(p)==v for p,v in pins.items());save()
