from __future__ import annotations
import ast, hashlib, importlib.util, json, signal, struct, sys, time, traceback
from pathlib import Path
import numpy as np
R=Path("/Users/n/numi-human-retained-delivery-20261009")
ROOT=R/"fullbody-source-surface-repair-1276/gluteus-maximus-pilot-001"
OUT=ROOT/"attempt-019"
TISS=R/"source-seam-connectivity-1247/fhl-current-7b23-count-reconciliation-1258/attempt-002/candidate/bodyparts3d-myosim-fullbody-muscle-surfaces.nhtissue"
MAN=TISS.with_suffix(".manifest.json")
ATTEMPT010=ROOT/"attempt-010/run_gluteus_union_010.py"
FORWARD=R/"signed-winding-self-union-1273/subscap-pilot-001/full-attribute-lift-007/run_offline_attribute_lift_pose_audit_007.py"
PAIR=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011"
OWNER=Path("/Users/n/numi-human-self-separation-partial-resume-1267/src")
SIGNED=Path("/Users/n/numi-human-signed-winding-1273/src")
sys.path.insert(0,str(OWNER)); sys.path.insert(0,str(SIGNED))
from numilab_human import common_atlas_skin_clearance as ca
from numilab_human import cardiac_cavity_intersections as ci
PINS={
 str(TISS):"6579d06d358bfcf51f964feb57425fe568c467fd361930bce46d376ec8aedaa4",
 str(MAN):"80d775bef6b8a4108e159fb7882a84b2fb8dce5b492059cd8c7cf3644a137467",
 str(ATTEMPT010):"3343c53df203e43d30d778b2f6178295ce250c1519326db55e97c5118e44fcd4",
 str(ROOT/"attempt-010/source-union-attribute-lift-terminal-audit-001.json"):"aa6a77296523f829dba885cdf37bb49b59cd649b71fdf3c054e0ecfa26edb838",
 str(ROOT/"attempt-010/stable-29-reference-union-row-patch.npz"):"6af6d36091228465a76f12764c6c82c6ad844f704ffcbea81f7545e57f467a03",
 str(ROOT/"attempt-010/stable-30-reference-union-row-patch.npz"):"46886a95bff1922f66709df0af8d87011c88d143144aa2bdcf75f6b87c082894",
 str(ROOT/"attempt-003/stable-29-exact-union.json"):"9cc5521c0c4b04c165beb3747c953fe7d541eba61e0299cb1527c451fccfe31c",
 str(ROOT/"attempt-003/stable-30-exact-union.json"):"aee6990edc4011dc70848cd23876901c69a1813cdfb4ba1468f20d41b80281fd",
 str(OWNER/"numilab_human/cardiac_cavity_geometry.py"):"f6e98744dad9e23cd3b505efc02e7faa618fccce81d2ee08b07f948ef182fb72",
 str(FORWARD):"e78fe261b2f625de51378c34d238b6716ac38bf2eb667824d669cdd2bda6ad47",
 str(OWNER/"numilab_human/common_atlas_skin_clearance.py"):"151ba8925910ae164bdf9a41417ca2cc5c63b07c3b05eb09496d20c4771c5e9b",
 str(OWNER/"numilab_human/cardiac_cavity_intersections.py"):"423180082e32d002375b612aad36f307ed439af07c04d655e6a8bedc87a338bd",
}
EXPECTED_PAIRS=[[357,465],[357,737],[358,737]]
CONSTRAINED_PAIRS=[[357,737]]
ADJACENT_TERMINAL_PAIRS={"29":{"357:465":[241],"358:737":[186]},"30":{"357:465":[948],"358:737":[1006]}}
MAX_SOURCE_MOTION_MM=0.25
START=time.monotonic()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(4*1024*1024),b""): h.update(b)
 return h.hexdigest()
def require(ok,msg):
 if not ok: raise RuntimeError(msg)
def progress(event,**kw):
 row={"event":event,"elapsed_s":time.monotonic()-START,**kw}
 with (OUT/"progress.jsonl").open("a") as f: f.write(json.dumps(row,sort_keys=True,separators=(",",": "))+"\n")
 print(json.dumps(row,sort_keys=True),flush=True)
def quat_rotation(q):
 x,y,z,w=map(float,np.asarray(q,dtype=np.float32))
 return np.asarray([[1.0-2.0*(y*y+z*z),2.0*(x*y-w*z),2.0*(x*z+w*y)],
  [2.0*(x*y+w*z),1.0-2.0*(x*x+z*z),2.0*(y*z-w*x)],
  [2.0*(x*z-w*y),2.0*(y*z+w*x),1.0-2.0*(x*x+y*y)]],dtype=np.float64)
def pose_map(receipt_path,step):
 receipt=json.loads(receipt_path.read_text())
 require(receipt.get("accepted_step")==step and receipt.get("physical_endpoint")=="accepted",f"pose receipt not accepted at {step}")
 pack=receipt_path.with_name(receipt_path.name.replace(".receipt.json",".mrvpack"))
 require(pack.is_file() and receipt.get("pack_file_sha256")==sha(pack),f"pose receipt does not bind pack at {step}")
 poses={int(x["body_index"]):(np.asarray(x["position_m"],dtype=np.float32),np.asarray(x["quaternion_xyzw"],dtype=np.float32)) for x in receipt["accepted_registered_body_poses"]}
 return poses,pack

def pose_jacobians(points,local,weights,row,tissue,poses):
 out=np.zeros((len(points),3,3),dtype=np.float64)
 for vi in range(len(points)):
  for slot in range(4):
   w=np.float32(weights[vi,slot])
   if w<=np.float32(2e-6): continue
   li=int(local[vi,slot]); require(li<row["bc"],"active candidate route index outside source binding table")
   binding=tissue["bindings"][row["fb"]+li]; core=int(binding["core"]); val=binding["value"]
   require(core in poses,f"candidate vertex {vi} route has no accepted pose for body {core}")
   body_rot=quat_rotation(poses[core][1]); local_rot=quat_rotation(val[3:7]); scale=float(np.float32(val[7]))
   out[vi]+=float(w)*body_rot@(scale*local_rot)
 return out

def exact_audit(points,faces):
 p=np.asarray(points,dtype="<f4"); f=np.asarray(faces,dtype=np.int64)
 uq,inv=np.unique(p,axis=0,return_inverse=True); qf=inv[f]
 lattice=[ci.float32_point_lattice_key(tuple(float(v) for v in row)) for row in uq]
 deg=[]
 for i,t in enumerate(qf):
  n=ci._cross(ci._sub(lattice[int(t[1])],lattice[int(t[0])]),ci._sub(lattice[int(t[2])],lattice[int(t[0])]))
  if not any(n): deg.append(int(i))
 if deg: return {"count":None,"pairs":None,"degenerate_faces":deg},None
 rec=ci._records(lattice,qf.tolist())
 result=ci._audit_pair(rec,rec,same_surface=True)
 return {"count":int(result["count"]),"pairs":result["triangle_pairs"],"degenerate_faces":[]},rec
def mutual_audit(a,fa,b,fb):
 aa,ra=exact_audit(a,fa); bb,rb=exact_audit(b,fb)
 if ra is None or rb is None: return {"count":None,"degenerate_a":aa["degenerate_faces"],"degenerate_b":bb["degenerate_faces"]}
 v=ci._audit_pair(ra,rb,same_surface=False)
 return {"count":int(v["count"]),"pairs":v["triangle_pairs"],"degenerate_a":[],"degenerate_b":[]}
def load_forward():
 tree=ast.parse(FORWARD.read_text()); ns={"np":np,"Path":Path,"struct":struct}
 wanted={"need","load_tissue","row_data","f32","cross32","rotate32","forward"}
 for node in tree.body:
  if isinstance(node,ast.FunctionDef) and node.name in wanted:
   exec(compile(ast.Module(body=[node],type_ignores=[]),str(FORWARD),"exec"),ns)
 return ns

def main():
 OUT.mkdir(parents=True,exist_ok=True)
 require(not (OUT/"result.json").exists() and not (OUT/"progress.jsonl").exists(),"attempt017 output already exists")
 pose_paths=[PAIR/arm/f"native-run/accepted-geometry/step-{step}.{suffix}" for arm in ("baseline","intervention") for step in (0,155000) for suffix in ("receipt.json","mrvpack")]
 context_paths=[PAIR/arm/name for arm in ("baseline","intervention") for name in ("run-declaration.json","execution.json","native-run/run-metadata.json")]
 candidate_paths=[ROOT/f"attempt-010/stable-{sid}-reference-union-row-patch.npz" for sid in (29,30)]
 union_paths=[ROOT/f"attempt-003/stable-{sid}-exact-union.json" for sid in (29,30)]
 report_paths=[ROOT/"attempt-003/union-execution-003.json",ROOT/"attempt-010/source-union-attribute-lift-terminal-audit-001.json"]
 input_paths=[Path(__file__),*map(Path,PINS),*pose_paths,*context_paths,*candidate_paths,*union_paths,*report_paths]
 pins_before={str(p):sha(p) for p in input_paths}
 for p,expected in PINS.items(): require(pins_before[p]==expected,f"pinned input hash mismatch: {p}")
 spec=importlib.util.spec_from_file_location("gluteus_union_010",ATTEMPT010)
 mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
 from numilab_human.cardiac_cavity_geometry import analyze_topology
 mod.analyze_topology=analyze_topology
 forward_ns=load_forward(); tissue=forward_ns["load_tissue"](TISS)
 forward=forward_ns["forward"]
 rows={sid:forward_ns["row_data"](tissue,sid) for sid in (29,30)}
 candidate={}; faces={}; locals_={}; weights={}; source_audits={}; baseline_world={}; terminal_world={}; jac_terminal={}; poses={}
 for arm in ("baseline","intervention"):
  for step in (0,155000):
   rp=PAIR/arm/f"native-run/accepted-geometry/step-{step}.receipt.json"
   poses[(arm,step)],pack=pose_map(rp,step)
   require(str(rp) in pins_before and str(pack) in pins_before,"pose receipt/pack missing from initial hash inventory")
 for sid in (29,30):
  z=np.load(ROOT/f"attempt-010/stable-{sid}-reference-union-row-patch.npz",allow_pickle=False)
  candidate[sid]=np.ascontiguousarray(z["vertices6"][:,:3],dtype="<f4")
  locals_[sid]=np.ascontiguousarray(z["binding_indices"],dtype="<u4")
  weights[sid]=np.ascontiguousarray(z["weights"],dtype="<f4")
  faces[sid]=np.ascontiguousarray(z["faces"],dtype=np.int64)
  source_audits[sid],_=exact_audit(candidate[sid],faces[sid])
  require(source_audits[sid]["count"]==0 and not source_audits[sid]["degenerate_faces"],f"source union candidate {sid} is not clear")
  for arm in ("baseline","intervention"):
   w0=forward(candidate[sid],locals_[sid],weights[sid],rows[sid],tissue,poses[(arm,0)])
   wt=forward(candidate[sid],locals_[sid],weights[sid],rows[sid],tissue,poses[(arm,155000)])
   a0,_=exact_audit(w0,faces[sid]); at,_=exact_audit(wt,faces[sid])
   require(not a0["degenerate_faces"] and not at["degenerate_faces"],f"candidate has degenerate faces in {arm} pose")
   progress("candidate_step0_pose_audit",stable_id=sid,arm=arm,count=a0["count"],pairs=a0["pairs"])
   require(at["pairs"]==EXPECTED_PAIRS,f"terminal pair identity changed in {arm} row{sid}: {at}")
   baseline_world[(sid,arm)]=w0; terminal_world[(sid,arm)]=wt
   jac_terminal[(sid,arm)]=pose_jacobians(candidate[sid],locals_[sid],weights[sid],rows[sid],tissue,poses[(arm,155000)])
  progress("candidate_geometry_loaded",stable_id=sid,vertices=len(candidate[sid]),faces=len(faces[sid]),source_pairs=source_audits[sid]["pairs"],step0_pairs=0,terminal_pairs=EXPECTED_PAIRS)
 original_mutual={}
 for arm in ("baseline","intervention"):
  for step,name in ((0,"step0"),(155000,"terminal")):
   world={sid:(baseline_world if step==0 else terminal_world)[(sid,arm)] for sid in (29,30)}
   original_mutual[(arm,name)]=mutual_audit(world[29],faces[29],world[30],faces[30])
 proposal_results={}; final_world={}; anchor_ids={}
 for sid in (29,30):
  active_pairs=np.asarray(CONSTRAINED_PAIRS,dtype=np.int64); seeds=np.unique(faces[sid][active_pairs].reshape(-1))
  # Preserve the pure-route endpoint vertices; leave every binding index and weight unchanged.
  pure=np.flatnonzero((weights[sid][:,0]>=np.float32(1.0-1.0e-7)) | (weights[sid][:,1]>=np.float32(1.0-1.0e-7))).astype(np.int64)
  require(len(pure)>0,f"stable {sid} has no pure-route attachment anchors")
  incident={int(v):set() for v in range(len(candidate[sid]))}
  for tri in faces[sid]:
   tri_ids=list(map(int,tri))
   for v in tri_ids: incident[v].update(tri_ids)
  movable_set=set(map(int,seeds))
  for v in seeds: movable_set.update(incident[int(v)])
  movable=np.asarray(sorted(movable_set-set(map(int,pure))),dtype=np.int64)
  require(np.all(np.isin(seeds,movable)),f"stable {sid} pair seed intersects a pure-route anchor")
  require(len(movable)<=256,f"stable {sid} one-ring patch exceeds existing helper bound: {len(movable)}")
  anchor_ids[sid]=pure
  pose_samples=[]
  for arm in ("baseline","intervention"):
   pose_samples.append({"vertex_ids":np.arange(len(candidate[sid]),dtype=np.int64),
       "baseline_world_positions":baseline_world[(sid,arm)],"rejected_world_positions":terminal_world[(sid,arm)],
       "jacobians":jac_terminal[(sid,arm)],"self_pair_rows":active_pairs})
  progress("local_solver_started",stable_id=sid,seeds=seeds.tolist(),movable_count=len(movable),pure_route_anchors=pure.tolist(),pair_pose_rows=len(pose_samples)*len(active_pairs))
  proposal=ca._propose_local_self_separation_increment(source_positions_m=candidate[sid],faces=faces[sid],
      movable_vertex_ids=movable,self_patch_seed_vertex_ids=seeds,
      required_target_seed_vertex_ids=np.asarray([],dtype=np.int64),active_target_face_vertex_ids=np.asarray([],dtype=np.int64),
      fixed_support_vertex_ids=pure,preserved_anchor_vertex_ids=pure,pose_samples=pose_samples)
  raw_proposed=np.asarray(proposal["proposal_source_positions_m_f32"],dtype="<f4")
  raw_displacement_mm=(raw_proposed.astype(np.float64)-candidate[sid].astype(np.float64))*1000.0
  raw_max_l2=float(np.linalg.norm(raw_displacement_mm,axis=1).max(initial=0.0))
  line_scale=min(1.0,(MAX_SOURCE_MOTION_MM*0.995)/raw_max_l2) if raw_max_l2>0 else 1.0
  proposed=np.asarray(candidate[sid].astype(np.float64)+(raw_proposed.astype(np.float64)-candidate[sid].astype(np.float64))*line_scale,dtype="<f4")
  displacement_mm=(proposed.astype(np.float64)-candidate[sid].astype(np.float64))*1000.0
  max_l2=float(np.linalg.norm(displacement_mm,axis=1).max(initial=0.0)); max_component=float(np.abs(displacement_mm).max(initial=0.0))
  require(max_l2<=MAX_SOURCE_MOTION_MM+1e-9,f"scaled helper direction exceeds test bound for {sid}: {max_l2}mm")
  require(proposed[pure].tobytes()==candidate[sid][pure].tobytes(),f"stable {sid} moved pure-route endpoint anchors")
  outside=np.setdiff1d(np.arange(len(proposed),dtype=np.int64),movable)
  require(proposed[outside].tobytes()==candidate[sid][outside].tobytes(),f"stable {sid} changed outside one-ring patch")
  s_audit,_=exact_audit(proposed,faces[sid])
  require(s_audit["count"]==0 and not s_audit["degenerate_faces"],f"source exact self audit failed stable {sid}: {s_audit}")
  w_by_pose={}
  for arm in ("baseline","intervention"):
   w0=forward(proposed,locals_[sid],weights[sid],rows[sid],tissue,poses[(arm,0)])
   wt=forward(proposed,locals_[sid],weights[sid],rows[sid],tissue,poses[(arm,155000)])
   a0,_=exact_audit(w0,faces[sid]); at,_=exact_audit(wt,faces[sid])
   require(not a0["degenerate_faces"] and not at["degenerate_faces"],f"stable {sid} exact posed faces degenerate {arm}")
   require(a0["count"]==0,f"stable {sid} proposed step0 self pairs remain {arm}: {a0}")
   require(at["count"]==0,f"stable {sid} scaled terminal self pairs remain {arm}: {at}")
   topology=mod.analyze_topology(proposed.astype(float).tolist(),faces[sid].tolist())
   top_terminal=mod.analyze_topology(wt.astype(float).tolist(),faces[sid].tolist())
   require(topology["closed_oriented_manifold_candidate"] and top_terminal["closed_oriented_manifold_candidate"],f"stable {sid} proposed topology failed {arm}")
   oldvol=mod.signed_volumes(mod.analyze_topology(candidate[sid].astype(float).tolist(),faces[sid].tolist()),candidate[sid],faces[sid])
   newvol=mod.signed_volumes(topology,proposed,faces[sid])
   require(len(oldvol)==len(newvol) and all(a*b>0 for a,b in zip(oldvol,newvol)),f"stable {sid} source component orientation changed")
   w_by_pose[(arm,0)]=w0; w_by_pose[(arm,155000)]=wt
  final_world[sid]=w_by_pose
  proposal_results[sid]={"status":proposal["status"],"max_source_vertex_l2_motion_mm":max_l2,"max_source_component_motion_mm":max_component,"moved_vertex_count":int(np.count_nonzero(np.any(displacement_mm!=0,axis=1))),"movable_vertex_count":int(len(movable)),"seed_vertex_ids":seeds.tolist(),"pure_route_anchor_vertex_ids":pure.tolist(),"source_self_after":s_audit,"source_area_relative_delta":float(mod.area(proposed,faces[sid])/mod.area(candidate[sid],faces[sid])-1.0),"helper_raw_max_l2_mm":float(proposal["float32_max_vertex_l2_increment_mm"]),"scaled_line_fraction":float(line_scale)}
  new_vertices6=np.concatenate([proposed,mod.vertex_normals(proposed,faces[sid])],axis=1).astype("<f4")
  outnpz=OUT/f"stable-{sid}-unadmitted-local-offset-candidate.npz"
  np.savez(outnpz,vertices6=new_vertices6,binding_indices=locals_[sid],weights=weights[sid],faces=faces[sid].astype("<u4"))
  proposal_results[sid]["npz_path"]=str(outnpz); proposal_results[sid]["npz_sha256"]=sha(outnpz)
  proposal_results[sid]["binding_indices_unchanged"]=True; proposal_results[sid]["weights_unchanged"]=True; proposal_results[sid]["faces_unchanged"]=True
  progress("local_candidate_exact_gates_passed",stable_id=sid,max_source_l2_mm=max_l2,moved_vertices=proposal_results[sid]["moved_vertex_count"],npz=str(outnpz))
 mutual_after={}
 for arm in ("baseline","intervention"):
  for step,name in ((0,"step0"),(155000,"terminal")):
   world={sid:final_world[sid][(arm,step)] for sid in (29,30)}
   mutual_after[(arm,name)]=mutual_audit(world[29],faces[29],world[30],faces[30])
 after={str(p):sha(p) for p in input_paths}; require(pins_before==after,"pinned source/owner/pose inputs changed during solve")
 report={"schema":"numi.human.gluteus-maximus-local-source-offset-terminal-self-probe-019.v1",
  "status":"unadmitted_local_offset_candidates_passed_exact_source_step0_terminal_self_and_topology_gates",
  "scope":"Stable IDs 29/30 only. Reuses exact union topology and existing local self-separation helper for source-position offsets. No full 16-pose/external-target admission, NHTISS composition, or native candidate run.",
  "source_owner_and_pose_pins_before":pins_before,"source_owner_and_pose_pins_after":after,"immutable_inputs_unchanged":pins_before==after,
  "accepted_pose_receipts_and_packs":[str(x) for x in pose_paths],"max_trial_source_motion_mm":MAX_SOURCE_MOTION_MM,"raw_helper_direction_max_vertex_l2_mm_by_row":{str(sid):float(proposal_results[sid]["helper_raw_max_l2_mm"]) for sid in proposal_results},
  "all_terminal_exact_pair_rows":EXPECTED_PAIRS,"helper_constrained_nonadjacent_pair_rows":CONSTRAINED_PAIRS,"vertex_adjacent_terminal_pairs":ADJACENT_TERMINAL_PAIRS,"baseline_source_self":{"29":source_audits[29],"30":source_audits[30]},
  "original_mutual_pair_counts":{f"{a}:{p}":v for (a,p),v in original_mutual.items()},
  "local_solver_and_exact_results":{"29":proposal_results[29],"30":proposal_results[30]},
  "mutual_pair_counts_after":{f"{a}:{p}":v for (a,p),v in mutual_after.items()},
  "limitations":["The local helper uses clear step0 source-derived forward geometry as the separation reference; it is a predicted candidate pose, not a native capture of the candidate.","Full all-pose/all-target audits remain required before composition.","Exact self/topology pass does not establish whole-body anatomy or inter-muscle clearance."],"wall_seconds":time.monotonic()-START}
 out=OUT/"result.json"; out.write_text(json.dumps(report,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":report["status"],"report":str(out),"sha256":sha(out),"wall_seconds":report["wall_seconds"]},sort_keys=True),flush=True)
if __name__=="__main__":
 try:
  signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError("bounded source offset probe exceeded 300 seconds")))
  signal.alarm(300); main()
 except Exception as exc:
  OUT.mkdir(parents=True,exist_ok=True)
  failure={"schema":"numi.human.gluteus-maximus-local-source-offset-terminal-self-probe-019.failure.v1","status":"failed_or_rejected_candidate","error_type":type(exc).__name__,"error":str(exc),"traceback":traceback.format_exc(),"pinned_hashes_at_failure":{p:sha(p) for p in PINS if Path(p).is_file()},"wall_seconds":time.monotonic()-START}
  fp=OUT/"failure.json"; fp.write_text(json.dumps(failure,indent=2,sort_keys=True)+"\n")
  print(json.dumps({"status":failure["status"],"failure":str(fp),"sha256":sha(fp),"error":str(exc)},sort_keys=True),flush=True)
  raise
 finally:
  signal.alarm(0)
