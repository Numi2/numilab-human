from pathlib import Path
import sys,json,hashlib,argparse,numpy as np,subprocess,shutil
R=Path("/Users/n/numi-human-retained-delivery-20261009");A=R/"anatomy-completion-1276"
O=A/"left-scm-masseters-native-composition-003";O.mkdir(exist_ok=False)
SRC=Path("/Users/n/numi-human-local-clearance-preservation-1280/src");sys.path.insert(0,str(SRC))
from numilab_human import passive_attachment_composition as pc,resting_run as rr
B=A/"masseters-native-composition-004";SK=A/"skin-candidate-30-pose-preparation-001/result-005";AP=A/"left-scm-and-masseters-composition-002"
P=R/"skin-resting-multipose-clearance-1218/native-coupled-pair-preparation-011";sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
arp=AP/"preparation-report.json";RP=AP/"native-masseter-pair-check.json";ar=json.loads(arp.read_text());r=json.loads(RP.read_text())
assert ar["inputs_unchanged"] and ar["parent_rows_and_bindings_byte_exact"] and ar["child_surface_count"]==154 and ar["mass_geometry_accounting_unchanged"] and ar["row152_matches_prior_left_candidate_exactly"]
assert r["combined_863_target_proof_available"] and r["all_eight_exact_pairs_zero_vs_159_160"] and r["all_eight_left_candidate_self_topology_clear"]
parent=json.loads((B/"native-verification-003/report.json").read_text());assert parent["all_native_checks_pass"] and parent["inputs_unchanged"]
C=Path(ar["payload_path"]);assert sha(C)=="9dad5934475e3c3517e920c821b54e69fc0cceee4958a27692f1e5905a6c1a7f"
inputpins={v["path"]:v["sha256"] for v in {**ar["input_pins"],**r["pins"]}.values()}
for path,digest in inputpins.items():assert sha(path)==digest,(path,sha(path),digest)
(O/"assets").symlink_to(AP/"assets",target_is_directory=True)
payload=C;receipt=AP/"resting-anatomy-receipt.json";(O/receipt.name).symlink_to(receipt)
assert json.loads(receipt.read_text())["mass_geometry_accounting"]==json.loads((B/"resting-anatomy-receipt.json").read_text())["mass_geometry_accounting"]
composition=json.loads((AP/"composition-result.json").read_text());(O/"composition-result.json").write_text(json.dumps(composition,indent=2,sort_keys=True)+"\n")
bounds=json.loads((AP/"source-reconstruction-proof.json").read_text());(O/"source-resolution-bounds.json").write_text(json.dumps(bounds,indent=2,sort_keys=True)+"\n")
proofpaths=[RP,arp,AP/"source-reconstruction-proof.json",B/"native-verification-003/report.json"];union_inputs=list(map(Path,inputpins));replacements=[]
base=json.loads((P/"baseline/run-declaration.json").read_text());argsv=base["argv"][base["argv"].index("human-resting")+1:]
for flag,value in [("--body-scene",str(SK/"resting-supine-scene.manifest.json")),("--anatomy-receipt",str(receipt)),("--output",str(O/"baseline/native-run")),("--seconds","16.0")]:argsv[argsv.index(flag)+1]=value
argsv+=["--lab","/Users/n/numi-lab-passive-single-binding-1328","--build","/Users/n/numi-lab-passive-single-binding-build-1328"]
parser=argparse.ArgumentParser();rr.add_arguments(parser);args=parser.parse_args(argsv);native,assets=rr.command(args)
env={}
for item in base["argv"][2:base["argv"].index("human-resting")-1]:
 key,value=item.split("=",1);env[key]=value
env["NUMI_HUMAN_ROOT"]=str(SRC.parent);env["PYTHONPATH"]=str(SRC)
env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"]="0,4767,5023,5599,6207,6815,7423,8000"
assert all(n in (0,8000) or (n+1)%32==0 for n in map(int,env["NUMI_HUMAN_RESTING_EXPORT_MRV_STEPS"].split(",")))
# Baseline011's Q observer is inactive throughout its first16s.
# A window beyond this short run is rejected; disable the observer and omit bounds.
env["NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT"]="0"
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_FIRST_STEP",None)
env.pop("NUMI_HUMAN_ACCEPTED_Q_INTEGRATION_AUDIT_LAST_STEP",None)
env["NUMI_HUMAN_RESTING_COMMON_FAILURE_RECEIPT"]=str(args.output/"common-field-failure.json")
env.update(DYLD_LIBRARY_PATH=str((args.build/"lib").resolve())+":"+str((args.build/"matter").resolve()),DYLD_PRINT_LIBRARIES="1",NUMI_HUMAN_RESTING_INSPECTION_TOUR="1",NUMI_HUMAN_RESTING_INSPECTION_PERIOD_SECONDS=str(args.inspection_period_seconds))
argv=["/usr/bin/env","-i"]+[k+"="+v for k,v in sorted(env.items())]+["/Users/n/numi-human-prep-venv-20261005/bin/python3.13","-m","numilab_human.resting_run"]+argsv
# Minimum free space: 3500MiB for this fixed 16s/eight-capture workload. Previous identical capture allocation peaked below 2700MiB; preserves >800MiB margin. Longer runs require their own guard.
launch=O/"launch_arm.py";launch.write_text((A/"ecu-apl-native-composition-005/launch_arm.py").read_text().replace("6000 * 1024 * 1024", "3500 * 1024 * 1024"))
pins={**assets,**{str(p):sha(p) for p in [Path(__file__),Path(pc.__file__),Path(rr.__file__),launch,O/"source-resolution-bounds.json",*proofpaths,*union_inputs]}}
for _,npz,rp in replacements:pins[str(npz)]=sha(npz);pins[str(rp)]=sha(rp)
decl={"schema":"numi.human.native-smoke.run-declaration.v1","seconds":16.0,"accepted_steps":8000,"capture_steps":[0,4767,5023,5599,6207,6815,7423,8000],"immutable_assets":pins,"argv":argv,"launch_adapter":{"path":str(launch),"sha256":sha(launch)},"owner_cli_preview":{"native_argv":native,"asset_sha256":assets,"recorded_invocation_environment":rr.invocation_environment(env)},"qualification":'Verified native masseter scene plus corrected source-derived passive left SCM152. Preserves all153parent rows, physical mass and routes. Eight predicted poses clear self/skin/vessels/bothmasseters; five unchanged bone/pectoral interfaces remain unresolved. Native verification pending; no full anatomy or finalfive-minutequalification; performance deferred.'}
(O/"baseline").mkdir();dp=O/"baseline/run-declaration.json";dp.write_text(json.dumps(decl,indent=2,sort_keys=True)+"\n")
(O/"launch-guard.json").write_text(json.dumps({"launcher_sha256":sha(launch),"arms":{"baseline":{"run_declaration_sha256":sha(dp),"native_output":str(args.output)}}},indent=2,sort_keys=True)+"\n")
print(json.dumps({"output":str(O),"payload_sha256":sha(payload),"pins":len(pins),"rows":list(bounds)},indent=2))

