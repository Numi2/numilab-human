from pathlib import Path
import hashlib
import importlib.util
import json
import signal
import sys
import time
import traceback
import numpy as np

P=Path("/Users/numi/Work/numi-human-connected-surface-069/D/connected-obstacle-207/physical-transfer-209")
OUT=P/"P/full-outer-parent-registration-322/run-001"
H=P/"bounded-parent-registration-314"
A=P/"P/physical-volume-producer-311/native-pose-matrix-capture-001"
OLD=P/"native-parent-layer-capture-256/run-001"
CANDIDATE=P/"geometry-worker/fixed-physical-O-local-nested-001/pilot-004-union/O-exact-witness-repair-286/candidate.npz"
PYTHON=sys.executable
if OUT.exists():raise SystemExit(f"refuse existing output {OUT}")
OUT.mkdir(parents=True,exist_ok=False)
sys.path.insert(0,str(H))
import export_authoring_registered_surface_sidecars_230 as m

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
class BoundedTimeout(Exception):pass
def timeout_handler(signum,frame):raise BoundedTimeout("180-second full O registration deadline reached")
signal.signal(signal.SIGALRM,timeout_handler)
signal.alarm(180)
started=time.monotonic()
layer_state={"layer":"O","surfaceVertexRow":None,"pointWorldM":None}
try:
 surface=m.validate_candidate(CANDIDATE,"O",True)
 frames,posemeta,bindings=m.load_frames(A/"registered-skin-poses-100.json")
 parent,index,mi,parentmeta=m.load_parent_current(A/"compiled-parent-cell-mass.csv")
 weights,weightmeta=m.load_parent_full86_weights(A/"compiled-parent-cell-mass.csv.weights.csv",parent,parentmeta)
 same_payload_files=[
  "compiled-parent-cell-mass.csv","compiled-parent-cell-mass.csv.labels.csv",
  "compiled-parent-cell-mass.csv.nodes.csv","compiled-parent-cell-mass.csv.source.csv",
  "compiled-parent-cell-mass.csv.tets.csv","compiled-parent-cell-mass.csv.weights.csv",
  "parent-deep-attachments.csv","parent-layer-rows.csv",
  "registered-skin-100-native.csv","registered-skin-100-native.csv.candidate033.csv"]
 equality={name:sha(A/name)==sha(OLD/name) for name in same_payload_files}
 if not all(equality.values()):raise ValueError(f"fresh parent packet differs from pinned old capture: {equality}")
 preflight={
  "schema":"full-O286-parent-registration-preflight.v1",
  "candidatePath":str(CANDIDATE),"candidateSHA256":sha(CANDIDATE),
  "candidatePointCount":surface["vertexCount"],"candidateFaceCount":surface["faceCount"],
  "candidateSourceSchema":surface["sourceSchema"],"candidateSourceOriginalFaceIDs":surface["sourceOriginalFaceIDs"],
  "exporterPath":str(H/"export_authoring_registered_surface_sidecars_230.py"),
  "exporterSHA256":sha(H/"export_authoring_registered_surface_sidecars_230.py"),
  "parentCapturePath":str(A),"parentPacketAgainstOldCaptureSHA256Equality":equality,
  "parent":parentmeta,"pose":posemeta,"weights":weightmeta,
  "tieToleranceM":1.0e-8,"maximumParentDistanceM":0.02,
  "registeredBindings":bindings,"physical_admission":False,"simulation_steps":0}
 (OUT/"preflight.json").write_text(json.dumps(preflight,indent=2,sort_keys=True)+"\n")
 original=m.closest_same_material
 def tracked(parent_arg,index_arg,material_arg,material,point,max_distance,tie_tol):
  try:return original(parent_arg,index_arg,material_arg,material,point,max_distance,tie_tol)
  except Exception as exc:
   setattr(exc,"registrationContext",{
    "layer":layer_state["layer"],"surfaceVertexRow":layer_state["surfaceVertexRow"],
    "pointWorldM":None if layer_state["pointWorldM"] is None else np.asarray(layer_state["pointWorldM"],dtype=float).tolist(),
    "candidatePath":str(CANDIDATE),"candidateSHA256":sha(CANDIDATE)})
   raise
 m.closest_same_material=tracked
 # register_layer calls this once per row in order. Keep the current row available
 # for a precise failure witness without repeating any parent queries.
 original_register=m.register_layer
 # Use a row-aware wrapper around the module-level lookup.
 def row_tracking(parent_arg,index_arg,material_arg,material,point,max_distance,tie_tol):
  layer_state["surfaceVertexRow"]=int(layer_state["nextVertex"])
  layer_state["pointWorldM"]=np.asarray(point,dtype=np.float64).copy()
  layer_state["nextVertex"]+=1
  return tracked(parent_arg,index_arg,material_arg,material,point,max_distance,tie_tol)
 m.closest_same_material=row_tracking
 layer_state["nextVertex"]=0
 result=original_register(surface,parent,index,mi,frames,weights,bindings,0.02,1.0e-8)
 signal.alarm(0)
 files=[
  ("registered-O.csv",m.NODE_HEADER,result["nodes"]),
  ("registered-O-faces.csv",m.FACE_HEADER,result["faces"]),
  ("parent-tet-full-weights-O.csv",m.WEIGHT_HEADER,result["weightRows"]),
  ("parent-tet-full-weight-owners-O.csv",m.WEIGHT_OWNER_HEADER,result["weightOwnerRows"]),
  ("node-parent-registration-O.csv",m.PARENT_HEADER,result["registrations"])]
 for name,header,rows in files:m.write_csv(OUT/name,header,rows)
 m.write_csv(OUT/"donor-frames.csv",m.FRAME_HEADER,m.frame_csv_rows(frames,bindings))
 (OUT/"source-domain-registry-O.json").write_text(json.dumps(result["sourceDomain"],indent=2,sort_keys=True)+"\n")
 if result.get("exactNearTieFallbacks"):
  fallback={"schema":"exact-parent-near-tie-fallbacks.v1","layer":"O","candidatePath":str(CANDIDATE),
   "candidateSHA256":sha(CANDIDATE),"parentCurrentSHA256":parentmeta["nodeSHA256"],
   "poseSnapshotSHA256":posemeta["sha256"],"fallbacks":result["exactNearTieFallbacks"],
   "physical_admission":False,"native_steps":0}
  (OUT/"exact-parent-near-tie-fallbacks-O.json").write_text(json.dumps(fallback,indent=2,sort_keys=True)+"\n")
 hashes={p.name:sha(p) for p in OUT.iterdir() if p.is_file()}
 receipt={"schema":"full-O286-parent-registration-receipt.v1","status":"reference_registration_ready_geometry_not_admitted",
  **preflight,"metrics":result["metrics"],"sourceDomain":result["sourceDomain"],
  "exactFallbackCount":len(result.get("exactNearTieFallbacks",[])),
  "elapsedSeconds":time.monotonic()-started,"outputsSHA256":hashes,
  "scope":"Full O286 node, face ancestry, parent material-15 registration, full86 weights, and native matrix donor-frame CSVs; no I/D, child volume, physical mass transfer, solver, or motion admission."}
 (OUT/"receipt.json").write_text(json.dumps(receipt,indent=2,sort_keys=True)+"\n")
 print(json.dumps({"status":receipt["status"],"output":str(OUT),"candidateSHA256":sha(CANDIDATE),
  "nodes":len(result["nodes"]),"faces":len(result["faces"]),"metrics":result["metrics"],
  "exactFallbackCount":receipt["exactFallbackCount"],"elapsedSeconds":receipt["elapsedSeconds"],
  "physical_admission":False,"receiptSHA256":sha(OUT/"receipt.json")},indent=2),flush=True)
except Exception as exc:
 signal.alarm(0)
 ctx=getattr(exc,"registrationContext",None)
 if ctx is None and layer_state["surfaceVertexRow"] is not None:
  ctx={"layer":layer_state["layer"],"surfaceVertexRow":layer_state["surfaceVertexRow"],
   "pointWorldM":None if layer_state["pointWorldM"] is None else np.asarray(layer_state["pointWorldM"],dtype=float).tolist(),
   "candidatePath":str(CANDIDATE),"candidateSHA256":sha(CANDIDATE) if CANDIDATE.is_file() else None}
 failure={"schema":"full-O286-parent-registration-failure.v1","status":"failed",
  "exceptionType":type(exc).__name__,"error":str(exc),"failureWitness":ctx,
  "elapsedSeconds":time.monotonic()-started,"candidatePath":str(CANDIDATE),
  "candidateSHA256":sha(CANDIDATE) if CANDIDATE.is_file() else None,
  "physical_admission":False,"simulation_steps":0}
 (OUT/"failure-witness.json").write_text(json.dumps(failure,indent=2,sort_keys=True)+"\n")
 print(json.dumps(failure,indent=2),flush=True)
 raise
